<?php
/**
 * joma-bridge.php — پل ساخت خودکار کاربری جوما (این فایل در سایت جوما نصب می‌شود)
 * ---------------------------------------------------------------------------------
 * ساخته‌شده برای سامانهٔ آزمون‌های میربلوکی — v1.1 (همراه اصلاح 1.3.8j)
 * v1.1: نمایش پیام خطای واقعی به‌جای صفحهٔ سفید ۵۰۰ + پرکردن خودکار ستون‌های
 *       اجباریِ بدون پیش‌فرض جدول کاربران + سازگاری با هاست‌های بدون mysqlnd
 *
 * کارها:
 *   ۱) این فایل را در پوشهٔ اصلی جوما (کنار index.php یا config جوما) بگذارید.
 *   ۲) آدرس آن را در مرورگر باز کنید → صفحهٔ راه‌اندازی قدم‌به‌قدم باز می‌شود:
 *      اتصال دیتابیس → جدول/ستون‌های کاربران → نوع رمز → کاربر آزمایشی
 *      → تست ورود دستی شما → فعال‌سازی و نمایش «کلید امنیتی»
 *   ۳) کلید + آدرس این فایل + آدرس ورود جوما را در پنل آزمون (اشتراک‌های جوما) وارد کنید.
 *
 * پس از فعال‌سازی فقط به درخواست‌های امضاشده با کلید جواب می‌دهد:
 *   POST JSON: {key, action:'ping'}
 *   POST JSON: {key, action:'create_user', username, password, email?, full_name?, mobile?}
 *   POST JSON: {key, action:'delete_user', username}
 *
 * برای تنظیم مجدد: فایل joma-bridge-config.php را از این پوشه حذف کنید.
 * سازگار PHP 7.x — بدون وابستگی.
 */

error_reporting(0);
ini_set('display_errors', '0');
header('Content-Type: text/html; charset=utf-8');

$__config_file = __DIR__ . '/joma-bridge-config.php';
$__is_setup = !file_exists($__config_file);

// ───────────────────────── ابزارهای مشترک ─────────────────────────
function jb_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function jb_json($arr) { header('Content-Type: application/json; charset=utf-8'); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
function jb_post($k, $d = '') { return isset($_POST[$k]) ? trim((string)$_POST[$k]) : $d; }
function jb_page($title, $body_html, $err = '', $ok = '') {
    $e = $err !== '' ? '<div style="background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:0.9rem;line-height:1.9;">⚠️ ' . jb_h($err) . '</div>' : '';
    $o = $ok !== '' ? '<div style="background:#ecfdf5;border:1px solid #6ee7b7;color:#065f46;border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:0.9rem;line-height:1.9;">✅ ' . jb_h($ok) . '</div>' : '';
    echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . jb_h($title) . '</title></head>'
       . '<body style="font-family:Tahoma,Arial;background:#f1f5f9;margin:0;padding:24px 12px;">'
       . '<div style="max-width:640px;margin:0 auto;background:#fff;border-radius:16px;padding:26px 28px;box-shadow:0 2px 10px rgba(0,0,0,.07);">'
       . '<div style="font-size:1.15rem;font-weight:800;color:#0f172a;margin-bottom:4px;">🤝 پل جوما ⇄ سامانهٔ آزمون میربلوکی</div>'
       . '<div style="color:#64748b;font-size:0.85rem;margin-bottom:18px;">' . jb_h($title) . ' — PHP ' . PHP_VERSION . '</div>'
       . $e . $o . $body_html . '</div></body></html>';
    exit;
}
function jb_field($label, $name, $val = '', $type = 'text', $dir = 'ltr', $req = true, $hint = '') {
    return '<div><label style="display:block;font-size:0.83rem;color:#334155;margin-bottom:4px;">' . jb_h($label) . '</label>'
         . '<input type="' . $type . '" name="' . jb_h($name) . '" value="' . jb_h($val) . '" dir="' . $dir . '"'
         . ($req ? ' required' : '') . ' style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:9px;font-size:0.9rem;' . ($dir === 'ltr' ? 'text-align:left;' : '') . '">'
         . ($hint !== '' ? '<div style="font-size:0.75rem;color:#94a3b8;margin-top:3px;">' . jb_h($hint) . '</div>' : '') . '</div>';
}
function jb_button($t) { return '<button type="submit" style="background:#0f766e;color:#fff;border:none;border-radius:9px;padding:10px 22px;font-size:0.92rem;font-weight:800;cursor:pointer;justify-self:start;">' . jb_h($t) . '</button>'; }
function jb_back($step) { return '<form method="POST" style="margin-top:8px;"><input type="hidden" name="step" value="' . jb_h($step) . '">' . jb_button('بازگشت') . '</form>'; }

/** کشف خودکار تنظیمات دیتابیس جوما از فایل‌های رایج */
function jb_detect_db() {
    $cands = array('wp-config.php', 'config.php', 'configuration.php', 'db.php', 'database.php',
                   'includes/config.php', 'includes/db.php', 'inc/config.php', 'app/config/database.php',
                   'system/config.php', 'connect.php', 'includes/connect.php');
    $found = array('host' => '', 'name' => '', 'user' => '', 'pass' => '');
    foreach ($cands as $f) {
        $p = __DIR__ . '/' . $f;
        if (!file_exists($p)) { continue; }
        $src = @file_get_contents($p);
        if ($src === false) { continue; }
        $get = function($name) use ($src) {
            if (preg_match("/'\\s*" . $name . "\\s*'\\s*,\\s*'([^']*)'/", $src, $m)) { return $m[1]; }
            if (preg_match('/"\\s*' . $name . '\\s*"\\s*,\\s*"([^"]*)"/', $src, $m)) { return $m[1]; }
            return null;
        };
        $h = $get('DB_HOST'); $n = $get('DB_NAME'); $u = $get('DB_USER'); $p2 = $get('DB_PASSWORD');
        if ($n !== null) {
            $found['name'] = (string)$n;
            $found['host'] = ($h !== null && $h !== '') ? $h : 'localhost';
            $found['user'] = (string)$u; $found['pass'] = (string)$p2;
            break;
        }
    }
    return $found;
}

function jb_hash_password($pass, $algo) {
    switch ($algo) {
        case 'md5': return md5($pass);
        case 'sha1': return sha1($pass);
        case 'sha256': return hash('sha256', $pass);
        case 'md5md5': return md5(md5($pass));
        case 'plain': return $pass;
        case 'bcrypt':
        default: return password_hash($pass, PASSWORD_BCRYPT);
    }
}

/** v1.1 — ستون‌های اجباریِ بدون پیش‌فرض جدول را با مقدار امن پر می‌کند */
function jb_required_fill($db, $table, $skip) {
    $fill = array();
    $t = str_replace('`', '', (string)$table);
    $res = @$db->query("SHOW COLUMNS FROM `{$t}`");
    if (!$res) { return $fill; }
    while ($r = $res->fetch_assoc()) {
        $field = (string)$r['Field'];
        if (strpos((string)$r['Extra'], 'auto_increment') !== false) { continue; }
        if (($r['Null']) !== 'NO') { continue; }
        if (array_key_exists('Default', $r) && $r['Default'] !== null) { continue; }
        if (in_array($field, $skip, true)) { continue; }
        $type = strtolower((string)$r['Type']);
        if (strpos($type, 'enum') === 0) {
            if (preg_match("/'([^']*)'/", $type, $m)) { $fill[$field] = $m[1]; }
            continue;
        }
        if (strpos($type, 'int') !== false || strpos($type, 'decimal') !== false || strpos($type, 'float') !== false || strpos($type, 'double') !== false) { $fill[$field] = 0; continue; }
        if (strpos($type, 'date') !== false) { $fill[$field] = (strpos($type, 'timestamp') !== false || strpos($type, 'datetime') !== false) ? date('Y-m-d H:i:s') : date('Y-m-d'); continue; }
        $fill[$field] = 'bridge';
    }
    return $fill;
}

/** v1.1 — درج امن: با پرکردن ستون‌های اجباری؛ پیام خطای خوانا در صورت شکست */
function jb_insert_row($db, $table, $user_cols, &$errmsg) {
    $errmsg = '';
    $t = str_replace('`', '', (string)$table);
    $fill = jb_required_fill($db, $t, array_keys($user_cols));
    $cols = array_merge($fill, $user_cols);
    $names = '`' . implode('`,`', array_keys($cols)) . '`';
    $qs = implode(',', array_fill(0, count($cols), '?'));
    $types = str_repeat('s', count($cols));
    $vals = array_values($cols);
    $st = @$db->prepare("INSERT INTO `{$t}` ($names) VALUES ($qs)");
    if ($st === false) { $errmsg = 'آماده‌سازی درج ناموفق: ' . $db->error; return false; }
    $bound = array($types);
    foreach ($vals as $k => $v) { $bound[] = &$vals[$k]; }
    if (!call_user_func_array(array($st, 'bind_param'), $bound)) { $errmsg = 'bind_param ناموفق.'; return false; }
    if (!@$st->execute()) { $errmsg = 'درج ناموفق: ' . (method_exists($st, 'error') ? $st->error : $db->error); return false; }
    return true;
}

try {

// ───────────────────────── حالت عملیاتی (پیکربندی‌شده) ─────────────────────────
if (!$__is_setup) {
    if (!class_exists('mysqli')) { jb_json(array('success' => false, 'message' => 'افزونهٔ mysqli روی این هاست فعال نیست.')); }
    $cfg = include $__config_file;
    if (!is_array($cfg)) { jb_json(array('success' => false, 'message' => 'config corrupt')); }
    $raw = file_get_contents('php://input');
    $in = json_decode($raw, true);
    if (!is_array($in)) { $in = $_POST; }
    $key = isset($in['key']) ? trim((string)$in['key']) : '';
    if ($key === '' || !hash_equals((string)$cfg['key'], $key)) {
        jb_json(array('success' => false, 'message' => 'کلید امنیتی نامعتبر است.'));
    }
    $action = isset($in['action']) ? (string)$in['action'] : '';
    $db = @new mysqli($cfg['db_host'], $cfg['db_user'], $cfg['db_pass'], $cfg['db_name']);
    if ($db->connect_error) { jb_json(array('success' => false, 'message' => 'اتصال دیتابیس جوما برقرار نشد.')); }
    $db->set_charset('utf8mb4');

    if ($action === 'ping') {
        jb_json(array('success' => true, 'message' => 'پل فعال است', 'joma_name' => (string)$cfg['joma_name']));
    }

    if ($action === 'create_user') {
        $username = isset($in['username']) ? trim((string)$in['username']) : '';
        $password = isset($in['password']) ? (string)$in['password'] : '';
        $email = isset($in['email']) ? trim((string)$in['email']) : '';
        $full = isset($in['full_name']) ? trim((string)$in['full_name']) : '';
        $mobile = isset($in['mobile']) ? trim((string)$in['mobile']) : '';
        if (!preg_match('/^[A-Za-z][A-Za-z0-9._]{2,31}$/', $username)) {
            jb_json(array('success' => false, 'message' => 'نام‌کاربری نامعتبر است.'));
        }
        if (mb_strlen($password) < 6) { jb_json(array('success' => false, 'message' => 'رمز کوتاه است.')); }
        // تکراری؟ → موفق (idempotent) — بدون وابستگی به mysqlnd
        $st = @$db->prepare('SELECT `' . $cfg['col_id'] . '` FROM `' . $cfg['table'] . '` WHERE `' . $cfg['col_user'] . '` = ? LIMIT 1');
        if ($st === false) { jb_json(array('success' => false, 'message' => 'کوئری ناموفق: ' . $db->error)); }
        $u0 = $username;
        $st->bind_param('s', $u0);
        $st->execute();
        $st->store_result();
        $exists = $st->num_rows > 0;
        $st->close();
        if ($exists) { jb_json(array('success' => true, 'message' => 'کاربر از قبل موجود بود.', 'existed' => true)); }
        $hash = jb_hash_password($password, $cfg['hash']);
        $cols = array($cfg['col_user'] => $username, $cfg['col_pass'] => $hash);
        if (!empty($cfg['col_email']) && $email !== '') { $cols[$cfg['col_email']] = $email; }
        if (!empty($cfg['col_full']) && $full !== '') { $cols[$cfg['col_full']] = $full; }
        if (!empty($cfg['col_mobile']) && $mobile !== '') { $cols[$cfg['col_mobile']] = $mobile; }
        $errmsg = '';
        if (!jb_insert_row($db, $cfg['table'], $cols, $errmsg)) {
            jb_json(array('success' => false, 'message' => 'درج در دیتابیس جوما ناموفق: ' . $errmsg));
        }
        jb_json(array('success' => true, 'message' => 'کاربر ساخته شد.', 'existed' => false));
    }

    if ($action === 'delete_user') {
        $username = isset($in['username']) ? trim((string)$in['username']) : '';
        $st = @$db->prepare('DELETE FROM `' . $cfg['table'] . '` WHERE `' . $cfg['col_user'] . '` = ? LIMIT 1');
        $u0 = $username;
        $st->bind_param('s', $u0);
        $st->execute();
        jb_json(array('success' => true, 'message' => 'انجام شد.'));
    }

    jb_json(array('success' => false, 'message' => 'اکشن نامشخص.'));
}

// ───────────────────────── صفحهٔ راه‌اندازی ─────────────────────────
if (!class_exists('mysqli')) {
    jb_page('خطا', '<div style="color:#991b1b;">افزونهٔ mysqli روی این هاست فعال نیست. از پشتیبانی هاست بخواهید فعالش کند.</div>');
}
$detected = jb_detect_db();
$step = jb_post('step', 'db');
$err = ''; $okmsg = '';

if ($step === 'db') {
    $body = '<form method="POST" style="display:grid;gap:12px;">'
        . '<input type="hidden" name="step" value="table">'
        . jb_field('هاست دیتابیس جوما (معمولاً localhost)', 'db_host', $detected['host'] !== '' ? $detected['host'] : 'localhost')
        . jb_field('نام دیتابیس جوما', 'db_name', $detected['name'])
        . jb_field('کاربر دیتابیس', 'db_user', $detected['user'])
        . jb_field('رمز دیتابیس', 'db_pass', $detected['pass'], 'password')
        . '<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:9px;padding:9px 12px;font-size:0.78rem;color:#92400e;line-height:1.8;">'
        . 'این اطلاعات داخل فایل config جوما هست (یا از برنامه‌نویس جوما بپرسید).' . ($detected['name'] !== '' ? ' ✅ از فایل‌های جوما به‌صورت خودکار پیشنهاد شد.' : '') . '</div>'
        . jb_button('اتصال و انتخاب جدول کاربران') . '</form>';
    jb_page('قدم ۱ از ۳ — اتصال به دیتابیس جوما', $body);
}

if ($step === 'table') {
    $h = jb_post('db_host', 'localhost'); $n = jb_post('db_name'); $u = jb_post('db_user'); $p = jb_post('db_pass');
    $db = @new mysqli($h, $u, $p, $n);
    if ($db->connect_error) { jb_page('قدم ۱ از ۳', jb_back('db'), 'اتصال برقرار نشد: ' . $db->connect_error); }
    $db->set_charset('utf8mb4');
    $tables = array(); $res = @$db->query('SHOW TABLES');
    if ($res === false) { jb_page('قدم ۱ از ۳', jb_back('db'), 'خواندن جدول‌ها ناموفق: ' . $db->error); }
    while ($r = $res->fetch_row()) {
        if (preg_match('/user|member|customer|account|client/i', $r[0])) { $tables[] = $r[0]; }
    }
    if (empty($tables)) { $res2 = @$db->query('SHOW TABLES'); while ($r2 = $res2->fetch_row()) { $tables[] = $r2[0]; } }
    $opts = '';
    $chosen = jb_post('table', '');
    foreach ($tables as $t) { $opts .= '<option value="' . jb_h($t) . '"' . ($t === $chosen ? ' selected' : '') . '>' . jb_h($t) . '</option>'; }
    $hidden = '<input type="hidden" name="step" value="columns">'
        . '<input type="hidden" name="db_host" value="' . jb_h($h) . '"><input type="hidden" name="db_name" value="' . jb_h($n) . '">'
        . '<input type="hidden" name="db_user" value="' . jb_h($u) . '"><input type="hidden" name="db_pass" value="' . jb_h($p) . '">';
    $body = '<form method="POST" style="display:grid;gap:12px;">' . $hidden
        . '<div><label style="display:block;font-size:0.83rem;color:#334155;margin-bottom:4px;">جدول کاربران جوما</label>'
        . '<select name="table" onchange="this.form.submit()" style="width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:9px;">' . $opts . '</select></div>'
        . '<div style="font-size:0.78rem;color:#94a3b8;">جدول را انتخاب کنید تا ستون‌ها نمایش داده شود.</div>'
        . jb_button('ادامه — تنظیم ستون‌ها') . '</form>' . jb_back('db');
    jb_page('قدم ۲ از ۳ — جدول کاربران', $body);
}

if ($step === 'columns') {
    $h = jb_post('db_host'); $n = jb_post('db_name'); $u = jb_post('db_user'); $p = jb_post('db_pass'); $t = jb_post('table');
    $db = @new mysqli($h, $u, $p, $n);
    if ($db->connect_error) { jb_page('قدم ۲ از ۳', jb_back('db'), 'اتصال برقرار نشد.'); }
    $db->set_charset('utf8mb4');
    $cols = array(); $res = @$db->query('SHOW COLUMNS FROM `' . str_replace('`', '', $t) . '`');
    if ($res === false) { jb_page('قدم ۲ از ۳', jb_back('table'), 'خواندن ستون‌ها ناموفق: ' . $db->error); }
    while ($r = $res->fetch_assoc()) { $cols[] = $r['Field']; }
    $guess_user = ''; $guess_pass = ''; $guess_email = '';
    foreach ($cols as $c) {
        if ($guess_user === '' && preg_match('/user(name)?|login|email|mobile|phone/i', $c)) { $guess_user = $c; }
        if ($guess_pass === '' && preg_match('/pass|pwd|secret/i', $c)) { $guess_pass = $c; }
        if ($guess_email === '' && preg_match('/mail/i', $c)) { $guess_email = $c; }
    }
    $sel = function($name, $label, $cols, $guess, $req = true) {
        $o = $req ? '' : '<option value="">— ندارد —</option>';
        foreach ($cols as $c) { $o .= '<option value="' . jb_h($c) . '"' . ($c === $guess ? ' selected' : '') . '>' . jb_h($c) . '</option>'; }
        return '<div><label style="display:block;font-size:0.83rem;color:#334155;margin-bottom:4px;">' . jb_h($label) . '</label>'
             . '<select name="' . jb_h($name) . '" style="width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:9px;">' . $o . '</select></div>';
    };
    $hidden = '<input type="hidden" name="step" value="test"><input type="hidden" name="db_host" value="' . jb_h($h) . '">'
        . '<input type="hidden" name="db_name" value="' . jb_h($n) . '"><input type="hidden" name="db_user" value="' . jb_h($u) . '">'
        . '<input type="hidden" name="db_pass" value="' . jb_h($p) . '"><input type="hidden" name="table" value="' . jb_h($t) . '">';
    $body = '<div style="font-size:0.85rem;color:#334155;margin-bottom:10px;">جدول انتخابی: <strong dir="ltr">' . jb_h($t) . '</strong></div>'
        . '<form method="POST" style="display:grid;gap:12px;">' . $hidden
        . $sel('col_id', 'ستون شناسه (ID)', $cols, (in_array('id', $cols, true) ? 'id' : $cols[0]))
        . $sel('col_user', 'ستون نام‌کاربری', $cols, $guess_user)
        . $sel('col_pass', 'ستون رمز عبور', $cols, $guess_pass)
        . $sel('col_email', 'ستون ایمیل (اختیاری)', $cols, $guess_email, false)
        . $sel('col_full', 'ستون نام کامل (اختیاری)', $cols, '', false)
        . $sel('col_mobile', 'ستون موبایل (اختیاری)', $cols, '', false)
        . '<div><label style="display:block;font-size:0.83rem;color:#334155;margin-bottom:4px;">نوع ذخیرهٔ رمز در جوما</label>'
        . '<select name="hash" style="width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:9px;">'
        . '<option value="bcrypt">استاندارد امن PHP — password_hash (bcrypt)</option>'
        . '<option value="md5">MD5</option><option value="sha1">SHA1</option><option value="sha256">SHA256</option>'
        . '<option value="md5md5">MD5 دوبل</option><option value="plain">بدون رمزنگاری</option></select>'
        . '<div style="font-size:0.75rem;color:#94a3b8;margin-top:3px;">نمی‌دانید؟ پیش‌فرض بگذارید؛ در قدم بعد با تست ورود مطمئن می‌شویم.</div></div>'
        . jb_field('نمایشی/شناسهٔ جوما (اختیاری، برای پیام تست)', 'joma_name', 'جوما', 'text', 'rtl', false)
        . jb_button('ساخت کاربر آزمایشی') . '</form>';
    jb_page('قدم ۲ از ۳ — ستون‌ها و نوع رمز', $body);
}

if ($step === 'test') {
    $h = jb_post('db_host'); $n = jb_post('db_name'); $u = jb_post('db_user'); $p = jb_post('db_pass');
    $t = jb_post('table'); $ci = jb_post('col_id', 'id'); $cu = jb_post('col_user'); $cp = jb_post('col_pass');
    $ce = jb_post('col_email'); $cf = jb_post('col_full'); $cm = jb_post('col_mobile');
    $hash = jb_post('hash', 'bcrypt'); $jn = jb_post('joma_name', 'جوما');
    $db = @new mysqli($h, $u, $p, $n);
    if ($db->connect_error) { jb_page('قدم ۳ از ۳', jb_back('columns'), 'اتصال برقرار نشد: ' . $db->connect_error); }
    $db->set_charset('utf8mb4');
    $test_user = 'bridgetest_' . substr(bin2hex(@random_bytes(3)), 0, 5);
    $test_pass = 'Test123!';
    $hashval = jb_hash_password($test_pass, $hash);
    $cols = array($cu => $test_user, $cp => $hashval);
    if ($ce !== '') { $cols[$ce] = 'bridgetest_' . substr(md5(uniqid('', true)), 0, 8) . '@example.com'; }
    if ($cf !== '') { $cols[$cf] = 'تست پل'; }
    $errmsg = '';
    if (!jb_insert_row($db, $t, $cols, $errmsg)) {
        // v1.1 — خطای واقعی نشان داده می‌شود؛ دیگر صفحهٔ سفید ۵۰۰ نیست
        $hidden = '<input type="hidden" name="step" value="columns">'
            . '<input type="hidden" name="db_host" value="' . jb_h($h) . '"><input type="hidden" name="db_name" value="' . jb_h($n) . '">'
            . '<input type="hidden" name="db_user" value="' . jb_h($u) . '"><input type="hidden" name="db_pass" value="' . jb_h($p) . '">'
            . '<input type="hidden" name="table" value="' . jb_h($t) . '">';
        jb_page('قدم ۳ از ۳ — خطا', $hidden . jb_button('بازگشت به تنظیم ستون‌ها'),
            'ساخت کاربر آزمایشی ناموفق بود: ' . $errmsg . ' — اگر علت روشن نیست، از همین جدول دیگری انتخاب کنید یا متن این پیام را برای پشتیبان سامانهٔ آزمون بفرستید.');
    }
    $hidden = '<input type="hidden" name="step" value="save">'
        . '<input type="hidden" name="db_host" value="' . jb_h($h) . '"><input type="hidden" name="db_name" value="' . jb_h($n) . '">'
        . '<input type="hidden" name="db_user" value="' . jb_h($u) . '"><input type="hidden" name="db_pass" value="' . jb_h($p) . '">'
        . '<input type="hidden" name="table" value="' . jb_h($t) . '"><input type="hidden" name="col_id" value="' . jb_h($ci) . '">'
        . '<input type="hidden" name="col_user" value="' . jb_h($cu) . '"><input type="hidden" name="col_pass" value="' . jb_h($cp) . '">'
        . '<input type="hidden" name="col_email" value="' . jb_h($ce) . '"><input type="hidden" name="col_full" value="' . jb_h($cf) . '">'
        . '<input type="hidden" name="col_mobile" value="' . jb_h($cm) . '"><input type="hidden" name="hash" value="' . jb_h($hash) . '">'
        . '<input type="hidden" name="joma_name" value="' . jb_h($jn) . '"><input type="hidden" name="test_user" value="' . jb_h($test_user) . '">';
    $body = '<div style="background:#eff6ff;border:1px solid #93c5fd;border-radius:10px;padding:14px 16px;font-size:0.9rem;color:#1e40af;line-height:2.1;margin-bottom:14px;">'
        . 'کاربر آزمایشی ساخته شد ✅<br>نام‌کاربری: <strong dir="ltr">' . jb_h($test_user) . '</strong><br>رمز: <strong dir="ltr">' . jb_h($test_pass) . '</strong><br>'
        . '<strong>حالا وارد سایت جوما شوید و با این اطلاعات تست کنید که ورود کار می‌کند.</strong><br>'
        . 'اگر ورود ناموفق بود، «بازگشت» را بزنید و نوع دیگری از «نوع ذخیرهٔ رمز» را امتحان کنید.</div>'
        . '<form method="POST" style="display:grid;gap:12px;">' . $hidden . jb_button('ورود کار کرد — ذخیره و فعال‌سازی ✅') . '</form>'
        . jb_back('columns');
    jb_page('قدم ۳ از ۳ — تست ورود', $body);
}

if ($step === 'save') {
    $key = bin2hex(@random_bytes(16));
    $cfg = array(
        'key' => $key,
        'db_host' => jb_post('db_host', 'localhost'), 'db_name' => jb_post('db_name'),
        'db_user' => jb_post('db_user'), 'db_pass' => jb_post('db_pass'),
        'table' => jb_post('table'), 'col_id' => jb_post('col_id', 'id'),
        'col_user' => jb_post('col_user'), 'col_pass' => jb_post('col_pass'),
        'col_email' => jb_post('col_email'), 'col_full' => jb_post('col_full'), 'col_mobile' => jb_post('col_mobile'),
        'hash' => jb_post('hash', 'bcrypt'), 'joma_name' => jb_post('joma_name', 'جوما'),
        'created_at' => date('Y-m-d H:i:s')
    );
    $code = "<?php\n// پل جوما — پیکربندی (حذف این فایل = ورود به حالت راه‌اندازی مجدد)\nreturn " . var_export($cfg, true) . ";\n";
    if (@file_put_contents($__config_file, $code, LOCK_EX) === false) {
        jb_page('فعال‌سازی', jb_back('db'), 'نوشتن فایل پیکربندی ناموفق بود — دسترسی پوشه را بررسی کنید.');
    }
    $db = @new mysqli($cfg['db_host'], $cfg['db_user'], $cfg['db_pass'], $cfg['db_name']);
    if (!$db->connect_error) {
        $st = @$db->prepare('DELETE FROM `' . str_replace('`', '', $cfg['table']) . '` WHERE `' . $cfg['col_user'] . '` = ? LIMIT 1');
        $tu = jb_post('test_user'); $st->bind_param('s', $tu); $st->execute();
    }
    $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
    $body = '<div style="background:#ecfdf5;border:1px solid #6ee7b7;border-radius:10px;padding:14px 16px;font-size:0.92rem;color:#065f46;line-height:2.2;margin-bottom:14px;">'
        . '🎉 پل فعال شد! حالا در پنل آزمون (اشتراک‌های جوما → تنظیمات پل) این سه مقدار را وارد کنید:<br>'
        . '۱) آدرس صفحهٔ ورود جوما<br>۲) آدرس همین فایل: <strong dir="ltr">' . jb_h($url) . '</strong><br>'
        . '۳) کلید امنیتی: <strong dir="ltr" style="font-size:1.05rem;user-select:all;">' . jb_h($key) . '</strong></div>';
    jb_page('فعال شد ✅', $body);
}

jb_page('راه‌اندازی', '<form method="POST"><input type="hidden" name="step" value="db">' . jb_button('شروع راه‌اندازی') . '</form>');

} catch (Throwable $e) {
    // v1.1 — هیچ خطایی دیگر صفحهٔ سفید ۵۰۰ نمی‌سازد
    $msg = $e->getMessage();
    if (!$__is_setup) { jb_json(array('success' => false, 'message' => 'خطای پل: ' . $msg)); }
    jb_page('خطای غیرمنتظره', jb_back('db'), $msg . ' — این متن را برای پشتیبان سامانهٔ آزمون بفرستید.');
}
