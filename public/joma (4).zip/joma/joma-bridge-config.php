<?php
// پل جوما — پیکربندی (حذف این فایل = ورود به حالت راه‌اندازی مجدد)
return array (
  'key' => 'd21af6d405a7f6c93fadea189c5d7d96',
  'db_host' => 'localhost',
  'db_name' => 'mirbolouki_joma',
  'db_user' => 'mirbolouki_jomausr',
  'db_pass' => 'MCQWI*AvOkl4Bt1)',
  'table' => 'joma_users',
  'col_id' => 'id',
  'col_user' => 'username',
  'col_pass' => 'password_hash',
  'col_email' => 'email',
  'col_full' => 'first_name',
  'col_mobile' => 'phone',
  'hash' => 'bcrypt',
  'joma_name' => 'جوما',
  'created_at' => '2026-10-11 15:25:12',
);
