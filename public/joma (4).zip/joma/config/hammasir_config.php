<?php
// دموی مستقل «هم‌مسیر» — ماژول فعال؛ bootstrap خالی
$HAMMASIR_CONFIG = array(
    'hammasir_enabled' => true,
    'bootstrap_owner_username' => 'm.ch',
    'bootstrap_owner_done' => true,
);
