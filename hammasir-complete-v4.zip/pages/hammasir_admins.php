<?php
/*
 * ماژول «هم‌مسیر» — مدیریت مدیران سیستم (D-ADMIN-2 — حکم PO بخش ۴)
 * ------------------------------------------------------------------
 * فقط از pages/hammasir.php در حالت admin include می‌شود؛ route عمومی ندارد.
 * ارتقا/سلب نقش مدیر فقط از کاربران موجود JOMA (نه یوزر موازی)؛
 * قفل آخرین مدیر در hammasir_user_set_role اعمال می‌شود (Backend).
 * نمایش فقط نام/نام‌کاربری/نقش — بدون ایمیل/موبایل (قانون داده‌ی حساس).
 */

// گارد مستقیم — partial هرگز مستقیماً از وب اجرا نمی‌شود → 403 خشک (AC6.3)
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// گارد دوگانه — فقط ADMIN_ACCESS (گیت دوم؛ گیت اول در صفحه‌ی میزبان است)
if (!function_exists('has_perm') || !has_perm('ADMIN_ACCESS')) {
    return;
}

// خواندن کاربران با مهار خطای PHP 8.1 (D-1)
$hammasir_a_users = array();
try {
    $hammasir_a_users = hammasir_users_list_roles(500);
    if (!is_array($hammasir_a_users)) $hammasir_a_users = array();
} catch (Throwable $e) {
    $hammasir_a_users = array();
}
?>
<section class="card">
  <h2>مدیران سیستم</h2>
  <p>ارتقا یا سلب نقش مدیر برای کاربران موجود جوما. پس از تغییر نقش، آن کاربر باید یک‌بار خارج و وارد شود تا دسترسی جدید اعمال گردد. آخرین مدیر سیستم قابل حذف از مدیریت نیست.</p>
  <?php if (count($hammasir_a_users) === 0) { ?>
    <p>کاربری برای نمایش وجود ندارد.</p>
  <?php } else { ?>
    <?php foreach ($hammasir_a_users as $hammasir_a_u) { ?>
      <?php
      $hammasir_a_name = trim($hammasir_a_u['first_name'] . ' ' . $hammasir_a_u['last_name']);
      $hammasir_a_is_admin = ($hammasir_a_u['role_key'] === 'admin');
      ?>
      <div class="card">
        <div class="btn-row">
          <span class="chip"><?php echo e($hammasir_a_name !== '' ? $hammasir_a_name : $hammasir_a_u['username']); ?></span>
          <span class="chip"><?php echo e($hammasir_a_u['username']); ?></span>
          <span class="chip"><?php echo $hammasir_a_is_admin ? 'مدیر' : 'کاربر'; ?></span>
        </div>
        <div class="btn-row">
          <?php if (!$hammasir_a_is_admin) { ?>
          <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="admin_promote">
            <input type="hidden" name="user_id" value="<?php echo (int) $hammasir_a_u['id']; ?>">
            <button class="btn" type="submit">ارتقا به مدیر</button>
          </form>
          <?php } else { ?>
          <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="admin_demote">
            <input type="hidden" name="user_id" value="<?php echo (int) $hammasir_a_u['id']; ?>">
            <button class="btn sec" type="submit">حذف از مدیریت</button>
          </form>
          <?php } ?>
        </div>
      </div>
    <?php } ?>
  <?php } ?>
</section>
