<?php
/*
 * ماژول «هم‌مسیر» — partial جریان همراه (Phase 3/4)
 * ------------------------------------------------------------------
 * فقط از pages/hammasir.php include می‌شود؛ route عمومی ندارد (D29/D30).
 * متغیر مورد انتظار: $hammasir_me (user_id کاربر جاری — که خودش همراه ثبت‌شده است)
 *
 * درخواست‌های PENDING: «کاربری درخواست کرده شما همراه او باشید.» + قبول/رد (D20)
 * لینک‌های ACTIVE: توگل واحد پیام (D37 — جمله‌ی مصوب) + گفتگو + قطع ارتباط
 * قبل از قبول: فقط اطلاعات درخواست و سطح دسترسی انتخابی — هیچ داده‌ی مراجع (AC2.3/AC3.2)
 */

// گارد مستقیم — partial هرگز مستقیماً از وب اجرا نمی‌شود → 403 خشک (AC6.3)
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// خواندها با مهار خطای PHP 8.1 (D-1): خطا → فهرست خالی
$hammasir_p_pending = array();
$hammasir_p_active = array();
try {
    $hammasir_p_pending = hammasir_links_by_provider($hammasir_me, 'PENDING');
    if (!is_array($hammasir_p_pending)) $hammasir_p_pending = array();
    $hammasir_p_active = hammasir_links_by_provider($hammasir_me, 'ACTIVE');
    if (!is_array($hammasir_p_active)) $hammasir_p_active = array();
} catch (Throwable $e) {
    $hammasir_p_pending = array();
    $hammasir_p_active = array();
}

$hammasir_p_labels = hammasir_perm_view_labels();

// هویت حالت مشاور (5.1): عنوان ثبت‌شده‌ی همراه برای این کاربر
$hammasir_p_row = null;
try {
    $hammasir_p_row = hammasir_provider_by_user_id($hammasir_me);
} catch (Throwable $e) {
    $hammasir_p_row = null;
}
?>
<section class="card">
  <h2>میز کار مشاور</h2>
  <div class="btn-row">
    <span class="chip">حالت مشاور</span>
    <?php if ($hammasir_p_row) { ?><span class="chip"><?php echo e($hammasir_p_row['title']); ?></span><?php } ?>
  </div>
  <?php if (count($hammasir_p_pending) === 0 && count($hammasir_p_active) === 0) { ?>
    <p>در حال حاضر درخواست یا مراجع فعالی ندارید. وقتی مراجعی برای شما درخواست همراهی بفرستد، اینجا می‌بینید.</p>
  <?php } ?>
</section>
<?php if (count($hammasir_p_pending) > 0) { ?>
<section class="card">
  <h2>درخواست‌های همراهی</h2>
  <p>کاربری درخواست کرده شما همراه او باشید.</p>
  <?php foreach ($hammasir_p_pending as $hammasir_p_l) { ?>
    <?php
    $hammasir_p_name = '';
    $hammasir_p_perms = null;
    try {
        $hammasir_p_name = hammasir_user_display((int) $hammasir_p_l['client_user_id']);
        $hammasir_p_perms = hammasir_perm_map((int) $hammasir_p_l['id']);
    } catch (Throwable $e) {
        $hammasir_p_name = '';
        $hammasir_p_perms = null;
    }
    ?>
    <div class="card">
      <div class="btn-row">
        <span class="chip"><?php echo e($hammasir_p_name); ?></span>
      </div>
      <p><?php echo e(hammasir_consent_text()); ?></p>
      <label>سطح دسترسی درخواست‌شده</label>
      <div class="btn-row">
        <?php foreach (array('VIEW_SUMMARY', 'VIEW_PROGRESS', 'VIEW_ACTIVITY_DETAILS', 'VIEW_MOOD') as $hammasir_p_k) { ?>
          <?php $hammasir_p_on = ($hammasir_p_perms !== null && isset($hammasir_p_perms[$hammasir_p_k]) && (int) $hammasir_p_perms[$hammasir_p_k] === 1); ?>
          <span class="chip"><?php echo e($hammasir_p_labels[$hammasir_p_k] . ($hammasir_p_on ? ' ✓' : ' ✗')); ?></span>
        <?php } ?>
      </div>
      <div class="btn-row">
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="hammasir_action" value="link_accept">
          <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
          <button class="btn" type="submit">قبول</button>
        </form>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="hammasir_action" value="link_decline">
          <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
          <button class="btn sec" type="submit">رد</button>
        </form>
      </div>
    </div>
  <?php } ?>
</section>
<?php } ?>
<?php if (count($hammasir_p_active) > 0) { ?>
<section class="card">
  <h2>همراهی‌های فعال شما</h2>
  <?php foreach ($hammasir_p_active as $hammasir_p_l) { ?>
    <?php
    $hammasir_p_name = '';
    $hammasir_p_msg_on = false;
    try {
        $hammasir_p_name = hammasir_user_display((int) $hammasir_p_l['client_user_id']);
        $hammasir_p_msg_on = (hammasir_messaging_enabled((int) $hammasir_p_l['id']) === true);
    } catch (Throwable $e) {
        $hammasir_p_name = '';
        $hammasir_p_msg_on = false;
    }
    ?>
    <div class="card">
      <div class="btn-row">
        <span class="chip"><?php echo e($hammasir_p_name); ?></span>
      </div>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="messaging_set">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
        <input type="hidden" name="enabled" value="<?php echo $hammasir_p_msg_on ? '0' : '1'; ?>">
        <label>مایل هستم از این مراجع پیام دریافت کنم.</label>
        <div class="btn-row">
          <button class="btn sec" type="submit"><?php echo $hammasir_p_msg_on ? 'غیرفعال‌سازی پیام‌رسانی' : 'فعال‌سازی پیام‌رسانی'; ?></button>
        </div>
      </form>
      <?php if ($hammasir_p_msg_on) { ?>
        <?php
        $hammasir_link = $hammasir_p_l;
        $hammasir_other_label = $hammasir_p_name;
        $hammasir_msg_on = true;
        include dirname(__FILE__) . '/hammasir_chat.php';
        ?>
      <?php } ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="link_revoke">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
        <div class="btn-row">
          <button class="btn sec" type="submit">قطع ارتباط</button>
        </div>
      </form>
      <?php
      // ----- پرونده‌ی مراجع (5.1): فقط بخش‌های مجازِ همین لینک؛ بدون مجوز = بدون نمایش -----
      $hammasir_p_perms = null;
      try {
          $hammasir_p_perms = hammasir_perm_map((int) $hammasir_p_l['id']);
      } catch (Throwable $e) {
          $hammasir_p_perms = null;
      }
      $hammasir_p_on = array(
          'VIEW_SUMMARY' => ($hammasir_p_perms !== null && isset($hammasir_p_perms['VIEW_SUMMARY']) && (int) $hammasir_p_perms['VIEW_SUMMARY'] === 1),
          'VIEW_PROGRESS' => ($hammasir_p_perms !== null && isset($hammasir_p_perms['VIEW_PROGRESS']) && (int) $hammasir_p_perms['VIEW_PROGRESS'] === 1),
          'VIEW_ACTIVITY_DETAILS' => ($hammasir_p_perms !== null && isset($hammasir_p_perms['VIEW_ACTIVITY_DETAILS']) && (int) $hammasir_p_perms['VIEW_ACTIVITY_DETAILS'] === 1),
          'VIEW_MOOD' => ($hammasir_p_perms !== null && isset($hammasir_p_perms['VIEW_MOOD']) && (int) $hammasir_p_perms['VIEW_MOOD'] === 1),
      );
      if ($hammasir_p_on['VIEW_SUMMARY'] || $hammasir_p_on['VIEW_PROGRESS'] || $hammasir_p_on['VIEW_ACTIVITY_DETAILS'] || $hammasir_p_on['VIEW_MOOD']) {
          ?>
          <h3>پرونده مراجع</h3>
          <?php if ($hammasir_p_on['VIEW_SUMMARY']) {
              $hammasir_p_dto = null;
              try { $hammasir_p_dto = hammasir_dto_summary((int) $hammasir_p_l['client_user_id']); } catch (Throwable $e) { $hammasir_p_dto = null; }
              ?>
              <?php if ($hammasir_p_dto !== null) { ?>
              <div class="btn-row">
                <span class="chip">دوره: <?php echo e(jalali_period_label($hammasir_p_dto['period_key'])); ?></span>
                <span class="chip">وضعیت برنامه: <?php echo e($hammasir_p_dto['plan_status']); ?></span>
                <span class="chip">فعالیت‌ها: <?php echo (int) $hammasir_p_dto['activity_count']; ?></span>
                <span class="chip">رویدادهای ثبت‌شده: <?php echo (int) $hammasir_p_dto['event_count']; ?></span>
                <span class="chip">جمع وزن‌ها: <?php echo (int) $hammasir_p_dto['weight_sum']; ?></span>
                <span class="chip">روزهای ثبت‌شده: <?php echo (int) $hammasir_p_dto['days_with_events']; ?></span>
              </div>
              <?php } else { ?>
              <p>هنوز برنامه‌ای برای نمایش وجود ندارد.</p>
              <?php } ?>
          <?php } ?>
          <?php if ($hammasir_p_on['VIEW_PROGRESS']) {
              $hammasir_p_dto = null;
              try { $hammasir_p_dto = hammasir_dto_progress((int) $hammasir_p_l['client_user_id']); } catch (Throwable $e) { $hammasir_p_dto = null; }
              ?>
              <?php if ($hammasir_p_dto !== null && (count($hammasir_p_dto['activities']) > 0 || $hammasir_p_dto['overall_coverage'] !== null)) { ?>
              <div class="btn-row">
                <?php if ($hammasir_p_dto['overall_coverage'] !== null) { ?><span class="chip">پوشش کل: <?php echo e(round((float) $hammasir_p_dto['overall_coverage'] * 100) . '٪'); ?></span><?php } ?>
                <?php if ($hammasir_p_dto['overall_success'] !== '') { ?><span class="chip">وضعیت کلی: <?php echo e(hammasir_achievement_label($hammasir_p_dto['overall_success'])); ?></span><?php } ?>
              </div>
              <?php foreach ($hammasir_p_dto['activities'] as $hammasir_p_a) { ?>
              <div class="btn-row">
                <span class="chip"><?php echo e($hammasir_p_a['title']); ?></span>
                <?php if ($hammasir_p_a['coverage'] !== null) { ?><span class="chip"><?php echo e(round((float) $hammasir_p_a['coverage'] * 100) . '٪'); ?></span><?php } ?>
                <span class="chip"><?php echo e(hammasir_achievement_label($hammasir_p_a['achievement'])); ?></span>
              </div>
              <?php } ?>
              <?php } else { ?>
              <p>داده‌ی پیشرفت برای نمایش وجود ندارد.</p>
              <?php } ?>
          <?php } ?>
          <?php if ($hammasir_p_on['VIEW_ACTIVITY_DETAILS']) {
              $hammasir_p_dto = null;
              try { $hammasir_p_dto = hammasir_dto_activity_details((int) $hammasir_p_l['client_user_id']); } catch (Throwable $e) { $hammasir_p_dto = null; }
              ?>
              <?php if ($hammasir_p_dto !== null) { ?>
                <?php if (count($hammasir_p_dto['activities']) > 0) { ?>
                <h4>فعالیت‌های برنامه</h4>
                <?php foreach ($hammasir_p_dto['activities'] as $hammasir_p_a) { ?>
                <div class="btn-row">
                  <span class="chip"><?php echo e($hammasir_p_a['title']); ?></span>
                  <span class="chip">هدف: <?php echo e($hammasir_p_a['target'] . ' ' . $hammasir_p_a['unit']); ?></span>
                </div>
                <?php } ?>
                <?php } ?>
                <?php if (count($hammasir_p_dto['events']) > 0) { ?>
                <h4>آخرین ثبت‌ها</h4>
                <?php foreach ($hammasir_p_dto['events'] as $hammasir_p_e) { ?>
                <div class="btn-row">
                  <span class="chip"><?php echo e(jalali_format($hammasir_p_e['date'])); ?></span>
                  <span><?php echo e($hammasir_p_e['title'] . ': ' . $hammasir_p_e['value'] . ' ' . $hammasir_p_e['unit']); ?></span>
                </div>
                <?php } ?>
                <?php } ?>
                <?php if (count($hammasir_p_dto['activities']) === 0 && count($hammasir_p_dto['events']) === 0) { ?>
                <p>هنوز فعالیتی ثبت نشده است.</p>
                <?php } ?>
              <?php } ?>
          <?php } ?>
          <?php if ($hammasir_p_on['VIEW_MOOD']) {
              $hammasir_p_dto = null;
              try { $hammasir_p_dto = hammasir_dto_mood((int) $hammasir_p_l['client_user_id']); } catch (Throwable $e) { $hammasir_p_dto = null; }
              ?>
              <?php if (is_array($hammasir_p_dto) && count($hammasir_p_dto) > 0) { ?>
              <h4>حال و احوال (۳۰ روز اخیر)</h4>
              <?php foreach ($hammasir_p_dto as $hammasir_p_m) { ?>
              <div class="btn-row">
                <span class="chip"><?php echo e(jalali_format($hammasir_p_m['date'])); ?></span>
                <span>حال کلی: <?php echo e((string) $hammasir_p_m['general_mood']); ?> — انرژی: <?php echo e((string) $hammasir_p_m['energy']); ?> — استرس: <?php echo e((string) $hammasir_p_m['stress']); ?></span>
                <?php if ($hammasir_p_m['note'] !== '') { ?><small><?php echo e($hammasir_p_m['note']); ?></small><?php } ?>
              </div>
              <?php } ?>
              <?php } else { ?>
              <p>حال و احوالی ثبت نشده است.</p>
              <?php } ?>
          <?php } ?>
          <?php
      }
      ?>
    </div>
  <?php } ?>
</section>
<?php } ?>
