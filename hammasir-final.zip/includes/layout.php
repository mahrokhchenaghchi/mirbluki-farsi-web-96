<?php
function joma_header($title, $crumbs = array(), $opts = array()) {
    $u = current_user();
    $page = isset($_GET['p']) ? $_GET['p'] : 'home';
    $compact = false;
    $prefs = array();
    if ($u) {
        $prefs = get_prefs($u['id']);
        $compact = !empty($prefs['compact_cards']);
    }
    $bodyClass = array();
    if ($u) $bodyClass[] = 'authed';
    if ($compact) $bodyClass[] = 'compact';
    if (!empty($opts['public'])) $bodyClass[] = 'is-public';
    echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<meta name="theme-color" content="#fbf7f2">';
    echo '<title>' . e($title) . ' | جوما</title>';
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link rel="stylesheet" href="' . e(joma_url('assets/css/joma.css')) . '">';
    echo '</head><body class="' . e(implode(' ', $bodyClass)) . '">';
    if ($u && empty($opts['public'])) {
        echo '<div class="topbar"></div>';
        echo '<aside class="side">';
        echo joma_logo(52);
        echo '<nav class="side-nav">';
        foreach (nav_items() as $k => $item) {
            $cls = $page === $k ? 'nav-link active' : 'nav-link';
            echo '<a class="' . $cls . '" href="' . e(joma_url('index.php?p=' . $k)) . '"><span>' . $item[1] . '</span>' . e($item[0]) . '</a>';
        }
        // JOMA-HAMMASIR-BEGIN (منوی هم‌مسیر + Badge + سوییچ حالت — Tier B با flag؛ fail-closed)
        // با Flag خاموش: فقط خواندن config ماژول؛ هیچ خروجی/رفتاری (D39/AC6.8).
        try {
            $__hcfg = dirname(__FILE__) . '/../config/hammasir_config.php';
            if (is_file($__hcfg)) {
                $HAMMASIR_CONFIG = array();
                include $__hcfg;
                if (!empty($HAMMASIR_CONFIG['hammasir_enabled']) && $u) {
                    $__hfn = dirname(__FILE__) . '/../functions/hammasir.php';
                    if (is_file($__hfn)) {
                        include_once $__hfn;
                        $__hmode = hammasir_active_mode();
                        $__hcap = hammasir_capabilities();
                        $__hbadge = hammasir_unread_badge((int) $u['id']);
                        $__hlabel = hammasir_mode_labels();
                        $__hcards = hammasir_mode_card_labels();
                        $__hcls = ($page === 'hammasir') ? 'nav-link active' : 'nav-link';
                        // باگ ۷ (گزارش PO): بدون استیکر/آیکون — فقط متن ساده «هم‌مسیر» (+ عدد Badge طبق D10)
                        echo '<a class="' . $__hcls . '" href="' . e(joma_url('index.php?p=hammasir')) . '"><span>' . (($__hbadge['total'] > 0) ? 'هم‌مسیر (' . (int) $__hbadge['total'] . ')' : 'هم‌مسیر') . '</span></a>';
                        // جعبه‌ی سوییچ فقط برای کاربر چندقابلیتی (حکم PO 2.2):
                        // کاربر تک‌قابلیتی فقط آیتم «هم‌مسیر» را می‌بیند.
                        if ($__hcap['can_provider'] || $__hcap['can_admin']) {
                        echo '<div class="hammasir-modebox" style="padding:6px 10px;display:flex;flex-direction:column;gap:4px;">';
                        echo '<small style="opacity:.7">حالت: ' . e($__hlabel[$__hmode]) . '</small>';
                        foreach (array('client', 'provider', 'admin') as $__hm) {
                            if ($__hm === $__hmode) continue;
                            if ($__hm === 'provider' && !$__hcap['can_provider']) continue;
                            if ($__hm === 'admin' && !$__hcap['can_admin']) continue;
                            echo '<form method="post" action="' . e(joma_url('index.php?p=hammasir')) . '">';
                            echo csrf_field();
                            echo '<input type="hidden" name="hammasir_action" value="mode_set">';
                            echo '<input type="hidden" name="mode" value="' . $__hm . '">';
                            echo '<button class="btn btn-ghost btn-block" type="submit">' . e($__hcards[$__hm]) . '</button>';
                            echo '</form>';
                        }
                        echo '</div>';
                        }
                    }
                }
                unset($HAMMASIR_CONFIG);
            }
            unset($__hcfg);
        } catch (Throwable $e) {
            // fail-closed: هیچ خروجی منو؛ فقط لاگ امن با پیام ثابت (PC-4)
            error_log('hammasir menu kept silent: safe load failed.');
        }
        // JOMA-HAMMASIR-END
        echo '</nav>';
        echo '<div class="side-foot">';
        echo '<div class="who"><strong>' . e($u['full_name']) . '</strong><small>@' . e($u['username']) . '</small></div>';
        // JOMA-HAMMASIR-BEGIN (چیپ حالت فعال کنار نام کاربر — فقط mode=admin/provider و flag روشن)
        try {
            if (isset($__hmode) && ($__hmode === 'provider' || $__hmode === 'admin')) {
                echo '<span class="chip">حالت ' . e($__hlabel[$__hmode]) . '</span>';
            }
        } catch (Throwable $e) {
            error_log('hammasir mode chip kept silent: safe load failed.');
        }
        // JOMA-HAMMASIR-END
        echo '<a class="btn btn-ghost btn-block" href="' . e(joma_url('index.php?p=logout')) . '">خروج</a>';
        echo '</div></aside>';
        echo '<header class="mob-head">';
        echo joma_logo(40, true);
        echo '<button class="icon-btn" type="button" data-more-toggle aria-label="منو">⋯</button>';
        echo '</header>';
        echo '<div class="mob-more" hidden>';
        $more = array('plan', 'periods', 'library', 'learn', 'profile', 'settings', 'about', 'support');
        foreach ($more as $k) {
            $item = nav_items();
            echo '<a href="' . e(joma_url('index.php?p=' . $k)) . '">' . e($item[$k][0]) . '</a>';
        }
        // JOMA-HAMMASIR-BEGIN (لینک منوی موبایل هم‌مسیر — فقط با flag؛ fail-closed)
        try {
            $__hcfg2 = dirname(__FILE__) . '/../config/hammasir_config.php';
            if (is_file($__hcfg2)) {
                $HAMMASIR_CONFIG = array();
                include $__hcfg2;
                if (!empty($HAMMASIR_CONFIG['hammasir_enabled'])) {
                    echo '<a href="' . e(joma_url('index.php?p=hammasir')) . '">هم‌مسیر</a>';
                }
                unset($HAMMASIR_CONFIG);
            }
            unset($__hcfg2);
        } catch (Throwable $e) {
            error_log('hammasir mobile menu kept silent: safe load failed.');
        }
        // JOMA-HAMMASIR-END
        echo '<a class="danger" href="' . e(joma_url('index.php?p=logout')) . '">خروج</a>';
        echo '</div>';
        echo '<main class="wrap">';
        echo '<div class="crumbs">';
        echo '<a class="back" href="javascript:history.back()">بازگشت</a>';
        foreach ($crumbs as $c) {
            echo '<span class="sep">/</span>';
            if (!empty($c['href'])) echo '<a href="' . e($c['href']) . '">' . e($c['label']) . '</a>';
            else echo '<span>' . e($c['label']) . '</span>';
        }
        echo '</div>';
        echo flash_get();
    } else {
        echo '<main class="public-shell">';
        echo flash_get();
    }
}

function joma_footer() {
    $u = current_user();
    echo '</main>';
    if ($u) {
        $page = isset($_GET['p']) ? $_GET['p'] : 'dashboard';
        $items = array(
            'dashboard' => array('خانه', '🏠'),
            'today' => array('امروز', '📝'),
            'mood' => array('خلق', '💗'),
            'reports' => array('گزارش', '📊'),
        );
        echo '<nav class="mobile">';
        foreach ($items as $k => $item) {
            $cls = $page === $k ? 'on' : '';
            echo '<a class="' . $cls . '" href="' . e(joma_url('index.php?p=' . $k)) . '"><span>' . $item[1] . '</span>' . e($item[0]) . '</a>';
        }
        echo '</nav>';
    }
    echo '<script src="' . e(joma_url('assets/js/joma.js')) . '"></script></body></html>';
}
