<?php
// نمونه‌ی تنظیمات مستقل ماژول «هم‌مسیر» (hammasir) — Phase 1A
// ------------------------------------------------------------------
// برای استفاده: این فایل را کپی کنید و نامش را «hammasir_config.php» بگذارید.
// فایل hammasir_config.php (مثل config.php فعلی) توسط .htaccess موجود پوشه‌ی config
// از دسترسی وب محروم است؛ این فایل نمونه صرفاً مستندات است.
//
// Feature Flag سطح Config/Deployment (D28):
// - پیش‌فرض قطعی: false (خاموش).
// - نبود فایل hammasir_config.php نیز معادل false و fail-closed است؛
//   یعنی ماژول بدون این فایل هرگز فعال نمی‌شود.
// - Flag هرگز از دیتابیس، joma_settings یا storage فایل خوانده نمی‌شود.
//
// Policyهای runtime (D9/D34/D40):
// - زنجیره‌ی حل: config مستقل هم‌مسیر → پیش‌فرض یک‌نقطه‌ای در کد.
// - پیش‌فرض‌ها فقط در یک نقطه تعریف شده‌اند:
//   hammasir_policy_defaults() در functions/hammasir.php
// - در v1 هیچ UI برای تغییر Flag یا policyها وجود ندارد (D28).
//
// ممنوع: credential، token، مسیر مطلق حساس یا هر تنظیم اتصال DB در این فایل.

$HAMMASIR_CONFIG = array(
    // Feature Flag — پیش‌فرض قطعی خاموش؛ فعال‌سازی فقط با تصمیم مستقل PO
    'hammasir_enabled' => false,

    // مالک سیستم (D-OWNER-BOOTSTRAP): نام کاربری مورداعتماد برای ارتقای
    // یک‌باره به مدیر وقتی هیچ مدیری وجود ندارد؛ خالی = خاموش.
    'bootstrap_owner_username' => '',
    'bootstrap_owner_done' => false,

    // Policyهای runtime — اختیاری؛ فقط برای override از پیش‌فرض‌های یک‌نقطه‌ای
    // (مقادیر باید عدد صحیح مثبت باشند؛ مقدار نامعتبر نادیده گرفته می‌شود و
    //  پیش‌فرض امن یک‌نقطه‌ای اعمال می‌گردد)
    // 'daily_message_limit' => <عدد صحیح مثبت>,          // سقف روزانه‌ی پیام مراجع
    // 'companion_daily_message_limit' => <عدد صحیح مثبت>, // سقف روزانه‌ی پیام همراه (فنی/ضداسپم)
    // 'message_cooldown_seconds' => <عدد صحیح مثبت>,      // کول‌داون ارسال برای هر دو طرف
    // 're_request_cooldown_hours' => <عدد صحیح مثبت>,     // کول‌داون درخواست مجدد به همان همراه (D34)
);
