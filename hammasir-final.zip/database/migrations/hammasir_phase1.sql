-- ------------------------------------------------------------------
-- ماژول «هم‌مسیر» (hammasir) — Migration فاز ۱ (Phase 1A)
-- ------------------------------------------------------------------
-- وضعیت: فقط فایل تعریف — هرگز اجرا نشده است.
-- اجرای این فایل فقط در محیط test و با مجوز جداگانه‌ی Product Owner مجاز است؛
-- اجرای آن روی Production در v1 ممنوع است.
--
-- قواعد (مطابق docs/HAMMASIR-PHASE0.md):
-- - دقیقاً ۷ دستور CREATE TABLE IF NOT EXISTS: ۶ موجودیت کسب‌وکاری + ۱ موجودیت
--   فراداده‌ی UI/حالت (joma_hammasir_user_flags) — D40 اصلاح‌شده (حکم PO).
-- - جدول تنظیمات وجود ندارد (D40)؛ policyها فقط در config مستقل + پیش‌فرض کد.
-- - joma_hammasir_user_flags فقط فراداده (active_mode/onboarding_seen/bootstrap marker)؛
--   هیچ داده‌ی کسب‌وکاری هم‌مسیر در آن ذخیره نمی‌شود.
-- - ارجاع به joma_users فقط «منطقی» است؛ هیچ FK فیزیکی/Trigger/Cascade وجود ندارد (D25).
-- - قید «حداکثر یک لینک باز» در کد داخل قفل canonical اعمال می‌شود، نه UNIQUE سخت (D6/D14).
-- - indexها فقط روی جدول‌های جدید و مطابق D32.
-- - Engine هدف: InnoDB — تأیید واقعی Engine فقط پس از ساخت در محیط test (بند ۳ Preflight).
-- - ستون‌های شناسه کاربر (user_id و مشابه) از نوع منطقی int هستند و
--   به جداول فعلی JOMA هیچ ارجاع فیزیکی ندارند.
-- ------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `joma_hammasir_providers` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'INACTIVE',
  `title` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hammasir_provider_user` (`user_id`),
  KEY `idx_hammasir_provider_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `joma_hammasir_links` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `provider_user_id` int(10) UNSIGNED NOT NULL,
  `client_user_id` int(10) UNSIGNED NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'PENDING',
  `consent_text` text NOT NULL,
  `consent_version` varchar(32) NOT NULL,
  `requested_at` datetime NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `declined_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `revoked_by_user_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hammasir_link_client_status` (`client_user_id`, `status`),
  KEY `idx_hammasir_link_provider_status` (`provider_user_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `joma_hammasir_permissions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_id` int(10) UNSIGNED NOT NULL,
  `perm_key` varchar(64) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `changed_by_user_id` int(10) UNSIGNED NOT NULL,
  `changed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hammasir_perm_link_key` (`link_id`, `perm_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `joma_hammasir_permission_history` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_id` int(10) UNSIGNED NOT NULL,
  `perm_key` varchar(64) NOT NULL,
  `previous_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `changed_by_user_id` int(10) UNSIGNED NOT NULL,
  `change_source` varchar(32) NOT NULL,
  `changed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hammasir_perm_hist_link` (`link_id`, `perm_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `joma_hammasir_messages` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_id` int(10) UNSIGNED NOT NULL,
  `sender_user_id` int(10) UNSIGNED NOT NULL,
  `recipient_user_id` int(10) UNSIGNED NOT NULL,
  `jalali_date` char(10) NOT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hammasir_msg_daily` (`link_id`, `sender_user_id`, `jalali_date`),
  KEY `idx_hammasir_msg_unread` (`recipient_user_id`, `is_read`),
  KEY `idx_hammasir_msg_page` (`link_id`, `created_at`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `joma_hammasir_system_events` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_id` int(10) UNSIGNED NOT NULL,
  `event_type` varchar(32) NOT NULL,
  `actor_user_id` int(10) UNSIGNED NOT NULL,
  `recipient_user_id` int(10) UNSIGNED NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hammasir_event_unread` (`recipient_user_id`, `is_read`),
  KEY `idx_hammasir_event_order` (`recipient_user_id`, `created_at`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `joma_hammasir_user_flags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `flag_key` varchar(64) NOT NULL,
  `flag_value` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hammasir_flag_user_key` (`user_id`, `flag_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
