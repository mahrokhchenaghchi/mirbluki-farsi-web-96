<?php
/*
 * ماژول «هم‌مسیر» — صفحه‌ی مرکزی (Phase 2..5 + مدیریت همراهان 1C)
 * ------------------------------------------------------------------
 * مسیر مجاز فقط Router مرکزی: index.php?p=hammasir (D29).
 *
 * گاردها (به ترتیب):
 *   ۱) گارد مستقیم (AC6.3/R13): فقط اجرای داخل اپ (Router مرکزی).
 *   ۲) گارد ورود: require_login().
 *   ۳) گارد Feature Flag (fail-closed — D28/D39).
 *   ۴) گارد محیط (AC1.7): بدون mbstring فقط پیام ثابت؛ هیچ فرم/عملیاتی.
 *
 * پردازش POST (فاز ۱..۵): قبل از هر خروجی؛ csrf_check() اجباری؛ action فقط
 * از $_POST و از whitelist ثابت؛ هیچ شناسه از Query String؛ مهار کامل
 * Throwable روی هر عملیات (D-1)؛ سپس PRG با flash موجود JOMA.
 *
 * نمایش: Badgeها (فاز ۵ — دو عدد جدا + درخواست نیازمند اقدام) → اعلان‌های
 * سیستمی (D17/D21) → جریان همراه (فاز ۳) → جریان مراجع (فاز ۲/۴) →
 * مدیریت همراهان (1C — فقط ADMIN_ACCESS).
 */

// ۱) گارد مستقیم — دسترسی مستقیم هرگز مشروع نیست → 403 خشک بدون هیچ خروجی
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// ۲) گارد ورود (احراز هویت با زیرساخت موجود JOMA)
require_login();

// ۳) گارد Feature Flag — دوگانه و fail-closed
if (!function_exists('hammasir_enabled') || !hammasir_enabled()) {
    joma_redirect('index.php?p=dashboard');
}

// هدر امنیتی صفحات داده‌دار هم‌مسیر (AC6.5)
header('Cache-Control: private, no-store');

// ۴) گارد محیط (fail-closed — AC1.7): در محیط ناسالم فقط پیام ثابت؛ بدون فرم/عملیات
if (!hammasir_env_ok()) {
    joma_header('هم‌مسیر', array(array('label' => 'هم‌مسیر')));
    ?>
    <section class="card">
      <h1>هم‌مسیر</h1>
      <p>ماژول هم‌مسیر در حال حاضر در دسترس نیست.</p>
    </section>
    <?php
    joma_footer();
    return;
}

// ===== پردازش POST — فاز ۱..۵؛ قبل از هر خروجی =====
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $hammasir_action = isset($_POST['hammasir_action']) ? (string) $_POST['hammasir_action'] : '';
    $hammasir_result = 'error';
    $hammasir_u_post = current_user();
    $hammasir_me_post = $hammasir_u_post ? (int) $hammasir_u_post['id'] : 0;
    $hammasir_link_id = isset($_POST['link_id']) ? (int) $_POST['link_id'] : 0;

    if ($hammasir_action === 'provider_register' || $hammasir_action === 'provider_set_title' || $hammasir_action === 'provider_set_status') {
        // --- عملیات Registry (1C) — فقط ADMIN_ACCESS (گیت دوم داخل partial) ---
        if (has_perm('ADMIN_ACCESS')) {
            $hammasir_uid = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
            try {
                if ($hammasir_action === 'provider_register') {
                    $hammasir_result = hammasir_provider_register($hammasir_uid, isset($_POST['title']) ? $_POST['title'] : '');
                } elseif ($hammasir_action === 'provider_set_title') {
                    $hammasir_result = hammasir_provider_set_title($hammasir_uid, isset($_POST['title']) ? $_POST['title'] : '');
                } else {
                    $hammasir_status = isset($_POST['status']) ? (string) $_POST['status'] : '';
                    $hammasir_result = in_array($hammasir_status, array('ACTIVE', 'INACTIVE'), true)
                        ? hammasir_provider_set_status($hammasir_uid, $hammasir_status)
                        : 'error';
                }
            } catch (Throwable $e) {
                $hammasir_result = 'error'; // D-1: هیچ exception به صفحه راه نمی‌یابد
            }
        }
    } elseif (in_array($hammasir_action, array('link_request', 'link_cancel', 'link_revoke', 'link_accept', 'link_decline', 'perms_update', 'messaging_set', 'message_send'), true)) {
        // --- عملیات فاز ۲..۵ — هر کاربر واردشده (گیت‌های نقش/مالکیت داخل توابع) ---
        try {
            if ($hammasir_action === 'link_request') {
                $hammasir_pv = array(
                    'VIEW_PROGRESS' => isset($_POST['perm_VIEW_PROGRESS']),
                    'VIEW_ACTIVITY_DETAILS' => isset($_POST['perm_VIEW_ACTIVITY_DETAILS']),
                    'VIEW_MOOD' => isset($_POST['perm_VIEW_MOOD']),
                );
                $hammasir_result = hammasir_link_request($hammasir_me_post, isset($_POST['provider_user_id']) ? (int) $_POST['provider_user_id'] : 0, $hammasir_pv);
            } elseif ($hammasir_action === 'link_cancel' || $hammasir_action === 'link_revoke') {
                // لغو درخواست (PENDING) و قطع ارتباط (ACTIVE) — هر دو D20 (تابع واحد)
                $hammasir_result = hammasir_link_revoke($hammasir_me_post, $hammasir_link_id);
            } elseif ($hammasir_action === 'link_accept') {
                $hammasir_result = hammasir_link_respond($hammasir_me_post, $hammasir_link_id, 'ACTIVE');
            } elseif ($hammasir_action === 'link_decline') {
                $hammasir_result = hammasir_link_respond($hammasir_me_post, $hammasir_link_id, 'DECLINED');
            } elseif ($hammasir_action === 'perms_update') {
                $hammasir_pv = array(
                    'VIEW_PROGRESS' => isset($_POST['perm_VIEW_PROGRESS']),
                    'VIEW_ACTIVITY_DETAILS' => isset($_POST['perm_VIEW_ACTIVITY_DETAILS']),
                    'VIEW_MOOD' => isset($_POST['perm_VIEW_MOOD']),
                );
                $hammasir_result = hammasir_perms_update_view($hammasir_me_post, $hammasir_link_id, $hammasir_pv);
            } elseif ($hammasir_action === 'messaging_set') {
                $hammasir_enabled_val = (isset($_POST['enabled']) && $_POST['enabled'] === '1');
                $hammasir_result = hammasir_messaging_set($hammasir_me_post, $hammasir_link_id, $hammasir_enabled_val);
            } else { // message_send
                $hammasir_result = hammasir_message_send($hammasir_me_post, $hammasir_link_id, isset($_POST['body']) ? $_POST['body'] : '');
            }
        } catch (Throwable $e) {
            $hammasir_result = 'error'; // D-1: مهار کامل؛ بدون rethrow
        }
    }

    // نگاشت نتیجه به پیام‌ها (مصوب‌های PO عیناً + رشته‌های جدید این فاز — گزارش شود)
    $hammasir_msgs_ok = array(
        'provider_register' => 'همراه ثبت شد.',
        'provider_set_title' => 'عنوان به‌روزرسانی شد.',
        'provider_set_status' => 'وضعیت همراه تغییر کرد.',
        'link_request' => 'درخواست همراهی ارسال شد.',
        'link_cancel' => 'درخواست همراهی لغو شد.',
        'link_revoke' => 'ارتباط قطع شد.',
        'link_accept' => 'درخواست پذیرفته شد.',
        'link_decline' => 'درخواست رد شد.',
        'perms_update' => 'دسترسی‌ها به‌روزرسانی شد.',
        'messaging_set' => 'تنظیم پیام‌رسانی تغییر کرد.',
        'message_send' => 'پیام ارسال شد.',
    );
    $hammasir_msgs_err = array(
        'invalid_user' => 'کاربر انتخاب‌شده معتبر نیست.',
        'duplicate' => 'این کاربر قبلاً به‌عنوان همراه ثبت شده است.',
        'invalid_title' => 'عنوان همراه الزامی است و حداکثر ۱۲۸ کاراکتر.',
        'open_link' => 'این همراه ارتباط باز (در انتظار یا فعال) دارد و نمی‌توان غیرفعالش کرد.',
        'self_link' => 'نمی‌توانید خودتان را همراه انتخاب کنید.',
        'invalid_provider' => 'همراه انتخاب‌شده در دسترس نیست.',
        'open_link_exists' => 'شما هم‌اکنون یک درخواست یا ارتباط باز دارید.',
        'request_cooldown' => 'برای درخواست مجدد به این همراه باید کمی صبر کنید.',
        'invalid_body' => 'متن پیام الزامی است و حداکثر ۲۰۰۰ کاراکتر.',
        'messaging_off' => 'همراه شما در حال حاضر دریافت پیام را فعال نکرده است.',
        'client_limit' => 'سقف پیام‌های امروز تکمیل شده است. امکان ارسال پیام جدید از فردا فعال می‌شود.',
        'companion_limit' => 'سقف روزانه‌ی پیام شما تکمیل شده است.',
        'cooldown' => 'لطفاً چند ثانیه دیگر تلاش کنید.',
        'lock_timeout' => 'لطفاً دوباره تلاش کنید.',
        'env' => 'امکان پردازش متن در حال حاضر وجود ندارد.',
        'error' => 'امکان انجام این عملیات در حال حاضر وجود ندارد.',
    );
    if ($hammasir_result === 'ok' && isset($hammasir_msgs_ok[$hammasir_action])) {
        flash_set('ok', $hammasir_msgs_ok[$hammasir_action]);
    } else {
        flash_set('err', isset($hammasir_msgs_err[$hammasir_result]) ? $hammasir_msgs_err[$hammasir_result] : $hammasir_msgs_err['error']);
    }
    // PRG: بازگشت به همان route — بدون هیچ شناسه در Query String (D29)
    joma_redirect('index.php?p=hammasir');
}

// ===== نمایش =====
$hammasir_u = current_user();
$hammasir_me = (int) $hammasir_u['id'];
// مرز روز ماژول (D35) — نه jalali_today() سرور (یادداشت C-4 مصوب)
$hammasir_today = hammasir_jalali_today();
$hammasir_today = ($hammasir_today !== null) ? jalali_format($hammasir_today) : '';
$hammasir_is_admin = has_perm('ADMIN_ACCESS');

// خواندهای Badge و جریان‌ها با مهار خطای PHP 8.1 (D-1)
$hammasir_unread_msgs = 0;
$hammasir_unread_events = 0;
$hammasir_pending_count = 0;
$hammasir_my_provider = null;
$hammasir_events = array();
try {
    $hammasir_n = hammasir_messages_unread_count($hammasir_me);
    $hammasir_unread_msgs = ($hammasir_n === null) ? 0 : (int) $hammasir_n;
    $hammasir_n = hammasir_events_unread_count($hammasir_me);
    $hammasir_unread_events = ($hammasir_n === null) ? 0 : (int) $hammasir_n;
    $hammasir_my_provider = hammasir_provider_by_user_id($hammasir_me);
    if ($hammasir_my_provider) {
        $hammasir_p_list = hammasir_links_by_provider($hammasir_me, 'PENDING');
        $hammasir_pending_count = is_array($hammasir_p_list) ? count($hammasir_p_list) : 0;
    }
    $hammasir_events = hammasir_events_list($hammasir_me);
    if (!is_array($hammasir_events)) $hammasir_events = array();
} catch (Throwable $e) {
    $hammasir_unread_msgs = 0;
    $hammasir_unread_events = 0;
    $hammasir_pending_count = 0;
    $hammasir_my_provider = null;
    $hammasir_events = array();
}

joma_header('هم‌مسیر', array(array('label' => 'هم‌مسیر')));
echo flash_get();
?>
<section class="card hero-card">
  <?php if ($hammasir_today !== '') { ?><p class="lede"><?php echo e($hammasir_today); ?></p><?php } ?>
  <h1>هم‌مسیر</h1>
  <div class="btn-row">
    <span class="chip"><?php echo e($hammasir_u['full_name'] ? $hammasir_u['full_name'] : $hammasir_u['username']); ?></span>
  </div>
  <?php if ($hammasir_unread_msgs > 0 || $hammasir_unread_events > 0 || $hammasir_pending_count > 0) { ?>
  <div class="btn-row">
    <?php if ($hammasir_unread_msgs > 0) { ?><span class="chip">پیام جدید: <?php echo (int) $hammasir_unread_msgs; ?></span><?php } ?>
    <?php if ($hammasir_unread_events > 0) { ?><span class="chip">رویداد جدید: <?php echo (int) $hammasir_unread_events; ?></span><?php } ?>
    <?php if ($hammasir_pending_count > 0) { ?><span class="chip">درخواست نیازمند اقدام: <?php echo (int) $hammasir_pending_count; ?></span><?php } ?>
  </div>
  <?php } ?>
</section>
<?php if (count($hammasir_events) > 0) { ?>
<section class="card">
  <h2>اعلان‌ها</h2>
  <?php foreach ($hammasir_events as $hammasir_ev) { ?>
    <div class="btn-row">
      <span class="chip"><?php echo e(((int) $hammasir_ev['is_read'] === 0) ? 'جدید' : 'دیده‌شده'); ?></span>
      <span><?php echo e(hammasir_event_label($hammasir_ev['event_type'])); ?></span>
      <small><?php echo e(jalali_format(hammasir_dt_to_jalali($hammasir_ev['created_at'])) . ' — ' . substr((string) $hammasir_ev['created_at'], 11, 5)); ?></small>
    </div>
  <?php } ?>
</section>
<?php
// مشاهده‌ی اعلان‌ها = خوانده‌شده برای کاربر جاری (فقط recipient خودم — AC5.3)
try {
    hammasir_mark_events_read($hammasir_me);
} catch (Throwable $e) {
    // بی‌اثر برای نمایش؛ دفعه‌ی بعد دوباره تلاش می‌شود
}
} ?>
<?php
// جریان همراه (فاز ۳/۴) — فقط اگر کاربر جاری خودش همراه ثبت‌شده باشد
if ($hammasir_my_provider) {
    include dirname(__FILE__) . '/hammasir_provider.php';
}
// جریان مراجع (فاز ۲/۴) — برای همه‌ی کاربران
include dirname(__FILE__) . '/hammasir_client.php';
// بخش مدیریت همراهان — فقط ADMIN_ACCESS؛ partial داخلی با گارد دوگانه (D30)
if ($hammasir_is_admin) {
    include dirname(__FILE__) . '/hammasir_admin.php';
}
joma_footer();
