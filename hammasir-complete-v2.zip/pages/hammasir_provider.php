<?php
/*
 * ماژول «هم‌مسیر» — partial جریان همراه (Phase 3/4)
 * ------------------------------------------------------------------
 * فقط از pages/hammasir.php include می‌شود؛ route عمومی ندارد (D29/D30).
 * متغیر مورد انتظار: $hammasir_me (user_id کاربر جاری — که خودش همراه ثبت‌شده است)
 *
 * درخواست‌های PENDING: «کاربری درخواست کرده شما همراه او باشید.» + قبول/رد (D20)
 * لینک‌های ACTIVE: توگل واحد پیام (D37 — جمله‌ی مصوب) + گفتگو + قطع ارتباط
 * قبل از قبول: فقط اطلاعات درخواست و سطح دسترسی انتخابی — هیچ داده‌ی مراجع (AC2.3/AC3.2)
 */

// گارد مستقیم — partial هرگز مستقیماً از وب اجرا نمی‌شود → 403 خشک (AC6.3)
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// خواندها با مهار خطای PHP 8.1 (D-1): خطا → فهرست خالی
$hammasir_p_pending = array();
$hammasir_p_active = array();
try {
    $hammasir_p_pending = hammasir_links_by_provider($hammasir_me, 'PENDING');
    if (!is_array($hammasir_p_pending)) $hammasir_p_pending = array();
    $hammasir_p_active = hammasir_links_by_provider($hammasir_me, 'ACTIVE');
    if (!is_array($hammasir_p_active)) $hammasir_p_active = array();
} catch (Throwable $e) {
    $hammasir_p_pending = array();
    $hammasir_p_active = array();
}

$hammasir_p_labels = hammasir_perm_view_labels();
?>
<?php if (count($hammasir_p_pending) > 0) { ?>
<section class="card">
  <h2>درخواست‌های همراهی</h2>
  <p>کاربری درخواست کرده شما همراه او باشید.</p>
  <?php foreach ($hammasir_p_pending as $hammasir_p_l) { ?>
    <?php
    $hammasir_p_name = '';
    $hammasir_p_perms = null;
    try {
        $hammasir_p_name = hammasir_user_display((int) $hammasir_p_l['client_user_id']);
        $hammasir_p_perms = hammasir_perm_map((int) $hammasir_p_l['id']);
    } catch (Throwable $e) {
        $hammasir_p_name = '';
        $hammasir_p_perms = null;
    }
    ?>
    <div class="card">
      <div class="btn-row">
        <span class="chip"><?php echo e($hammasir_p_name); ?></span>
      </div>
      <p><?php echo e(hammasir_consent_text()); ?></p>
      <label>سطح دسترسی درخواست‌شده</label>
      <div class="btn-row">
        <?php foreach (array('VIEW_SUMMARY', 'VIEW_PROGRESS', 'VIEW_ACTIVITY_DETAILS', 'VIEW_MOOD') as $hammasir_p_k) { ?>
          <?php $hammasir_p_on = ($hammasir_p_perms !== null && isset($hammasir_p_perms[$hammasir_p_k]) && (int) $hammasir_p_perms[$hammasir_p_k] === 1); ?>
          <span class="chip"><?php echo e($hammasir_p_labels[$hammasir_p_k] . ($hammasir_p_on ? ' ✓' : ' ✗')); ?></span>
        <?php } ?>
      </div>
      <div class="btn-row">
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="hammasir_action" value="link_accept">
          <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
          <button class="btn" type="submit">قبول</button>
        </form>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="hammasir_action" value="link_decline">
          <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
          <button class="btn sec" type="submit">رد</button>
        </form>
      </div>
    </div>
  <?php } ?>
</section>
<?php } ?>
<?php if (count($hammasir_p_active) > 0) { ?>
<section class="card">
  <h2>همراهی‌های فعال شما</h2>
  <?php foreach ($hammasir_p_active as $hammasir_p_l) { ?>
    <?php
    $hammasir_p_name = '';
    $hammasir_p_msg_on = false;
    try {
        $hammasir_p_name = hammasir_user_display((int) $hammasir_p_l['client_user_id']);
        $hammasir_p_msg_on = (hammasir_messaging_enabled((int) $hammasir_p_l['id']) === true);
    } catch (Throwable $e) {
        $hammasir_p_name = '';
        $hammasir_p_msg_on = false;
    }
    ?>
    <div class="card">
      <div class="btn-row">
        <span class="chip"><?php echo e($hammasir_p_name); ?></span>
      </div>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="messaging_set">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
        <input type="hidden" name="enabled" value="<?php echo $hammasir_p_msg_on ? '0' : '1'; ?>">
        <label>مایل هستم از این مراجع پیام دریافت کنم.</label>
        <div class="btn-row">
          <button class="btn sec" type="submit"><?php echo $hammasir_p_msg_on ? 'غیرفعال‌سازی پیام‌رسانی' : 'فعال‌سازی پیام‌رسانی'; ?></button>
        </div>
      </form>
      <?php if ($hammasir_p_msg_on) { ?>
        <?php
        $hammasir_link = $hammasir_p_l;
        $hammasir_other_label = $hammasir_p_name;
        $hammasir_msg_on = true;
        include dirname(__FILE__) . '/hammasir_chat.php';
        ?>
      <?php } ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="link_revoke">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_p_l['id']; ?>">
        <div class="btn-row">
          <button class="btn sec" type="submit">قطع ارتباط</button>
        </div>
      </form>
    </div>
  <?php } ?>
</section>
<?php } ?>
