<?php
/*
 * ماژول «هم‌مسیر» — partial جریان مراجع (Phase 2/4)
 * ------------------------------------------------------------------
 * فقط از pages/hammasir.php include می‌شود؛ route عمومی ندارد (D29/D30).
 * متغیر مورد انتظار: $hammasir_me (user_id کاربر جاری)
 *
 * بدون لینک باز: سؤال رسمی + فهرست همراهان ACTIVE + فرم رضایت (متن مصوب)
 * با لینک باز: وضعیت + ویرایش مجوزهای مشاهده (فقط مراجع — D19) +
 *   توگل واحد پیام (D37) + گفتگو + لغو/قطع (D20)
 */

// گارد مستقیم — partial هرگز مستقیماً از وب اجرا نمی‌شود → 403 خشک (AC6.3)
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// خواندها با مهار خطای PHP 8.1 (D-1): خطا → حالت خالی/امن
$hammasir_c_open = null;
$hammasir_c_pick = array();
$hammasir_c_prov = null;
$hammasir_c_perms = null;
$hammasir_c_msg_on = false;
$hammasir_c_choice = 2;      // پیش‌فرض امن: هیچ فرمی خودکار نمایش نده (باگ ۳)
$hammasir_c_latest = null;   // آخرین لینک با هر وضعیت (باگ ۴)
$hammasir_c_show_form = false;
try {
    $hammasir_c_open = hammasir_link_open_by_client($hammasir_me);
    $hammasir_c_pick = hammasir_provider_list(true);
    if (!is_array($hammasir_c_pick)) $hammasir_c_pick = array();
    if ($hammasir_c_open) {
        $hammasir_c_prov = hammasir_provider_by_user_id((int) $hammasir_c_open['provider_user_id']);
        $hammasir_c_perms = hammasir_perm_map((int) $hammasir_c_open['id']);
        $hammasir_c_msg_on = (hammasir_messaging_enabled((int) $hammasir_c_open['id']) === true);
    } else {
        // انتخاب Onboarding کاربر (باگ ۳): 1=پذیرش (فرم انتخاب)، 2=رد (هیچ فرمی خودکار)؛
        // مهاجرت از v4: onboarding_seen قدیمی بدون choice → معادل «رد» (محافظه‌کارانه)
        $hammasir_c_choice = (int) hammasir_user_flag_get($hammasir_me, 'onboarding_choice');
        if ($hammasir_c_choice !== 1 && $hammasir_c_choice !== 2) {
            $hammasir_c_choice = (hammasir_user_flag_get($hammasir_me, 'onboarding_seen') === 1) ? 2 : 0;
        }
        // باگ ۴: آخرین لینک با «هر وضعیتی» → به‌جای فرم، وضعیت نمایش داده می‌شود
        $hammasir_c_latest = hammasir_latest_link_by_client($hammasir_me);
        // فرم انتخاب فقط آگاهانه: پذیرشِ onboarding (بدون لینک) یا دکمه‌ی «درخواست همراهی جدید»
        if ($hammasir_c_choice === 1 && !$hammasir_c_latest) $hammasir_c_show_form = true;
        if ($hammasir_c_latest && !empty($_SESSION['hammasir_show_request_form'])) $hammasir_c_show_form = true;
    }
} catch (Throwable $e) {
    $hammasir_c_open = null;
    $hammasir_c_pick = array();
    $hammasir_c_choice = 2;
    $hammasir_c_latest = null;
    $hammasir_c_show_form = false;
}

if (!$hammasir_c_open) {
    // ----- بدون لینک باز (باگ ۳/۴/۵): وضعیت لینک بسته یا دعوت یک‌باره یا فرمِ آگاهانه -----
    if ($hammasir_c_latest) {
        // باگ ۴: کاربر لینک (بسته) دارد → فرم انتخاب هرگز خودکار نمی‌آید؛ وضعیت نمایش داده می‌شود
        $hammasir_c_sl = hammasir_link_status_labels();
        $hammasir_c_status = isset($hammasir_c_sl[$hammasir_c_latest['status']]) ? $hammasir_c_sl[$hammasir_c_latest['status']] : $hammasir_c_latest['status'];
        $hammasir_c_lprov = hammasir_provider_by_user_id((int) $hammasir_c_latest['provider_user_id']);
        $hammasir_c_ltitle = $hammasir_c_lprov ? $hammasir_c_lprov['title'] : ('همراه #' . (int) $hammasir_c_latest['provider_user_id']);
        ?>
        <section class="card">
          <h2>همراه شما در این مسیر</h2>
          <div class="btn-row">
            <span class="chip"><?php echo e($hammasir_c_ltitle); ?></span>
            <span class="chip"><?php echo e($hammasir_c_status); ?></span>
          </div>
          <?php if ($hammasir_c_latest['status'] === 'DECLINED') { ?>
            <p>درخواست شما از سوی همراه رد شده است.</p>
          <?php } else { ?>
            <p>این ارتباط قبلاً قطع شده است.</p>
          <?php } ?>
          <?php if (!$hammasir_c_show_form) { ?>
          <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="client_request_new">
            <div class="btn-row">
              <button class="btn sec" type="submit">درخواست همراهی جدید</button>
            </div>
          </form>
          <?php } ?>
        </section>
        <?php
    } elseif ($hammasir_c_choice === 0) {
        // ----- دعوت یک‌باره (Onboarding — حکم PO 3.1 + باگ ۵: سؤال + توضیح + دو دکمه) -----
        ?>
        <section class="card">
          <h2>آیا مایلید در این مسیر یک همراه داشته باشید؟</h2>
          <p><?php echo nl2br(e(hammasir_onboarding_text())); ?></p>
          <div class="btn-row">
            <form method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="hammasir_action" value="onboarding_accept">
              <button class="btn" type="submit">بله، انتخاب می‌کنم</button>
            </form>
            <form method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="hammasir_action" value="onboarding_dismiss">
              <button class="btn sec" type="submit">فعلاً نه</button>
            </form>
          </div>
        </section>
        <?php
    } elseif ($hammasir_c_choice === 2) {
        // باگ ۳: «فعلاً نه» زده → هیچ فرمی خودکار نمی‌آید؛ ورود آگاهانه با یک دکمه‌ی کوچک
        ?>
        <section class="card">
          <h2>همراه شما در این مسیر کیست؟</h2>
          <p>فعلاً همراهی انتخاب نکرده‌اید.</p>
          <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="onboarding_reopen">
            <div class="btn-row">
              <button class="btn sec" type="submit">انتخاب همراه</button>
            </div>
          </form>
        </section>
        <?php
    }
    if ($hammasir_c_show_form) {
        // ----- فرم انتخاب + رضایت (فاز ۲) — فقط آگاهانه (پذیرش onboarding یا دکمه‌ی درخواست جدید) -----
        $hammasir_c_labels = hammasir_perm_view_labels();
        ?>
        <section class="card">
          <h2>همراه شما در این مسیر کیست؟</h2>
          <?php if (count($hammasir_c_pick) === 0) { ?>
            <p>فعلاً همراهی برای انتخاب ثبت نشده است.</p>
          <?php } else { ?>
          <form class="card" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="link_request">
            <label>انتخاب همراه</label>
            <!-- حکم PO (C): فهرست همراهان ACTIVE فقط با «عنوان همراه» — بدون ایمیل/موبایل/نام کاربری؛
                 select بومی مرورگر → فرم بدون JS هم کار می‌کند (PC-1) -->
            <select name="provider_user_id" required>
              <option value="" disabled selected>انتخاب کنید</option>
              <?php foreach ($hammasir_c_pick as $hammasir_c_p) { ?>
                <?php if ((int) $hammasir_c_p['user_id'] === $hammasir_me) continue; // self-link ممنوع (D20) ?>
                <option value="<?php echo (int) $hammasir_c_p['user_id']; ?>"><?php echo e($hammasir_c_p['title']); ?></option>
              <?php } ?>
            </select>
            <p>با ارسال این درخواست، همراه انتخاب‌شده می‌تواند مواردی را که در زیر اجازه می‌دهید مشاهده کند. شما هر زمان بخواهید می‌توانید دسترسی را کاهش دهید یا ارتباط را قطع کنید.</p>
            <label>اجازه‌ی مشاهده</label>
            <div><label><input type="checkbox" checked disabled> <?php echo e($hammasir_c_labels['VIEW_SUMMARY']); ?> (پایه — همیشه فعال)</label></div>
            <div><label><input type="checkbox" name="perm_VIEW_PROGRESS" value="1" checked> <?php echo e($hammasir_c_labels['VIEW_PROGRESS']); ?></label></div>
            <div><label><input type="checkbox" name="perm_VIEW_ACTIVITY_DETAILS" value="1"> <?php echo e($hammasir_c_labels['VIEW_ACTIVITY_DETAILS']); ?></label></div>
            <div>
              <label><input type="checkbox" name="perm_VIEW_MOOD" value="1"> <?php echo e($hammasir_c_labels['VIEW_MOOD']); ?></label>
              <small>داده‌ی حساس است؛ فقط با انتخاب آگاهانه‌ی شما فعال می‌شود و هر زمان می‌توانید غیرفعالش کنید.</small>
            </div>
            <div class="btn-row">
              <button class="btn" type="submit">ارسال درخواست</button>
            </div>
          </form>
          <?php } ?>
          <?php if ($hammasir_c_latest) { ?>
          <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="client_request_cancel">
            <div class="btn-row">
              <button class="btn sec" type="submit">انصراف</button>
            </div>
          </form>
          <?php } ?>
        </section>
        <?php
    }
} else {
    // ----- حالت ۲: لینک باز — وضعیت + مجوزها + پیام + اقدام‌ها -----
    $hammasir_c_sl = hammasir_link_status_labels(); // برچسب وضعیت از یک نقطه (D4)
    $hammasir_c_status = isset($hammasir_c_sl[$hammasir_c_open['status']]) ? $hammasir_c_sl[$hammasir_c_open['status']] : $hammasir_c_open['status'];
    $hammasir_c_title = $hammasir_c_prov ? $hammasir_c_prov['title'] : ('همراه #' . (int) $hammasir_c_open['provider_user_id']);
    $hammasir_c_labels = hammasir_perm_view_labels();
    ?>
    <section class="card">
      <h2>همراه شما در این مسیر</h2>
      <div class="btn-row">
        <span class="chip"><?php echo e($hammasir_c_title); ?></span>
        <span class="chip"><?php echo e($hammasir_c_status); ?></span>
      </div>
      <?php if ($hammasir_c_open['status'] === 'PENDING') { ?>
        <p>تا قبل از پذیرش همراه، هیچ اطلاعاتی از شما برای او نمایش داده نمی‌شود.</p>
        <form class="card" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="hammasir_action" value="link_cancel">
          <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_c_open['id']; ?>">
          <div class="btn-row">
            <button class="btn sec" type="submit">لغو درخواست</button>
          </div>
        </form>
      <?php } else { ?>
      <form class="card" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="perms_update">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_c_open['id']; ?>">
        <label>اجازه‌ی مشاهده</label>
        <div><label><input type="checkbox" checked disabled> <?php echo e($hammasir_c_labels['VIEW_SUMMARY']); ?> (پایه — همیشه فعال)</label></div>
        <div><label><input type="checkbox" name="perm_VIEW_PROGRESS" value="1" <?php if (isset($hammasir_c_perms['VIEW_PROGRESS']) && (int) $hammasir_c_perms['VIEW_PROGRESS'] === 1) echo 'checked'; ?>> <?php echo e($hammasir_c_labels['VIEW_PROGRESS']); ?></label></div>
        <div><label><input type="checkbox" name="perm_VIEW_ACTIVITY_DETAILS" value="1" <?php if (isset($hammasir_c_perms['VIEW_ACTIVITY_DETAILS']) && (int) $hammasir_c_perms['VIEW_ACTIVITY_DETAILS'] === 1) echo 'checked'; ?>> <?php echo e($hammasir_c_labels['VIEW_ACTIVITY_DETAILS']); ?></label></div>
        <div><label><input type="checkbox" name="perm_VIEW_MOOD" value="1" <?php if (isset($hammasir_c_perms['VIEW_MOOD']) && (int) $hammasir_c_perms['VIEW_MOOD'] === 1) echo 'checked'; ?>> <?php echo e($hammasir_c_labels['VIEW_MOOD']); ?></label></div>
        <div class="btn-row">
          <button class="btn" type="submit">ذخیره‌ی دسترسی‌ها</button>
        </div>
      </form>
      <form class="card" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="messaging_set">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_c_open['id']; ?>">
        <input type="hidden" name="enabled" value="<?php echo $hammasir_c_msg_on ? '0' : '1'; ?>">
        <div class="btn-row">
          <button class="btn sec" type="submit"><?php echo $hammasir_c_msg_on ? 'غیرفعال‌سازی پیام‌رسانی' : 'فعال‌سازی پیام‌رسانی'; ?></button>
        </div>
      </form>
      <?php if ($hammasir_c_msg_on) { ?>
        <?php
        $hammasir_link = $hammasir_c_open;
        $hammasir_other_label = $hammasir_c_title;
        $hammasir_msg_on = true;
        include dirname(__FILE__) . '/hammasir_chat.php';
        ?>
      <?php } else { ?>
        <section class="card">
          <p>همراه شما در حال حاضر دریافت پیام را فعال نکرده است.</p>
        </section>
      <?php } ?>
      <form class="card" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="hammasir_action" value="link_revoke">
        <input type="hidden" name="link_id" value="<?php echo (int) $hammasir_c_open['id']; ?>">
        <div class="btn-row">
          <button class="btn sec" type="submit">قطع ارتباط</button>
        </div>
      </form>
      <?php } ?>
    </section>
    <?php
}
