<?php
/*
 * ماژول «هم‌مسیر» — صفحه‌ی مرکزی (Phase 1C — Placeholder + مدیریت همراهان)
 * ------------------------------------------------------------------
 * مسیر مجاز فقط Router مرکزی: index.php?p=hammasir (D29).
 * UI فازهای ۲ تا ۵ (انتخاب/رضایت/پیام/Badge) هنوز ساخته نشده و مجاز نیست.
 *
 * گاردها (به ترتیب):
 *   ۱) گارد مستقیم (AC6.3/R13): فقط اجرای داخل اپ (Router مرکزی).
 *   ۲) گارد ورود: require_login().
 *   ۳) گارد Feature Flag (fail-closed — D28/D39).
 *   ۴) گارد محیط (AC1.7): بدون mbstring فقط پیام ثابت؛ هیچ فرم/عملیاتی.
 *
 * پردازش POST (1C — فقط عملیات Registry):
 *   - قبل از هر خروجی؛ csrf_check() اجباری؛ action فقط از $_POST و از
 *     whitelist ثابت؛ هیچ شناسه از Query String؛ سپس PRG با flash موجود JOMA.
 *
 * maybe_mood_gate فعلی بدون تغییر و سراسری روی این route اعمال می‌شود (D29).
 */

// ۱) گارد مستقیم — دسترسی مستقیم هرگز مشروع نیست → 403 خشک بدون هیچ خروجی
// (حکم PO — ساده‌سازی گارد؛ مستقل از عمق نصب/ریشه/زیرپوشه/symlink)
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// ۲) گارد ورود (احراز هویت با زیرساخت موجود JOMA)
require_login();

// ۳) گارد Feature Flag — دوگانه و fail-closed
if (!function_exists('hammasir_enabled') || !hammasir_enabled()) {
    joma_redirect('index.php?p=dashboard');
}

// هدر امنیتی صفحات داده‌دار هم‌مسیر (AC6.5)
header('Cache-Control: private, no-store');

// ۴) گارد محیط (fail-closed — AC1.7): در محیط ناسالم فقط پیام ثابت؛ بدون فرم/عملیات
if (!hammasir_env_ok()) {
    joma_header('هم‌مسیر', array(array('label' => 'هم‌مسیر')));
    ?>
    <section class="card">
      <h1>هم‌مسیر</h1>
      <p>ماژول هم‌مسیر در حال حاضر در دسترس نیست.</p>
    </section>
    <?php
    joma_footer();
    return;
}

// ===== پردازش POST — فقط عملیات Registry (D30)؛ قبل از هر خروجی =====
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $hammasir_action = isset($_POST['hammasir_action']) ? (string) $_POST['hammasir_action'] : '';
    $hammasir_allowed_actions = array('provider_register', 'provider_set_title', 'provider_set_status');
    $hammasir_result = 'error';
    // گیت اول ADMIN_ACCESS (گیت دوم داخل partial خود بخش ادمین است)
    if (in_array($hammasir_action, $hammasir_allowed_actions, true) && has_perm('ADMIN_ACCESS')) {
        $hammasir_uid = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
        if ($hammasir_action === 'provider_register') {
            $hammasir_result = hammasir_provider_register($hammasir_uid, isset($_POST['title']) ? $_POST['title'] : '');
        } elseif ($hammasir_action === 'provider_set_title') {
            $hammasir_result = hammasir_provider_set_title($hammasir_uid, isset($_POST['title']) ? $_POST['title'] : '');
        } elseif ($hammasir_action === 'provider_set_status') {
            $hammasir_status = isset($_POST['status']) ? (string) $_POST['status'] : '';
            $hammasir_result = in_array($hammasir_status, array('ACTIVE', 'INACTIVE'), true)
                ? hammasir_provider_set_status($hammasir_uid, $hammasir_status)
                : 'error';
        }
    }
    // نگاشت نتیجه به پیام‌های مصوب PO (عیناً — بدون رشته‌ی جدید)
    $hammasir_msgs_ok = array(
        'provider_register' => 'همراه ثبت شد.',
        'provider_set_title' => 'عنوان به‌روزرسانی شد.',
        'provider_set_status' => 'وضعیت همراه تغییر کرد.',
    );
    $hammasir_msgs_err = array(
        'invalid_user' => 'کاربر انتخاب‌شده معتبر نیست.',
        'duplicate' => 'این کاربر قبلاً به‌عنوان همراه ثبت شده است.',
        'invalid_title' => 'عنوان همراه الزامی است و حداکثر ۱۲۸ کاراکتر.',
        'open_link' => 'این همراه ارتباط باز (در انتظار یا فعال) دارد و نمی‌توان غیرفعالش کرد.',
        'lock_timeout' => 'لطفاً دوباره تلاش کنید.',
        'env' => 'امکان پردازش متن در حال حاضر وجود ندارد.',
        'error' => 'امکان انجام این عملیات در حال حاضر وجود ندارد.',
    );
    if ($hammasir_result === 'ok' && isset($hammasir_msgs_ok[$hammasir_action])) {
        flash_set('ok', $hammasir_msgs_ok[$hammasir_action]);
    } else {
        flash_set('err', isset($hammasir_msgs_err[$hammasir_result]) ? $hammasir_msgs_err[$hammasir_result] : $hammasir_msgs_err['error']);
    }
    // PRG: بازگشت به همان route — بدون هیچ شناسه در Query String (D29)
    joma_redirect('index.php?p=hammasir');
}

// ===== نمایش =====
$hammasir_u = current_user();
// مرز روز ماژول (D35) — نه jalali_today() سرور (یادداشت C-4 مصوب)
$hammasir_today = hammasir_jalali_today();
$hammasir_today = ($hammasir_today !== null) ? jalali_format($hammasir_today) : '';
$hammasir_is_admin = has_perm('ADMIN_ACCESS');
joma_header('هم‌مسیر', array(array('label' => 'هم‌مسیر')));
echo flash_get();
?>
<section class="card hero-card">
  <?php if ($hammasir_today !== '') { ?><p class="lede"><?php echo e($hammasir_today); ?></p><?php } ?>
  <h1>هم‌مسیر</h1>
  <div class="btn-row">
    <span class="chip"><?php echo e($hammasir_u['full_name'] ? $hammasir_u['full_name'] : $hammasir_u['username']); ?></span>
  </div>
</section>
<section class="card">
  <h2>همراه شما در این مسیر کیست؟</h2>
  <p>این بخش به‌زودی در دسترس قرار می‌گیرد.</p>
</section>
<?php
// بخش مدیریت همراهان — فقط ADMIN_ACCESS؛ partial داخلی با گارد دوگانه (D30)
if ($hammasir_is_admin) {
    include dirname(__FILE__) . '/hammasir_admin.php';
}
joma_footer();
