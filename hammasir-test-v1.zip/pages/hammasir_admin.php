<?php
/*
 * ماژول «هم‌مسیر» — مدیریت همراهان / Provider Registry (Phase 1C)
 * ------------------------------------------------------------------
 * این فایل یک partial داخلی است:
 *   - فقط از pages/hammasir.php include می‌شود؛ هیچ route عمومی/مستقل ندارد
 *     (دستور مصوب PO — بند پیوست فاز ۰؛ D29/D30).
 *   - گارد دوگانه ADMIN_ACCESS: هم در صفحه‌ی میزبان (پیش از include)
 *     و هم اینجا دوباره چک می‌شود.
 * همه‌ی متن‌های کاربر-رو در این فایل مصوب PO هستند (دستور فاز 1C — بخش C).
 */

// گارد مستقیم — partial هرگز مستقیماً از وب اجرا نمی‌شود → 403 خشک بدون خروجی
// (حکم PO — ساده‌سازی گارد؛ مستقل از عمق نصب/ریشه/زیرپوشه/symlink)
if (!defined('JOMA_IN_APP')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// گارد دوگانه — حتی اگر میزبان فراموش کند، اینجا دوباره چک می‌شود (D30)
if (!function_exists('has_perm') || !has_perm('ADMIN_ACCESS')) {
    return;
}

// مهار کامل خطاهای mysqli در PHP 8.1 (D-1): خطای خواندن داده → فهرست خالی، بدون fatal صفحه
try {
    $hammasir_providers = hammasir_registry_list();
    $hammasir_user_options = hammasir_registry_user_options();
} catch (Throwable $e) {
    $hammasir_providers = null;
    $hammasir_user_options = array();
}
// تشخیص سرریز سقف انتخاب (C-2): از حد گذشت → ورودی عددی به‌جای select؛ اعتبارسنجی سرور یکسان است
$hammasir_user_max = hammasir_user_select_max();
$hammasir_user_overflow = is_array($hammasir_user_options) && count($hammasir_user_options) > $hammasir_user_max;
?>
<section class="card">
  <h2>مدیریت همراهان</h2>

  <form class="card" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="hammasir_action" value="provider_register">
    <div class="field-row">
      <div>
        <label>کاربر</label>
        <?php if ($hammasir_user_overflow) { ?>
          <input type="number" name="user_id" min="1">
        <?php } else { ?>
          <select name="user_id">
            <?php foreach ($hammasir_user_options as $hammasir_opt) { ?>
              <option value="<?php echo (int) $hammasir_opt['id']; ?>"><?php echo e($hammasir_opt['display']); ?></option>
            <?php } ?>
          </select>
        <?php } ?>
      </div>
      <div>
        <label>عنوان همراه</label>
        <input type="text" name="title" maxlength="128">
      </div>
    </div>
    <button class="btn" type="submit">ثبت همراه</button>
  </form>

  <?php if ($hammasir_providers !== null && count($hammasir_providers) > 0) { ?>
    <?php foreach ($hammasir_providers as $hammasir_p) { ?>
      <div class="card">
        <h3><?php echo e($hammasir_p['display_name']); ?></h3>
        <div class="btn-row">
          <span class="chip"><?php echo e($hammasir_p['title']); ?></span>
          <span class="chip"><?php echo ($hammasir_p['status'] === 'ACTIVE') ? 'فعال' : 'غیرفعال'; ?></span>
        </div>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="hammasir_action" value="provider_set_status">
          <input type="hidden" name="user_id" value="<?php echo e($hammasir_p['user_id']); ?>">
          <input type="hidden" name="status" value="<?php echo ($hammasir_p['status'] === 'ACTIVE') ? 'INACTIVE' : 'ACTIVE'; ?>">
          <button class="btn sec" type="submit"><?php echo ($hammasir_p['status'] === 'ACTIVE') ? 'غیرفعال‌سازی' : 'فعال‌سازی'; ?></button>
        </form>
        <details>
          <summary>ویرایش عنوان</summary>
          <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hammasir_action" value="provider_set_title">
            <input type="hidden" name="user_id" value="<?php echo e($hammasir_p['user_id']); ?>">
            <label>عنوان همراه</label>
            <input type="text" name="title" maxlength="128" value="<?php echo e($hammasir_p['title']); ?>">
            <button class="btn" type="submit">ذخیره</button>
          </form>
        </details>
      </div>
    <?php } ?>
  <?php } ?>
</section>
