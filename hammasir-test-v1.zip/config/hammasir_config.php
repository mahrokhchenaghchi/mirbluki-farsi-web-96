<?php
// تنظیمات مستقل ماژول «هم‌مسیر» (hammasir) — Phase 1A (Tier A / Add-Only)
// ------------------------------------------------------------------
// این فایل توسط index.php یا includes/bootstrap.php فعلی JOMA لود نمی‌شود؛
// ادغام آن فقط در Phase 1B و با مجوز جداگانه‌ی Product Owner انجام می‌شود (D28/D29).
//
// Feature Flag سطح Config/Deployment (D28):
// - پیش‌فرض قطعی: خاموش (false).
// - «نبودِ همین فایل» نیز معادل false و fail-closed است
//   (در functions/hammasir.php تضمین شده است).
// - فعال‌سازی فقط با تصمیم مستقل Product Owner.
//
// Policyهای runtime (D9/D40):
// - مقدار پیش‌فرض هر policy فقط در «یک نقطه» تعریف می‌شود:
//   تابع hammasir_policy_defaults() در functions/hammasir.php.
// - این فایل فقط در صورت نیاز به override از پیش‌فرض‌ها پر می‌شود.
// - جدول تنظیمات وجود ندارد (D40) و joma_settings فعلی JOMA
//   هرگز توسط هم‌مسیر خوانده/نوشته نمی‌شود.
//
// ممنوع: قرار دادن credential، token، مسیر مطلق حساس یا هر تنظیم اتصال DB در این فایل.

$HAMMASIR_CONFIG = array(
    // Feature Flag — پیش‌فرض قطعی خاموش
    'hammasir_enabled' => false,

    // Policyهای runtime (اختیاری — فقط برای override از پیش‌فرض‌های یک‌نقطه‌ای)
    // 'daily_message_limit' => ...,
    // 'companion_daily_message_limit' => ...,
    // 'message_cooldown_seconds' => ...,
    // 're_request_cooldown_hours' => ...,
);
