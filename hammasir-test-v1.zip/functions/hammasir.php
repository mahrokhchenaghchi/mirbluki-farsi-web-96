<?php
/*
 * ماژول «هم‌مسیر» (hammasir) — لایه‌ی داده — Phase 1A (Tier A / Add-Only)
 * ------------------------------------------------------------------
 * الزامات فاز 1A (مصوب PO):
 * - این فایل در زمان include فقط «تعریف» است؛ هیچ اتصال DB، query،
 *   mutation، ساخت پوشه یا نوشتن فایل انجام نمی‌شود.
 * - در Phase 1A هیچ بخشی از JOMA این فایل را include نمی‌کند؛
 *   ادغام (route/flag) مربوط به Phase 1B و با مجوز جداگانه است.
 * - سازگار با PHP 7.x — بدون قابلیت‌های نسخه‌های جدیدتر.
 * - ارجاع به joma_users فقط «منطقی» است؛ بدون FK فیزیکی (D25).
 * - جدول تنظیمات نداریم (D40)؛ policyها فقط از config مستقل + پیش‌فرض یک‌نقطه‌ای (D9).
 * - بدون mbstring ماژول fail-closed می‌ماند؛ fallback به strlen ممنوع (AC1.7/R18).
 * - مبنای زمانی: timezone صریح Asia/Tehran (D35)؛
 *   jalali_today() و includes/jalali.php فعلی JOMA تغییر نمی‌کنند.
 *
 * پیش‌نیاز include (در 1B): توابع فعلی JOMA از bootstrap لود شده باشند
 * (store_mode, db, joma_query, joma_query_one, joma_exec).
 *
 * نکته برای 1B (D28 fail-closed): db() فعلی JOMA در خطای اتصال die می‌کند؛
 * گارد Flag و در دسترس‌بودن باید «قبل از» هر فراخوانی عملیات هم‌مسیر باشد.
 *
 * نکته file mode (R7): قفل فایل روی فایل‌سیستم شبکه‌ای (NFS) تضمین نیست؛
 * در Preflight استقرار بررسی می‌شود.
 *
 * ارجاع مستندات: docs/HAMMASIR-PHASE0.md (D0 تا D40، ACها، Risk Register)
 */

if (defined('HAMMASIR_PHP')) return;
define('HAMMASIR_PHP', '1a');
define('HAMMASIR_TZ', 'Asia/Tehran');          // D35 — timezone صریح ماژول
define('HAMMASIR_MESSAGE_MAX_LEN', 2000);      // D11 — تنها نقطه‌ی تعریف حد پیام
define('HAMMASIR_LOCK_TIMEOUT', 2);            // D14 — مهلت قفل canonical (ثانیه)
define('HAMMASIR_PAGE_SIZE', 100);             // D36 — صفحه‌بندی پیش‌فرض پیام‌ها

/* ==================================================================
 * بخش ۱) Whitelistهای Backend (AC6.6)
 * ================================================================== */

function hammasir_perm_keys() {
    return array(
        'VIEW_SUMMARY',
        'VIEW_PROGRESS',
        'VIEW_ACTIVITY_DETAILS',
        'VIEW_MOOD',
        'CLIENT_CAN_MESSAGE_COMPANION',
        'COMPANION_CAN_MESSAGE_CLIENT',
    );
}

function hammasir_is_valid_perm_key($key) {
    return in_array($key, hammasir_perm_keys(), true);
}

function hammasir_link_statuses() {
    return array('PENDING', 'ACTIVE', 'DECLINED', 'REVOKED');
}

function hammasir_is_valid_link_status($status) {
    return in_array($status, hammasir_link_statuses(), true);
}

function hammasir_provider_statuses() {
    return array('ACTIVE', 'INACTIVE');
}

function hammasir_is_valid_provider_status($status) {
    return in_array($status, hammasir_provider_statuses(), true);
}

function hammasir_event_types() {
    return array('LINK_REQUESTED', 'LINK_ACCEPTED', 'LINK_DECLINED', 'LINK_REVOKED', 'LINK_CANCELLED');
}

function hammasir_is_valid_event_type($type) {
    return in_array($type, hammasir_event_types(), true);
}

function hammasir_change_sources() {
    return array('INITIAL_CONSENT', 'CLIENT_UPDATE', 'PROVIDER_MESSAGE_SETTING', 'SYSTEM');
}

function hammasir_is_valid_change_source($source) {
    return in_array($source, hammasir_change_sources(), true);
}

/* ==================================================================
 * بخش ۲) Config مستقل / Feature Flag / Policyها (D26/D28/D9/D40)
 * ================================================================== */

function hammasir_config() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = array();
    $file = dirname(__FILE__) . '/../config/hammasir_config.php';
    if (is_file($file)) {
        $HAMMASIR_CONFIG = null;
        include $file;
        if (is_array($HAMMASIR_CONFIG)) $cache = $HAMMASIR_CONFIG;
    }
    return $cache;
}

function hammasir_enabled() {
    $cfg = hammasir_config();
    // fail-closed (D28): نبود فایل یا هر مقداری غیر true → خاموش
    return isset($cfg['hammasir_enabled']) && $cfg['hammasir_enabled'] === true;
}

function hammasir_policy_defaults() {
    // تنها نقطه‌ی تعریف مقادیر پیش‌فرض policyها (D9/D40)
    return array(
        'daily_message_limit' => 3,
        'companion_daily_message_limit' => 20,
        'message_cooldown_seconds' => 5,
        're_request_cooldown_hours' => 24,
    );
}

function hammasir_policy($key) {
    // زنجیره‌ی واحد (D40): config مستقل هم‌مسیر → پیش‌فرض یک‌نقطه‌ای
    $cfg = hammasir_config();
    if (isset($cfg[$key]) && is_int($cfg[$key]) && $cfg[$key] > 0) return $cfg[$key];
    $defaults = hammasir_policy_defaults();
    if (isset($defaults[$key]) && $defaults[$key] > 0) return $defaults[$key];
    return null;
}

function hammasir_message_daily_limit() {
    return hammasir_policy('daily_message_limit');
}

function hammasir_companion_daily_limit() {
    return hammasir_policy('companion_daily_message_limit');
}

function hammasir_message_cooldown_seconds() {
    return hammasir_policy('message_cooldown_seconds');
}

function hammasir_re_request_cooldown_hours() {
    return hammasir_policy('re_request_cooldown_hours');
}

/* ==================================================================
 * بخش ۳) زمان (D35) و پیش‌نیاز محیط (AC1.7 — fail-closed)
 * ================================================================== */

function hammasir_now() {
    // زمان سرور ماژول با TZ صریح Asia/Tehran — مستقل از TZ پیش‌فرض سرور (D35)
    $dt = new DateTime('now', new DateTimeZone(HAMMASIR_TZ));
    return $dt->format('Y-m-d H:i:s');
}

function hammasir_jalali_today() {
    // روز جاری شمسی با TZ صریح Asia/Tehran (D35).
    // تبدیل شمسی با توابع فعلی JOMA (بدون تغییر آن‌ها) انجام می‌شود؛
    // اگر توابع JOMA در دسترس نباشند، fail-closed (null) — بدون fallback به date() سرور.
    if (!function_exists('gregorian_to_jalali') || !function_exists('jalali_pad')) {
        return null;
    }
    $dt = new DateTime('now', new DateTimeZone(HAMMASIR_TZ));
    $p = gregorian_to_jalali((int) $dt->format('Y'), (int) $dt->format('n'), (int) $dt->format('j'));
    return $p[0] . '-' . jalali_pad($p[1]) . '-' . jalali_pad($p[2]);
}

function hammasir_mbstring_available() {
    return function_exists('mb_strlen');
}

function hammasir_mb_strlen($s) {
    // wrapper واحد طول متن (حکم PO — بستن 1C):
    // تمام اعتبارسنجی‌های طول (title/body) فقط از همین تابع انجام می‌شوند.
    // fail-closed: بدون mbstring هرگز strlen جایگزین نمی‌شود (AC1.7/R18 — استثنای مستند PC).
    // خروجی: طول صحیح | false در نبود mbstring → عملیات رد می‌شود.
    if (!hammasir_mbstring_available()) return false;
    return mb_strlen((string) $s);
}

function hammasir_env_ok() {
    // پیش‌نیاز محیطی ماژول؛ فعال‌سازی Feature تا رفع پیش‌نیاز مجاز نیست (AC1.7/R18).
    // صریح: اگر function_exists('mb_strlen') برقرار نباشد → env_ok = false → fail-closed کامل.
    return function_exists('mb_strlen');
}

function hammasir_validate_message_body($body) {
    // اعتبارسنجی بدنه‌ی پیام (D11) — سمت سرور؛ طول فقط از طریق hammasir_mb_strlen (fail-closed)
    $body = trim((string) $body);
    if ($body === '') {
        return array('ok' => false, 'error' => 'empty');
    }
    $len = hammasir_mb_strlen($body);
    if ($len === false) {
        return array('ok' => false, 'error' => 'env');
    }
    if ($len > HAMMASIR_MESSAGE_MAX_LEN) {
        return array('ok' => false, 'error' => 'too_long');
    }
    return array('ok' => true, 'body' => $body);
}

/* ==================================================================
 * بخش ۴) File mode — storage مستقل (D16/D24 — گزینه A)
 * ------------------------------------------------------------------
 * - storage فقط data/hammasir/store.json ؛ قفل فقط data/hammasir/store.lock
 * - هیچ خواندن/نوشتی روی data/store.json یا writerهای فعلی JOMA انجام نمی‌شود.
 * - ساخت پوشه/فایل فقط «lazy» و در اولین mutation واقعی انجام می‌شود
 *   (در Phase 1A هیچ mutation واقعی اجرا نمی‌شود).
 * - شکست load → هیچ نوشتی انجام نمی‌شود.
 * - ذخیره: فایل موقت در همان دایرکتوری + rename اتمیک؛
 *   JSON پیش از rename اعتبارسنجی می‌شود.
 * - پیش از اولین بازنویسی store.json، نسخه‌ی ابتدای عمر داده در
 *   store.json.bak حفظ می‌شود (backup پیش از اولین ذخیره ماژول).
 * ================================================================== */

function hammasir_store_dir() {
    return dirname(__FILE__) . '/../data/hammasir';
}

function hammasir_store_path() {
    return hammasir_store_dir() . '/store.json';
}

function hammasir_store_lock_path() {
    return hammasir_store_dir() . '/store.lock';
}

function hammasir_store_empty() {
    // ۶ موجودیت کسب‌وکاری + seq — بدون کلید settings (D40)
    return array(
        'providers' => array(),
        'links' => array(),
        'permissions' => array(),
        'permission_history' => array(),
        'messages' => array(),
        'system_events' => array(),
        'seq' => 1,
    );
}

function hammasir_next_id(&$store) {
    $id = isset($store['seq']) ? (int) $store['seq'] : 1;
    $store['seq'] = $id + 1;
    return $id;
}

function hammasir_store_load() {
    // خواندن بدون هیچ نوشتن/ساخت پوشه‌ای.
    // خطا/خرابی JSON → null (fail-closed)؛ فراخواننده نباید در این حالت بنویسد.
    $path = hammasir_store_path();
    if (!is_file($path)) return hammasir_store_empty();
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') return null;
    $data = json_decode($raw, true);
    if (!is_array($data)) return null;
    $base = hammasir_store_empty();
    foreach ($base as $k => $v) {
        if (!array_key_exists($k, $data)) $data[$k] = $v;
    }
    return $data;
}

function hammasir_store_save_atomic($data) {
    $dir = hammasir_store_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return false;
    $path = hammasir_store_path();
    $bak = $path . '.bak';
    // backup فقط یک‌بار، پیش از اولین بازنویسی (حفظ ابتدای عمر داده)
    if (is_file($path) && !is_file($bak)) {
        if (!@copy($path, $bak)) return false;
    }
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    if ($json === false || $json === '') return false;
    // اعتبارسنجی JSON پیش از rename
    if (!is_array(json_decode($json, true))) return false;
    $tmp = $path . '.tmp.' . uniqid('', true);
    if (@file_put_contents($tmp, $json) === false) {
        @unlink($tmp);
        return false;
    }
    // rename در همان دایرکتوری = اتمیک روی همان فایل‌سیستم
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

function hammasir_store_mutate($callback) {
    // الگوی واحد mutation در file mode (D14/D15 — معادل قفل canonical + تراکنش):
    //   قفل فایل انحصاری (مهلت HAMMASIR_LOCK_TIMEOUT ثانیه) → خواندن →
    //   callback(&$store) → ذخیره‌ی اتمیک → آزادسازی قفل در هر مسیر.
    //
    // قرارداد callback:
    //   function (&$store) use (...) { ... }
    //   - return false → لغو کامل بدون ذخیره
    //   - return array/مقدار → ذخیره و همان نتیجه برگردانده می‌شود
    //   - return null → ذخیره و true برگردانده می‌شود
    $dir = hammasir_store_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return false;
    $lock = @fopen(hammasir_store_lock_path(), 'c');
    if (!$lock) return false;
    $deadline = microtime(true) + (float) HAMMASIR_LOCK_TIMEOUT;
    $locked = false;
    while (true) {
        $locked = @flock($lock, LOCK_EX | LOCK_NB);
        if ($locked) break;
        if (microtime(true) >= $deadline) break;
        usleep(50000);
    }
    if (!$locked) {
        @fclose($lock);
        return false; // معادل خطای timeout قفل: «لطفاً دوباره تلاش کنید.»
    }
    try {
        $store = hammasir_store_load();
        if ($store === null) return false; // شکست load → هیچ نوشتی
        $result = $callback($store);
        if ($result === false) return false;
        if (!hammasir_store_save_atomic($store)) return false;
        return ($result === null) ? true : $result;
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

/* ==================================================================
 * بخش ۵) قفل canonical و تراکنش MySQL (D14/D15)
 * ------------------------------------------------------------------
 * - قفل نامدار joma_hammasir_client_{client_user_id} با مهلت ۲ ثانیه
 *   روی «همان اتصال» مشترک JOMA (db())؛ بدون اتصال جدید.
 * - ترتیب: GET_LOCK → BEGIN → callback($mysqli) → COMMIT / ROLLBACK
 *   → آزادسازی تضمین‌شده‌ی قفل در finally (هر دو مسیر موفق/خطا).
 * - در file mode این تابع کاربرد ندارد؛ قفل canonical همان قفل فایل
 *   داخل hammasir_store_mutate است (D14/D22) و false برمی‌گردد.
 * ================================================================== */

function hammasir_lock_name($client_user_id) {
    // R6: joma_hammasir_client_ + id — بسیار کوتاه‌تر از سقف طول نام قفل MySQL
    return 'joma_hammasir_client_' . (int) $client_user_id;
}

function hammasir_with_lock($client_user_id, $fn) {
    // D-1 (PHP 8.1): خطاهای mysqli به‌صورت exception پرتاب می‌شوند؛ کل مسیر — از جمله
    // GET_LOCK و db() — داخل try مهار می‌شود و نتیجه به کد داخلی (false/نتیجه) تبدیل می‌گردد.
    // آزادسازی قفل در finally با مهار خودش؛ rollback در catch با مهار خودش (بدون پرتاب به بیرون).
    if (store_mode() !== 'mysql') {
        // در file mode از hammasir_store_mutate استفاده شود
        return false;
    }
    $mysqli = null;
    $name = hammasir_lock_name($client_user_id);
    $lock_acquired = false;
    $in_txn = false;
    try {
        $mysqli = db();
        if (!$mysqli) return false;
        $row = joma_query_one('SELECT GET_LOCK(?, ' . (int) HAMMASIR_LOCK_TIMEOUT . ')', 's', array($name));
        if (!$row || (int) current($row) !== 1) return false; // timeout → «لطفاً دوباره تلاش کنید.»
        $lock_acquired = true;
        if (!mysqli_begin_transaction($mysqli)) return false;
        $in_txn = true;
        $result = call_user_func($fn, $mysqli);
        if ($result === false) {
            mysqli_rollback($mysqli);
            $in_txn = false;
            return false;
        }
        if (!mysqli_commit($mysqli)) {
            mysqli_rollback($mysqli);
            $in_txn = false;
            return false;
        }
        $in_txn = false;
        return ($result === null) ? true : $result;
    } catch (Throwable $e) {
        if ($in_txn && $mysqli) {
            try { @mysqli_rollback($mysqli); } catch (Throwable $e2) { /* rollback ناموفق؛ اتصال بسته می‌شود */ }
        }
        return false;
    } finally {
        if ($lock_acquired) {
            try {
                joma_exec('SELECT RELEASE_LOCK(?)', 's', array($name));
            } catch (Throwable $e3) {
                // آزادسازی صریح ناموفق؛ ایمنی آخر: آزادسازی خودکار MySQL در پایان اتصال (D1)
            }
        }
    }
}

/* ==================================================================
 * بخش ۶) موجودیت‌ها — خواندن (دو شاخه mysql/file)
 * ------------------------------------------------------------------
 * خواندن‌ها بدون قفل (الگوی فعلی JOMA)؛ همه‌ی نوشتن‌ها فقط از طریق
 * عملیات مرکب فازهای بعد و داخل قفل canonical انجام می‌شوند.
 * در شاخه file، خرابی storage → null (fail-closed، نه آرایه‌ی خالی).
 * در شاخه mysql، خطای query توسط helperهای فعلی JOMA به نتیجه‌ی خالی
 * تبدیل می‌شود؛ تفکیک خطای DB در محیط test بررسی می‌شود.
 * ================================================================== */

function hammasir_provider_by_user_id($user_id) {
    if (store_mode() === 'mysql') {
        return joma_query_one('SELECT * FROM joma_hammasir_providers WHERE user_id=?', 'i', array((int) $user_id));
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    foreach ($store['providers'] as $p) {
        if ((int) $p['user_id'] === (int) $user_id) return $p;
    }
    return null;
}

function hammasir_provider_list($only_active = true) {
    if (store_mode() === 'mysql') {
        $sql = 'SELECT * FROM joma_hammasir_providers';
        if ($only_active) $sql .= " WHERE status = 'ACTIVE'";
        $sql .= ' ORDER BY title ASC, user_id ASC';
        return joma_query($sql, '', array());
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $out = array();
    foreach ($store['providers'] as $p) {
        if ($only_active && $p['status'] !== 'ACTIVE') continue;
        $out[] = $p;
    }
    usort($out, function ($a, $b) {
        $c = strcmp($a['title'], $b['title']);
        if ($c !== 0) return $c;
        return (int) $a['user_id'] - (int) $b['user_id'];
    });
    return $out;
}

function hammasir_link_get($link_id) {
    if (store_mode() === 'mysql') {
        return joma_query_one('SELECT * FROM joma_hammasir_links WHERE id=?', 'i', array((int) $link_id));
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    foreach ($store['links'] as $l) {
        if ((int) $l['id'] === (int) $link_id) return $l;
    }
    return null;
}

function hammasir_link_open_by_client($client_user_id) {
    // D6: حداکثر یک لینک باز (PENDING/ACTIVE) — اعمال در کد داخل قفل؛
    // این خواندن فقط «وجود/عدم وجود» لینک باز را برمی‌گرداند.
    if (store_mode() === 'mysql') {
        return joma_query_one(
            "SELECT * FROM joma_hammasir_links WHERE client_user_id=? AND status IN ('PENDING','ACTIVE') ORDER BY id DESC LIMIT 1",
            'i',
            array((int) $client_user_id)
        );
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $found = null;
    foreach ($store['links'] as $l) {
        if ((int) $l['client_user_id'] === (int) $client_user_id
            && ($l['status'] === 'PENDING' || $l['status'] === 'ACTIVE')) {
            if ($found === null || (int) $l['id'] > (int) $found['id']) $found = $l;
        }
    }
    return $found;
}

function hammasir_links_by_provider($provider_user_id, $status = null) {
    $want = null;
    if ($status !== null) {
        if (!hammasir_is_valid_link_status($status)) return array();
        $want = $status;
    }
    if (store_mode() === 'mysql') {
        if ($want !== null) {
            return joma_query(
                'SELECT * FROM joma_hammasir_links WHERE provider_user_id=? AND status=? ORDER BY id DESC',
                'is',
                array((int) $provider_user_id, $want)
            );
        }
        return joma_query('SELECT * FROM joma_hammasir_links WHERE provider_user_id=? ORDER BY id DESC', 'i', array((int) $provider_user_id));
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $out = array();
    foreach ($store['links'] as $l) {
        if ((int) $l['provider_user_id'] !== (int) $provider_user_id) continue;
        if ($want !== null && $l['status'] !== $want) continue;
        $out[] = $l;
    }
    return array_reverse($out);
}

function hammasir_links_closed_between($client_user_id, $provider_user_id) {
    // همه‌ی ارتباط‌های بسته (DECLINED/REVOKED) بین یک جفت مراجع/همراه — مبنای D34
    if (store_mode() === 'mysql') {
        return joma_query(
            "SELECT * FROM joma_hammasir_links WHERE client_user_id=? AND provider_user_id=? AND status IN ('DECLINED','REVOKED') ORDER BY id DESC",
            'ii',
            array((int) $client_user_id, (int) $provider_user_id)
        );
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $out = array();
    foreach ($store['links'] as $l) {
        if ((int) $l['client_user_id'] === (int) $client_user_id
            && (int) $l['provider_user_id'] === (int) $provider_user_id
            && ($l['status'] === 'DECLINED' || $l['status'] === 'REVOKED')) {
            $out[] = $l;
        }
    }
    return array_reverse($out);
}

function hammasir_re_request_block_until($client_user_id, $provider_user_id) {
    // D34: لحظه‌ی بازشدن مجوز درخواست مجدد (unix timestamp) برای همان جفت؛
    // null = بدون محدودیت. مبنای محاسبه: declined_at / revoked_at سرور
    // (شامل REVOKED توسط هر طرف و لغو PENDING توسط مراجع — PENDING→REVOKED طبق D20).
    $rows = hammasir_links_closed_between($client_user_id, $provider_user_id);
    if ($rows === null) return null;
    $max = null;
    foreach ($rows as $l) {
        $t = null;
        if ($l['status'] === 'DECLINED' && isset($l['declined_at']) && $l['declined_at'] !== '') {
            $t = $l['declined_at'];
        } elseif (isset($l['revoked_at']) && $l['revoked_at'] !== '') {
            $t = $l['revoked_at'];
        }
        if ($t !== null && ($max === null || strcmp($t, $max) > 0)) $max = $t;
    }
    if ($max === null) return null;
    $hours = hammasir_policy('re_request_cooldown_hours');
    if ($hours === null || $hours < 1) return null;
    $ts = strtotime($max . ' ' . HAMMASIR_TZ);
    if ($ts === false) return null;
    return $ts + $hours * 3600;
}

function hammasir_permissions_for_link($link_id) {
    if (store_mode() === 'mysql') {
        $rows = joma_query('SELECT perm_key, enabled FROM joma_hammasir_permissions WHERE link_id=?', 'i', array((int) $link_id));
        $map = array();
        foreach ($rows as $r) {
            $map[$r['perm_key']] = ((int) $r['enabled'] === 1);
        }
        return $map;
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $map = array();
    foreach ($store['permissions'] as $p) {
        if ((int) $p['link_id'] === (int) $link_id) {
            $map[$p['perm_key']] = ((int) $p['enabled'] === 1);
        }
    }
    return $map;
}

function hammasir_permission_history_for_link($link_id) {
    if (store_mode() === 'mysql') {
        return joma_query('SELECT * FROM joma_hammasir_permission_history WHERE link_id=? ORDER BY id ASC', 'i', array((int) $link_id));
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $out = array();
    foreach ($store['permission_history'] as $h) {
        if ((int) $h['link_id'] === (int) $link_id) $out[] = $h;
    }
    return $out;
}

function hammasir_messages_count_today($link_id, $sender_user_id, $jalali_date) {
    // شمارش سقف روزانه: link + sender + تاریخ شمسی (D32/P7 — تاریخ فقط از hammasir_jalali_today)
    if (store_mode() === 'mysql') {
        $row = joma_query_one(
            'SELECT COUNT(*) AS c FROM joma_hammasir_messages WHERE link_id=? AND sender_user_id=? AND jalali_date=?',
            'iis',
            array((int) $link_id, (int) $sender_user_id, (string) $jalali_date)
        );
        return $row ? (int) $row['c'] : null;
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $n = 0;
    foreach ($store['messages'] as $m) {
        if ((int) $m['link_id'] === (int) $link_id
            && (int) $m['sender_user_id'] === (int) $sender_user_id
            && $m['jalali_date'] === $jalali_date) {
            $n++;
        }
    }
    return $n;
}

function hammasir_messages_last_sender_time($link_id, $sender_user_id) {
    // آخرین زمان ارسال همان link+sender — مبنای کول‌داون (P3)
    if (store_mode() === 'mysql') {
        $row = joma_query_one(
            'SELECT created_at FROM joma_hammasir_messages WHERE link_id=? AND sender_user_id=? ORDER BY created_at DESC, id DESC LIMIT 1',
            'ii',
            array((int) $link_id, (int) $sender_user_id)
        );
        return $row ? $row['created_at'] : null;
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $max = null;
    foreach ($store['messages'] as $m) {
        if ((int) $m['link_id'] === (int) $link_id && (int) $m['sender_user_id'] === (int) $sender_user_id) {
            if ($max === null || strcmp($m['created_at'], $max) > 0) $max = $m['created_at'];
        }
    }
    return $max;
}

function hammasir_messages_page($link_id, $before_id = 0, $limit = 0) {
    // D36/P6/AC4.9: پیش‌فرض آخرین ۱۰۰ پیام + امکان قدیمی‌تر (id < before_id)؛
    // خروجی صعودی (قدیمی بالا، جدید پایین)؛ ترتیب پایدار created_at سپس id.
    if ($limit < 1) $limit = HAMMASIR_PAGE_SIZE;
    if (store_mode() === 'mysql') {
        $sql = 'SELECT * FROM joma_hammasir_messages WHERE link_id=?';
        $types = 'i';
        $values = array((int) $link_id);
        if ($before_id > 0) {
            $sql .= ' AND id < ?';
            $types .= 'i';
            $values[] = (int) $before_id;
        }
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ?';
        $types .= 'i';
        $values[] = (int) $limit;
        return array_reverse(joma_query($sql, $types, $values));
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $out = array();
    foreach ($store['messages'] as $m) {
        if ((int) $m['link_id'] !== (int) $link_id) continue;
        if ($before_id > 0 && (int) $m['id'] >= (int) $before_id) continue;
        $out[] = $m;
    }
    if (count($out) > $limit) $out = array_slice($out, -$limit);
    return $out;
}

function hammasir_messages_unread_count($recipient_user_id) {
    // Badge پیام متنی: فقط لینک‌های ACTIVE (D21/AC5.4)
    if (store_mode() === 'mysql') {
        $row = joma_query_one(
            "SELECT COUNT(*) AS c FROM joma_hammasir_messages m INNER JOIN joma_hammasir_links l ON m.link_id = l.id WHERE m.recipient_user_id=? AND m.is_read=0 AND l.status='ACTIVE'",
            'i',
            array((int) $recipient_user_id)
        );
        return $row ? (int) $row['c'] : null;
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $active = array();
    foreach ($store['links'] as $l) {
        if ($l['status'] === 'ACTIVE') $active[(int) $l['id']] = true;
    }
    $n = 0;
    foreach ($store['messages'] as $m) {
        if ((int) $m['recipient_user_id'] === (int) $recipient_user_id
            && (int) $m['is_read'] === 0
            && isset($active[(int) $m['link_id']])) {
            $n++;
        }
    }
    return $n;
}

function hammasir_events_unread_count($recipient_user_id) {
    // Badge رویداد سیستمی: مستقل از وضعیت لینک (D21/AC5.5)
    if (store_mode() === 'mysql') {
        $row = joma_query_one(
            'SELECT COUNT(*) AS c FROM joma_hammasir_system_events WHERE recipient_user_id=? AND is_read=0',
            'i',
            array((int) $recipient_user_id)
        );
        return $row ? (int) $row['c'] : null;
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $n = 0;
    foreach ($store['system_events'] as $ev) {
        if ((int) $ev['recipient_user_id'] === (int) $recipient_user_id && (int) $ev['is_read'] === 0) $n++;
    }
    return $n;
}

function hammasir_events_list($recipient_user_id, $limit = 0) {
    // رویدادهای سیستمی recipient — جدیدترین اول؛ ترتیب پایدار created_at سپس id (D32)
    if ($limit < 1) $limit = HAMMASIR_PAGE_SIZE;
    if (store_mode() === 'mysql') {
        return joma_query(
            'SELECT * FROM joma_hammasir_system_events WHERE recipient_user_id=? ORDER BY created_at DESC, id DESC LIMIT ?',
            'ii',
            array((int) $recipient_user_id, (int) $limit)
        );
    }
    $store = hammasir_store_load();
    if ($store === null) return null;
    $out = array();
    foreach ($store['system_events'] as $ev) {
        if ((int) $ev['recipient_user_id'] === (int) $recipient_user_id) $out[] = $ev;
    }
    if (count($out) > $limit) $out = array_slice($out, -$limit);
    return array_reverse($out);
}

/* ==================================================================
 * بخش ۷) موجودیت‌ها — نوشتن (primitiveهای دو شاخه)
 * ------------------------------------------------------------------
 * قواعد مهم (D14/D15):
 * - این توابع هرگز مستقیماً از UI/route صدا زده نمی‌شوند.
 * - شاخه db_*: فقط داخل callbackِ hammasir_with_lock
 *   (قفل نامدار + تراکنش روی همان اتصال).
 * - شاخه file_*: فقط داخل callbackِ hammasir_store_mutate روی &$store؛
 *   نوشتن‌های چندگانه در یک callback یکجا و اتمیک اعمال می‌شوند.
 * - عملیات‌های مرکب (ساخت درخواست، ارسال پیام و…) در فازهای بعد
 *   روی همین primitiveها ساخته می‌شوند.
 * ================================================================== */

function hammasir_db_last_insert_id() {
    $mysqli = db();
    return $mysqli ? (int) mysqli_insert_id($mysqli) : 0;
}

/* ---------- providers (D30) ---------- */

function hammasir_db_provider_upsert($user_id, $title, $status) {
    if (!hammasir_is_valid_provider_status($status)) return false;
    $now = hammasir_now();
    return joma_exec(
        'INSERT INTO joma_hammasir_providers (user_id, title, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE title = VALUES(title), status = VALUES(status), updated_at = VALUES(updated_at)',
        'issss',
        array((int) $user_id, (string) $title, $status, $now, $now)
    );
}

function hammasir_file_provider_upsert(&$store, $user_id, $title, $status) {
    if (!hammasir_is_valid_provider_status($status)) return false;
    $now = hammasir_now();
    foreach ($store['providers'] as $i => $p) {
        if ((int) $p['user_id'] === (int) $user_id) {
            $store['providers'][$i]['title'] = (string) $title;
            $store['providers'][$i]['status'] = $status;
            $store['providers'][$i]['updated_at'] = $now;
            return (int) $p['id'];
        }
    }
    $id = hammasir_next_id($store);
    $store['providers'][] = array(
        'id' => $id,
        'user_id' => (int) $user_id,
        'status' => $status,
        'title' => (string) $title,
        'created_at' => $now,
        'updated_at' => $now,
    );
    return $id;
}

/* ---------- links (D6/D20/D34) ---------- */

function hammasir_db_link_insert($provider_user_id, $client_user_id, $consent_text, $consent_version) {
    // لینک جدید همیشه PENDING است (D20)؛ درخواست = فاز ۲
    $now = hammasir_now();
    $ok = joma_exec(
        'INSERT INTO joma_hammasir_links (provider_user_id, client_user_id, status, consent_text, consent_version, requested_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        'iissssss',
        array((int) $provider_user_id, (int) $client_user_id, 'PENDING', (string) $consent_text, (string) $consent_version, $now, $now, $now)
    );
    return $ok ? hammasir_db_last_insert_id() : 0;
}

function hammasir_file_link_insert(&$store, $provider_user_id, $client_user_id, $consent_text, $consent_version) {
    $now = hammasir_now();
    $id = hammasir_next_id($store);
    $store['links'][] = array(
        'id' => $id,
        'provider_user_id' => (int) $provider_user_id,
        'client_user_id' => (int) $client_user_id,
        'status' => 'PENDING',
        'consent_text' => (string) $consent_text,
        'consent_version' => (string) $consent_version,
        'requested_at' => $now,
        'accepted_at' => null,
        'declined_at' => null,
        'revoked_at' => null,
        'revoked_by_user_id' => null,
        'created_at' => $now,
        'updated_at' => $now,
    );
    return $id;
}

function hammasir_link_patch_fields() {
    // ستون‌های مجاز تغییر لینک — whitelist ثابت (بدون ورودی کاربر در نام ستون)
    return array('status', 'accepted_at', 'declined_at', 'revoked_at', 'revoked_by_user_id', 'updated_at');
}

function hammasir_db_link_patch($link_id, $patch) {
    if (isset($patch['status']) && !hammasir_is_valid_link_status($patch['status'])) return false;
    $sets = array();
    $types = '';
    $values = array();
    foreach (hammasir_link_patch_fields() as $f) {
        if (!array_key_exists($f, $patch)) continue;
        $sets[] = $f . ' = ?';
        if ($f === 'revoked_by_user_id') {
            $types .= 'i';
            $values[] = ($patch[$f] === null) ? null : (int) $patch[$f];
        } else {
            $types .= 's';
            $values[] = (string) $patch[$f];
        }
    }
    if (count($sets) === 0) return false;
    if (!array_key_exists('updated_at', $patch)) {
        $sets[] = 'updated_at = ?';
        $types .= 's';
        $values[] = hammasir_now();
    }
    $types .= 'i';
    $values[] = (int) $link_id;
    return joma_exec('UPDATE joma_hammasir_links SET ' . implode(', ', $sets) . ' WHERE id = ?', $types, $values);
}

function hammasir_file_link_patch(&$store, $link_id, $patch) {
    if (isset($patch['status']) && !hammasir_is_valid_link_status($patch['status'])) return false;
    foreach ($store['links'] as $i => $l) {
        if ((int) $l['id'] !== (int) $link_id) continue;
        foreach (hammasir_link_patch_fields() as $f) {
            if (!array_key_exists($f, $patch)) continue;
            if ($f === 'revoked_by_user_id') {
                $store['links'][$i][$f] = ($patch[$f] === null) ? null : (int) $patch[$f];
            } else {
                $store['links'][$i][$f] = $patch[$f];
            }
        }
        if (!array_key_exists('updated_at', $patch)) {
            $store['links'][$i]['updated_at'] = hammasir_now();
        }
        return true;
    }
    return false;
}

/* ---------- permissions (D5/D18/D37) ---------- */

function hammasir_db_permission_set($link_id, $perm_key, $enabled, $changed_by_user_id) {
    if (!hammasir_is_valid_perm_key($perm_key)) return false;
    $now = hammasir_now();
    return joma_exec(
        'INSERT INTO joma_hammasir_permissions (link_id, perm_key, enabled, changed_by_user_id, changed_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE enabled = VALUES(enabled), changed_by_user_id = VALUES(changed_by_user_id), changed_at = VALUES(changed_at)',
        'isiis',
        array((int) $link_id, $perm_key, $enabled ? 1 : 0, (int) $changed_by_user_id, $now)
    );
}

function hammasir_file_permission_set(&$store, $link_id, $perm_key, $enabled, $changed_by_user_id) {
    if (!hammasir_is_valid_perm_key($perm_key)) return false;
    $now = hammasir_now();
    foreach ($store['permissions'] as $i => $p) {
        if ((int) $p['link_id'] === (int) $link_id && $p['perm_key'] === $perm_key) {
            $store['permissions'][$i]['enabled'] = $enabled ? 1 : 0;
            $store['permissions'][$i]['changed_by_user_id'] = (int) $changed_by_user_id;
            $store['permissions'][$i]['changed_at'] = $now;
            return true;
        }
    }
    $store['permissions'][] = array(
        'id' => hammasir_next_id($store),
        'link_id' => (int) $link_id,
        'perm_key' => $perm_key,
        'enabled' => $enabled ? 1 : 0,
        'changed_by_user_id' => (int) $changed_by_user_id,
        'changed_at' => $now,
    );
    return true;
}

/* ---------- permission_history (D18 — append-only) ---------- */

function hammasir_db_permission_history_add($link_id, $perm_key, $previous_enabled, $enabled, $changed_by_user_id, $change_source) {
    if (!hammasir_is_valid_perm_key($perm_key)) return false;
    if (!hammasir_is_valid_change_source($change_source)) return false;
    return joma_exec(
        'INSERT INTO joma_hammasir_permission_history (link_id, perm_key, previous_enabled, enabled, changed_by_user_id, change_source, changed_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        'isiiiss',
        array((int) $link_id, $perm_key, (int) $previous_enabled, (int) $enabled, (int) $changed_by_user_id, $change_source, hammasir_now())
    );
}

function hammasir_file_permission_history_add(&$store, $link_id, $perm_key, $previous_enabled, $enabled, $changed_by_user_id, $change_source) {
    if (!hammasir_is_valid_perm_key($perm_key)) return false;
    if (!hammasir_is_valid_change_source($change_source)) return false;
    $store['permission_history'][] = array(
        'id' => hammasir_next_id($store),
        'link_id' => (int) $link_id,
        'perm_key' => $perm_key,
        'previous_enabled' => (int) $previous_enabled,
        'enabled' => (int) $enabled,
        'changed_by_user_id' => (int) $changed_by_user_id,
        'change_source' => $change_source,
        'changed_at' => hammasir_now(),
    );
    return true;
}

/* ---------- messages (D11/P3/P6) ---------- */

function hammasir_db_message_insert($link_id, $sender_user_id, $recipient_user_id, $jalali_date, $body) {
    // jalali_date فقط server-generated (hammasir_jalali_today) — هرگز از client (P7)
    return joma_exec(
        'INSERT INTO joma_hammasir_messages (link_id, sender_user_id, recipient_user_id, jalali_date, body, is_read, read_at, created_at) VALUES (?, ?, ?, ?, ?, 0, NULL, ?)',
        'iiisss',
        array((int) $link_id, (int) $sender_user_id, (int) $recipient_user_id, (string) $jalali_date, (string) $body, hammasir_now())
    );
}

function hammasir_file_message_insert(&$store, $link_id, $sender_user_id, $recipient_user_id, $jalali_date, $body) {
    $store['messages'][] = array(
        'id' => hammasir_next_id($store),
        'link_id' => (int) $link_id,
        'sender_user_id' => (int) $sender_user_id,
        'recipient_user_id' => (int) $recipient_user_id,
        'jalali_date' => (string) $jalali_date,
        'body' => (string) $body,
        'is_read' => 0,
        'read_at' => null,
        'created_at' => hammasir_now(),
    );
    return true;
}

function hammasir_db_messages_mark_read($recipient_user_id) {
    // فقط پیام‌های recipient جاری (D11)
    return joma_exec(
        'UPDATE joma_hammasir_messages SET is_read = 1, read_at = ? WHERE recipient_user_id = ? AND is_read = 0',
        'si',
        array(hammasir_now(), (int) $recipient_user_id)
    );
}

function hammasir_file_messages_mark_read(&$store, $recipient_user_id) {
    $now = hammasir_now();
    foreach ($store['messages'] as $i => $m) {
        if ((int) $m['recipient_user_id'] === (int) $recipient_user_id && (int) $m['is_read'] === 0) {
            $store['messages'][$i]['is_read'] = 1;
            $store['messages'][$i]['read_at'] = $now;
        }
    }
    return true;
}

/* ---------- system_events (D17/D21) ---------- */

function hammasir_db_event_add($link_id, $event_type, $actor_user_id, $recipient_user_id) {
    // متن رویداد از template ثابت UI تولید می‌شود؛ body آزاد ذخیره نمی‌شود (D17)
    if (!hammasir_is_valid_event_type($event_type)) return false;
    return joma_exec(
        'INSERT INTO joma_hammasir_system_events (link_id, event_type, actor_user_id, recipient_user_id, is_read, read_at, created_at) VALUES (?, ?, ?, ?, 0, NULL, ?)',
        'isiis',
        array((int) $link_id, $event_type, (int) $actor_user_id, (int) $recipient_user_id, hammasir_now())
    );
}

function hammasir_file_event_add(&$store, $link_id, $event_type, $actor_user_id, $recipient_user_id) {
    if (!hammasir_is_valid_event_type($event_type)) return false;
    $store['system_events'][] = array(
        'id' => hammasir_next_id($store),
        'link_id' => (int) $link_id,
        'event_type' => $event_type,
        'actor_user_id' => (int) $actor_user_id,
        'recipient_user_id' => (int) $recipient_user_id,
        'is_read' => 0,
        'read_at' => null,
        'created_at' => hammasir_now(),
    );
    return true;
}

function hammasir_db_events_mark_read($recipient_user_id) {
    // فقط رویدادهای recipient جاری (D17/D21)
    return joma_exec(
        'UPDATE joma_hammasir_system_events SET is_read = 1, read_at = ? WHERE recipient_user_id = ? AND is_read = 0',
        'si',
        array(hammasir_now(), (int) $recipient_user_id)
    );
}

function hammasir_file_events_mark_read(&$store, $recipient_user_id) {
    $now = hammasir_now();
    foreach ($store['system_events'] as $i => $ev) {
        if ((int) $ev['recipient_user_id'] === (int) $recipient_user_id && (int) $ev['is_read'] === 0) {
            $store['system_events'][$i]['is_read'] = 1;
            $store['system_events'][$i]['read_at'] = $now;
        }
    }
    return true;
}

/* ==================================================================
 * بخش ۸) Provider Registry (D30/D41) — Phase 1C
 * ------------------------------------------------------------------
 * - قفل مستقل عملیات Registry: joma_hammasir_provider_{user_id} (D41)
 *   در MySQL داخل تراکنش (D15) روی همان اتصال مشترک؛ در file داخل
 *   hammasir_store_mutate (قفل فایل سراسری storage مستقل — گزینه A).
 * - یکتایی user_id و وضعیت لینک‌های باز، داخل قفل/تراکنش re-check می‌شوند (D20/D22).
 * - همه‌ی نوشتن‌ها فقط روی joma_hammasir_providers / storage مستقل؛
 *   خواندن کاربران JOMA فقط read-only و بدون هیچ نوشتن (ارجاع منطقی — D25).
 * - کدهای نتیجه (نگاشت به پیام‌های مصوب در UI):
 *   ok | invalid_user | duplicate | invalid_title | open_link | lock_timeout | error
 * ================================================================== */

function hammasir_provider_lock_name($user_id) {
    // D41 — قفل نام‌دار مستقل Registry (R6: بسیار کوتاه‌تر از سقف طول نام قفل MySQL)
    return 'joma_hammasir_provider_' . (int) $user_id;
}

function hammasir_registry_with_lock($provider_user_id, $fn) {
    // D41 + D15: قفل نام‌دار مستقل Registry + تراکنش روی همان اتصال.
    // خروجی: '__LOCK_TIMEOUT__' = نرسیدن به قفل در مهلت؛ false = خطا؛
    // در غیر این صورت نتیجه‌ی callback (false → rollback کامل).
    // D-1 (PHP 8.1): کل مسیر — از جمله GET_LOCK و db() — داخل try مهار می‌شود؛
    // آزادسازی قفل در finally با مهار خودش؛ rollback در catch با مهار خودش.
    if (store_mode() !== 'mysql') return false;
    $mysqli = null;
    $name = hammasir_provider_lock_name($provider_user_id);
    $lock_acquired = false;
    $in_txn = false;
    try {
        $mysqli = db();
        if (!$mysqli) return false;
        $row = joma_query_one('SELECT GET_LOCK(?, ' . (int) HAMMASIR_LOCK_TIMEOUT . ')', 's', array($name));
        if (!$row || (int) current($row) !== 1) return '__LOCK_TIMEOUT__';
        $lock_acquired = true;
        if (!mysqli_begin_transaction($mysqli)) return false;
        $in_txn = true;
        $result = call_user_func($fn, $mysqli);
        if ($result === false) {
            mysqli_rollback($mysqli);
            $in_txn = false;
            return false;
        }
        if (!mysqli_commit($mysqli)) {
            mysqli_rollback($mysqli);
            $in_txn = false;
            return false;
        }
        $in_txn = false;
        return ($result === null) ? true : $result;
    } catch (Throwable $e) {
        if ($in_txn && $mysqli) {
            try { @mysqli_rollback($mysqli); } catch (Throwable $e2) { /* rollback ناموفق؛ اتصال بسته می‌شود */ }
        }
        return false;
    } finally {
        if ($lock_acquired) {
            try {
                joma_exec('SELECT RELEASE_LOCK(?)', 's', array($name));
            } catch (Throwable $e3) {
                // آزادسازی صریح ناموفق؛ ایمنی آخر: آزادسازی خودکار MySQL در پایان اتصال (D1)
            }
        }
    }
}

function hammasir_user_select_max() {
    // سقف نمایش <select> کاربران (حکم PO — بستن 1C، بخش C):
    // زنجیره‌ی config مستقل هم‌مسیر → پیش‌فرض یک‌نقطه‌ای (همان الگوی D9/D40)
    $cfg = hammasir_config();
    if (isset($cfg['user_select_max']) && is_int($cfg['user_select_max']) && $cfg['user_select_max'] > 0) {
        return $cfg['user_select_max'];
    }
    return 200;
}

function hammasir_registry_user_options() {
    // کاربران موجود JOMA — فقط id + نام نمایشی/نام کاربری (بدون ایمیل/داده‌ی اضافی)؛ read-only.
    // LIMIT (max+1): تشخیص ارزانِ «از حد گذشت» → در آن حالت UI به‌جای select ورودی عددی می‌دهد (C-2).
    $out = array();
    $max = hammasir_user_select_max();
    if (store_mode() === 'mysql') {
        $rows = joma_query('SELECT id, first_name, last_name, username FROM joma_users ORDER BY username ASC LIMIT ' . (int) ($max + 1), '', array());
        foreach ($rows as $r) {
            $name = trim($r['first_name'] . ' ' . $r['last_name']);
            $out[] = array(
                'id' => (int) $r['id'],
                'display' => ($name !== '' ? $name . ' (' . $r['username'] . ')' : $r['username']),
            );
        }
        return $out;
    }
    $data = store_load();
    $users = isset($data['users']) ? $data['users'] : array();
    usort($users, function ($a, $b) { return strcmp($a['username'], $b['username']); });
    if (count($users) > $max + 1) {
        $users = array_slice($users, 0, $max + 1);
    }
    foreach ($users as $u) {
        $name = trim($u['first_name'] . ' ' . $u['last_name']);
        $out[] = array(
            'id' => (int) $u['id'],
            'display' => ($name !== '' ? $name . ' (' . $u['username'] . ')' : $u['username']),
        );
    }
    return $out;
}

function hammasir_registry_display_map() {
    // نگاشت user_id → نام نمایشی (فقط برای فهرست ادمین) — read-only
    $map = array();
    foreach (hammasir_registry_user_options() as $o) {
        $map[$o['id']] = $o['display'];
    }
    return $map;
}

function hammasir_registry_validate_user($user_id) {
    // اعتبارسنجی read-only وجود کاربر در منبع فعلی JOMA (ارجاع منطقی — D25/D30)
    $user_id = (int) $user_id;
    if ($user_id < 1) return false;
    if (store_mode() === 'mysql') {
        $row = joma_query_one('SELECT id FROM joma_users WHERE id=?', 'i', array($user_id));
        return $row ? true : false;
    }
    $data = store_load();
    foreach ($data['users'] as $u) {
        if ((int) $u['id'] === $user_id) return true;
    }
    return false;
}

function hammasir_registry_validate_title($title) {
    // عنوان همراه — اعتبارسنجی نهایی سمت سرور (نه فقط maxlength در UI):
    // trim + غیرخالی + حداکثر ۱۲۸ کاراکتر؛ طول فقط از طریق hammasir_mb_strlen (fail-closed — AC1.7)
    $title = trim((string) $title);
    if ($title === '') {
        return array('ok' => false, 'error' => 'invalid_title');
    }
    $len = hammasir_mb_strlen($title);
    if ($len === false) {
        return array('ok' => false, 'error' => 'env');
    }
    if ($len > 128) {
        return array('ok' => false, 'error' => 'invalid_title');
    }
    return array('ok' => true, 'title' => $title);
}

function hammasir_registry_open_link_exists($provider_user_id) {
    // D20: آیا لینک PENDING/ACTIVE برای این provider هست؟ (re-check داخل قفل/تراکنش)
    if (store_mode() === 'mysql') {
        $row = joma_query_one(
            "SELECT id FROM joma_hammasir_links WHERE provider_user_id=? AND status IN ('PENDING','ACTIVE') LIMIT 1",
            'i',
            array((int) $provider_user_id)
        );
        return $row ? true : false;
    }
    $store = hammasir_store_load();
    if ($store === null) return true; // شکست خواندن → محافظه‌کارانه مانع INACTIVE (fail-closed)
    foreach ($store['links'] as $l) {
        if ((int) $l['provider_user_id'] === (int) $provider_user_id
            && ($l['status'] === 'PENDING' || $l['status'] === 'ACTIVE')) {
            return true;
        }
    }
    return false;
}

function hammasir_registry_list() {
    // فهرست همه‌ی همراهان + نام نمایشی کاربر (join منطقی در PHP؛ read-only از JOMA)
    $display = hammasir_registry_display_map();
    $providers = hammasir_provider_list(false);
    if ($providers === null) return null;
    $out = array();
    foreach ($providers as $p) {
        $uid = (int) $p['user_id'];
        $out[] = array(
            'id' => (int) $p['id'],
            'user_id' => $uid,
            'title' => (string) $p['title'],
            'status' => (string) $p['status'],
            'display_name' => isset($display[$uid]) ? $display[$uid] : 'کاربر', // برچسب عمومی مجاز (D33)
        );
    }
    return $out;
}

/* ---------- نوشتن‌های Registry (فقط داخل قفل D41) ---------- */

function hammasir_db_provider_insert($user_id, $title) {
    // ثبت جدید — وضعیت اولیه ACTIVE (D30: پس از ثبت، همراه در فهرست انتخاب پدیدار می‌شود)
    $now = hammasir_now();
    return joma_exec(
        'INSERT INTO joma_hammasir_providers (user_id, title, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
        'issss',
        array((int) $user_id, (string) $title, 'ACTIVE', $now, $now)
    );
}

function hammasir_db_provider_set_title($user_id, $title) {
    return joma_exec(
        'UPDATE joma_hammasir_providers SET title = ?, updated_at = ? WHERE user_id = ?',
        'ssi',
        array((string) $title, hammasir_now(), (int) $user_id)
    );
}

function hammasir_db_provider_set_status($user_id, $status) {
    return joma_exec(
        'UPDATE joma_hammasir_providers SET status = ?, updated_at = ? WHERE user_id = ?',
        'ssi',
        array($status, hammasir_now(), (int) $user_id)
    );
}

function hammasir_file_provider_set_title(&$store, $user_id, $title) {
    foreach ($store['providers'] as $i => $p) {
        if ((int) $p['user_id'] === (int) $user_id) {
            $store['providers'][$i]['title'] = (string) $title;
            $store['providers'][$i]['updated_at'] = hammasir_now();
            return true;
        }
    }
    return false;
}

function hammasir_file_provider_set_status(&$store, $user_id, $status) {
    foreach ($store['providers'] as $i => $p) {
        if ((int) $p['user_id'] === (int) $user_id) {
            $store['providers'][$i]['status'] = $status;
            $store['providers'][$i]['updated_at'] = hammasir_now();
            return true;
        }
    }
    return false;
}

/* ---------- عملیات‌های Registry (گیت ADMIN_ACCESS در UI؛ قفل D41 اینجا) ---------- */

function hammasir_provider_register($user_id, $title) {
    // ثبت همراه: کاربر موجود و معتبر + عنوان معتبر + یکتایی user_id (D30)
    $user_id = (int) $user_id;
    // D-1 (PHP 8.1): validate_user قبل از قفل است — خطای mysqli آن هم مهار و به کد داخلی تبدیل می‌شود
    try {
        $hammasir_user_valid = hammasir_registry_validate_user($user_id);
    } catch (Throwable $e) {
        return 'error';
    }
    if (!$hammasir_user_valid) return 'invalid_user';
    $t = hammasir_registry_validate_title($title);
    if (!$t['ok']) return ($t['error'] === 'env') ? 'env' : 'invalid_title';
    if (store_mode() === 'mysql') {
        $res = hammasir_registry_with_lock($user_id, function ($mysqli) use ($user_id, $t) {
            // re-check یکتایی داخل قفل و تراکنش (D41/D15)
            if (hammasir_provider_by_user_id($user_id)) return 'duplicate';
            if (!hammasir_db_provider_insert($user_id, $t['title'])) return false;
            return 'ok';
        });
        if ($res === '__LOCK_TIMEOUT__') return 'lock_timeout';
        if ($res === 'ok' || $res === 'duplicate') return $res;
        return 'error';
    }
    $res = hammasir_store_mutate(function (&$store) use ($user_id, $t) {
        foreach ($store['providers'] as $p) {
            if ((int) $p['user_id'] === $user_id) return 'duplicate';
        }
        return hammasir_file_provider_upsert($store, $user_id, $t['title'], 'ACTIVE') ? 'ok' : false;
    });
    if ($res === 'ok' || $res === 'duplicate') return $res;
    // در file mode تفکیک timeout قفل از خطای IO در این سطح ممکن نیست → پیام عمومی مصوب
    return 'error';
}

function hammasir_provider_set_title($user_id, $title) {
    $user_id = (int) $user_id;
    $t = hammasir_registry_validate_title($title);
    if (!$t['ok']) return ($t['error'] === 'env') ? 'env' : 'invalid_title';
    if (store_mode() === 'mysql') {
        $res = hammasir_registry_with_lock($user_id, function ($mysqli) use ($user_id, $t) {
            if (!hammasir_provider_by_user_id($user_id)) return false;
            if (!hammasir_db_provider_set_title($user_id, $t['title'])) return false;
            return 'ok';
        });
        if ($res === '__LOCK_TIMEOUT__') return 'lock_timeout';
        return ($res === 'ok') ? 'ok' : 'error';
    }
    $res = hammasir_store_mutate(function (&$store) use ($user_id, $t) {
        return hammasir_file_provider_set_title($store, $user_id, $t['title']) ? 'ok' : false;
    });
    return ($res === 'ok') ? 'ok' : 'error';
}

function hammasir_provider_set_status($user_id, $status) {
    // ACTIVE/INACTIVE — قید D20: INACTIVE فقط بدون لینک باز (re-check داخل قفل/تراکنش — D22/D41)
    $user_id = (int) $user_id;
    if (!hammasir_is_valid_provider_status($status)) return 'error';
    if (store_mode() === 'mysql') {
        $res = hammasir_registry_with_lock($user_id, function ($mysqli) use ($user_id, $status) {
            if (!hammasir_provider_by_user_id($user_id)) return false;
            if ($status === 'INACTIVE' && hammasir_registry_open_link_exists($user_id)) return 'open_link';
            if (!hammasir_db_provider_set_status($user_id, $status)) return false;
            return 'ok';
        });
        if ($res === '__LOCK_TIMEOUT__') return 'lock_timeout';
        if ($res === 'ok' || $res === 'open_link') return $res;
        return 'error';
    }
    $res = hammasir_store_mutate(function (&$store) use ($user_id, $status) {
        $exists = false;
        foreach ($store['providers'] as $p) {
            if ((int) $p['user_id'] === $user_id) { $exists = true; break; }
        }
        if (!$exists) return false;
        if ($status === 'INACTIVE') {
            foreach ($store['links'] as $l) {
                if ((int) $l['provider_user_id'] === $user_id
                    && ($l['status'] === 'PENDING' || $l['status'] === 'ACTIVE')) {
                    return 'open_link';
                }
            }
        }
        return hammasir_file_provider_set_status($store, $user_id, $status) ? 'ok' : false;
    });
    if ($res === 'ok' || $res === 'open_link') return $res;
    return 'error';
}
