<?php
/**
 * مسیر دسترسی سریع دانلود گزارش PDF
 */
require_once __DIR__ . '/user/download_report.php';
