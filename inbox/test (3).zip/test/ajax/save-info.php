<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * ذخیره مشخصات هویتی کاربر و نهایی‌سازی کارنامه آزمون (Save Profile & Finalize Result)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';
require_once dirname(__DIR__) . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/tests/');
}

if (!csrf_verify()) {
    set_flash('danger', 'خطای امنیتی نشست. لطفاً دوباره تلاش نمایید.');
    redirect('/tests/');
}

$token = isset($_POST['session_token']) ? clean_input($_POST['session_token']) : '';
$first_name = isset($_POST['first_name']) ? clean_input($_POST['first_name']) : '';
$last_name = isset($_POST['last_name']) ? clean_input($_POST['last_name']) : '';
$mobile_raw = isset($_POST['mobile']) ? clean_input($_POST['mobile']) : '';
$gender = isset($_POST['gender']) ? clean_input($_POST['gender']) : '';
$age = isset($_POST['age']) ? intval($_POST['age']) : 0;

// اعتبارسنجی فیلدهای اجباری
if (empty($token) || empty($first_name) || empty($last_name) || empty($mobile_raw) || empty($gender) || $age <= 0) {
    set_flash('danger', 'لطفاً تمام فیلدهای ستاره‌دار را با دقت تکمیل فرمایید.');
    redirect('/user/complete-info.php?token=' . urlencode($token));
}

// اعتبارسنجی شماره همراه
$mobile = validate_iran_mobile($mobile_raw);
if (!$mobile) {
    set_flash('danger', 'شماره همراه وارد شده نامعتبر است. نمونه صحیح: 09123456789');
    redirect('/user/complete-info.php?token=' . urlencode($token));
}

// اعتبارسنجی سن
if ($age < 10 || $age > 120) {
    set_flash('danger', 'سن وارد شده باید عددی منطقی بین ۱۰ تا ۱۲۰ سال باشد.');
    redirect('/user/complete-info.php?token=' . urlencode($token));
}

// بررسی جلسه آزمون
$session = db_fetch_one("SELECT * FROM `test_sessions` WHERE `session_token` = ? LIMIT 1", 's', array($token));
if (!$session) {
    set_flash('danger', 'جلسه آزمون یافت نشد یا منقضی شده است.');
    redirect('/tests/');
}

// بازیابی داده‌های محاسبه‌شده از نشست یا بازتولید
$calc_data = isset($_SESSION['pending_calc_data']) ? $_SESSION['pending_calc_data'] : null;
if (!$calc_data) {
    // بازخوانی پاسخ‌های موقت این جلسه از دیتابیس در صورت وجود
    set_flash('warning', 'اطلاعات جلسه منقضی شده است. لطفاً آزمون را مجدداً شروع فرمایید.');
    redirect('/tests/');
}

// ۱. جستجو یا ثبت کاربر در جدول users
$existing_user = db_fetch_one("SELECT * FROM `users` WHERE `mobile` = ? LIMIT 1", 's', array($mobile));
$user_id = null;

if ($existing_user) {
    $user_id = intval($existing_user['id']);
    // بروزرسانی مشخصات تکمیلی در صورت نیاز
    db_update('users', array(
        'first_name' => $first_name,
        'last_name' => $last_name,
        'gender' => $gender,
        'age' => $age,
        'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0'
    ), 'id = ?', 'i', array($user_id));
} else {
    $user_id = db_insert('users', array(
        'mobile' => $mobile,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'gender' => $gender,
        'age' => $age,
        'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0'
    ));
}

if (!$user_id) {
    set_flash('danger', 'خطا در ثبت اطلاعات کاربر.');
    redirect('/user/complete-info.php?token=' . urlencode($token));
}

// ۲. لاگین کردن کاربر در سشن
$_SESSION['user_id'] = $user_id;
$_SESSION['user_mobile'] = $mobile;
$_SESSION['user_name'] = $first_name . ' ' . $last_name;
$_SESSION['user_logged_in'] = true;

// ۳. ذخیره نهایی کارنامه آزمون
$result_id = engine_save_test_result(intval($session['id']), $user_id, intval($session['test_id']), $calc_data);

// پاکسازی متغیرهای موقت
unset($_SESSION['pending_session_id']);
unset($_SESSION['pending_session_token']);
unset($_SESSION['pending_calc_data']);

if (!$result_id) {
    set_flash('danger', 'خطا در ذخیره‌سازی کارنامه آزمون.');
    redirect('/tests/');
}

log_event('info', 'test_completed', "کاربر {$mobile} آزمون شناسه {$session['test_id']} را به پایان رساند.");

set_flash('success', 'کارنامه شما با موفقیت صادر شد.');
redirect('/user/result.php?id=' . $result_id);
