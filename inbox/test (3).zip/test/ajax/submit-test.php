<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * پردازش و ارزیابی پاسخ‌های آزمون در سرور (Test Submission Handler)
 * اعتبارسنجی قطعی سمت سرور و جلوگیری از هرگونه دستکاری کلاینت
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';

$is_ajax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') 
        || (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false)
        || isset($_POST['answers']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($is_ajax) {
        json_response(array('success' => false, 'message' => 'روش درخواست نامعتبر است.'), 405);
    }
    redirect('/tests/');
}

// بررسی توکن امنیتی CSRF
if (!csrf_verify()) {
    if ($is_ajax) {
        json_response(array('success' => false, 'message' => 'اعتبار نشست امنیتی به پایان رسیده است. لطفاً صفحه را تازه‌سازی نمایید.'), 403);
    }
    set_flash('danger', 'خطای امنیتی نشست. لطفاً دوباره تلاش نمایید.');
    redirect('/tests/');
}

$test_id = isset($_POST['test_id']) ? intval($_POST['test_id']) : 0;
$submitted_answers = isset($_POST['answers']) && is_array($_POST['answers']) ? $_POST['answers'] : array();

if ($test_id <= 0 || empty($submitted_answers)) {
    if ($is_ajax) {
        json_response(array('success' => false, 'message' => 'داده‌های آزمون ارسالی ناقص هستند.'), 400);
    }
    set_flash('danger', 'پاسخ‌های آزمون به درستی دریافت نشدند.');
    redirect('/tests/');
}

// اعتبارسنجی سمت سرور: اطمینان از پاسخ دادن به تک‌تک سوالات بدون استثنا
$validation = engine_validate_answers($test_id, $submitted_answers);
if (!$validation['valid']) {
    if ($is_ajax) {
        json_response(array('success' => false, 'message' => $validation['message']), 422);
    }
    set_flash('danger', $validation['message']);
    redirect('/tests/take.php?id=' . $test_id);
}

// محاسبه قطعی نمرات توسط موتور مرکزی در بک‌اند
$calc_data = engine_calculate_scores($test_id, $submitted_answers);
if (!$calc_data) {
    if ($is_ajax) {
        json_response(array('success' => false, 'message' => 'خطا در محاسبه و ارزیابی نمرات.'), 500);
    }
    set_flash('danger', 'خطا در پردازش آزمون.');
    redirect('/tests/');
}

// ایجاد نشست آزمون
$session_info = engine_create_session($test_id);
if (!$session_info) {
    if ($is_ajax) {
        json_response(array('success' => false, 'message' => 'خطا در ثبت جلسه آزمون.'), 500);
    }
    set_flash('danger', 'خطا در ثبت اطلاعات.');
    redirect('/tests/');
}

$session_id = $session_info['session_id'];
$session_token = $session_info['session_token'];

// ذخیره موقت پاسخ‌ها در نشست برای پیوند با اطلاعات هویتی کاربر
$_SESSION['pending_session_id'] = $session_id;
$_SESSION['pending_session_token'] = $session_token;
$_SESSION['pending_test_id'] = $test_id;
$_SESSION['pending_calc_data'] = $calc_data;

// اگر کاربر از قبل لاگین باشد، بلافاصله نتیجه را نهایی و ذخیره کن
if (!empty($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
    $result_id = engine_save_test_result($session_id, $user_id, $test_id, $calc_data);
    if ($result_id) {
        unset($_SESSION['pending_session_id']);
        unset($_SESSION['pending_session_token']);
        unset($_SESSION['pending_calc_data']);
        
        $redirect_url = '/user/result.php?id=' . $result_id;
        if ($is_ajax) {
            json_response(array('success' => true, 'redirect_url' => $redirect_url));
        }
        redirect($redirect_url);
    }
}

$redirect_url = '/user/complete-info.php?token=' . urlencode($session_token);

if ($is_ajax) {
    json_response(array(
        'success' => true,
        'session_token' => $session_token,
        'redirect_url' => $redirect_url
    ));
}

redirect($redirect_url);
