<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * پردازش و ذخیره‌سازی امن فیش واریزی (Secure Receipt Upload Handler)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/user/dashboard.php');
}

if (!csrf_verify()) {
    set_flash('danger', 'خطای امنیتی نشست. لطفاً مجدداً تلاش فرمایید.');
    redirect('/user/dashboard.php');
}

$current_user = get_auth_user();
if (!$current_user) {
    set_flash('danger', 'برای ثبت رسید باید ابتدا وارد حساب کاربری شوید.');
    redirect('/user/login.php');
}

$result_id = isset($_POST['result_id']) ? intval($_POST['result_id']) : 0;
$user_notes = isset($_POST['user_notes']) ? clean_input($_POST['user_notes']) : '';

$result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($result_id));
if (!$result || intval($result['user_id']) !== intval($current_user['id'])) {
    set_flash('danger', 'کارنامه مورد نظر یافت نشد.');
    redirect('/user/dashboard.php');
}

// اعتبارسنجی فایل آپلود شده
if (!isset($_FILES['receipt_file']) || $_FILES['receipt_file']['error'] !== UPLOAD_ERR_OK) {
    set_flash('danger', 'لطفاً فایل فیش واریزی را انتخاب نمایید.');
    redirect('/user/request-interpretation.php?result_id=' . $result_id);
}

$file = $_FILES['receipt_file'];
if ($file['size'] > MAX_UPLOAD_SIZE) {
    set_flash('danger', 'حجم فایل فیش نباید بیشتر از ۵ مگابایت باشد.');
    redirect('/user/request-interpretation.php?result_id=' . $result_id);
}

// بررسی پسوند فایل
$allowed_extensions = array('jpg', 'jpeg', 'png', 'webp', 'pdf');
$original_filename = $file['name'];
$extension = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));

if (!in_array($extension, $allowed_extensions, true)) {
    set_flash('danger', 'فرمت فایل مجاز نیست. لطفاً یکی از فرمت‌های JPG, PNG, WEBP یا PDF را بارگذاری نمایید.');
    redirect('/user/request-interpretation.php?result_id=' . $result_id);
}

// بررسی MIME Type واقعی با finfo
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime_type = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

$allowed_mimes = array(
    'image/jpeg',
    'image/pjpeg',
    'image/png',
    'image/x-png',
    'image/webp',
    'application/pdf'
);

if (!in_array($mime_type, $allowed_mimes, true)) {
    set_flash('danger', 'نوع فایل آپلودشده معتبر نیست.');
    redirect('/user/request-interpretation.php?result_id=' . $result_id);
}

// ایجاد نام تصادفی و امن برای فایل
if (!is_dir(RECEIPTS_DIR)) {
    mkdir(RECEIPTS_DIR, 0755, true);
}

$random_filename = 'receipt_' . $result_id . '_' . generate_token(16) . '.' . $extension;
$destination = RECEIPTS_DIR . '/' . $random_filename;

if (!move_uploaded_file($file['tmp_name'], $destination)) {
    set_flash('danger', 'خطا در ذخیره‌سازی فایل روی سرور.');
    redirect('/user/request-interpretation.php?result_id=' . $result_id);
}

$relative_file_path = '/uploads/receipts/' . $random_filename;

// ثبت یا بروزرسانی درخواست در جدول interpretation_requests
$existing_request = db_fetch_one("SELECT * FROM `interpretation_requests` WHERE `result_id` = ? LIMIT 1", 'i', array($result_id));

if ($existing_request) {
    db_update('interpretation_requests', array(
        'payment_status' => 'receipt_submitted',
        'receipt_file' => $relative_file_path,
        'user_notes' => $user_notes,
        'requested_at' => date('Y-m-d H:i:s')
    ), 'id = ?', 'i', array($existing_request['id']));
    $request_code = $existing_request['request_code'];
} else {
    $request_code = generate_request_code();
    db_insert('interpretation_requests', array(
        'request_code' => $request_code,
        'user_id' => intval($current_user['id']),
        'result_id' => $result_id,
        'test_id' => intval($result['test_id']),
        'amount' => INTERPRETATION_PRICE,
        'payment_status' => 'receipt_submitted',
        'receipt_file' => $relative_file_path,
        'user_notes' => $user_notes,
        'requested_at' => date('Y-m-d H:i:s')
    ));
}

log_event('info', 'receipt_uploaded', "فیش واریزی برای نتیجه {$result_id} توسط کاربر {$current_user['mobile']} بارگذاری شد.");

set_flash('success', 'فیش واریزی شما با کد پیگیری ' . $request_code . ' با موفقیت ثبت شد و در صف بررسی قرار گرفت.');
redirect('/user/result.php?id=' . $result_id);
