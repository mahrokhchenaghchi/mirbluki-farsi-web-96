<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * فایل پیکربندی اصلی سامانه (Main Configuration)
 * سازگار با PHP 7.x و درایور mysqli
 */

// جلوگیری از نمایش خطاهای حساس در محیط پروداکشن (Error Handling)
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);

// تنظیم منطقه زمانی
date_default_timezone_set('Asia/Tehran');

// شروع نشست امن
if (session_status() === PHP_SESSION_NONE) {
    // تنظیمات امنیتی کوکی‌های نشست
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

// ==========================================
// ۱. مشخصات اتصال پایگاه داده (Database Config)
// ==========================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'mirbolouki_test1');
define('DB_USER', 'mirbolouki_usrtest1');
define('DB_PASS', 't]7;N9}@rzq5;k#,'); // در هاست اشتراکی رمز دیتابیس را اینجا وارد کنید
define('DB_PORT', 3306);
define('DB_CHARSET', 'utf8mb4');

// ==========================================
// ۲. تنظیمات عمومی سامانه و آدرس‌ها (Site Config)
// ==========================================
define('SITE_NAME', 'سامانه تخصصی آزمون‌های روان‌شناختی جواد میربلوکی');
define('SITE_SHORT_NAME', 'آزمون‌های میربلوکی');
define('SITE_URL', 'https://test.mirbolouki.com');
define('MAIN_SITE_URL', 'https://mirbolouki.com');
define('SITE_VERSION', '1.0.0');

// ==========================================
// ۳. اطلاعات مالی و پرداخت تفسیر کامل (Payment Info)
// ==========================================
define('INTERPRETATION_PRICE', 369000); // به تومان
define('PAYMENT_CARD_NUMBER', '5859831854405833');
define('PAYMENT_CARD_OWNER', 'جواد میربلوکی');
define('PAYMENT_SUPPORT_MOBILE', '09967979471');
define('BALE_CHANNEL_URL', 'https://ble.ir/mirbolouki');

// ==========================================
// ۴. مسیرهای ذخیره‌سازی فایل‌ها (Upload Paths)
// ==========================================
define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_DIR', ROOT_PATH . '/uploads');
define('RECEIPTS_DIR', UPLOAD_DIR . '/receipts');
define('TEST_IMAGES_DIR', UPLOAD_DIR . '/tests');

// حداکثر حجم مجاز آپلود فیش (بر حسب بایت - ۵ مگابایت)
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);
