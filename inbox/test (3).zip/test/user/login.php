<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * ورود به حساب کاربری مراجعین (User Mobile Login)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

if (is_user_logged_in()) {
    redirect('/user/dashboard.php');
}

$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error_msg = 'خطای امنیتی نشست. لطفاً دوباره تلاش فرمایید.';
    } else {
        $mobile = isset($_POST['mobile']) ? clean_input($_POST['mobile']) : '';
        $login_result = user_login_by_mobile($mobile);
        
        if ($login_result['success']) {
            set_flash('success', 'به سامانه خوش آمدید.');
            redirect('/user/dashboard.php');
        } else {
            $error_msg = $login_result['message'];
        }
    }
}

$page_title = 'ورود به حساب کاربری و آزمون‌های من';
$meta_description = 'ورود به حساب کاربری جهت مشاهده کارنامه‌ها و پیگیری وضعیت تفاسیر کامل آزمون‌های روان‌شناختی.';
$is_noindex = true;

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding container-narrow">
  <div class="test-container-box" style="max-width: 480px; margin: 0 auto;">
    
    <div style="text-align: center; margin-bottom: 28px;">
      <div class="feature-icon" style="margin: 0 auto 16px;">
        <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
      </div>
      <h1 style="font-size: 1.55rem; margin-bottom: 8px;">ورود به حساب کاربری</h1>
      <p style="color: var(--text-muted); font-size: 0.9rem;">
        برای مشاهده کارنامه‌ها و تفاسیر، شماره همراه ثبت‌شده در آزمون را وارد نمایید.
      </p>
    </div>

    <?php if (!empty($error_msg)): ?>
      <div class="alert alert-danger">
        <?php echo escape_html($error_msg); ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="/user/login.php">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label" for="mobile">شماره تلفن همراه</label>
        <input type="tel" id="mobile" name="mobile" class="form-control" dir="ltr" style="text-align: left; font-size: 1.1rem;" required placeholder="09123456789" pattern="^09[0-9]{9}$" autofocus>
      </div>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 24px;">
        <span>ورود به حساب من</span>
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/></svg>
      </button>
    </form>

    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid var(--border-light); text-align: center; font-size: 0.88rem; color: #64748b;">
      هنوز در آزمونی شرکت نکرده‌اید؟ <a href="/tests/" style="font-weight: 700;">مشاهده فهرست آزمون‌ها</a>
    </div>

  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
