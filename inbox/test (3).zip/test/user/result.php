<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * صفحه نمایش کارنامه و نتیجه آزمون (Result & Interpretation View)
 * کنترل دسترسی قطعی: کاربر فقط نتایج خود را می‌بیند.
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';
require_once dirname(__DIR__) . '/includes/auth.php';

$result_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($result_id <= 0) {
    set_flash('danger', 'شناسه کارنامه نامعتبر است.');
    redirect('/user/login.php');
}

$result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($result_id));
if (!$result) {
    set_flash('danger', 'کارنامه مورد نظر یافت نشد.');
    redirect('/user/login.php');
}

// بررسی دسترسی کاربر
$current_user = get_auth_user();
$current_admin = get_current_admin();

// اگر کاربر لاگین نیست یا نتیجه متعلق به شخص دیگری است و ادمین هم نیست
if (!$current_admin) {
    if (!$current_user || intval($current_user['id']) !== intval($result['user_id'])) {
        set_flash('danger', 'شما اجازه دسترسی به کارنامه شخص دیگری را ندارید.');
        redirect('/user/login.php');
    }
}

$test = engine_get_test($result['test_id']);
$user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($result['user_id']));

$dimension_scores = json_decode($result['dimension_scores_json'], true);
$audit_trail = json_decode($result['scientific_audit_trail_json'], true);

// دریافت وضعیت درخواست تفسیر کامل در صورت وجود
$interp_request = db_fetch_one(
    "SELECT * FROM `interpretation_requests` WHERE `result_id` = ? LIMIT 1",
    'i',
    array($result_id)
);

// دریافت تفسیر کامل منتشرشده در صورت تایید و انتشار قطعی ادمین
$full_interp = null;
if ($interp_request && $interp_request['payment_status'] === 'payment_confirmed') {
    $full_interp = db_fetch_one(
        "SELECT * FROM `full_interpretations` WHERE `result_id` = ? AND `status` = 'published' LIMIT 1",
        'i',
        array($result_id)
    );
}

$page_title = 'کارنامه آزمون ' . $test['title'];
$is_noindex = true;
$extra_css = array('/assets/css/result.css');
$extra_js = array('/assets/js/charts.js');

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding">
  
  <!-- Navigation Top Link & Action Buttons -->
  <div style="margin-bottom: 24px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px;">
    <a href="/user/dashboard.php" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; color: #64748b; font-weight: 600;">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
      <span>بازگشت به تاریخچه آزمون‌های من</span>
    </a>
    
    <div style="display: flex; flex-wrap: wrap; gap: 10px;">
      <!-- دکمه دانلود PDF کارنامه اولیه -->
      <a href="/user/download_report.php?id=<?php echo $result_id; ?>&type=initial" class="btn btn-outline btn-sm" style="display: inline-flex; align-items: center; gap: 6px;">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
        <span>دانلود کارنامه اولیه (PDF)</span>
      </a>

      <!-- دکمه دانلود PDF تفسیر پیشرفته در صورت انتشار -->
      <?php if ($full_interp && $full_interp['status'] === 'published'): ?>
        <a href="/user/download_report.php?id=<?php echo $result_id; ?>&type=advanced" class="btn btn-luxury btn-sm" style="display: inline-flex; align-items: center; gap: 6px; background: linear-gradient(135deg, #0f766e 0%, #0d9488 100%); color: #ffffff; border: none;">
          <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
          <span>دانلود تفسیر پیشرفته بالینی (PDF)</span>
        </a>
      <?php endif; ?>
    </div>
  </div>

  <!-- Header Card & Short Interpretation -->
  <div class="result-header-card">
    <div class="result-meta-top">
      <div>
        <span class="custom-badge badge-primary">آزمون روان‌شناختی استاندارد</span>
        <h1 style="color: #ffffff; font-size: 1.85rem; margin-top: 8px; margin-bottom: 4px;">
          کارنامه ارزیابی: <?php echo escape_html($test['title']); ?>
        </h1>
        <small style="color: #94a3b8;">نسخه ابزار: <?php echo to_persian_num($result['test_version']); ?> | تاریخ صدور: <?php echo format_jalali_date($result['created_at']); ?></small>
      </div>
      <div class="result-user-badge">
        شرکت‌کننده: <?php echo escape_html($user['first_name'] . ' ' . $user['last_name']); ?> 
        <span style="font-size: 0.85rem; color: #94a3b8;">(<?php echo to_persian_num($user['age']); ?> ساله)</span>
      </div>
    </div>

    <div class="result-score-overview">
      <div class="result-score-circle">
        <span class="score-num"><?php echo to_persian_num($result['total_score']); ?></span>
        <span class="score-lbl">نمره کل آزمون</span>
      </div>
      <div class="result-summary-text">
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
          <h3 style="margin-bottom: 0;">طبقه‌بندی کلی: <?php echo escape_html($result['overall_category']); ?></h3>
          <?php echo format_severity_badge($result['overall_severity']); ?>
        </div>
        <p><?php echo nl2br(escape_html($result['short_interpretation'])); ?></p>
      </div>
    </div>
  </div>

  <!-- Charts Section -->
  <div class="chart-card-box">
    <h3>نمودار نیم‌رخ ابعاد و مؤلفه‌های آزمون</h3>
    <p class="chart-subtitle">مقایسه نمرات خام کسب‌شده در ابعاد مختلف آزمون بر مبنای پردازش دقیق روان‌سنجی</p>
    
    <div class="chart-canvas-wrapper">
      <canvas id="dimensionBarChart" style="width: 100%; height: 360px;"></canvas>
    </div>
  </div>

  <?php 
  $is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
  if ($is_young_test && is_array($dimension_scores)):
    $domains = engine_calculate_schema_domains($dimension_scores);
  ?>
  <!-- 5 Schema Domains Overview -->
  <div class="chart-card-box" style="margin-bottom: 30px;">
    <h3>حوزه‌های پنج‌گانه طرحواره‌های یانگ (Schema Domains)</h3>
    <p class="chart-subtitle">طبقه‌بندی مرتبه دوم طرحواره‌ها در پنج حوزه بنیادین نیازهای هیجانی تحولی</p>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-top: 16px;">
      <?php foreach ($domains as $d_id => $dom): ?>
        <div style="background: #f8fafc; border: 1px solid var(--border-light); border-top: 4px solid <?php echo $dom['color']; ?>; border-radius: var(--radius-md); padding: 16px;">
          <div style="font-size: 0.85rem; font-weight: 700; color: #1e293b; margin-bottom: 8px;">
            <?php echo escape_html($dom['title']); ?>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px;">
            <span style="font-size: 1.5rem; font-weight: 900; color: <?php echo $dom['color']; ?>;">
              <?php echo to_persian_num($dom['percentage']); ?>٪
            </span>
            <span><?php echo format_severity_badge($dom['severity']); ?></span>
          </div>
          <div class="dim-progress-track" style="margin-bottom: 0;">
            <div class="dim-progress-bar" style="width: <?php echo $dom['percentage']; ?>%; background: <?php echo $dom['color']; ?>;"></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Dimension Details Cards Grid -->
  <h2 style="font-size: 1.4rem; margin-bottom: 20px;"><?php echo $is_young_test ? 'تحلیل تفکیکی ۱۸ طرحواره ناسازگار اولیه' : 'تحلیل تفکیکی ابعاد'; ?></h2>
  <div class="dimension-cards-grid">
    <?php if (is_array($dimension_scores)): ?>
      <?php foreach ($dimension_scores as $dim): ?>
        <div class="dimension-card">
          <div class="dim-header">
            <span class="dim-title"><?php echo escape_html($dim['title']); ?></span>
            <span style="font-weight: 800; color: <?php echo escape_html($dim['color_hex']); ?>; font-size: 1.1rem;">
              <?php echo to_persian_num($dim['raw_score']); ?>
            </span>
          </div>

          <div class="dim-progress-track">
            <?php 
              $pct = ($dim['max_score'] > 0) ? min(100, round(($dim['raw_score'] / $dim['max_score']) * 100)) : 50;
            ?>
            <div class="dim-progress-bar" style="width: <?php echo $pct; ?>%; background: <?php echo escape_html($dim['color_hex']); ?>;"></div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <span style="font-size: 0.82rem; color: #64748b;">طبقه: <strong><?php echo escape_html($dim['category_name']); ?></strong></span>
            <?php echo format_severity_badge($dim['severity_level']); ?>
          </div>

          <p class="dim-desc"><?php echo escape_html($dim['interpretation']); ?></p>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Full Interpretation Section / CTA / Status -->
  <?php if ($full_interp && $full_interp['status'] === 'published'): ?>
    
    <!-- Full Interpretation is Published by Admin! -->
    <div class="feature-box" style="background: #ffffff; border: 2px solid var(--primary-teal); border-radius: var(--radius-xl); padding: 40px; margin-bottom: 40px; box-shadow: var(--shadow-lg);">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border-light); flex-wrap: wrap; gap: 12px;">
        <div>
          <span class="custom-badge badge-success" style="font-size: 0.9rem; padding: 6px 14px;">تفسیر کامل و تخصصی تأییدشده ✓</span>
          <h2 style="font-size: 1.65rem; margin-top: 10px; margin-bottom: 0;">گزارش تحلیل جامع بالینی و روان‌شناختی</h2>
        </div>
        <div style="display: flex; align-items: center; gap: 10px;">
          <a href="/user/download_report.php?id=<?php echo $result_id; ?>&type=advanced" class="btn btn-luxury btn-sm" style="background: #0f766e; color: #fff; padding: 8px 18px; border-radius: 8px; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 6px;">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
            <span>دریافت نسخه رسمی PDF پیشرفته</span>
          </a>
        </div>
      </div>

      <div style="margin-bottom: 30px;">
        <h4 style="color: var(--primary-navy); font-size: 1.15rem; margin-bottom: 12px;">۱. تحلیل عمیق سازه‌ها و الگوهای روان‌شناختی:</h4>
        <div style="line-height: 1.9; color: #334155; font-size: 0.96rem; background: #f8fafc; padding: 20px; border-radius: var(--radius-md);">
          <?php echo nl2br(escape_html($full_interp['scientific_interpretation'])); ?>
        </div>
      </div>

      <?php if (!empty($full_interp['admin_additional_notes'])): ?>
        <div style="margin-bottom: 30px;">
          <h4 style="color: var(--primary-navy); font-size: 1.15rem; margin-bottom: 12px;">۲. یادداشت‌ها و مشاهدات اختصاصی درمانگر (دکتر میربلوکی):</h4>
          <div style="line-height: 1.9; color: #1e293b; font-size: 0.96rem; background: #f0fdf4; border-right: 4px solid #10b981; padding: 20px; border-radius: var(--radius-md);">
            <?php echo nl2br(escape_html($full_interp['admin_additional_notes'])); ?>
          </div>
        </div>
      <?php endif; ?>

      <?php if (!empty($full_interp['clinical_recommendations'])): ?>
        <div>
          <h4 style="color: var(--primary-navy); font-size: 1.15rem; margin-bottom: 12px;">۳. راهکارهای عملی و گام‌های پیشنهادی:</h4>
          <div style="line-height: 1.9; color: #334155; font-size: 0.96rem; background: #fffbeb; border-right: 4px solid #f59e0b; padding: 20px; border-radius: var(--radius-md);">
            <?php echo nl2br(escape_html($full_interp['clinical_recommendations'])); ?>
          </div>
        </div>
      <?php endif; ?>
    </div>

  <?php elseif ($interp_request): ?>

    <!-- Interpretation is Requested but Not Yet Published -->
    <div class="feature-box" style="background: #ffffff; border-radius: var(--radius-xl); padding: 36px; margin-bottom: 40px; border: 1.5px solid var(--border-light); text-align: center;">
      <div style="margin-bottom: 16px;">
        <?php echo format_request_status_badge($interp_request['payment_status']); ?>
      </div>
      <h3 style="font-size: 1.4rem; margin-bottom: 10px;">وضعیت درخواست تفسیر کامل</h3>
      
      <?php if ($interp_request['payment_status'] === 'receipt_submitted' || $interp_request['payment_status'] === 'payment_pending_verification'): ?>
        <p style="color: #475569; max-width: 600px; margin: 0 auto 20px;">
          فیش واریزی شما با کد رهگیری <strong><?php echo escape_html($interp_request['request_code']); ?></strong> با موفقیت ثبت گردید و هم‌اکنون در مرحله بررسی مالی و تخصصی قرار دارد. پس از تأیید، گزارش تحلیل در همین صفحه منتشر خواهد شد.
        </p>
      <?php elseif ($interp_request['payment_status'] === 'payment_confirmed' || $interp_request['payment_status'] === 'interpretation_draft'): ?>
        <p style="color: #047857; max-width: 600px; margin: 0 auto 20px; font-weight: 600;">
          پرداخت شما تایید شده است. تفسیر تخصصی آزمون شما توسط درمانگر در حال نگارش و نهایی‌سازی است.
        </p>
      <?php elseif ($interp_request['payment_status'] === 'rejected'): ?>
        <div class="alert alert-danger" style="max-width: 600px; margin: 0 auto 20px;">
          متأسفانه فیش ارسالی تأیید نشد. علت: <?php echo escape_html($interp_request['admin_notes'] ? $interp_request['admin_notes'] : 'عدم وضوح یا مغایرت مبلغ'); ?>.
        </div>
        <a href="/user/request-interpretation.php?result_id=<?php echo $result_id; ?>" class="btn btn-primary">
          ارسال مجدد فیش واریزی
        </a>
      <?php else: ?>
        <p style="color: #475569; max-width: 600px; margin: 0 auto 20px;">
          درخواست شما ثبت شده است. لطفاً پس از واریز مبلغ، فیش پرداختی خود را بارگذاری فرمایید.
        </p>
        <a href="/user/request-interpretation.php?result_id=<?php echo $result_id; ?>" class="btn btn-luxury">
          تکمیل فرآیند پرداخت و ارسال رسید
        </a>
      <?php endif; ?>
    </div>

  <?php else: ?>

    <!-- CTA Box for Ordering Full Interpretation -->
    <div class="full-interp-cta-box">
      <div class="cta-grid">
        <div class="cta-content">
          <span class="custom-badge badge-warning" style="margin-bottom: 12px;">تحلیل عمیق و اختصاصی</span>
          <h3>درخواست <span>تفسیر کامل و تخصصی</span> نتایج</h3>
          <p>
            کارنامه اولیه تصویری کلی از نمرات شما را نشان داد. در تفسیر جامع، دکتر جواد میربلوکی سازه‌های عمیق شخصیتی، الگوهای تعارضات ارتباطی و راهکارهای درمانی متمایز را به صورت اختصاصی برای وضعیت شما تحلیل و ارائه می‌نمایند.
          </p>

          <ul class="cta-features-list">
            <li>
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
              <span>تحلیل بالینی الگوهای ناهشیار و باورهای هسته‌ای</span>
            </li>
            <li>
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
              <span>بررسی اثر متقابل ابعاد بر روابط عاطفی و زناشویی</span>
            </li>
            <li>
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
              <span>توصیه‌های کاربردی اختصاصی جهت تغییر الگوها</span>
            </li>
          </ul>

          <a href="/user/request-interpretation.php?result_id=<?php echo $result_id; ?>" class="btn btn-luxury btn-lg">
            <span>ثبت درخواست و پرداخت هزینه تفسیر</span>
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
          </a>
        </div>

        <div class="payment-card-badge">
          <div style="font-size: 0.9rem; color: #cbd5e1; margin-bottom: 4px;">هزینه تفسیر کامل:</div>
          <div class="payment-price-tag"><?php echo format_toman(INTERPRETATION_PRICE); ?></div>

          <div class="bank-card-container">
            <span style="font-size: 0.8rem; color: #94a3b8; display: block; margin-bottom: 4px;">شماره کارت جهت واریز:</span>
            <span class="card-num-text"><?php echo PAYMENT_CARD_NUMBER; ?></span>
            <span class="card-owner-text">به نام: <?php echo escape_html(PAYMENT_CARD_OWNER); ?></span>
          </div>

          <button type="button" class="btn btn-outline-white btn-sm btn-block btn-copy-card" data-card="<?php echo PAYMENT_CARD_NUMBER; ?>">
            کپی شماره کارت
          </button>
        </div>
      </div>
    </div>

  <?php endif; ?>

  <!-- Joma Smart Planner Recommendation Banner (Post-Result Soft CTA) -->
  <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #ffffff; border-radius: var(--radius-lg); padding: 30px; margin-bottom: 30px; border: 1px solid rgba(217, 119, 6, 0.3); box-shadow: var(--shadow-md); display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 20px;">
    <div style="max-width: 680px;">
      <div style="display: inline-flex; align-items: center; gap: 6px; color: #fbbf24; font-size: 0.85rem; font-weight: 700; margin-bottom: 8px;">
        <span>🦉</span>
        <span>گام بعدی: از شناخت الگوها تا تغییر پایدار رفتاری</span>
      </div>
      <h3 style="color: #ffffff; font-size: 1.25rem; margin-bottom: 8px;">تغییر رفتارهای ناهشیار با پلنر هوشمند روان‌شناسی جوما (جغد دانا)</h3>
      <p style="color: #cbd5e1; font-size: 0.92rem; line-height: 1.8; margin-bottom: 0;">
        دانستن طرحواره‌ها و الگوهای روانی اولین گام است. برای تعدیل تله‌های ذهنی و ساختن عادات سالم، رفتارهای روزانه خود را در پلنر هوشمند <strong>جوما</strong> ثبت و پیگیری کنید.
      </p>
    </div>
    <div>
      <a href="https://joma.mirbolouki.com" target="_blank" rel="noopener" class="btn btn-primary" style="background: linear-gradient(135deg, #0d9488, #0f766e); white-space: nowrap; padding: 12px 24px;">
        <span>ورود به پلنر جوما (جغد دانا) ↗</span>
      </a>
    </div>
  </div>

  <!-- Scientific Audit Trail Accordion (Auditability) -->
  <div class="audit-trail-container">
    <details>
      <summary style="font-size: 1rem; font-weight: 700; color: var(--primary-navy); cursor: pointer; user-select: none;">
        🔍 مشاهده مسیر شفاف استناد و محاسبه نمرات (Scientific Audit Trail)
      </summary>
      <p style="margin-top: 10px; font-size: 0.86rem; color: #64748b;">
        مسیر دقیق تبدیل هر پاسخ به نمره، اعمال نمره‌گذاری معکوس و انتساب به بعد مربوطه جهت تضمین شفافیت علمی:
      </p>

      <div class="table-responsive">
        <table class="audit-table">
          <thead>
            <tr>
              <th>شماره سؤال</th>
              <th>متن سؤال</th>
              <th>گزینه انتخابی</th>
              <th>نمره اختصاص‌یافته</th>
              <th>بعد متناظر</th>
            </tr>
          </thead>
          <tbody>
            <?php if (is_array($audit_trail)): ?>
              <?php foreach ($audit_trail as $item): ?>
                <tr>
                  <td><?php echo to_persian_num($item['question_number']); ?></td>
                  <td><?php echo escape_html($item['question_text']); ?></td>
                  <td><?php echo escape_html($item['selected_option_text']); ?></td>
                  <td style="font-weight: 700; color: var(--primary-teal);"><?php echo to_persian_num($item['item_final_score']); ?><?php echo $item['is_reverse_scored'] ? ' (معکوس)' : ''; ?></td>
                  <td><?php echo escape_html($item['dimension_title']); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </details>
  </div>

</div>

<!-- Render Dimensions Chart via Canvas Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const dimensionsData = <?php echo json_encode($dimension_scores ? $dimension_scores : array(), JSON_UNESCAPED_UNICODE); ?>;
  if (typeof MirboloukiCharts !== 'undefined') {
    MirboloukiCharts.renderDimensionBarChart('dimensionBarChart', dimensionsData);
  }
});
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
