<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * صفحه ثبت درخواست تفسیر کامل و بارگذاری فیش واریزی (Request Full Interpretation)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';
require_once dirname(__DIR__) . '/includes/auth.php';

$result_id = isset($_GET['result_id']) ? intval($_GET['result_id']) : 0;
if ($result_id <= 0) {
    set_flash('danger', 'شناسه کارنامه نامعتبر است.');
    redirect('/user/dashboard.php');
}

$result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($result_id));
if (!$result) {
    set_flash('danger', 'کارنامه یافت نشد.');
    redirect('/user/dashboard.php');
}

// کنترل دسترسی کاربر
$current_user = get_auth_user();
if (!$current_user || intval($current_user['id']) !== intval($result['user_id'])) {
    set_flash('danger', 'دسترسی غیرمجاز.');
    redirect('/user/login.php');
}

$test = engine_get_test($result['test_id']);
$existing_request = db_fetch_one("SELECT * FROM `interpretation_requests` WHERE `result_id` = ? LIMIT 1", 'i', array($result_id));

$page_title = 'درخواست تفسیر کامل آزمون ' . $test['title'];
$is_noindex = true;

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding container-narrow">
  <div class="test-container-box" style="max-width: 720px; margin: 0 auto;">
    
    <div style="margin-bottom: 24px;">
      <a href="/user/result.php?id=<?php echo $result_id; ?>" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; color: #64748b; font-weight: 600;">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
        <span>بازگشت به کارنامه آزمون</span>
      </a>
    </div>

    <div style="text-align: center; margin-bottom: 30px;">
      <span class="custom-badge badge-warning" style="margin-bottom: 10px;">تحلیل تخصصی و بالینی</span>
      <h1 style="font-size: 1.75rem; margin-bottom: 8px;">درخواست تفسیر کامل و اختصاصی</h1>
      <p style="color: var(--text-muted); font-size: 0.95rem;">
        برای آزمون <strong>«<?php echo escape_html($test['title']); ?>»</strong> شرکت‌کننده <strong><?php echo escape_html($current_user['first_name'] . ' ' . $current_user['last_name']); ?></strong>
      </p>
    </div>

    <!-- Payment Information Box -->
    <div style="background: linear-gradient(135deg, #091424, #112239); color: #ffffff; border-radius: var(--radius-lg); padding: 28px; margin-bottom: 30px; box-shadow: var(--shadow-md);">
      <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid rgba(255,255,255,0.1);">
        <div>
          <span style="color: #94a3b8; font-size: 0.85rem;">مبلغ قابل واریز:</span>
          <div style="font-size: 1.6rem; font-weight: 800; color: #fbbf24;"><?php echo format_toman(INTERPRETATION_PRICE); ?></div>
        </div>
        <div style="text-align: left;">
          <button type="button" class="btn btn-outline-white btn-sm btn-copy-card" data-card="<?php echo PAYMENT_CARD_NUMBER; ?>">
            کپی شماره کارت
          </button>
        </div>
      </div>

      <div style="background: rgba(255,255,255,0.06); border: 1px dashed rgba(255,255,255,0.2); border-radius: var(--radius-md); padding: 18px; text-align: center; margin-bottom: 16px;">
        <span style="font-size: 0.85rem; color: #cbd5e1; display: block; margin-bottom: 6px;">شماره کارت بانکی:</span>
        <span style="font-family: monospace; font-size: 1.35rem; font-weight: bold; letter-spacing: 2px; color: #ffffff; direction: ltr; display: block; margin-bottom: 6px;">
          <?php echo PAYMENT_CARD_NUMBER; ?>
        </span>
        <span style="color: #2dd4bf; font-weight: 600; font-size: 0.92rem;">به نام: <?php echo escape_html(PAYMENT_CARD_OWNER); ?></span>
      </div>

      <div style="font-size: 0.88rem; color: #cbd5e1; line-height: 1.8;">
        📌 <strong>روش‌های ارسال رسید واریز:</strong> پس از واریز، می‌توانید تصویر رسید را از طریق فرم زیر بارگذاری فرمایید یا رسید واریز را به شماره <strong><?php echo to_persian_num(PAYMENT_SUPPORT_MOBILE); ?></strong> پیامک کرده و یا از طریق پیام‌رسان <strong>بله</strong> ارسال نمایید.
      </div>
    </div>

    <!-- Receipt Upload Form -->
    <form method="POST" action="/ajax/submit-receipt.php" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="result_id" value="<?php echo $result_id; ?>">

      <div class="form-group">
        <label class="form-label" for="receipt_file">
          تصویر یا فایل فیش واریزی <span style="color: #dc2626;">*</span>
        </label>
        <input type="file" id="receipt_file" name="receipt_file" class="form-control" accept="image/jpeg,image/png,image/webp,application/pdf" required>
        <small style="color: #64748b; font-size: 0.82rem; display: block; margin-top: 4px;">
          فرمت‌های مجاز: JPG, PNG, WEBP, PDF (حداکثر حجم: ۵ مگابایت)
        </small>
      </div>

      <div class="form-group">
        <label class="form-label" for="user_notes">یادداشت یا توضیحات تکمیلی (اختیاری)</label>
        <textarea id="user_notes" name="user_notes" class="form-control" rows="3" placeholder="در صورت وجود توضیح خاص، شماره پیگیری بانکی یا نکته مدنظر خود را اینجا بنویسید..."></textarea>
      </div>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 24px;">
        <span>ثبت نهایی رسید و ارسال برای بررسی</span>
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
      </button>
    </form>

    <div style="margin-top: 24px; text-align: center;">
      <a href="<?php echo BALE_CHANNEL_URL; ?>" target="_blank" rel="noopener" style="display: inline-flex; align-items: center; gap: 8px; font-size: 0.9rem; color: #059669; font-weight: 600;">
        <img src="/assets/images/icon-bale.svg" alt="Bale" width="20" height="20">
        <span>ارسال رسید از طریق پیام‌رسان بله</span>
      </a>
    </div>

  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
