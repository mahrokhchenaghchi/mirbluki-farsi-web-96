<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی دکتر میربلوکی
 * کنترلر امن دانلود گزارش‌های رسمی PDF (Secure PDF Download Controller)
 * 
 * کنترل دقیق سطوح دسترسی (RBAC):
 * ۱. مراجع فقط می‌تواند گزارش‌های متعلق به خودش را دانلود کند (جلوگیری قطعی از دسترسی بین‌کاربری / Cross-User Access Blocked).
 * ۲. مدیر سامانه (Admin) اجازه مشاهده و دانلود تمامی گزارش‌ها را دارد.
 * ۳. گزارش پیشرفته (Advanced PDF) فقط و فقط در صورت تأیید و انتشار قطعی (Published) در دسترس خواهد بود.
 * ۴. جلوگیری از افشای مستقیم فایل‌ها و دسترسی به پوشه‌های محرمانه.
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/pdf_engine.php';

$result_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$type = (isset($_GET['type']) && $_GET['type'] === 'advanced') ? 'advanced' : 'initial';
$action = (isset($_GET['action']) && $_GET['action'] === 'view') ? 'inline' : 'attachment';

if ($result_id <= 0) {
    http_response_code(400);
    die('شناسه کارنامه نامعتبر است.');
}

// دریافت مشخصات نتیجه از پایگاه داده
$result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($result_id));
if (!$result) {
    http_response_code(404);
    die('کارنامه مورد نظر در سامانه یافت نشد.');
}

// بررسی احراز هویت و مالکیت کارنامه
$current_user = get_auth_user();
$current_admin = get_current_admin();

if (!$current_admin) {
    // کاربر عادی باید لاگین باشد و شناسه کاربری وی با نتیجه مطابقت داشته باشد
    if (!$current_user || intval($current_user['id']) !== intval($result['user_id'])) {
        http_response_code(403);
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
          <meta charset="UTF-8">
          <title>عدم دسترسی | دکتر میربلوکی</title>
          <style>
            body { background: #091424; font-family: Tahoma, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; color: #ffffff; }
            .box { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 32px; max-width: 440px; text-align: center; }
            h2 { color: #f87171; margin-top: 0; }
            p { color: #94a3b8; font-size: 0.9rem; line-height: 1.6; }
            a { display: inline-block; margin-top: 16px; padding: 10px 20px; background: #0f766e; color: #ffffff; text-decoration: none; border-radius: 8px; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="box">
            <h2>⛔ دسترسی غیرمجاز</h2>
            <p>شما اجازه دسترسی یا دانلود کارنامه ارزیابی شخص دیگری را ندارید. لطفاً با حساب کاربری خود وارد شوید.</p>
            <a href="/user/login.php">ورود به حساب کاربری &larr;</a>
          </div>
        </body>
        </html>
        <?php
        exit;
    }
}

$test = engine_get_test($result['test_id']);
if (!$test) {
    http_response_code(404);
    die('آزمون مرتبط یافت نشد.');
}

// در صورت درخواست گزارش پیشرفته، بررسی وضعیت انتشار
if ($type === 'advanced') {
    $full_interp = db_fetch_one(
        "SELECT * FROM `full_interpretations` WHERE `result_id` = ? AND `status` = 'published' LIMIT 1",
        'i',
        array($result_id)
    );

    if (!$full_interp) {
        http_response_code(403);
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
          <meta charset="UTF-8">
          <title>گزارش پیشرفته هنوز آماده نیست | دکتر میربلوکی</title>
          <style>
            body { background: #091424; font-family: Tahoma, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; color: #ffffff; }
            .box { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 32px; max-width: 480px; text-align: center; }
            h2 { color: #fbbf24; margin-top: 0; }
            p { color: #cbd5e1; font-size: 0.9rem; line-height: 1.7; }
            a { display: inline-block; margin-top: 16px; padding: 10px 20px; background: #0f766e; color: #ffffff; text-decoration: none; border-radius: 8px; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="box">
            <h2>⏳ گزارش پیشرفته در حال بررسی و نهایی‌سازی است</h2>
            <p>تفسیر بالینی پیشرفته برای این کارنامه هنوز توسط درمانگر تأیید و منتشر نشده است. پس از بررسی و انتشار توسط مدیریت، دانلود این فایل فعال خواهد شد.</p>
            <a href="/user/result.php?id=<?php echo $result_id; ?>">بازگشت به کارنامه اولیه &larr;</a>
          </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// تولید یا دریافت از حافظه موقت (Cache)
$pdf_file_path = pdf_get_cached_or_generate($result_id, $type);

if (!$pdf_file_path || !file_exists($pdf_file_path)) {
    http_response_code(500);
    die('خطا در تولید فایل PDF گزارش. لطفاً مجدداً تلاش فرمایید.');
}

// تنظیم هدرهای ارسال امن فایل
$download_filename = 'Mirbolouki-' . $test['slug'] . '-' . ucfirst($type) . '-' . $result['id'] . '.pdf';

// پاکسازی هرگونه خروجی بافر قبلی
while (ob_get_level()) {
    ob_end_clean();
}

header('Content-Type: application/pdf');
header('Content-Disposition: ' . $action . '; filename="' . $download_filename . '"');
header('Content-Length: ' . filesize($pdf_file_path));
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');
header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');

readfile($pdf_file_path);
exit;
