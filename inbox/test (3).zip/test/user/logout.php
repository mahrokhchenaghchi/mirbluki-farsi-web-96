<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * خروج کاربر از حساب (User Logout)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/auth.php';

user_logout();
set_flash('info', 'با موفقیت از حساب کاربری خارج شدید.');
redirect('/');
