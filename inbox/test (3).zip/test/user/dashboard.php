<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * پنل کاربری مراجعین - آزمون‌های من (User Dashboard)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

require_user_login();
$user = get_auth_user();

// دریافت کلیه نتایج آزمون‌های این کاربر
$results = db_fetch_all(
    "SELECT r.*, t.title as test_title, t.slug as test_slug, t.accent_color,
     req.payment_status, req.request_code, req.id as request_id,
     fi.status as interp_status
     FROM `test_results` r 
     JOIN `tests` t ON r.test_id = t.id 
     LEFT JOIN `interpretation_requests` req ON r.id = req.result_id 
     LEFT JOIN `full_interpretations` fi ON r.id = fi.result_id 
     WHERE r.user_id = ? 
     ORDER BY r.created_at DESC",
    'i',
    array($user['id'])
);

$page_title = 'آزمون‌های من';
$is_noindex = true;

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding">
  
  <!-- User Profile Header -->
  <div style="background: #ffffff; border-radius: var(--radius-xl); border: 1px solid var(--border-light); padding: 30px; margin-bottom: 35px; box-shadow: var(--shadow-sm); display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 20px;">
    <div>
      <div style="font-size: 0.88rem; color: var(--primary-teal); font-weight: 700; margin-bottom: 4px;">حساب کاربری مراجع</div>
      <h1 style="font-size: 1.65rem; margin-bottom: 6px;">
        <?php echo escape_html($user['first_name'] . ' ' . $user['last_name']); ?>
      </h1>
      <div style="display: flex; flex-wrap: wrap; gap: 16px; font-size: 0.9rem; color: #64748b;">
        <span>📱 شماره تماس: <?php echo to_persian_num($user['mobile']); ?></span>
        <span>👤 سن: <?php echo to_persian_num($user['age']); ?> سال</span>
        <span>جنسیت: <?php echo $user['gender'] === 'female' ? 'زن' : ($user['gender'] === 'male' ? 'مرد' : 'نامشخص'); ?></span>
      </div>
    </div>

    <div>
      <a href="/tests/" class="btn btn-primary">
        <span>شرکت در آزمون جدید</span>
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4"/></svg>
      </a>
    </div>
  </div>

  <h2 style="font-size: 1.4rem; margin-bottom: 20px;">تاریخچه آزمون‌های انجام‌شده</h2>

  <?php if (empty($results)): ?>
    <div class="feature-box text-center" style="max-width: 600px; margin: 40px auto; text-align: center;">
      <div class="feature-icon" style="margin: 0 auto 16px;">📝</div>
      <h3 class="feature-title">شما تاکنون در آزمونی شرکت نکرده‌اید</h3>
      <p class="feature-desc">برای ارزیابی و شناخت الگوهای عمیق شخصیتی خود، یکی از آزمون‌های تخصصی را آغاز فرمایید.</p>
      <a href="/tests/" class="btn btn-primary" style="margin-top: 15px;">مشاهده فهرست آزمون‌ها</a>
    </div>
  <?php else: ?>
    
    <div style="display: flex; flex-direction: column; gap: 20px;">
      <?php foreach ($results as $res): ?>
        <div style="background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-light); padding: 24px; box-shadow: var(--shadow-sm); display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 20px;">
          
          <div style="flex-grow: 1; min-width: 280px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
              <h3 style="font-size: 1.2rem; margin-bottom: 0;">
                <?php echo escape_html($res['test_title']); ?>
              </h3>
              <?php echo format_severity_badge($res['overall_severity']); ?>
            </div>

            <div style="display: flex; flex-wrap: wrap; gap: 14px; font-size: 0.88rem; color: #64748b; margin-bottom: 12px;">
              <span>📅 تاریخ: <?php echo format_jalali_date($res['created_at']); ?></span>
              <span>نمره کل: <strong style="color: var(--primary-navy);"><?php echo to_persian_num($res['total_score']); ?></strong></span>
              <span>طبقه: <strong><?php echo escape_html($res['overall_category']); ?></strong></span>
            </div>

            <div>
              <span style="font-size: 0.85rem; color: #475569;">وضعیت تفسیر کامل: </span>
              <?php echo format_request_status_badge($res['payment_status'] ? $res['payment_status'] : 'not_requested'); ?>
            </div>
          </div>

          <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <a href="/user/result.php?id=<?php echo $res['id']; ?>" class="btn btn-outline">
              <span>مشاهده کارنامه و نمودارها</span>
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
            </a>

            <?php if ($res['interp_status'] === 'published'): ?>
              <a href="/user/result.php?id=<?php echo $res['id']; ?>#interpretation" class="btn btn-primary">
                <span>مشاهده تفسیر کامل منتشرشده</span>
              </a>
            <?php elseif (empty($res['payment_status']) || $res['payment_status'] === 'not_requested'): ?>
              <a href="/user/request-interpretation.php?result_id=<?php echo $res['id']; ?>" class="btn btn-luxury">
                <span>درخواست تفسیر کامل</span>
              </a>
            <?php endif; ?>
          </div>

        </div>
      <?php endforeach; ?>
    </div>

  <?php endif; ?>

</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
