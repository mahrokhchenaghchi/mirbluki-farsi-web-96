<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * صفحه دریافت اطلاعات هویتی و دموگرافیک پس از پایان آزمون
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';
require_once dirname(__DIR__) . '/includes/auth.php';

$token = isset($_GET['token']) ? clean_input($_GET['token']) : (isset($_SESSION['pending_session_token']) ? $_SESSION['pending_session_token'] : '');

if (empty($token)) {
    set_flash('warning', 'جلسه آزمون معتبری یافت نشد. لطفاً ابتدا در یکی از آزمون‌ها شرکت فرمایید.');
    redirect('/tests/');
}

$session = db_fetch_one("SELECT * FROM `test_sessions` WHERE `session_token` = ? LIMIT 1", 's', array($token));
if (!$session) {
    set_flash('warning', 'جلسه آزمون منقضی شده است.');
    redirect('/tests/');
}

$test = engine_get_test($session['test_id']);

$page_title = 'تکمیل مشخصات برای دریافت نتیجه';
$is_noindex = true;

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding container-narrow">
  <div class="test-container-box" style="max-width: 620px; margin: 0 auto;">
    
    <div style="text-align: center; margin-bottom: 28px;">
      <div style="width: 60px; height: 60px; background: #ecfdf5; color: #059669; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; margin: 0 auto 16px;">
        ✓
      </div>
      <h2 style="font-size: 1.6rem; margin-bottom: 8px;">آزمون شما با موفقیت تکمیل شد</h2>
      <p style="color: var(--text-muted); font-size: 0.94rem;">
        برای صدور کارنامه، محاسبه نهایی نمودارها و ذخیره دائمی نتایج آزمون <strong>«<?php echo escape_html($test['title']); ?>»</strong> لطفاً مشخصات خود را وارد نمایید.
      </p>
    </div>

    <form method="POST" action="/ajax/save-info.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="session_token" value="<?php echo escape_html($token); ?>">

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="form-group">
          <label class="form-label" for="first_name">نام <span style="color: #dc2626;">*</span></label>
          <input type="text" id="first_name" name="first_name" class="form-control" required placeholder="مثال: علی">
        </div>

        <div class="form-group">
          <label class="form-label" for="last_name">نام خانوادگی <span style="color: #dc2626;">*</span></label>
          <input type="text" id="last_name" name="last_name" class="form-control" required placeholder="مثال: محمدی">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="mobile">شماره تلفن همراه <span style="color: #dc2626;">*</span></label>
        <input type="tel" id="mobile" name="mobile" class="form-control" dir="ltr" style="text-align: left;" required placeholder="09123456789" pattern="^09[0-9]{9}$">
        <small style="color: #64748b; font-size: 0.82rem; display: block; margin-top: 4px;">
          برای دسترسی‌های بعدی به کارنامه و تفاسیر، این شماره به عنوان نام کاربری شما خواهد بود.
        </small>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="form-group">
          <label class="form-label" for="gender">جنسیت <span style="color: #dc2626;">*</span></label>
          <select id="gender" name="gender" class="form-control" required>
            <option value="">انتخاب کنید...</option>
            <option value="female">زن</option>
            <option value="male">مرد</option>
            <option value="other">ترجیح می‌دهم پاسخ ندهم</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="age">سن (به سال) <span style="color: #dc2626;">*</span></label>
          <input type="number" id="age" name="age" class="form-control" min="10" max="120" required placeholder="مثال: 28">
        </div>
      </div>

      <div style="background: #f8fafc; border-radius: var(--radius-md); padding: 14px; margin-bottom: 24px; font-size: 0.86rem; color: #475569; border: 1px solid var(--border-light);">
        🔒 تمامی اطلاعات شما نزد سامانه تخصصی روان‌شناختی دکتر جواد میربلوکی کاملاً محرمانه باقی می‌ماند.
      </div>

      <button type="submit" class="btn btn-primary btn-block btn-lg">
        <span>محاسبه، صدور کارنامه و مشاهده نتیجه</span>
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
      </button>
    </form>

  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
