<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * صفحه معرفی و راهنمای شروع آزمون (Test Intro & Scientific Spec)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';

$slug = isset($_GET['slug']) ? clean_input($_GET['slug']) : (isset($_GET['id']) ? intval($_GET['id']) : '');
if (empty($slug)) {
    redirect('/tests/');
}

$structure = engine_get_test_structure($slug);
if (!$structure || empty($structure['test']) || intval($structure['test']['is_active']) !== 1) {
    set_flash('warning', 'آزمون مورد نظر یافت نشد یا در حال حاضر غیرفعال است.');
    redirect('/tests/');
}

$test = $structure['test'];
$dimensions = $structure['dimensions'];
$questions = $structure['questions'];
$sources = $structure['sources'];

$page_title = 'معرفی ' . $test['title'];
$meta_description = 'راهنما، مشخصات علمی و شروع ' . $test['title'] . ' در سامانه آزمون‌های روان‌شناختی دکتر جواد میربلوکی.';
$active_nav = 'tests';

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding container-narrow">
  <div class="test-container-box">
    <div style="margin-bottom: 24px;">
      <a href="/tests/" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; color: #64748b; font-weight: 500;">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
        <span>بازگشت به فهرست آزمون‌ها</span>
      </a>
    </div>

    <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 20px;">
      <span class="custom-badge badge-primary">نسخه <?php echo to_persian_num($test['version']); ?></span>
      <span style="font-size: 0.88rem; color: #64748b; font-weight: 600;">⏱ زمان تقریبی: <?php echo to_persian_num($test['estimated_minutes']); ?> دقیقه</span>
    </div>

    <h1 style="font-size: 1.95rem; margin-bottom: 12px;"><?php echo escape_html($test['title']); ?></h1>
    <?php if (!empty($test['original_name'])): ?>
      <div style="font-size: 0.95rem; color: var(--primary-teal); margin-bottom: 20px; font-weight: 700;">
        (<?php echo escape_html($test['original_name']); ?>)
      </div>
    <?php endif; ?>

    <div style="background: #f8fafc; border-radius: var(--radius-md); padding: 20px; margin-bottom: 28px; border-right: 4px solid var(--primary-teal);">
      <p style="margin-bottom: 0; font-size: 0.96rem; line-height: 1.8; color: #334155;">
        <?php echo nl2br(escape_html($test['description'])); ?>
      </p>
    </div>

    <?php if (!empty($test['intro_text'])): ?>
      <div style="margin-bottom: 30px;">
        <h3 style="font-size: 1.2rem; margin-bottom: 12px;">دستورالعمل و نحوه پاسخ‌دهی</h3>
        <div style="color: #475569; font-size: 0.94rem; line-height: 1.8;">
          <?php echo nl2br(escape_html($test['intro_text'])); ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Overview Meta -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 30px;">
      <div style="background: #ffffff; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 16px; text-align: center;">
        <div style="font-size: 1.6rem; font-weight: 800; color: var(--primary-navy);"><?php echo to_persian_num(count($questions)); ?></div>
        <div style="font-size: 0.85rem; color: #64748b;">تعداد کل سؤالات</div>
      </div>
      <div style="background: #ffffff; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 16px; text-align: center;">
        <div style="font-size: 1.6rem; font-weight: 800; color: var(--primary-teal);"><?php echo to_persian_num(count($dimensions)); ?></div>
        <div style="font-size: 0.85rem; color: #64748b;">ابعاد مورد سنجش</div>
      </div>
      <div style="background: #ffffff; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 16px; text-align: center;">
        <div style="font-size: 1.6rem; font-weight: 800; color: var(--accent-gold);"><?php echo to_persian_num($test['estimated_minutes']); ?></div>
        <div style="font-size: 0.85rem; color: #64748b;">دقیقه زمان پیشنهادی</div>
      </div>
    </div>

    <?php if (!empty($dimensions)): ?>
      <div style="margin-bottom: 30px;">
        <h3 style="font-size: 1.2rem; margin-bottom: 14px;">ابعاد و مؤلفه‌های مورد ارزیابی در این آزمون:</h3>
        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
          <?php foreach ($dimensions as $dim): ?>
            <span style="background: #f1f5f9; border: 1px solid #e2e8f0; color: #334155; font-size: 0.85rem; font-weight: 600; padding: 6px 14px; border-radius: var(--radius-full);">
              <?php echo escape_html($dim['title']); ?>
            </span>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <?php if (!empty($sources)): ?>
      <div style="margin-bottom: 30px; padding-top: 20px; border-top: 1px solid var(--border-light);">
        <h4 style="font-size: 1.05rem; margin-bottom: 10px; color: #475569;">مستندات و منابع علمی:</h4>
        <ul style="list-style: none; font-size: 0.85rem; color: #64748b; line-height: 1.8;">
          <?php foreach ($sources as $src): ?>
            <li style="margin-bottom: 6px;">
              • <strong><?php echo escape_html($src['citation_title']); ?></strong> 
              <?php if (!empty($src['authors'])): ?> (<?php echo escape_html($src['authors']); ?>, <?php echo escape_html($src['year']); ?>)<?php endif; ?>
              <?php if (!empty($src['doi'])): ?> | DOI: <?php echo escape_html($src['doi']); ?><?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <!-- Ethical Note -->
    <div class="alert alert-info" style="font-size: 0.9rem; line-height: 1.7; margin-bottom: 35px;">
      <strong>توصیه مهم بالینی:</strong> برای دریافت دقیق‌ترین نتیجه، لطفاً بر اساس احساس و وضعیت واقعی خود پاسخ دهید (نه آن‌گونه که فکر می‌کنید «باید» باشد). در این آزمون پاسخ درست یا غلط وجود ندارد.
    </div>

    <div style="text-align: center;">
      <a href="/tests/take.php?slug=<?php echo urlencode($test['slug']); ?>" class="btn btn-primary btn-lg" style="min-width: 260px; justify-content: center;">
        <span>شروع پاسخ‌دهی به سؤالات</span>
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
      </a>
    </div>
  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
