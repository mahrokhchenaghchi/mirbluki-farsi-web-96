<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * فهرست تمام آزمون‌های روان‌شناختی (Tests Catalog)
 */

$page_title = 'فهرست آزمون‌های روان‌شناختی';
$meta_description = 'فهرست کامل آزمون‌ها و مقیاس‌های ارزیابی روان‌شناختی دکتر جواد میربلوکی جهت خودشناسی، ارزیابی طرحواره‌ها و روابط عاطفی.';
$active_nav = 'tests';

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';

$tests = db_fetch_all(
    "SELECT t.*, 
     (SELECT COUNT(*) FROM `test_questions` q WHERE q.test_id = t.id) as question_count,
     (SELECT COUNT(*) FROM `test_dimensions` d WHERE d.test_id = t.id) as dimension_count
     FROM `tests` t 
     WHERE t.is_active = 1 
     ORDER BY t.sort_order ASC, t.id ASC"
);

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="container section-padding">
  <div class="section-header">
    <span class="section-subtitle">ابزارهای سنجش و خودآگاهی</span>
    <h1 class="section-title">فهرست آزمون‌های روان‌شناختی</h1>
    <p class="section-desc">آزمون مورد نظر خود را انتخاب کرده و پس از مطالعه راهنما، پاسخ‌دهی را آغاز نمایید.</p>
  </div>

  <?php if (empty($tests)): ?>
    <div class="feature-box text-center" style="max-width: 600px; margin: 40px auto; text-align: center;">
      <div class="feature-icon" style="margin: 0 auto 20px;">📋</div>
      <h3 class="feature-title">در حال حاضر آزمونی فعال نشده است</h3>
      <p class="feature-desc">به زودی آزمون‌های جدید به سامانه اضافه خواهند شد.</p>
    </div>
  <?php else: ?>
    <div class="tests-grid">
      <?php foreach ($tests as $test): ?>
        <div class="test-card">
          <div class="test-card-media">
            <?php if (!empty($test['banner_image']) && file_exists(ROOT_PATH . $test['banner_image'])): ?>
              <img src="<?php echo escape_html($test['banner_image']); ?>" alt="<?php echo escape_html($test['title']); ?>" loading="lazy">
            <?php else: ?>
              <img src="/assets/images/placeholder-test.svg" alt="<?php echo escape_html($test['title']); ?>" loading="lazy">
            <?php endif; ?>
            <div class="test-badge-time">
              ⏱ <?php echo to_persian_num($test['estimated_minutes']); ?> دقیقه
            </div>
          </div>

          <div class="test-card-body">
            <h3 class="test-card-title"><?php echo escape_html($test['title']); ?></h3>
            <?php if (!empty($test['original_name'])): ?>
              <div style="font-size: 0.82rem; color: var(--primary-teal); margin-bottom: 10px; font-weight: 600;">
                (<?php echo escape_html($test['original_name']); ?>)
              </div>
            <?php endif; ?>

            <p class="test-card-desc"><?php echo escape_html($test['description']); ?></p>

            <div class="test-meta-items">
              <div class="test-meta-item">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <span><?php echo to_persian_num($test['question_count']); ?> سؤال</span>
              </div>
              <div class="test-meta-item">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                <span><?php echo to_persian_num($test['dimension_count']); ?> بعد تحلیلی</span>
              </div>
            </div>

            <div style="margin-top: auto;">
              <a href="/tests/intro.php?slug=<?php echo urlencode($test['slug']); ?>" class="btn btn-primary btn-block">
                <span>مشاهده مشخصات و شروع</span>
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
