<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * صفحه اجرای تعاملی آزمون (Interactive Test Engine)
 * کلیه پاسخ‌ها صرفاً رادیوباتن بوده و انتخاب یک گزینه برای هر سوال اجباری است.
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/engine.php';

$slug = isset($_GET['slug']) ? clean_input($_GET['slug']) : (isset($_GET['id']) ? intval($_GET['id']) : '');
if (empty($slug)) {
    redirect('/tests/');
}

$structure = engine_get_test_structure($slug);
if (!$structure || empty($structure['test']) || intval($structure['test']['is_active']) !== 1) {
    set_flash('warning', 'آزمون یافت نشد.');
    redirect('/tests/');
}

$test = $structure['test'];
$questions = $structure['questions'];
$options = $structure['options'];

if (empty($questions) || empty($options)) {
    set_flash('warning', 'سوالات یا گزینه‌های این آزمون هنوز بارگذاری نشده‌اند.');
    redirect('/tests/intro.php?slug=' . urlencode($test['slug']));
}

$page_title = 'پاسخ‌دهی به ' . $test['title'];
$is_noindex = true; // صفحات آزمون ایندکس نشوند
$extra_css = array('/assets/css/test.css');
$extra_js = array('/assets/js/test-runner.js');

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="test-wrapper">
  <div class="container container-narrow">
    <div class="test-container-box">
      
      <!-- Test Header / Title -->
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div>
          <h2 style="font-size: 1.35rem; color: var(--primary-navy); margin-bottom: 4px;">
            <?php echo escape_html($test['title']); ?>
          </h2>
          <small style="color: #64748b; font-size: 0.85rem;">
            <?php echo escape_html($test['original_name']); ?>
          </small>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button type="button" class="btn-matrix-toggle" id="btnToggleMatrix">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            <span>جدول دسترسی سؤالات</span>
          </button>
          <span class="custom-badge badge-primary"><?php echo to_persian_num(count($questions)); ?> سؤال</span>
        </div>
      </div>

      <!-- Progress Bar & Counter -->
      <div class="test-progress-header">
        <div class="progress-info-bar">
          <div>
            <span>سؤال </span>
            <span id="currentQuestionNum" style="color: var(--primary-teal); font-weight: 800;">۱</span>
            <span> از </span>
            <span id="totalQuestionsCount"><?php echo to_persian_num(count($questions)); ?></span>
          </div>
          <div>
            <span id="progressPercent" style="color: #64748b;">۰٪</span>
          </div>
        </div>
        <div class="progress-track">
          <div class="progress-fill" id="progressBarFill"></div>
        </div>
      </div>

      <!-- Validation Alert Banner -->
      <div class="validation-error-alert" id="validationAlert">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
        <span id="validationAlertText">لطفاً یکی از گزینه‌ها را انتخاب کنید.</span>
      </div>

      <!-- Test Form Container -->
      <form id="psychTestForm" method="POST" action="/ajax/submit-test.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="test_id" value="<?php echo escape_html($test['id']); ?>">
        <input type="hidden" name="session_token" value="<?php echo escape_html('mb_' . $test['id'] . '_' . md5($test['slug'])); ?>">

        <!-- Questions Loop -->
        <?php foreach ($questions as $index => $q): ?>
          <div class="question-card <?php echo $index === 0 ? 'active' : ''; ?>" data-question-id="<?php echo escape_html($q['id']); ?>" data-index="<?php echo $index; ?>">
            
            <?php if (!empty($q['dimension_title'])): ?>
              <div class="question-meta">
                <span>مؤلفه: <?php echo escape_html($q['dimension_title']); ?></span>
              </div>
            <?php endif; ?>

            <div class="question-title">
              <span style="color: var(--primary-teal); margin-left: 6px;"><?php echo to_persian_num($q['question_number']); ?>.</span>
              <?php echo escape_html($q['question_text']); ?>
            </div>

            <?php if (!empty($q['help_text'])): ?>
              <div class="question-help-text">
                💡 <?php echo escape_html($q['help_text']); ?>
              </div>
            <?php endif; ?>

            <!-- Strictly Radio Button Options List -->
            <div class="options-list">
              <?php foreach ($options as $opt): ?>
                <label class="option-item-label" for="q_<?php echo $q['id']; ?>_opt_<?php echo $opt['id']; ?>">
                  <input 
                    type="radio" 
                    id="q_<?php echo $q['id']; ?>_opt_<?php echo $opt['id']; ?>" 
                    name="answers[<?php echo $q['id']; ?>]" 
                    value="<?php echo $opt['id']; ?>"
                    required
                  >
                  <div class="option-text-wrap">
                    <span class="option-title"><?php echo escape_html($opt['option_text']); ?></span>
                    <span class="option-number-badge"><?php echo to_persian_num($opt['option_number']); ?></span>
                  </div>
                </label>
              <?php endforeach; ?>
            </div>

          </div>
        <?php endforeach; ?>

        <!-- Navigation Stepper Footer -->
        <div class="test-navigation-footer">
          <button type="button" class="btn btn-outline nav-btn-prev" id="btnPrevQuestion">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
            <span>سؤال قبلی</span>
          </button>

          <div style="display: flex; gap: 10px; align-items: center;">
            <button type="button" class="btn btn-primary" id="btnNextQuestion">
              <span>سؤال بعدی</span>
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
            </button>
            <button type="submit" class="btn btn-luxury" id="btnSubmitTest" style="display: none;">
              <span>تکمیل آزمون و دریافت نتیجه</span>
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
            </button>
          </div>
        </div>

      </form>

    </div>
  </div>
</div>

<!-- Question Matrix Modal -->
<div class="matrix-modal-overlay" id="questionMatrixModal">
  <div class="matrix-modal-card">
    <div class="matrix-modal-header">
      <h4>فهرست و وضعیت پاسخ‌دهی به سؤالات</h4>
      <button type="button" id="btnCloseMatrix" style="background: none; border: none; font-size: 1.4rem; cursor: pointer; color: #64748b;">&times;</button>
    </div>
    <div class="matrix-modal-body">
      <div style="display: flex; gap: 14px; margin-bottom: 14px; font-size: 0.8rem; color: #475569; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 4px;">
          <span style="display: inline-block; width: 12px; height: 12px; border-radius: 3px; background: #ecfdf5; border: 1px solid #10b981;"></span>
          <span>پاسخ‌داده‌شده</span>
        </div>
        <div style="display: flex; align-items: center; gap: 4px;">
          <span style="display: inline-block; width: 12px; height: 12px; border-radius: 3px; background: #d4af37; border: 1px solid #b8972e;"></span>
          <span>سؤال جاری</span>
        </div>
        <div style="display: flex; align-items: center; gap: 4px;">
          <span style="display: inline-block; width: 12px; height: 12px; border-radius: 3px; background: #f8fafc; border: 1px solid #cbd5e1;"></span>
          <span>پاسخ‌نداده‌شده</span>
        </div>
      </div>
      <div class="matrix-grid-wrap" id="matrixGrid"></div>
    </div>
  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
