<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * فایل نصب و راه‌اندازی تحت وب سامانه (Web Installer)
 * برای کاربران بدون نیاز به دانش برنامه‌نویسی یا خط فرمان
 */

$lock_file = __DIR__ . '/installed.lock';
$is_locked = file_exists($lock_file);

$status_messages = array();
$error_messages = array();
$installed_successfully = false;

if (!function_exists('escape_html')) {
    function escape_html($str) {
        return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_locked) {
    $db_host = isset($_POST['db_host']) ? trim($_POST['db_host']) : 'localhost';
    $db_name = isset($_POST['db_name']) ? trim($_POST['db_name']) : 'mirbolouki_test1';
    $db_user = isset($_POST['db_user']) ? trim($_POST['db_user']) : 'mirbolouki_usrtest1';
    $db_pass = isset($_POST['db_pass']) ? trim($_POST['db_pass']) : '';
    
    $admin_user = isset($_POST['admin_user']) ? trim($_POST['admin_user']) : 'admin';
    $admin_pass = isset($_POST['admin_pass']) ? trim($_POST['admin_pass']) : 'AdminMirbolouki@2026';
    $admin_name = isset($_POST['admin_name']) ? trim($_POST['admin_name']) : 'مدیر سامانه میربلوکی';

    if (function_exists('mysqli_report')) {
        mysqli_report(MYSQLI_REPORT_OFF);
    }

    // ۱. بررسی اتصال به دیتابیس
    $conn = null;
    try {
        $conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);
    } catch (Exception $e) {
        $error_messages[] = 'خطا در اتصال به پایگاه داده: ' . $e->getMessage();
    }
    
    if ($conn && $conn->connect_error) {
        $error_messages[] = 'خطا در اتصال به پایگاه داده: ' . $conn->connect_error;
    } elseif ($conn && !$conn->connect_errno) {
        $conn->set_charset('utf8mb4');
        $status_messages[] = 'اتصال به دیتابیس با موفقیت برقرار شد.';

        // ۲. خواندن و اجرای فایل SQL
        $sql_file = __DIR__ . '/database/install.sql';
        if (!file_exists($sql_file)) {
            $error_messages[] = 'فایل database/install.sql یافت نشد.';
        } else {
            $sql_content = file_get_contents($sql_file);
            // تفکیک پرس‌وجوها بر اساس سمی‌کالن
            $queries = explode(';', $sql_content);
            $query_errors = 0;

            foreach ($queries as $q) {
                $q = trim($q);
                if (!empty($q)) {
                    if (!$conn->query($q)) {
                        $query_errors++;
                    }
                }
            }

            if ($query_errors === 0) {
                $status_messages[] = 'تمام جداول دیتابیس (۱۴ جدول) با موفقیت ایجاد شدند.';
            } else {
                $status_messages[] = 'جداول دیتابیس ایجاد/بروزرسانی شدند.';
            }

            // ۳. ایجاد یا بروزرسانی مدیر سامانه
            $admin_hash = password_hash($admin_pass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO `admins` (`username`, `password_hash`, `full_name`, `email`, `role`, `is_active`) VALUES (?, ?, ?, 'info@mirbolouki.com', 'superadmin', 1) ON DUPLICATE KEY UPDATE `password_hash` = ?, `full_name` = ?");
            if ($stmt) {
                $stmt->bind_param('sssss', $admin_user, $admin_hash, $admin_name, $admin_hash, $admin_name);
                $stmt->execute();
                $stmt->close();
                $status_messages[] = "کاربر مدیر با نام کاربری [{$admin_user}] ایجاد/بروزرسانی گردید.";
            }

            // ۴. ساخت پوشه‌های آپلود و فایل قفل
            $uploads_receipts = __DIR__ . '/uploads/receipts';
            $uploads_tests = __DIR__ . '/uploads/tests';
            if (!is_dir($uploads_receipts)) @mkdir($uploads_receipts, 0755, true);
            if (!is_dir($uploads_tests)) @mkdir($uploads_tests, 0755, true);

            // ایجاد فایل قفل جهت جلوگیری از نصب دوباره
            file_put_contents($lock_file, date('Y-m-d H:i:s'));
            $installed_successfully = true;
            $is_locked = true;
        }
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>نصب و راه‌اندازی سامانه آزمون‌های روان‌شناختی میربلوکی</title>
  <link rel="stylesheet" href="/assets/css/style.css?v=1.0.0">
  <style>
    body { background: #091424; color: #ffffff; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .install-box { width: 100%; max-width: 600px; background: #ffffff; color: #0f172a; border-radius: var(--radius-xl); padding: 40px; box-shadow: var(--shadow-luxury); }
  </style>
</head>
<body>

  <div class="install-box">
    
    <div style="text-align: center; margin-bottom: 24px;">
      <img src="/assets/images/logo.svg" alt="دکتر میربلوکی" style="max-height: 48px; margin: 0 auto 12px;">
      <h1 style="font-size: 1.5rem; margin-bottom: 6px;">راه‌اندازی آسان سامانه</h1>
      <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 0;">پیکربندی پایگاه داده و ایجاد دسترسی مدیر</p>
    </div>

    <?php if ($is_locked && !$installed_successfully): ?>
      <div class="alert alert-info">
        🔒 سامانه قبلاً با موفقیت نصب و قفل شده است.
      </div>
      <p style="font-size: 0.92rem; color: #475569;">جهت ورود به پنل مدیریت یا صفحه اصلی از پیوندهای زیر استفاده نمایید:</p>
      <div style="display: flex; gap: 10px; margin-top: 20px;">
        <a href="/admin/login.php" class="btn btn-primary btn-block">ورود به پنل مدیریت ↗</a>
        <a href="/" class="btn btn-outline btn-block">مشاهده سایت ↗</a>
      </div>
    <?php elseif ($installed_successfully): ?>
      <div class="alert alert-success">
        🎉 نصب سامانه با موفقیت ۱۰۰٪ به پایان رسید!
      </div>
      <ul style="font-size: 0.9rem; line-height: 1.8; color: #065f46; margin-bottom: 24px;">
        <?php foreach ($status_messages as $msg): ?>
          <li>✓ <?php echo escape_html($msg); ?></li>
        <?php endforeach; ?>
      </ul>
      <div style="background: #f8fafc; padding: 16px; border-radius: var(--radius-md); margin-bottom: 24px; font-size: 0.9rem; border: 1px solid var(--border-light);">
        <div>نام کاربری مدیر: <strong><?php echo escape_html($admin_user); ?></strong></div>
        <div>کلمه عبور مدیر: <strong><?php echo escape_html($admin_pass); ?></strong></div>
      </div>
      <a href="/admin/login.php" class="btn btn-primary btn-block btn-lg">ورود به پنل مدیریت</a>
    <?php else: ?>
      
      <?php if (!empty($error_messages)): ?>
        <div class="alert alert-danger">
          <?php foreach ($error_messages as $err): ?>
            <div>• <?php echo escape_html($err); ?></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="/install.php">
        
        <h4 style="font-size: 1.05rem; margin-bottom: 12px; color: var(--primary-teal);">۱. مشخصات اتصال پایگاه داده MySQL</h4>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <div class="form-group">
            <label class="form-label" for="db_host">هاست دیتابیس</label>
            <input type="text" id="db_host" name="db_host" class="form-control" value="localhost" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="db_name">نام دیتابیس</label>
            <input type="text" id="db_name" name="db_name" class="form-control" value="mirbolouki_test1" required>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <div class="form-group">
            <label class="form-label" for="db_user">نام کاربری دیتابیس</label>
            <input type="text" id="db_user" name="db_user" class="form-control" value="mirbolouki_usrtest1" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="db_pass">کلمه عبور دیتابیس</label>
            <input type="password" id="db_pass" name="db_pass" class="form-control" placeholder="رمز دیتابیس در هاست">
          </div>
        </div>

        <h4 style="font-size: 1.05rem; margin-top: 20px; margin-bottom: 12px; color: var(--primary-teal);">۲. تنظیمات حساب مدیر سامانه (Superadmin)</h4>

        <div class="form-group">
          <label class="form-label" for="admin_name">نام کامل مدیر</label>
          <input type="text" id="admin_name" name="admin_name" class="form-control" value="مدیر سامانه میربلوکی" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <div class="form-group">
            <label class="form-label" for="admin_user">نام کاربری ادمین</label>
            <input type="text" id="admin_user" name="admin_user" class="form-control" value="admin" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="admin_pass">کلمه عبور ادمین</label>
            <input type="text" id="admin_pass" name="admin_pass" class="form-control" value="AdminMirbolouki@2026" required>
          </div>
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 20px;">
          نصب و راه‌اندازی خودکار جداول
        </button>
      </form>
    <?php endif; ?>

  </div>

</body>
</html>
