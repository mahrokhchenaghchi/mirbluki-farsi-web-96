<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * ماژول مرکزی ارتباط با پایگاه داده (MySQLi Database Handler)
 * کاملاً منطبق بر PHP 7.x و بدون استفاده از PDO
 */

require_once dirname(__DIR__) . '/config/config.php';

/**
 * ایجاد و دریافت اتصال فعال به پایگاه داده
 * @return mysqli
 */
function db_connect() {
    static $conn = null;
    
    if ($conn === null) {
        if (function_exists('mysqli_report')) {
            mysqli_report(MYSQLI_REPORT_OFF);
        }
        
        // ایجاد اتصال جدید با mysqli
        $conn = mysqli_init();
        if (!$conn) {
            error_log('MySQLi init failed');
            die('خطا در راه‌اندازی درایور پایگاه داده.');
        }
        
        $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 5);
        
        $connected = @$conn->real_connect(
            DB_HOST,
            DB_USER,
            DB_PASS,
            DB_NAME,
            defined('DB_PORT') ? DB_PORT : 3306
        );
        
        if (!$connected || $conn->connect_errno) {
            error_log('Database Connection Error (' . $conn->connect_errno . '): ' . $conn->connect_error);
            die('خطا در برقراری ارتباط با پایگاه داده. لطفاً فایل config/config.php را بررسی فرمایید.');
        }
        
        // تنظیم صریح و استاندارد کدگذاری کاراکترها به utf8mb4
        mysqli_set_charset($conn, 'utf8mb4');
        @mysqli_query($conn, "SET NAMES 'utf8mb4'");
        @mysqli_query($conn, "SET CHARACTER SET 'utf8mb4'");
        @mysqli_query($conn, "SET character_set_connection = 'utf8mb4'");
    }
    
    return $conn;
}

/**
 * اجرای پرس‌وجوی آماده‌شده (Prepared Statement) به‌صورت امن
 * 
 * @param string $sql دستور SQL با نشانگرهای ?
 * @param string $types نوع داده پارامترها (مثلاً 'sisd' برای string, int, string, double)
 * @param array $params مقادیر پارامترها
 * @return array ['stmt' => mysqli_stmt, 'result' => mysqli_result|bool, 'insert_id' => int, 'affected_rows' => int]
 */
function db_query($sql, $types = '', $params = array()) {
    $conn = db_connect();
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log('Database Prepare Error: ' . $conn->error . ' | SQL: ' . $sql);
        return false;
    }
    
    if (!empty($types) && !empty($params)) {
        // سازگاری کامل با PHP 7 برای bind_param
        $bind_names = array();
        $bind_names[] = $types;
        for ($i = 0; $i < count($params); $i++) {
            $bind_name = 'bind_' . $i;
            $$bind_name = $params[$i];
            $bind_names[] = &$$bind_name;
        }
        call_user_func_array(array($stmt, 'bind_param'), $bind_names);
    }
    
    $execute_success = $stmt->execute();
    if (!$execute_success) {
        error_log('Database Execute Error: ' . $stmt->error . ' | SQL: ' . $sql);
        $stmt->close();
        return false;
    }
    
    $result = $stmt->get_result();
    $insert_id = $conn->insert_id;
    $affected_rows = $stmt->affected_rows;
    
    return array(
        'stmt' => $stmt,
        'result' => $result,
        'insert_id' => $insert_id,
        'affected_rows' => $affected_rows
    );
}

/**
 * دریافت یک سطر از پایگاه داده به‌صورت آرایه انجمنی (Associative Array)
 * 
 * @param string $sql
 * @param string $types
 * @param array $params
 * @return array|null
 */
function db_fetch_one($sql, $types = '', $params = array()) {
    $res = db_query($sql, $types, $params);
    if (!$res || !$res['result']) {
        if ($res && isset($res['stmt'])) {
            $res['stmt']->close();
        }
        return null;
    }
    
    $row = $res['result']->fetch_assoc();
    $res['stmt']->close();
    return $row ? $row : null;
}

/**
 * دریافت تمام سطرهای منطبق به‌صورت آرایه چندبعدی
 * 
 * @param string $sql
 * @param string $types
 * @param array $params
 * @return array
 */
function db_fetch_all($sql, $types = '', $params = array()) {
    $res = db_query($sql, $types, $params);
    if (!$res || !$res['result']) {
        if ($res && isset($res['stmt'])) {
            $res['stmt']->close();
        }
        return array();
    }
    
    $rows = array();
    while ($row = $res['result']->fetch_assoc()) {
        $rows[] = $row;
    }
    
    $res['stmt']->close();
    return $rows;
}

/**
 * درج یک رکورد در جدول و بازگرداندن شناسه ایجاد شده
 * 
 * @param string $table نام جدول
 * @param array $data آرایه کلید-مقدار فیلدها
 * @return int|bool شناسه رکورد جدید یا false
 */
function db_insert($table, $data) {
    $conn = db_connect();
    $columns = array_keys($data);
    $escaped_cols = array_map(function($col) {
        return '`' . str_replace('`', '', $col) . '`';
    }, $columns);
    
    $placeholders = array_fill(0, count($columns), '?');
    $sql = "INSERT INTO `{$table}` (" . implode(', ', $escaped_cols) . ") VALUES (" . implode(', ', $placeholders) . ")";
    
    $types = '';
    $params = array();
    foreach ($data as $value) {
        if (is_int($value)) {
            $types .= 'i';
        } elseif (is_float($value) || is_double($value)) {
            $types .= 'd';
        } else {
            $types .= 's';
        }
        $params[] = $value;
    }
    
    $res = db_query($sql, $types, $params);
    if ($res) {
        $insert_id = $res['insert_id'];
        $res['stmt']->close();
        return $insert_id;
    }
    
    return false;
}

/**
 * بروزرسانی رکورد در جدول
 * 
 * @param string $table نام جدول
 * @param array $data داده‌های جدید
 * @param string $where_sql شرط SQL
 * @param string $where_types انواع داده برای شرط
 * @param array $where_params مقادیر شرط
 * @return int|bool تعداد سطرهای ویرایش‌شده یا false
 */
function db_update($table, $data, $where_sql, $where_types = '', $where_params = array()) {
    $columns = array_keys($data);
    $set_parts = array();
    $types = '';
    $params = array();
    
    foreach ($data as $col => $value) {
        $set_parts[] = '`' . str_replace('`', '', $col) . '` = ?';
        if (is_int($value)) {
            $types .= 'i';
        } elseif (is_float($value) || is_double($value)) {
            $types .= 'd';
        } else {
            $types .= 's';
        }
        $params[] = $value;
    }
    
    $sql = "UPDATE `{$table}` SET " . implode(', ', $set_parts) . " WHERE " . $where_sql;
    $types .= $where_types;
    $params = array_merge($params, $where_params);
    
    $res = db_query($sql, $types, $params);
    if ($res) {
        $affected = $res['affected_rows'];
        $res['stmt']->close();
        return $affected;
    }
    
    return false;
}

/**
 * شروع تراکنش امن
 */
function db_begin_transaction() {
    $conn = db_connect();
    $conn->begin_transaction();
}

/**
 * تایید تراکنش
 */
function db_commit() {
    $conn = db_connect();
    $conn->commit();
}

/**
 * لغو و بازگرداندن تراکنش
 */
function db_rollback() {
    $conn = db_connect();
    $conn->rollback();
}
