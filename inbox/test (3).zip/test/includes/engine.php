<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * موتور مرکزی و یکتای اجرای آزمون و نمره‌دهی روان‌سنجی (Central Psychological Scoring Engine)
 * تمام محاسبات صرفاً در سمت سرور انجام می‌شود و غیرقابل دستکاری است.
 * سازگار با PHP 7.x
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

/**
 * دریافت مشخصات کامل یک آزمون بر اساس ID یا Slug
 */
function engine_get_test($id_or_slug) {
    if (is_numeric($id_or_slug)) {
        return db_fetch_one("SELECT * FROM `tests` WHERE `id` = ? LIMIT 1", 'i', array(intval($id_or_slug)));
    }
    return db_fetch_one("SELECT * FROM `tests` WHERE `slug` = ? LIMIT 1", 's', array(trim($id_or_slug)));
}

/**
 * دریافت ساختار کامل آزمون (ابعاد، سوالات، گزینه‌ها، قوانین نمره‌دهی و منابع علمی)
 */
function engine_get_test_structure($test_id) {
    $test = engine_get_test($test_id);
    if (!$test) {
        return null;
    }
    
    $dimensions = db_fetch_all(
        "SELECT * FROM `test_dimensions` WHERE `test_id` = ? ORDER BY `sort_order` ASC, `id` ASC",
        'i',
        array($test['id'])
    );
    
    $questions = db_fetch_all(
        "SELECT q.*, d.code as dimension_code, d.title as dimension_title, d.color_hex as dimension_color 
         FROM `test_questions` q 
         LEFT JOIN `test_dimensions` d ON q.dimension_id = d.id 
         WHERE q.test_id = ? 
         ORDER BY q.sort_order ASC, q.question_number ASC, q.id ASC",
        'i',
        array($test['id'])
    );
    
    $options = db_fetch_all(
        "SELECT * FROM `test_options` WHERE `test_id` = ? ORDER BY `sort_order` ASC, `option_number` ASC, `id` ASC",
        'i',
        array($test['id'])
    );
    
    $scoring_rules = db_fetch_all(
        "SELECT * FROM `test_scoring_rules` WHERE `test_id` = ? ORDER BY `min_range` ASC",
        'i',
        array($test['id'])
    );
    
    $sources = db_fetch_all(
        "SELECT * FROM `test_sources` WHERE `test_id` = ? ORDER BY `id` ASC",
        'i',
        array($test['id'])
    );
    
    return array(
        'test' => $test,
        'dimensions' => $dimensions,
        'questions' => $questions,
        'options' => $options,
        'scoring_rules' => $scoring_rules,
        'sources' => $sources
    );
}

/**
 * ایجاد یک نشست جدید برای اجرای آزمون
 */
function engine_create_session($test_id, $user_id = null) {
    $test = engine_get_test($test_id);
    if (!$test) {
        return false;
    }
    
    $token = generate_token(40);
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 255) : '';
    
    $session_data = array(
        'session_token' => $token,
        'test_id' => $test['id'],
        'test_version' => $test['version'],
        'status' => 'started',
        'ip_address' => $ip,
        'user_agent' => $ua
    );

    if (!empty($user_id) && intval($user_id) > 0) {
        $session_data['user_id'] = intval($user_id);
    }
    
    $session_id = db_insert('test_sessions', $session_data);
    
    if (!$session_id) {
        return false;
    }
    
    return array(
        'session_id' => $session_id,
        'session_token' => $token
    );
}

/**
 * اعتبارسنجی پاسخ‌های ارسال‌شده کاربر سمت سرور
 */
function engine_validate_answers($test_id, $submitted_answers) {
    $structure = engine_get_test_structure($test_id);
    if (!$structure || empty($structure['questions'])) {
        return array('valid' => false, 'message' => 'ساختار سوالات آزمون یافت نشد.');
    }
    
    $questions = $structure['questions'];
    $options = $structure['options'];
    $valid_option_ids = array();
    foreach ($options as $opt) {
        $valid_option_ids[intval($opt['id'])] = $opt;
    }
    
    $total_questions = count($questions);
    $answered_count = 0;
    $missing_questions = array();
    
    foreach ($questions as $q) {
        $q_id = intval($q['id']);
        if (!isset($submitted_answers[$q_id]) || $submitted_answers[$q_id] === '' || $submitted_answers[$q_id] === null) {
            $missing_questions[] = $q['question_number'];
        } else {
            $opt_id = intval($submitted_answers[$q_id]);
            if (!isset($valid_option_ids[$opt_id])) {
                return array('valid' => false, 'message' => 'گزینه انتخابی برای سؤال شماره ' . to_persian_num($q['question_number']) . ' معتبر نیست.');
            }
            $answered_count++;
        }
    }
    
    if (!empty($missing_questions)) {
        return array(
            'valid' => false,
            'message' => 'پاسخ به تمام سؤالات اجباری است. سؤالات بدون پاسخ: ' . to_persian_num(implode('، ', array_slice($missing_questions, 0, 10))) . (count($missing_questions) > 10 ? ' و ...' : ''),
            'missing_questions' => $missing_questions
        );
    }
    
    return array('valid' => true, 'total' => $total_questions);
}

/**
 * محاسبه نمرات خام، ابعاد، طبقه‌بندی و مستندسازی مسیر محاسبه (Scientific Scoring Calculation)
 */
function engine_calculate_scores($test_id, $submitted_answers) {
    $structure = engine_get_test_structure($test_id);
    if (!$structure) {
        return null;
    }
    
    $test = $structure['test'];
    $dimensions = $structure['dimensions'];
    $questions = $structure['questions'];
    $options = $structure['options'];
    $scoring_rules = $structure['scoring_rules'];
    
    // نگاشت گزینه‌ها برای دسترسی سریع
    $options_map = array();
    $min_option_val = null;
    $max_option_val = null;
    foreach ($options as $opt) {
        $val = floatval($opt['score_value']);
        $options_map[intval($opt['id'])] = $opt;
        if ($min_option_val === null || $val < $min_option_val) {
            $min_option_val = $val;
        }
        if ($max_option_val === null || $val > $max_option_val) {
            $max_option_val = $val;
        }
    }
    if ($min_option_val === null) $min_option_val = 1;
    if ($max_option_val === null) $max_option_val = count($options);
    
    // آماده‌سازی ابعاد برای تجمیع نمرات
    $dimension_scores = array();
    $dimension_details = array();
    foreach ($dimensions as $dim) {
        $dim_id = intval($dim['id']);
        $dimension_scores[$dim_id] = 0.0;
        $dimension_details[$dim_id] = array(
            'id' => $dim_id,
            'code' => $dim['code'],
            'title' => $dim['title'],
            'description' => $dim['description'],
            'min_score' => floatval($dim['min_score']),
            'max_score' => floatval($dim['max_score']),
            'color_hex' => $dim['color_hex'],
            'raw_score' => 0.0,
            'item_count' => 0,
            'average_score' => 0.0,
            'percentage' => 0.0,
            'category_name' => '',
            'severity_level' => 'normal',
            'interpretation' => ''
        );
    }
    
    $total_score = 0.0;
    $audit_trail = array();
    $processed_answers = array();
    
    // پیمایش سوالات و محاسبه نمره هر سوال
    foreach ($questions as $q) {
        $q_id = intval($q['id']);
        $opt_id = intval($submitted_answers[$q_id]);
        $opt_data = $options_map[$opt_id];
        
        $raw_val = floatval($opt_data['score_value']);
        $final_val = $raw_val;
        
        // در صورت نمره‌گذاری معکوس: Score = (Min + Max) - Value
        $is_reverse = intval($q['is_reverse_scored']) === 1;
        if ($is_reverse) {
            $final_val = ($min_option_val + $max_option_val) - $raw_val;
        }
        
        $total_score += $final_val;
        
        $dim_id = !empty($q['dimension_id']) ? intval($q['dimension_id']) : 0;
        if ($dim_id > 0 && isset($dimension_scores[$dim_id])) {
            $dimension_scores[$dim_id] += $final_val;
            $dimension_details[$dim_id]['raw_score'] += $final_val;
            $dimension_details[$dim_id]['item_count']++;
        }
        
        $processed_answers[] = array(
            'question_id' => $q_id,
            'option_id' => $opt_id,
            'calculated_score' => $final_val
        );
        
        // ثبت در لاگ مسیر استناد (Audit Trail)
        $audit_trail[] = array(
            'question_number' => $q['question_number'],
            'question_text' => $q['question_text'],
            'selected_option_number' => $opt_data['option_number'],
            'selected_option_text' => $opt_data['option_text'],
            'option_raw_score' => $raw_val,
            'is_reverse_scored' => $is_reverse,
            'item_final_score' => $final_val,
            'dimension_id' => $dim_id,
            'dimension_title' => !empty($q['dimension_title']) ? $q['dimension_title'] : 'عمومی'
        );
    }
    
    $is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
    
    // محاسبه میانگین، درصد، سطح شدت و تفسیر هر بعد
    foreach ($dimension_details as $d_id => &$d_info) {
        if ($d_info['item_count'] > 0) {
            $d_info['average_score'] = round($d_info['raw_score'] / $d_info['item_count'], 2);
            
            // محاسبه درصد دقیق مقیاس: (Raw - Min) / (Max - Min) * 100
            $range_span = ($d_info['max_score'] - $d_info['min_score']);
            if ($range_span > 0) {
                $d_info['percentage'] = round((($d_info['raw_score'] - $d_info['min_score']) / $range_span) * 100, 1);
            } else {
                $d_info['percentage'] = 0.0;
            }
        }
        
        // ارزیابی اختصاصی طرحواره‌ها بر اساس مشخصات YSQ_INTERPRETATION_SPEC_FINAL_v2.1
        if ($is_young_test) {
            $pct = $d_info['percentage'];
            if ($pct <= 20.0) {
                $d_info['severity_level'] = 'normal';
                $d_info['category_name'] = 'غیرفعال / سازگار (Dormant)';
                $d_info['interpretation'] = 'این طرحواره در شما خاموش و غیرفعال است و نشان‌دهنده تعادل و سلامت روان در این سازه می‌باشد.';
            } elseif ($pct <= 32.0) {
                $d_info['severity_level'] = 'low';
                $d_info['category_name'] = 'خفیف / کنترل‌شده (Quiescent)';
                $d_info['interpretation'] = 'طرحواره در شرایط عادی فعال نیست اما ممکن است در موقعیت‌های تنش‌زای خاص برانگیخته شود.';
            } elseif ($pct <= 48.0) {
                $d_info['severity_level'] = 'moderate';
                $d_info['category_name'] = 'متوسط / نیمه‌فعال (Emerging)';
                $d_info['interpretation'] = 'این سازه در مرز فعال‌سازی قرار دارد و نیازمند خودآگاهی و تمرین‌های خودتنظیمی است.';
            } elseif ($pct <= 68.0) {
                $d_info['severity_level'] = 'high';
                $d_info['category_name'] = 'بالا / فعال و پررنگ (Active)';
                $d_info['interpretation'] = 'طرحواره در الگوهای فکری و ارتباطی شما فعال است و بر تصمیم‌گیری‌ها اثرگذار می‌باشد.';
            } else {
                $d_info['severity_level'] = 'severe';
                $d_info['category_name'] = 'بسیار شدید / مسلط (Pervasive)';
                $d_info['interpretation'] = 'طرحواره به صورت هسته‌ای و فراگیر فعال بوده و اولویت اصلی در مداخلات طرحواره‌درمانی است.';
            }
        } else {
            // انطباق با قوانین نمره‌گذاری پایگاه داده برای سایر آزمون‌ها
            $matched_rule = null;
            foreach ($scoring_rules as $rule) {
                if ($rule['dimension_id'] == $d_id) {
                    if ($d_info['raw_score'] >= floatval($rule['min_range']) && $d_info['raw_score'] <= floatval($rule['max_range'])) {
                        $matched_rule = $rule;
                        break;
                    }
                }
            }
            
            if ($matched_rule) {
                $d_info['category_name'] = $matched_rule['category_name'];
                $d_info['severity_level'] = $matched_rule['severity_level'];
                $d_info['interpretation'] = $matched_rule['short_interpretation'];
            } else {
                // ارزیابی پیش‌فرض بر اساس درصد نمره
                $pct = $d_info['percentage'];
                if ($pct >= 75) {
                    $d_info['severity_level'] = 'severe';
                    $d_info['category_name'] = 'بسیار شدید / بالا';
                } elseif ($pct >= 50) {
                    $d_info['severity_level'] = 'high';
                    $d_info['category_name'] = 'بالا / شدید';
                } elseif ($pct >= 25) {
                    $d_info['severity_level'] = 'moderate';
                    $d_info['category_name'] = 'متوسط';
                } else {
                    $d_info['severity_level'] = 'normal';
                    $d_info['category_name'] = 'عادی / بهنجار';
                }
                $d_info['interpretation'] = "نمره کسب‌شده در این بعد برابر با " . to_persian_num($d_info['raw_score']) . " می‌باشد.";
            }
        }
    }
    unset($d_info);
    
    // تعیین طبقه‌بندی و وضعیت کلی آزمون
    $overall_category = 'پایان آزمون';
    $overall_severity = 'normal';
    $short_interpretation = 'پاسخ‌های شما با موفقیت ثبت و نمرات محاسبه گردیدند.';
    
    if ($is_young_test) {
        $overall_category = 'پروفایل جامع ۱۸ طرحواره یانگ';
        // شناسایی بالاترین طرحواره
        $top_schema = null;
        $max_pct = -1;
        foreach ($dimension_details as $d) {
            if ($d['percentage'] > $max_pct) {
                $max_pct = $d['percentage'];
                $top_schema = $d;
            }
        }
        if ($top_schema && $max_pct >= 50.0) {
            $overall_severity = 'high';
            $short_interpretation = "ارزیابی نشان‌دهنده فعال بودن طرحواره «{$top_schema['title']}» با شدت {$top_schema['percentage']}٪ به عنوان برجسته‌ترین الگوی شناختی مراجع است.";
        } elseif ($top_schema && $max_pct >= 30.0) {
            $overall_severity = 'moderate';
            $short_interpretation = "ارزیابی نشان‌دهنده تعادل نسبی با گرایش ملایم به سمت طرحواره «{$top_schema['title']}» (شدت {$top_schema['percentage']}٪) در شرایط پرفشار است.";
        } else {
            $overall_severity = 'normal';
            $short_interpretation = "تمامی ۱۸ طرحواره در محدوده بهنجار و غیرفعال قرار داشته و نشان‌دهنده انعطاف‌پذیری شناختی و سلامت روانی مناسب مراجع است.";
        }
    } else {
        foreach ($scoring_rules as $rule) {
            if (empty($rule['dimension_id']) || $rule['dimension_id'] == 0) {
                if ($total_score >= floatval($rule['min_range']) && $total_score <= floatval($rule['max_range'])) {
                    $overall_category = $rule['category_name'];
                    $overall_severity = $rule['severity_level'];
                    $short_interpretation = $rule['short_interpretation'];
                    break;
                }
            }
        }
    }
    
    return array(
        'total_score' => $total_score,
        'dimension_scores' => array_values($dimension_details),
        'overall_category' => $overall_category,
        'overall_severity' => $overall_severity,
        'short_interpretation' => $short_interpretation,
        'processed_answers' => $processed_answers,
        'audit_trail' => $audit_trail
    );
}

/**
 * ذخیره‌سازی نهایی نتیجه آزمون در پایگاه داده
 */
function engine_save_test_result($session_id, $user_id, $test_id, $calc_data) {
    db_begin_transaction();
    try {
        $test = engine_get_test($test_id);
        
        // ۱. بروزرسانی جلسه آزمون
        db_update('test_sessions', array(
            'user_id' => $user_id,
            'status' => 'completed',
            'completed_at' => date('Y-m-d H:i:s')
        ), 'id = ?', 'i', array($session_id));
        
        // ۲. حذف پاسخ‌های احتمالی قبلی این جلسه و درج پاسخ‌های قطعی
        db_query("DELETE FROM `user_answers` WHERE `session_id` = ?", 'i', array($session_id));
        
        foreach ($calc_data['processed_answers'] as $ans) {
            db_insert('user_answers', array(
                'session_id' => $session_id,
                'question_id' => $ans['question_id'],
                'option_id' => $ans['option_id'],
                'calculated_score' => $ans['calculated_score']
            ));
        }
        
        // ۳. حذف نتیجه قبلی این نشست در صورت وجود
        db_query("DELETE FROM `test_results` WHERE `session_id` = ?", 'i', array($session_id));
        
        // ۴. درج رکورد نتیجه نهایی در test_results
        $result_id = db_insert('test_results', array(
            'session_id' => $session_id,
            'user_id' => $user_id,
            'test_id' => $test['id'],
            'test_version' => $test['version'],
            'total_score' => $calc_data['total_score'],
            'dimension_scores_json' => json_encode($calc_data['dimension_scores'], JSON_UNESCAPED_UNICODE),
            'overall_category' => $calc_data['overall_category'],
            'overall_severity' => $calc_data['overall_severity'],
            'short_interpretation' => $calc_data['short_interpretation'],
            'scientific_audit_trail_json' => json_encode($calc_data['audit_trail'], JSON_UNESCAPED_UNICODE)
        ));
        
        db_commit();
        return $result_id;
    } catch (Exception $e) {
        db_rollback();
        error_log('Engine Save Result Error: ' . $e->getMessage());
        return false;
    }
}

/**
 * محاسبه نمرات حوزه‌های پنج‌گانه مرتبه دوم یانگ (5 Schema Domains Aggregation)
 */
function engine_calculate_schema_domains($dimension_scores) {
    $domain_definitions = array(
        'dom_1' => array('title' => 'حوزه ۱: بریدگی و طرد (Disconnection & Rejection)', 'schemas' => array('ED', 'AB', 'MA', 'DS', 'SI'), 'indices' => array(0, 1, 2, 3, 4), 'color' => '#0284c7'),
        'dom_2' => array('title' => 'حوزه ۲: خودگردانی و عملکرد مختل (Impaired Autonomy)', 'schemas' => array('DI', 'VH', 'EM', 'FA'), 'indices' => array(5, 6, 7, 8), 'color' => '#d97706'),
        'dom_3' => array('title' => 'حوزه ۳: محدودیت‌های مختل (Impaired Limits)', 'schemas' => array('ET', 'IS'), 'indices' => array(9, 10), 'color' => '#dc2626'),
        'dom_4' => array('title' => 'حوزه ۴: دیگرجهت‌مندی (Other-Directedness)', 'schemas' => array('SB', 'SS', 'AS'), 'indices' => array(11, 12, 13), 'color' => '#059669'),
        'dom_5' => array('title' => 'حوزه ۵: گوش‌به‌زنگی و بازداری (Overvigilance & Inhibition)', 'schemas' => array('NP', 'EI', 'US', 'PU'), 'indices' => array(14, 15, 16, 17), 'color' => '#4f46e5')
    );
    
    $schema_pct_map = array();
    $dim_list = array_values($dimension_scores);
    
    foreach ($dim_list as $idx => $dim) {
        $raw = isset($dim['raw_score']) ? floatval($dim['raw_score']) : 0.0;
        $max = (isset($dim['max_score']) && floatval($dim['max_score']) > 0) ? floatval($dim['max_score']) : ($raw > 0 ? $raw : 30.0);
        $pct = (isset($dim['percentage']) && floatval($dim['percentage']) > 0) ? floatval($dim['percentage']) : round(($raw / $max) * 100, 1);
        
        $code = isset($dim['code']) ? $dim['code'] : '';
        if ($code) {
            $schema_pct_map[$code] = $pct;
        }
        
        $title = isset($dim['title']) ? $dim['title'] : '';
        if (strpos($title, 'محرومیت') !== false) $schema_pct_map['ED'] = $pct;
        elseif (strpos($title, 'رهاشدگی') !== false) $schema_pct_map['AB'] = $pct;
        elseif (strpos($title, 'بی‌اعتمادی') !== false || strpos($title, 'بدرفتاری') !== false) $schema_pct_map['MA'] = $pct;
        elseif (strpos($title, 'انزوا') !== false || strpos($title, 'بیگانگی') !== false) $schema_pct_map['SI'] = $pct;
        elseif (strpos($title, 'نقص') !== false || strpos($title, 'شرم') !== false) $schema_pct_map['DS'] = $pct;
        elseif (strpos($title, 'شکست') !== false) $schema_pct_map['FA'] = $pct;
        elseif (strpos($title, 'وابستگی') !== false) $schema_pct_map['DI'] = $pct;
        elseif (strpos($title, 'آسیب') !== false) $schema_pct_map['VH'] = $pct;
        elseif (strpos($title, 'گرفتاری') !== false) $schema_pct_map['EM'] = $pct;
        elseif (strpos($title, 'اطاعت') !== false) $schema_pct_map['SB'] = $pct;
        elseif (strpos($title, 'ایثار') !== false) $schema_pct_map['SS'] = $pct;
        elseif (strpos($title, 'پذیرش') !== false || strpos($title, 'جلب توجه') !== false) $schema_pct_map['AS'] = $pct;
        elseif (strpos($title, 'منفی') !== false || strpos($title, 'بدبینی') !== false) $schema_pct_map['NP'] = $pct;
        elseif (strpos($title, 'بازداری') !== false) $schema_pct_map['EI'] = $pct;
        elseif (strpos($title, 'معیار') !== false || strpos($title, 'سرسخت') !== false) $schema_pct_map['US'] = $pct;
        elseif (strpos($title, 'استحقاق') !== false || strpos($title, 'بزرگ‌منشی') !== false) $schema_pct_map['ET'] = $pct;
        elseif (strpos($title, 'خویشتن') !== false || strpos($title, 'انضباط') !== false) $schema_pct_map['IS'] = $pct;
        elseif (strpos($title, 'تنبیه') !== false) $schema_pct_map['PU'] = $pct;
    }
    
    $domain_results = array();
    foreach ($domain_definitions as $dom_id => $dom_info) {
        $sum_pct = 0.0;
        $count = 0;
        foreach ($dom_info['schemas'] as $sch_code) {
            if (isset($schema_pct_map[$sch_code])) {
                $sum_pct += $schema_pct_map[$sch_code];
                $count++;
            }
        }
        
        // اگر کدی یافت نشد از اندیس‌های آرایه استفاده کن
        if ($count === 0 && count($dim_list) >= 18) {
            foreach ($dom_info['indices'] as $pos) {
                if (isset($dim_list[$pos])) {
                    $raw = floatval($dim_list[$pos]['raw_score']);
                    $max = floatval($dim_list[$pos]['max_score']) ?: 30.0;
                    $sum_pct += round(($raw / $max) * 100, 1);
                    $count++;
                }
            }
        }
        
        $avg_pct = $count > 0 ? round($sum_pct / $count, 1) : 0.0;
        $domain_results[$dom_id] = array(
            'id' => $dom_id,
            'title' => $dom_info['title'],
            'color' => $dom_info['color'],
            'percentage' => $avg_pct,
            'schemas_count' => $count,
            'severity' => ($avg_pct >= 50.0) ? 'high' : (($avg_pct >= 30.0) ? 'moderate' : 'normal')
        );
    }
    
    return $domain_results;
}

/**
 * ارزیابی الگوهای تعاملی چندبعدی (Pattern Engine - Layer 3 CLINICAL_HYPOTHESIS)
 */
function engine_evaluate_schema_patterns($dimension_scores) {
    $schema_map = array();
    foreach ($dimension_scores as $d) {
        $code = isset($d['code']) ? $d['code'] : '';
        $schema_map[$code] = isset($d['percentage']) ? floatval($d['percentage']) : 0.0;
    }
    
    $patterns = array();
    
    // Pattern 1: ایثار بالا + اطاعت پایین (Altruistic Self-Sacrifice vs Subjugation)
    if (isset($schema_map['SS']) && isset($schema_map['SB']) && $schema_map['SS'] >= 36.0 && $schema_map['SB'] <= 24.0) {
        $patterns[] = array(
            'rule_id' => 'R_PAT_SS_SB',
            'title' => 'الگوی ایثارگرانه مستقل (Altruistic Self-Sacrifice)',
            'tier' => 'Tier C (CLINICAL_HYPOTHESIS)',
            'source' => 'Arntz & Jacob (2013)',
            'description' => 'الگوی فداکاری مراجع ناشی از درونی‌سازی احساس مسئولیت و شفقت مفرط است، نه تسلیم منفعلانه یا ترس از مجازات و خشم دیگران.'
        );
    }
    
    // Pattern 2: استحقاق + معیارهای سرسختانه (Competitive Perfectionism)
    if (isset($schema_map['ET']) && isset($schema_map['US']) && $schema_map['ET'] >= 32.0 && $schema_map['US'] >= 30.0) {
        $patterns[] = array(
            'rule_id' => 'R_PAT_ET_US',
            'title' => 'کمال‌گرایی رقابت‌جویانه (Competitive Perfectionism)',
            'tier' => 'Tier C (CLINICAL_HYPOTHESIS)',
            'source' => 'Bamelis et al. (2014)',
            'description' => 'پیگیری اهداف با استانداردهای شخصی کمال‌گرایانه همراه با تمایل به ارجحیت و تمایز نسبت به همتایان که در صورت ناکامی ممکن است فشار روانی مضاعف ایجاد کند.'
        );
    }
    
    // Pattern 3: رهاشدگی + بی‌اعتمادی پایین (Affective Vulnerability Guard)
    if (isset($schema_map['AB']) && isset($schema_map['MA']) && $schema_map['AB'] >= 30.0 && $schema_map['MA'] <= 20.0) {
        $patterns[] = array(
            'rule_id' => 'R_PAT_AB_MA',
            'title' => 'آسیب‌پذیری عاطفی گزینشی (Selective Attachment Guard)',
            'tier' => 'Tier C (CLINICAL_HYPOTHESIS)',
            'source' => 'Young et al. (2003)',
            'description' => 'مراجع دیدگاه عمومی مثبتی به صداقت اطرافیان دارد اما در روابط صمیمی نزدیک، حساسیت بیشتری به غیاب یا فاصله‌گیری موقت نشان می‌دهد.'
        );
    }
    
    return $patterns;
}

/**
 * تولید نقشه اهداف درمانی پیشنهادی و پرسش‌های بالینی درمانگر (Treatment Map - Layer 4)
 */
function engine_generate_treatment_map($dimension_scores, $patterns = array()) {
    $treatment_map = array();
    
    foreach ($dimension_scores as $d) {
        $code = isset($d['code']) ? $d['code'] : '';
        $pct = isset($d['percentage']) ? floatval($d['percentage']) : 0.0;
        $title = isset($d['title']) ? $d['title'] : $code;
        
        if ($pct >= 30.0) {
            $entry = array(
                'schema_code' => $code,
                'schema_title' => $title,
                'percentage' => $pct,
                'priority' => ($pct >= 50.0) ? 'بالا (High)' : 'متوسط (Moderate)',
                'explore_questions' => array(),
                'treatment_target' => '',
                'intervention_domain' => '',
                'monitoring_metric' => '',
                'source' => 'Young (2003) / Arntz (2013)'
            );
            
            if ($code === 'SS') {
                $entry['explore_questions'] = array(
                    'آیا هنگام اختصاص زمان به خواسته‌های شخصی، احساس گناه یا عذاب وجدان را تجربه می‌کنید؟',
                    'آیا نشانه‌های روان‌تنی ناشی از استرس مزمن (سردرد تنشی، مشکلات گوارشی) وجود دارد؟'
                );
                $entry['treatment_target'] = 'تعدیل باورهای مسئولیت افراطی و ایجاد مرزهای سالم بین‌فردی';
                $entry['intervention_domain'] = 'آموزش رفتار جرأت‌مندانه، بازسازی شناختی احساس گناه و تمرین دریافت حمایت';
                $entry['monitoring_metric'] = 'مقیاس احساس گناه روزانه (۰-۱۰) و ساعات اختصاص‌یافته به مراقبت از خود';
            } elseif ($code === 'ET') {
                $entry['explore_questions'] = array(
                    'در موقعیت‌هایی که خواسته‌ها فوراً برآورده نمی‌شوند چه واکنشی نشان می‌دهید؟',
                    'دیدگاه اطرافیان درباره میزان درک متقابل شما در روابط چگونه است؟'
                );
                $entry['treatment_target'] = 'تقویت همدلی دوجانبه و پذیرش محدودیت‌های واقع‌بینانه';
                $entry['intervention_domain'] = 'تمرین‌های دیدگاه‌گیری (Perspective-Taking) و مهارت‌های حل تعارض';
                $entry['monitoring_metric'] = 'دفعات بروز احساس خشم ناشی از ناکامی در روابط روزمره';
            } elseif ($code === 'US') {
                $entry['explore_questions'] = array(
                    'آیا کمال‌گرایی در انجام بدون نقص کارها، مانع از استراحت و تفریح شما می‌شود؟',
                    'معیار شما برای ارزیابی عملکرد خود چیست (همه یا هیچ در برابر پیوستار)؟'
                );
                $entry['treatment_target'] = 'تعدیل معیارهای انعطاف‌ناپذیر و تمرین عملکرد خوبِ کافی';
                $entry['intervention_domain'] = 'تکنیک زنجیره پیوستار شناختی و جدول‌بندی تعادل کار-تفریح';
                $entry['monitoring_metric'] = 'سطح استرس ثبت‌شده در پایان وظایف کاری و تحصیلی';
            } elseif ($code === 'AB') {
                $entry['explore_questions'] = array(
                    'هنگام جدایی موقت یا دیر پاسخ دادن پیام توسط افراد مهم زندگی، چه افکاری فعال می‌شوند؟',
                    'آیا رفتارهای اطمینان‌طلبی افراطی برای حفظ ارتباط رخ می‌دهد؟'
                );
                $entry['treatment_target'] = 'تقویت حس امنیت درونی و آزمون واقعیت در برابر فاجعه‌سازی جدایی';
                $entry['intervention_domain'] = 'تکنیک‌های ذهن‌آگاهی و ثبت شواهد ردکننده رهاشدگی';
                $entry['monitoring_metric'] = 'تعداد رفتارهای اطمینان‌طلبی در طول هفته';
            } elseif ($code === 'PU') {
                $entry['explore_questions'] = array(
                    'در برابر خطاهای خود و دیگران چقدر فضا برای بخشش و درک شرایط قائل می‌شوید؟'
                );
                $entry['treatment_target'] = 'کاهش انتقادگری بی‌رحمانه و پرورش نگرش شفقت‌ورزانه به خود';
                $entry['intervention_domain'] = 'تکنیک‌های گفت‌وگوی صندلی با والد تنبیه‌گر درونی';
                $entry['monitoring_metric'] = 'شاخص خودسرزنش‌گری هفتگی';
            } else {
                $entry['explore_questions'] = array("بررسی موقعیت‌های فعال‌کننده این سازه در طول هفته.");
                $entry['treatment_target'] = "شناسایی محرک‌ها و اصلاح باورهای ناکارآمد مرتبط با {$title}";
                $entry['intervention_domain'] = "تکنیک‌های بازسازی شناختی و آزمایش رفتاری";
                $entry['monitoring_metric'] = "شاخص شدت احساسات منفی در موقعیت‌های هدف";
            }
            
            $treatment_map[] = $entry;
        }
    }
    
    return $treatment_map;
}

/**
 * موتور تولید تفسیر جامع و تخصصی روان‌شناختی بر پایه قوانین علمی (Full Interpretation Engine)
 * تحلیل داده‌محور، ساختاریافته و منطبق بر نقاط برش و راهنماهای بالینی آزمون
 */
function engine_generate_full_interpretation($result_id) {
    $result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array(intval($result_id)));
    if (!$result) {
        return false;
    }
    
    $user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array(intval($result['user_id'])));
    $test = engine_get_test($result['test_id']);
    if (!$test) {
        return false;
    }
    
    $dimension_scores = json_decode($result['dimension_scores_json'], true);
    if (!is_array($dimension_scores)) {
        $dimension_scores = array();
    }
    
    $sources = db_fetch_all("SELECT * FROM `test_sources` WHERE `test_id` = ? ORDER BY `id` ASC", 'i', array(intval($test['id'])));
    
    $user_name = $user ? ($user['first_name'] . ' ' . $user['last_name']) : 'مراجع محترم';
    $gender_title = ($user && $user['gender'] === 'female') ? 'خانم' : (($user && $user['gender'] === 'male') ? 'آقای' : 'مراجع گرامی');
    $age_str = $user ? to_persian_num($user['age']) . ' ساله' : '';
    $test_date = format_jalali_date($result['created_at']);
    
    $is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
    
    // ۱. هدر و مشخصات ارزیابی
    $report = "■ گزارش تخصصی و فرمول‌بندی بالینی آزمون: {$test['title']}\n";
    if (!empty($test['original_name'])) {
        $report .= "عنوان استاندارد لاتین: {$test['original_name']} (نسخه " . to_persian_num($result['test_version']) . ")\n";
    }
    $report .= "مراجع ارزیابی‌شده: {$gender_title} {$user_name} ({$age_str})\n";
    $report .= "تاریخ اجرای آزمون: {$test_date}\n\n";
    
    // ۲. بخش اول: خلاصه وضعیت بالینی در یک نگاه (Clinical Snapshot - Tier A/B)
    $report .= "════════════════════════════════════════════════════════════════\n";
    $report .= "۱. خلاصه وضعیت بالینی در یک نگاه (Clinical Snapshot)\n";
    $report .= "════════════════════════════════════════════════════════════════\n";
    $report .= "• طبقه‌بندی کلی نیمرخ: {$result['overall_category']}\n";
    $report .= "• نمره کل محاسبه‌شده: " . to_persian_num($result['total_score']) . " | سطح شدت کلی: " . format_severity_label($result['overall_severity']) . "\n";
    $report .= "• تفسیر کوتاه اولیه:\n{$result['short_interpretation']}\n\n";
    
    if ($is_young_test) {
        $domains = engine_calculate_schema_domains($dimension_scores);
        $report .= "■ نیمرخ حوزه‌های پنج‌گانه مرتبه دوم یانگ (5 Schema Domains):\n";
        foreach ($domains as $dom) {
            $report .= "  - حوزه «{$dom['title']}»: شدت " . to_persian_num($dom['percentage']) . "٪ (" . format_severity_label($dom['severity']) . ")\n";
        }
        $report .= "\n";
    }
    
    // ۳. بخش دوم: تحلیل ساختاریافته تک‌تک ابعاد (Dimension Analysis - Tier B)
    $report .= "════════════════════════════════════════════════════════════════\n";
    $report .= "۲. تحلیل ساختاریافته مؤلفه‌ها و زیرمقیاس‌ها (Evidence-Based Dimension Analysis)\n";
    $report .= "════════════════════════════════════════════════════════════════\n";
    
    $high_dimensions = array();
    $moderate_dimensions = array();
    $normal_dimensions = array();
    
    if (!empty($dimension_scores)) {
        foreach ($dimension_scores as $dim) {
            $dim_title = isset($dim['title']) ? $dim['title'] : 'بعد';
            $raw_sc = isset($dim['raw_score']) ? to_persian_num($dim['raw_score']) : '۰';
            $pct_val = isset($dim['percentage']) ? floatval($dim['percentage']) : 0.0;
            $pct_sc = to_persian_num($pct_val) . '٪';
            $cat_name = !empty($dim['category_name']) ? $dim['category_name'] : 'معمولی';
            $sev = isset($dim['severity_level']) ? $dim['severity_level'] : 'normal';
            $interp = !empty($dim['interpretation']) ? $dim['interpretation'] : 'در بازه هنجار قرار دارد.';
            
            $report .= "◀ بعد «{$dim_title}»:\n";
            $report .= "  - نمره خام: {$raw_sc} | شدت نسبی: {$pct_sc} | طبقه‌بندی: {$cat_name} | سطح: " . format_severity_label($sev) . "\n";
            $report .= "  - تحلیل روان‌سنجی: {$interp}\n\n";
            
            if ($sev === 'severe' || $sev === 'high') {
                $high_dimensions[] = $dim_title;
            } elseif ($sev === 'moderate') {
                $moderate_dimensions[] = $dim_title;
            } else {
                $normal_dimensions[] = $dim_title;
            }
        }
    }
    
    // ۴. بخش سوم: تحلیل الگوهای تعاملی و فرضیه‌سازی بالینی (Patterns - Tier C)
    $report .= "════════════════════════════════════════════════════════════════\n";
    $report .= "۳. فرضیه‌سازی بالینی و تعامل سازه‌ها (Cross-Dimension Patterns / Tier C)\n";
    $report .= "════════════════════════════════════════════════════════════════\n";
    
    $patterns = $is_young_test ? engine_evaluate_schema_patterns($dimension_scores) : array();
    if (!empty($patterns)) {
        foreach ($patterns as $p) {
            $report .= "• [{$p['tier']}] {$p['title']}:\n";
            $report .= "  {$p['description']}\n";
            $report .= "  (منبع استناد: {$p['source']})\n\n";
        }
    } else {
        if (!empty($high_dimensions)) {
            $report .= "• سازه‌های با فعالیت و شدت بالا:\n  " . implode('، ', $high_dimensions) . "\n\n";
        }
        if (!empty($moderate_dimensions)) {
            $report .= "• سازه‌های در مرز فعال‌سازی متوسط:\n  " . implode('، ', $moderate_dimensions) . "\n\n";
        }
        if (!empty($normal_dimensions)) {
            $report .= "• سازه‌های سازگار و نقاط قوت روان‌شناختی:\n  " . implode('، ', $normal_dimensions) . "\n\n";
        }
    }
    
    // ۵. بخش چهارم: نقشه پیشنهادی درمان و پرسش‌های بالینی (Treatment Map - Tier D)
    $report .= "════════════════════════════════════════════════════════════════\n";
    $report .= "۴. نقشه اهداف درمانی پیشنهادی و راهنمای درمانگر (Suggested Treatment Map / Tier D)\n";
    $report .= "════════════════════════════════════════════════════════════════\n";
    
    $treatment_map = engine_generate_treatment_map($dimension_scores, $patterns);
    if (!empty($treatment_map)) {
        foreach ($treatment_map as $t_entry) {
            $report .= "■ حوزه هدف: {$t_entry['schema_title']} (اولویت: {$t_entry['priority']})\n";
            $report .= "  • هدف بالینی: {$t_entry['treatment_target']}\n";
            $report .= "  • تکنیک‌های مداخله: {$t_entry['intervention_domain']}\n";
            if (!empty($t_entry['explore_questions'])) {
                $report .= "  • پرسش‌های اکتشافی برای درمانگر:\n";
                foreach ($t_entry['explore_questions'] as $q_item) {
                    $report .= "    - {$q_item}\n";
                }
            }
            $report .= "  • شاخص پایش تغییر: {$t_entry['monitoring_metric']}\n\n";
        }
    } else {
        $report .= "تمامی سازه‌ها در محدوده تعادل و هنجار قرار داشته و تمرکز بر حفظ راهبردهای انطباقی و خودمراقبتی توصیه می‌گردد.\n\n";
    }
    
    // ۶. بخش پنجم: منابع علمی و بیانیه سلب مسئولیت تشخیصی قطعی (References & Guardrails)
    $report .= "════════════════════════════════════════════════════════════════\n";
    $report .= "۵. مبانی استانداردسازی، مراجع دانشگاهی و مرزبندی بالینی\n";
    $report .= "════════════════════════════════════════════════════════════════\n";
    if (!empty($test['scientific_profile'])) {
        $report .= "• پیشینه ابزار: {$test['scientific_profile']}\n";
    }
    if (!empty($sources)) {
        $report .= "• مراجع دانشگاهی مورد استناد:\n";
        foreach ($sources as $s) {
            $report .= "  - {$s['citation_title']}";
            if (!empty($s['authors'])) $report .= " ({$s['authors']}, {$s['year']})";
            if (!empty($s['notes'])) $report .= " - {$s['notes']}";
            $report .= "\n";
        }
    }
    $report .= "\n⚠️ بیانیه مرزبندی بالینی (Clinical Decision Support Disclaimer): این گزارش یک ابزار کمک‌تشخیصی و تصمیم‌یار بالینی است که بر مبنای خودگزارش‌دهی مراجع تدوین شده و به هیچ عنوان جایگزین مصاحبه ساختاریافته بالینی، قضاوت تخصصی روان‌شناس یا تشخیص قطعی اختلالات روان‌پزشکی نمی‌باشد.\n";
    
    // تولید توصیه‌های عملی پیشنهادی
    $recs = "۱. بررسی ابعاد و الگوهای برجسته‌شده با درمانگر در جلسات مشاوره تخصصی\n";
    $recs .= "۲. ثبت موقعیت‌ها و محرک‌های فعال‌ساز در طول هفته جهت پایش خودآگاهی\n";
    $recs .= "۳. پیگیری تمرین‌های شناختی-رفتاری متناسب با نتایج این ارزیابی";
    if (!empty($high_dimensions)) {
        $recs .= "\n۴. اولویت‌بخشی به مداخله در زمینه «" . implode(' و ', array_slice($high_dimensions, 0, 2)) . "»";
    }

    return array(
        'scientific_interpretation' => $report,
        'clinical_recommendations' => $recs,
        'high_dimensions' => $high_dimensions,
        'patterns' => $patterns,
        'treatment_map' => $treatment_map
    );
}

/**
 * دریافت ردگیری علمی و مراجع دانشگاهی برای پنل مدیریت (Admin Scientific Traceability)
 */
function engine_get_interpretation_trace($result_id) {
    $result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array(intval($result_id)));
    if (!$result) {
        return array();
    }
    
    $test = engine_get_test($result['test_id']);
    $dimension_scores = json_decode($result['dimension_scores_json'], true);
    if (!is_array($dimension_scores)) {
        $dimension_scores = array();
    }
    
    $is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
    $patterns = $is_young_test ? engine_evaluate_schema_patterns($dimension_scores) : array();
    $treatment_map = engine_generate_treatment_map($dimension_scores, $patterns);
    
    $trace = array(
        'result_id' => $result['id'],
        'test_id' => $test['id'],
        'test_slug' => $test['slug'],
        'test_title' => $test['title'],
        'test_version' => $result['test_version'],
        'total_score' => $result['total_score'],
        'overall_category' => $result['overall_category'],
        'overall_severity' => $result['overall_severity'],
        'dimensions_count' => count($dimension_scores),
        'patterns_triggered' => count($patterns),
        'treatment_targets_count' => count($treatment_map),
        'evidence_tiers' => array(
            'Tier A (FACT)' => 'نمرات خام گویه‌ها و ضرایب خطی ابعاد',
            'Tier B (EVIDENCE-BASED)' => 'تفسیر تک‌تک ۱۸ طرحواره بر پایه راهنمای جفری یانگ (۲۰۰۳، ۲۰۰۵)',
            'Tier C (CLINICAL_HYPOTHESIS)' => 'فرضیه‌سازی الگوهای تعاملی چندبعدی (Pattern Rules)',
            'Tier D (TREATMENT_SUPPORT)' => 'نقشه اهداف درمانی پیشنهادی و پرسش‌های بالینی درمانگر'
        )
    );
    
    return $trace;
}

function format_severity_label($sev) {
    switch ($sev) {
        case 'severe': return 'بسیار شدید / مسلط';
        case 'high': return 'شدید / فعال';
        case 'moderate': return 'متوسط / نیمه‌فعال';
        case 'low': return 'خفیف / کنترل‌شده';
        case 'normal':
        default: return 'عادی / بهنجار / خاموش';
    }
}
