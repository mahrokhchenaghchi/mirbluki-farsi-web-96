<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی دکتر میربلوکی
 * موتور اختصاصی تولید گزارش‌های رسمی PDF (Professional PDF Report Engine)
 * 
 * سازگار با PHP 7.x و محیط‌های هاست اشتراکی (بدون وابستگی به Composer یا Node)
 * پشتیبانی کامل از زبان فارسی، چیدمان راست‌به‌چپ (RTL)، قلم وزیرمتن (Vazirmatn)،
 * نمودارهای برداری، هدر و فوتر اختصاصی در تمام صفحات، و حفاظت از محتوا.
 */

require_once __DIR__ . '/tcpdf/tcpdf.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/engine.php';

/**
 * کلاس اختصاصی گزارش‌گیری با سربرگ، پانویس و واترمارک رسمی برند
 */
class MirboloukiPDFReport extends TCPDF {
    public $report_title = '';
    public $report_type_label = '';
    public $report_id_str = '';
    public $client_name = '';

    /**
     * سربرگ رسمی در تمامی صفحات
     */
    public function Header() {
        if (!$this->print_header) {
            return;
        }

        $this->setRTL(true);
        $this->SetFont('vazirmatn', '', 8);

        $emblem_path = ROOT_PATH . '/assets/images/joma-emblem-logo.jpg';
        $emblem_img_tag = file_exists($emblem_path) ? '<img src="' . $emblem_path . '" width="24" height="24" />' : '⚜';

        $header_html = '
        <table cellpadding="3" cellspacing="0" style="width: 100%; border-bottom: 1.5px solid #0f766e; font-size: 8pt; color: #475569;">
          <tr>
            <td style="width: 10%; vertical-align: middle; text-align: right;">
              ' . $emblem_img_tag . '
            </td>
            <td style="width: 60%; vertical-align: middle; text-align: right;">
              <div style="font-size: 9pt; font-weight: bold; color: #0f172a;">دکتر جواد میربلوکی | سامانه تخصصی ارزیابی‌های روان‌شناختی</div>
              <div style="font-size: 7.5pt; color: #64748b;">test.mirbolouki.com &bull; ' . escape_html($this->report_type_label) . '</div>
            </td>
            <td style="width: 30%; vertical-align: middle; text-align: left;" dir="ltr">
              <div style="font-size: 8pt; font-weight: bold; color: #0f766e; font-family: monospace;">' . escape_html($this->report_id_str) . '</div>
              <div style="font-size: 7pt; color: #94a3b8;">Official Assessment</div>
            </td>
          </tr>
        </table>';

        $this->SetY(6);
        $this->writeHTMLCell(190, 16, 10, 6, $header_html, 0, 1, false, true, 'R', true);
    }

    /**
     * پانویس رسمی در تمامی صفحات
     */
    public function Footer() {
        if (!$this->print_footer) {
            return;
        }

        $this->setRTL(true);
        $this->SetY(-15);
        $this->SetFont('vazirmatn', '', 7.5);

        $page_str = 'صفحه ' . $this->getAliasNumPage() . ' از ' . $this->getAliasNbPages();

        $footer_html = '
        <table cellpadding="2" cellspacing="0" style="width: 100%; border-top: 1px solid #e2e8f0; font-size: 7pt; color: #64748b;">
          <tr>
            <td style="width: 45%; text-align: right;">
              سامانه آزمون‌های روان‌شناختی میربلوکی &bull; <span dir="ltr">test.mirbolouki.com</span>
            </td>
            <td style="width: 30%; text-align: center; color: #0f766e; font-weight: bold;">
              شناسه: ' . escape_html($this->report_id_str) . '
            </td>
            <td style="width: 25%; text-align: left; font-weight: bold;">
              ' . $page_str . '
            </td>
          </tr>
          <tr>
            <td colspan="3" style="text-align: center; font-size: 6.2pt; color: #94a3b8; padding-top: 2px;">
              این سند حاوی اطلاعات محرمانه روان‌سنجی مراجع است و صرفاً برای تصمیم‌یاری بالینی و خودشناسی صادر شده است.
            </td>
          </tr>
        </table>';

        $this->writeHTMLCell(190, 12, 10, $this->GetY(), $footer_html, 0, 1, false, true, 'R', true);
    }
}

/**
 * ایجاد شیء پایه PDF با تنظیمات فونت، مارجین و امنیت
 */
function pdf_init_instance($report_title, $report_type_label, $report_id_str, $client_name = '') {
    $pdf = new MirboloukiPDFReport(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    $pdf->report_title = $report_title;
    $pdf->report_type_label = $report_type_label;
    $pdf->report_id_str = $report_id_str;
    $pdf->client_name = $client_name;

    // متادیتای حرفه‌ای سند
    $pdf->SetCreator('Mirbolouki Psychological Assessment Platform');
    $pdf->SetAuthor('دکتر جواد میربلوکی');
    $pdf->SetTitle($report_title . ' - ' . $client_name);
    $pdf->SetSubject('کارنامه ارزیابی روان‌شناختی استاندارد');
    $pdf->SetKeywords('روانشناسی, طرحواره درمانی, میربلوکی, آزمون روانی, فرمول‌بندی بالینی, خودشناسی');

    // تنظیمات امنیت PDF (غیرفعال‌سازی ویرایش مستقیم و فرم‌ها)
    $pdf->SetProtection(array('print', 'copy'), '', null, 0, null);

    // تنظیم جهت راست‌به‌چپ
    $pdf->setRTL(true);

    // ثبت قلم‌های استاندارد
    $pdf->SetFont('vazirmatn', '', 10);

    // تنظیم مارجین‌های صفحه (A4)
    $pdf->SetMargins(10, 24, 10);
    $pdf->SetHeaderMargin(5);
    $pdf->SetFooterMargin(14);
    $pdf->SetAutoPageBreak(TRUE, 18);

    return $pdf;
}

/**
 * تولید نمودار برداری نمرات ابعاد به صورت HTML جدول‌بندی‌شده دقیق
 */
function pdf_render_dimension_bars_html($dimension_scores) {
    if (empty($dimension_scores) || !is_array($dimension_scores)) {
        return '';
    }

    $html = '<table cellpadding="4" cellspacing="0" style="width: 100%; border-collapse: collapse; font-size: 8pt;">';
    $html .= '<tr style="background-color: #0f172a; color: #ffffff; font-weight: bold;">
                <th style="width: 32%; text-align: right; padding: 5px;">مؤلفه / بعد روان‌سنجی</th>
                <th style="width: 14%; text-align: center; padding: 5px;">نمره خام</th>
                <th style="width: 38%; text-align: right; padding: 5px;">نمودار شدت نسبی</th>
                <th style="width: 16%; text-align: center; padding: 5px;">سطح بالینی</th>
              </tr>';

    $i = 0;
    foreach ($dimension_scores as $dim) {
        $bg = ($i % 2 === 0) ? '#ffffff' : '#f8fafc';
        $title = isset($dim['title']) ? escape_html($dim['title']) : 'بعد';
        
        $raw_val = isset($dim['raw_score']) ? floatval($dim['raw_score']) : 0;
        $max_val = (isset($dim['max_score']) && $dim['max_score'] > 0) ? floatval($dim['max_score']) : ($raw_val > 0 ? $raw_val : 10);
        
        $pct_val = (isset($dim['percentage']) && floatval($dim['percentage']) > 0) 
            ? floatval($dim['percentage']) 
            : round(($raw_val / $max_val) * 100);
            
        $raw_str = to_persian_num($raw_val);
        $max_str = to_persian_num($max_val);
        $color = !empty($dim['color_hex']) ? $dim['color_hex'] : '#0f766e';
        $sev = isset($dim['severity_level']) ? $dim['severity_level'] : 'normal';
        $sev_label = format_severity_label($sev);
        
        // رنگ نشانگر سطح
        $sev_bg = '#dcfce7';
        $sev_color = '#15803d';
        if ($sev === 'severe' || $sev === 'high') {
            $sev_bg = '#fee2e2';
            $sev_color = '#b91c1c';
        } elseif ($sev === 'moderate') {
            $sev_bg = '#fef3c7';
            $sev_color = '#b45309';
        }

        $bar_pct = max(4, min(100, round($pct_val)));
        $remain_pct = 100 - $bar_pct;

        $html .= '<tr style="background-color: ' . $bg . '; border-bottom: 1px solid #e2e8f0;">';
        $html .= '<td style="width: 32%; font-weight: bold; color: #1e293b; padding: 4px 5px;">' . $title . '</td>';
        $html .= '<td style="width: 14%; text-align: center; color: #475569; padding: 4px 5px;">' . $raw_str . ' <span style="font-size: 6.8pt; color: #94a3b8;">از ' . $max_str . '</span></td>';
        
        // رسم نوار پیشرفت با عرض صریح
        $html .= '<td style="width: 38%; padding: 4px 5px; vertical-align: middle;">
                    <table cellpadding="0" cellspacing="0" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 3px;">
                      <tr>
                        <td style="width: ' . $bar_pct . '%; background-color: ' . $color . '; height: 8px; font-size: 1px; line-height: 8px;">&nbsp;</td>
                        <td style="width: ' . $remain_pct . '%; background-color: #f1f5f9; height: 8px; font-size: 1px; line-height: 8px;">&nbsp;</td>
                      </tr>
                    </table>
                    <div style="font-size: 6.8pt; color: #64748b; margin-top: 1px;">شدت: ' . to_persian_num($pct_val) . '٪</div>
                  </td>';
        
        $html .= '<td style="width: 16%; text-align: center; padding: 4px 5px;">
                    <span style="background-color: ' . $sev_bg . '; color: ' . $sev_color . '; padding: 2px 4px; font-size: 7pt; font-weight: bold; border-radius: 3px;">' . $sev_label . '</span>
                  </td>';
        $html .= '</tr>';
        $i++;
    }

    $html .= '</table>';
    return $html;
}

/**
 * تولید کارت مشخصات مراجع و اطلاعات سند
 */
function pdf_render_client_info_card($user, $test, $result, $report_id_str, $report_type_title) {
    $user_name = $user ? escape_html($user['first_name'] . ' ' . $user['last_name']) : 'مراجع محترم';
    $gender_title = ($user && $user['gender'] === 'female') ? 'زن' : (($user && $user['gender'] === 'male') ? 'مرد' : 'ثبت‌نشده');
    $age_str = ($user && !empty($user['age'])) ? to_persian_num($user['age']) . ' سال' : 'ثبت‌نشده';
    $mobile_masked = ($user && !empty($user['mobile'])) ? substr($user['mobile'], 0, 4) . '***' . substr($user['mobile'], -4) : '—';
    $test_date = format_jalali_date($result['created_at']);
    $report_date = format_jalali_date(date('Y-m-d H:i:s'));

    $html = '
    <table cellpadding="5" cellspacing="0" style="width: 100%; background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 5px; margin-bottom: 10px; font-size: 8pt;">
      <tr>
        <td style="width: 50%; border-bottom: 1px solid #e2e8f0;">
          <span style="color: #64748b;">نام و نام خانوادگی مراجع:</span> 
          <strong style="color: #0f172a; font-size: 9pt;">' . $user_name . '</strong>
        </td>
        <td style="width: 50%; border-bottom: 1px solid #e2e8f0;">
          <span style="color: #64748b;">عنوان ابزار سنجش:</span> 
          <strong style="color: #0f766e;">' . escape_html($test['title']) . '</strong>
        </td>
      </tr>
      <tr>
        <td style="width: 25%; border-bottom: 1px solid #e2e8f0;">
          <span style="color: #64748b;">جنسیت:</span> <strong>' . $gender_title . '</strong>
        </td>
        <td style="width: 25%; border-bottom: 1px solid #e2e8f0;">
          <span style="color: #64748b;">سن:</span> <strong>' . $age_str . '</strong>
        </td>
        <td style="width: 25%; border-bottom: 1px solid #e2e8f0;">
          <span style="color: #64748b;">نسخه آزمون:</span> <strong>' . to_persian_num($result['test_version']) . '</strong>
        </td>
        <td style="width: 25%; border-bottom: 1px solid #e2e8f0;">
          <span style="color: #64748b;">شماره تماس:</span> <strong dir="ltr">' . $mobile_masked . '</strong>
        </td>
      </tr>
      <tr>
        <td style="width: 35%;">
          <span style="color: #64748b;">تاریخ آزمون:</span> <strong>' . $test_date . '</strong>
        </td>
        <td style="width: 35%;">
          <span style="color: #64748b;">تاریخ صدور گزارش:</span> <strong>' . $report_date . '</strong>
        </td>
        <td style="width: 30%; text-align: left;">
          <span style="color: #64748b;">شناسه:</span> <strong style="color: #d97706; font-family: monospace;" dir="ltr">' . $report_id_str . '</strong>
        </td>
      </tr>
    </table>';
    return $html;
}

/**
 * =========================================================================
 * 1. تولید گزارش کارنامه اولیه مراجع (REPORT TYPE A — INITIAL INTERPRETATION)
 * =========================================================================
 */
function pdf_generate_initial_report($result_id, $output_type = 'F') {
    $result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array(intval($result_id)));
    if (!$result) {
        return false;
    }

    $test = engine_get_test($result['test_id']);
    $user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($result['user_id']));
    $dimension_scores = json_decode($result['dimension_scores_json'], true);

    $report_id_str = 'RPT-INI-' . str_pad($result['id'], 6, '0', STR_PAD_LEFT);
    $user_full_name = $user ? ($user['first_name'] . ' ' . $user['last_name']) : 'مراجع';

    $pdf = pdf_init_instance('کارنامه ارزیابی روان‌شناختی', 'تفسیر اولیه (Initial Report)', $report_id_str, $user_full_name);
    $pdf->AddPage();

    // عنوان اصلی گزارش
    $html = '
    <div style="text-align: center; margin-bottom: 6px;">
      <h1 style="color: #0f172a; font-size: 13pt; font-weight: bold; margin: 0;">کارنامه و گزارش ارزیابی روان‌شناختی</h1>
      <div style="font-size: 8.5pt; color: #0f766e; font-weight: bold; margin-top: 2px;">' . escape_html($test['title']) . '</div>
    </div>';

    // جدول اطلاعات هویتی و مشخصات آزمون
    $html .= pdf_render_client_info_card($user, $test, $result, $report_id_str, 'گزارش ارزیابی اولیه');

    // محاسبه نمره کل و سقف
    $total_sc_val = floatval($result['total_score']);
    $max_sc_val = 0;
    if (is_array($dimension_scores)) {
        foreach ($dimension_scores as $d) {
            $max_sc_val += isset($d['max_score']) ? floatval($d['max_score']) : 0;
        }
    }
    if ($max_sc_val <= 0) {
        $max_sc_val = $total_sc_val > 0 ? $total_sc_val : 100;
    }

    // کادر خلاصه نمره کل و دسته‌بندی
    $sev_label = format_severity_label($result['overall_severity']);
    $sev_bg = '#dcfce7'; $sev_color = '#15803d';
    if ($result['overall_severity'] === 'severe' || $result['overall_severity'] === 'high') {
        $sev_bg = '#fee2e2'; $sev_color = '#b91c1c';
    } elseif ($result['overall_severity'] === 'moderate') {
        $sev_bg = '#fef3c7'; $sev_color = '#b45309';
    }

    $html .= '
    <table cellpadding="6" cellspacing="0" style="width: 100%; background-color: #091424; color: #ffffff; border-radius: 5px; margin-bottom: 10px;">
      <tr>
        <td style="width: 25%; text-align: center; border-left: 1px solid #1e293b; vertical-align: middle;">
          <div style="font-size: 7.5pt; color: #94a3b8;">نمره کل آزمون</div>
          <div style="font-size: 16pt; font-weight: bold; color: #fbbf24; margin: 2px 0;">' . to_persian_num($total_sc_val) . '</div>
          <div style="font-size: 6.8pt; color: #cbd5e1;">از حداکثر ' . to_persian_num($max_sc_val) . '</div>
        </td>
        <td style="width: 75%; padding-right: 10px;">
          <div style="margin-bottom: 3px;">
            <strong style="font-size: 9.5pt; color: #ffffff;">طبقه‌بندی کلی: ' . escape_html($result['overall_category']) . '</strong>
            &nbsp;
            <span style="background-color: ' . $sev_bg . '; color: ' . $sev_color . '; font-size: 7.5pt; font-weight: bold; padding: 2px 5px; border-radius: 3px;">' . $sev_label . '</span>
          </div>
          <div style="font-size: 8pt; color: #cbd5e1; line-height: 1.5;">' . nl2br(escape_html($result['short_interpretation'])) . '</div>
        </td>
      </tr>
    </table>';

    // حوزه‌های ۵گانه طرحواره‌ها در صورت وجود
    $is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
    if ($is_young_test && !empty($dimension_scores)) {
        $domains = engine_calculate_schema_domains($dimension_scores);
        $html .= '<h3 style="font-size: 9.5pt; color: #0f172a; margin: 8px 0 4px; border-bottom: 1.5px solid #0f766e; padding-bottom: 2px;">حوزه‌های پنج‌گانه نیازهای هیجانی تحولی (Schema Domains)</h3>';
        $html .= '<table cellpadding="4" cellspacing="0" style="width: 100%; margin-bottom: 10px; font-size: 7.5pt;"><tr>';
        
        foreach ($domains as $dom) {
            $html .= '<td style="width: 20%; background-color: #f8fafc; border: 1px solid #e2e8f0; border-top: 3px solid ' . $dom['color'] . '; border-radius: 4px; padding: 5px; text-align: center;">
                        <div style="font-weight: bold; color: #1e293b; font-size: 7pt; height: 18px;">' . escape_html($dom['title']) . '</div>
                        <div style="font-size: 11pt; font-weight: bold; color: ' . $dom['color'] . '; margin: 1px 0;">' . to_persian_num($dom['percentage']) . '٪</div>
                        <div style="font-size: 6.8pt; color: #64748b;">' . format_severity_label($dom['severity']) . '</div>
                      </td>';
        }
        $html .= '</tr></table>';
    }

    // جدول و نمودار تفکیکی ابعاد
    $html .= '<h3 style="font-size: 9.5pt; color: #0f172a; margin: 8px 0 4px; border-bottom: 1.5px solid #0f766e; padding-bottom: 2px;">کارنامه و نمودار نیم‌رخ مؤلفه‌های ارزیابی‌شده</h3>';
    $html .= pdf_render_dimension_bars_html($dimension_scores);

    // نقاط قوت و حوزه‌های نیازمند توجه (Dynamic Key Findings)
    $high_items = array();
    $norm_items = array();
    if (!empty($dimension_scores)) {
        foreach ($dimension_scores as $d) {
            if ($d['severity_level'] === 'severe' || $d['severity_level'] === 'high') {
                $high_items[] = '<strong>«' . escape_html($d['title']) . '»</strong> (نمره: ' . to_persian_num($d['raw_score']) . ')';
            } elseif ($d['severity_level'] === 'normal') {
                $norm_items[] = '<strong>«' . escape_html($d['title']) . '»</strong>';
            }
        }
    }

    $html .= '<div style="margin-top: 8px;">';
    if (!empty($high_items)) {
        $html .= '<div style="background-color: #fff1f2; border: 1px solid #fecdd3; border-radius: 5px; padding: 6px 8px; margin-bottom: 6px; font-size: 7.5pt; color: #9f1239;">
                    <strong>مؤلفه‌های با شدت بالا (حوزه‌های اولویت‌دار جهت بررسی):</strong> ' . implode(' • ', $high_items) . '
                  </div>';
    }
    if (!empty($norm_items)) {
        $html .= '<div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 5px; padding: 6px 8px; margin-bottom: 6px; font-size: 7.5pt; color: #166534;">
                    <strong>سازه‌های متعادل و نقاط قوت روان‌شناختی:</strong> ' . implode(' • ', array_slice($norm_items, 0, 8)) . '
                  </div>';
    }
    $html .= '</div>';

    // بیانیه مرزبندی بالینی و اخلاقی (Clinical Disclaimer)
    $html .= '
    <div style="background-color: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 5px; padding: 6px 8px; margin-top: 8px; font-size: 6.8pt; color: #64748b; line-height: 1.4;">
      <strong>بیانیه مرزبندی بالینی (Clinical Disclaimer):</strong> این کارنامه بر پایه خودگزارش‌دهی مراجع و پردازش روان‌سنجی رایانه‌ای تنظیم شده و به عنوان ابزار غربالگری و تصمیم‌یار عمل می‌کند؛ تشخیص قطعی روان‌پزشکی و بالینی تنها از طریق مصاحبه ساختاریافته توسط متخصص روان‌شناس یا روان‌پزشک امکان‌پذیر است.
    </div>';

    // پل خودمدیریتی جوما (غیرتهاجمی)
    $html .= '
    <div style="background-color: #fffbeb; border: 1px solid #fef3c7; border-radius: 5px; padding: 5px 8px; margin-top: 5px; font-size: 6.8pt; color: #92400e; text-align: center;">
      <strong>گام بعد از خودآگاهی:</strong> جهت تبدیل نتایج آزمون به عادات پایدار روزمره، از پلنر هوشمند روان‌شناسی <strong>جوما</strong> (<span dir="ltr">joma.mirbolouki.com</span>) استفاده نمایید.
    </div>';

    $pdf->writeHTML($html, true, false, true, false, '');

    // مسیر ذخیره امن فایل
    $cache_dir = ROOT_PATH . '/uploads/reports';
    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0755, true);
    }
    $file_name = 'Mirbolouki-' . $test['slug'] . '-Initial-' . $result['id'] . '.pdf';
    $file_path = $cache_dir . '/' . $file_name;

    if ($output_type === 'F') {
        $pdf->Output($file_path, 'F');
        return $file_path;
    } elseif ($output_type === 'I' || $output_type === 'D') {
        $pdf->Output($file_name, $output_type);
        exit;
    }
    return $file_path;
}

/**
 * =========================================================================
 * 2. تولید گزارش تفسیر پیشرفته بالینی (REPORT TYPE B — ADVANCED INTERPRETATION)
 * =========================================================================
 */
function pdf_generate_advanced_report($result_id, $output_type = 'F') {
    $result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array(intval($result_id)));
    if (!$result) {
        return false;
    }

    // بررسی انتشار تفسیر پیشرفته
    $full_interp = db_fetch_one(
        "SELECT * FROM `full_interpretations` WHERE `result_id` = ? AND `status` = 'published' LIMIT 1",
        'i',
        array(intval($result_id))
    );
    if (!$full_interp) {
        return false; // فقط گزارش‌های منتشرشده قابل تولید در نسخه پیشرفته هستند
    }

    $test = engine_get_test($result['test_id']);
    $user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($result['user_id']));
    $sources = db_fetch_all("SELECT * FROM `test_sources` WHERE `test_id` = ? ORDER BY `id` ASC", 'i', array(intval($test['id'])));
    $dimension_scores = json_decode($result['dimension_scores_json'], true);

    $report_id_str = 'RPT-ADV-' . str_pad($result['id'], 6, '0', STR_PAD_LEFT);
    $user_full_name = $user ? ($user['first_name'] . ' ' . $user['last_name']) : 'مراجع محترم';
    $gender_title = ($user && $user['gender'] === 'female') ? 'خانم' : (($user && $user['gender'] === 'male') ? 'آقای' : 'مراجع گرامی');

    $pdf = pdf_init_instance('گزارش جامع فرمول‌بندی بالینی و تفسیر پیشرفته', 'تفسیر پیشرفته (Advanced Report)', $report_id_str, $user_full_name);

    // ==========================================
    // ۱. صفحه جلد اختصاصی و شکیل (Cover Page)
    // ==========================================
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    $pdf->AddPage();

    // پس‌زمینه تیره و لوکس جلد
    $pdf->SetFillColor(9, 20, 36);
    $pdf->Rect(0, 0, 210, 297, 'F');

    // کادر طلایی جلد
    $pdf->SetLineStyle(array('width' => 1, 'color' => array(217, 119, 6)));
    $pdf->Rect(10, 10, 190, 277);
    $pdf->SetLineStyle(array('width' => 0.3, 'color' => array(15, 118, 110)));
    $pdf->Rect(12, 12, 186, 273);

    // نشان اختصاصی / لوگو در مرکز
    $emblem_path = ROOT_PATH . '/assets/images/joma-emblem-logo.jpg';
    $emblem_img_tag = file_exists($emblem_path) ? '<img src="' . $emblem_path . '" width="80" height="80" style="border-radius: 50%;" />' : '';

    $cover_html = '
    <div style="text-align: center; color: #ffffff; padding-top: 30px;">
      <div>' . $emblem_img_tag . '</div>
      
      <div style="font-size: 13pt; color: #fbbf24; font-weight: bold; margin-top: 15px; letter-spacing: 1px;">دکتر جواد میربلوکی</div>
      <div style="font-size: 8pt; color: #94a3b8; margin-top: 3px;">سامانه تخصصی ارزیابی‌های بالینی و روان‌سنجی &bull; <span dir="ltr">test.mirbolouki.com</span></div>
      
      <div style="margin: 30px 0 15px;">
        <div style="display: inline-block; background-color: #0f766e; color: #ffffff; padding: 4px 16px; font-size: 8.5pt; font-weight: bold; border-radius: 15px;">
          گزارش جامع فرمول‌بندی بالینی و تفسیر پیشرفته
        </div>
        <h1 style="font-size: 16pt; color: #ffffff; font-weight: bold; margin: 12px 0 6px; line-height: 1.4;">
          ' . escape_html($test['title']) . '
        </h1>';
        
    if (!empty($test['original_name'])) {
        $cover_html .= '<div style="font-size: 8.5pt; color: #2dd4bf; font-family: sans-serif;" dir="ltr">' . escape_html($test['original_name']) . '</div>';
    }

    $cover_html .= '
      </div>

      <div style="margin-top: 25px; background-color: rgba(15, 23, 42, 0.85); border: 1px solid #334155; border-radius: 8px; padding: 14px; width: 85%; margin-left: auto; margin-right: auto; text-align: right; font-size: 8.5pt;">
        <table cellpadding="4" cellspacing="0" style="width: 100%; color: #e2e8f0;">
          <tr>
            <td style="width: 50%;"><span style="color: #94a3b8;">مراجع ارزیابی‌شده:</span> <strong style="color: #ffffff;">' . $gender_title . ' ' . $user_full_name . '</strong></td>
            <td style="width: 50%;"><span style="color: #94a3b8;">شناسه اختصاصی سند:</span> <strong style="color: #fbbf24; font-family: monospace;" dir="ltr">' . $report_id_str . '</strong></td>
          </tr>
          <tr>
            <td style="width: 50%;"><span style="color: #94a3b8;">تاریخ ارزیابی:</span> ' . format_jalali_date($result['created_at']) . '</td>
            <td style="width: 50%;"><span style="color: #94a3b8;">تاریخ تایید و انتشار:</span> ' . format_jalali_date($full_interp['updated_at']) . '</td>
          </tr>
          <tr>
            <td style="width: 50%;"><span style="color: #94a3b8;">وضعیت تأیید:</span> <strong style="color: #4ade80;">تأییدشده بالینی (Published)</strong></td>
            <td style="width: 50%;"><span style="color: #94a3b8;">سطح سند:</span> محرمانه بالینی (Tier C/D)</td>
          </tr>
        </table>
      </div>

      <div style="margin-top: 40px; font-size: 7pt; color: #64748b;">
        تولید شده توسط موتور تصمیم‌یار بالینی میربلوکی &bull; کلیه حقوق مالکیت معنوی محفوظ است
      </div>
    </div>';

    $pdf->writeHTML($cover_html, true, false, true, false, '');

    // ==========================================
    // ۲. صفحات محتوای تفصیلی (Report Body Pages)
    // ==========================================
    $pdf->setPrintHeader(true);
    $pdf->setPrintFooter(true);
    $pdf->AddPage();

    $body_html = '
    <div style="border-bottom: 2px solid #0f766e; padding-bottom: 3px; margin-bottom: 8px;">
      <h2 style="color: #0f172a; font-size: 11pt; font-weight: bold; margin: 0;">بخش اول: شناسنامه ارزیابی و خلاصه وضعیت بالینی (Snapshot)</h2>
    </div>';

    $body_html .= pdf_render_client_info_card($user, $test, $result, $report_id_str, 'گزارش پیشرفته بالینی');

    // محاسبه نمره کل و سقف
    $total_sc_val = floatval($result['total_score']);
    $max_sc_val = 0;
    if (is_array($dimension_scores)) {
        foreach ($dimension_scores as $d) {
            $max_sc_val += isset($d['max_score']) ? floatval($d['max_score']) : 0;
        }
    }
    if ($max_sc_val <= 0) {
        $max_sc_val = $total_sc_val > 0 ? $total_sc_val : 100;
    }

    // خلاصه نمره و وضعیت
    $sev_label = format_severity_label($result['overall_severity']);
    $body_html .= '
    <table cellpadding="5" cellspacing="0" style="width: 100%; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 5px; margin-bottom: 10px; font-size: 8pt;">
      <tr>
        <td style="width: 25%; text-align: center; background-color: #0f172a; color: #ffffff; border-radius: 4px;">
          <div style="font-size: 7.5pt; color: #94a3b8;">نمره کل روان‌سنجی</div>
          <div style="font-size: 15pt; font-weight: bold; color: #fbbf24;">' . to_persian_num($total_sc_val) . '</div>
          <div style="font-size: 6.8pt; color: #cbd5e1;">از ' . to_persian_num($max_sc_val) . ' | ' . $sev_label . '</div>
        </td>
        <td style="width: 75%; padding-right: 10px;">
          <div style="font-weight: bold; color: #0f172a; margin-bottom: 3px;">طبقه‌بندی نیم‌رخ: ' . escape_html($result['overall_category']) . '</div>
          <div style="color: #475569; line-height: 1.5;">' . nl2br(escape_html($result['short_interpretation'])) . '</div>
        </td>
      </tr>
    </table>';

    // حوزه‌های ۵ گانه یانگ
    $is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
    if ($is_young_test && !empty($dimension_scores)) {
        $domains = engine_calculate_schema_domains($dimension_scores);
        $body_html .= '<h3 style="font-size: 9.5pt; color: #0f172a; margin: 8px 0 4px;">تحلیل حوزه‌های ۵گانه نیازهای بنیادین روانی (Schema Domains)</h3>';
        $body_html .= '<table cellpadding="3" cellspacing="0" style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 7.5pt;">';
        $body_html .= '<tr style="background-color: #1e293b; color: #ffffff; font-weight: bold;">
                        <th style="width: 40%; text-align: right; padding: 4px;">نام حوزه</th>
                        <th style="width: 20%; text-align: center; padding: 4px;">شدت نسبی</th>
                        <th style="width: 20%; text-align: center; padding: 4px;">سطح فعال‌سازی</th>
                        <th style="width: 20%; text-align: center; padding: 4px;">نیاز تحولی زیربنایی</th>
                       </tr>';
        
        $need_map = array(
            1 => 'دلبستگی ایمن و پذیرش',
            2 => 'خودمختاری و هویت مستقل',
            3 => 'محدودیت‌های واقع‌بینانه',
            4 => 'ابراز آزادانه هیجان و نیازها',
            5 => 'خودانگیختگی و تفریح سالم'
        );

        foreach ($domains as $d_id => $dom) {
            $need_text = isset($need_map[$d_id]) ? $need_map[$d_id] : 'نیازهای عاطفی';
            $body_html .= '<tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="font-weight: bold; color: #1e293b; padding: 4px;">' . escape_html($dom['title']) . '</td>
                            <td style="text-align: center; color: ' . $dom['color'] . '; font-weight: bold; padding: 4px;">' . to_persian_num($dom['percentage']) . '٪</td>
                            <td style="text-align: center; padding: 4px;">' . format_severity_label($dom['severity']) . '</td>
                            <td style="text-align: center; color: #64748b; font-size: 7pt; padding: 4px;">' . $need_text . '</td>
                           </tr>';
        }
        $body_html .= '</table>';
    }

    // نیم‌رخ کامل ابعاد
    $body_html .= '<h3 style="font-size: 9.5pt; color: #0f172a; margin: 8px 0 4px;">نیم‌رخ کمّی و نمودار تفکیکی ابعاد آزمون</h3>';
    $body_html .= pdf_render_dimension_bars_html($dimension_scores);

    // ==========================================
    // ۳. تحلیل ساختاریافته متن منتشرشده تفسیر کامل
    // ==========================================
    $body_html .= '<div style="margin-top: 14px; border-bottom: 2px solid #0f766e; padding-bottom: 3px; margin-bottom: 8px;">
                    <h2 style="color: #0f172a; font-size: 11pt; font-weight: bold; margin: 0;">بخش دوم: گزارش تفصیلی، فرضیه‌سازی بالینی و نقشه درمان</h2>
                   </div>';

    // متن تفسیر علمی تاییدشده
    $body_html .= '<div style="background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 5px; padding: 10px; margin-bottom: 10px; font-size: 8pt; line-height: 1.7; color: #1e293b;">
                    <div style="font-weight: bold; color: #0f766e; margin-bottom: 4px; font-size: 9pt;">■ تحلیل تخصصی و فرمول‌بندی ابعاد:</div>
                    ' . nl2br(escape_html($full_interp['scientific_interpretation'])) . '
                   </div>';

    // یادداشت‌های اختصاصی و بالینی درمانگر
    if (!empty($full_interp['admin_additional_notes'])) {
        $body_html .= '<div style="background-color: #f0fdfa; border: 1px solid #99f6e4; border-right: 4px solid #0f766e; border-radius: 5px; padding: 10px; margin-bottom: 10px; font-size: 8pt; line-height: 1.7; color: #134e4a;">
                        <div style="font-weight: bold; color: #0f766e; margin-bottom: 4px; font-size: 9pt;">■ ملاحظات اختصاصی بالینی و فرضیه‌سازی تشخیصی:</div>
                        ' . nl2br(escape_html($full_interp['admin_additional_notes'])) . '
                       </div>';
    }

    // توصیه‌های عملی و نقشه اهداف درمانی
    if (!empty($full_interp['clinical_recommendations'])) {
        $body_html .= '<div style="background-color: #fffbeb; border: 1px solid #fde68a; border-right: 4px solid #d97706; border-radius: 5px; padding: 10px; margin-bottom: 10px; font-size: 8pt; line-height: 1.7; color: #78350f;">
                        <div style="font-weight: bold; color: #b45309; margin-bottom: 4px; font-size: 9pt;">■ نقشه اهداف مداخله و راهکارهای درمانی پیشنهادی:</div>
                        ' . nl2br(escape_html($full_interp['clinical_recommendations'])) . '
                       </div>';
    }

    // مبانی علمی و مراجع دانشگاهی
    if (!empty($sources) || !empty($test['scientific_profile'])) {
        $body_html .= '<div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 5px; padding: 8px; margin-top: 10px; font-size: 7pt; color: #475569; line-height: 1.5;">
                        <div style="font-weight: bold; color: #1e293b; margin-bottom: 3px; font-size: 8pt;">■ مراجع علمی و استنادهای دانشگاهی (Evidence-Based Traceability):</div>';
        if (!empty($test['scientific_profile'])) {
            $body_html .= '<div>' . nl2br(escape_html($test['scientific_profile'])) . '</div>';
        }
        if (!empty($sources)) {
            $body_html .= '<ul style="margin: 3px 0; padding-right: 12px;">';
            foreach ($sources as $s) {
                $body_html .= '<li>' . escape_html($s['citation_title']);
                if (!empty($s['authors'])) $body_html .= ' (' . escape_html($s['authors']) . ', ' . escape_html($s['year']) . ')';
                if (!empty($s['notes'])) $body_html .= ' — ' . escape_html($s['notes']);
                $body_html .= '</li>';
            }
            $body_html .= '</ul>';
        }
        $body_html .= '</div>';
    }

    // بیانیه رسمی سلب مسئولیت حقوقی و مرزبندی بالینی
    $body_html .= '
    <div style="background-color: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 5px; padding: 6px 8px; margin-top: 8px; font-size: 6.8pt; color: #64748b; line-height: 1.4;">
      <strong>بیانیه رسمی مرزبندی بالینی (Clinical Decision Support Disclaimer):</strong> این گزارش به عنوان سند تخصصی کمک‌تشخیصی و تصمیم‌یار بالینی صادر شده و حاصل تطبیق نمرات با هنجارهای روان‌سنجی است. این سند به تنهایی جایگزین مصاحبه تشخیصی بالینی نیست و تصمیم‌گیری نهایی درمانی بر عهده روان‌درمانگر معالج می‌باشد.
    </div>';

    $pdf->writeHTML($body_html, true, false, true, false, '');

    // مسیر ذخیره امن فایل
    $cache_dir = ROOT_PATH . '/uploads/reports';
    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0755, true);
    }
    $file_name = 'Mirbolouki-' . $test['slug'] . '-Advanced-' . $result['id'] . '.pdf';
    $file_path = $cache_dir . '/' . $file_name;

    if ($output_type === 'F') {
        $pdf->Output($file_path, 'F');
        return $file_path;
    } elseif ($output_type === 'I' || $output_type === 'D') {
        $pdf->Output($file_name, $output_type);
        exit;
    }
    return $file_path;
}

/**
 * دریافت یا تولید با کش هوشمند
 */
function pdf_get_cached_or_generate($result_id, $type = 'initial') {
    $result_id = intval($result_id);
    $result = db_fetch_one("SELECT test_id FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($result_id));
    if (!$result) {
        return false;
    }
    $test = engine_get_test($result['test_id']);
    if (!$test) {
        return false;
    }

    $cache_dir = ROOT_PATH . '/uploads/reports';
    $file_name = 'Mirbolouki-' . $test['slug'] . '-' . ucfirst($type) . '-' . $result_id . '.pdf';
    $file_path = $cache_dir . '/' . $file_name;

    if (file_exists($file_path) && filesize($file_path) > 1000) {
        return $file_path;
    }

    if ($type === 'initial') {
        return pdf_generate_initial_report($result_id, 'F');
    } elseif ($type === 'advanced') {
        return pdf_generate_advanced_report($result_id, 'F');
    }
    return false;
}

/**
 * باطل‌سازی کش PDF پس از ویرایش یا انتشار جدید توسط مدیر
 */
function pdf_invalidate_cache($result_id) {
    $result_id = intval($result_id);
    $cache_dir = ROOT_PATH . '/uploads/reports';
    if (!is_dir($cache_dir)) {
        return;
    }
    $files = glob($cache_dir . '/*-' . $result_id . '.pdf');
    if ($files) {
        foreach ($files as $f) {
            if (is_file($f)) {
                @unlink($f);
            }
        }
    }
}
