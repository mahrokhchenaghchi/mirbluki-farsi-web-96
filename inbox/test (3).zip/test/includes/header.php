<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * سربرگ اصلی صفحات (Main Site Header)
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$current_user = get_auth_user();
$page_title = isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME;
$meta_description = isset($meta_description) ? $meta_description : 'سامانه تخصصی آزمون‌ها و غربالگری‌های روان‌شناختی جواد میربلوکی، روانشناس و زوج‌درمانگر';
$is_noindex = isset($is_noindex) && $is_noindex;

if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo escape_html($page_title); ?></title>
  <meta name="description" content="<?php echo escape_html($meta_description); ?>">
  <?php if ($is_noindex): ?>
    <meta name="robots" content="noindex, nofollow">
  <?php else: ?>
    <meta name="robots" content="index, follow">
  <?php endif; ?>
  
  <!-- Open Graph -->
  <meta property="og:title" content="<?php echo escape_html($page_title); ?>">
  <meta property="og:description" content="<?php echo escape_html($meta_description); ?>">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?php echo escape_html(SITE_URL . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '')); ?>">
  <meta property="og:image" content="<?php echo escape_html(SITE_URL); ?>/assets/images/mirbolouki-joma.jpg">

  <!-- JSON-LD Structured Data for Clinical E-E-A-T & SEO -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "MedicalWebPage",
    "name": "<?php echo escape_html($page_title); ?>",
    "description": "<?php echo escape_html($meta_description); ?>",
    "url": "<?php echo escape_html(SITE_URL . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '')); ?>",
    "author": {
      "@type": "Person",
      "name": "دکتر جواد میربلوکی",
      "jobTitle": "روانشناس، زوج‌درمانگر و بنیان‌گذار برندینگ جغد دانا (جوما)",
      "url": "https://mirbolouki.com"
    },
    "publisher": {
      "@type": "Organization",
      "name": "سامانه آزمون‌های روان‌شناختی میربلوکی",
      "logo": {
        "@type": "ImageObject",
        "url": "<?php echo escape_html(SITE_URL); ?>/assets/images/joma-emblem-logo.jpg"
      }
    }
  }
  </script>

  <!-- Stylesheets -->
  <link rel="stylesheet" href="/assets/css/style.css?v=<?php echo SITE_VERSION; ?>">
  <?php if (isset($extra_css)): ?>
    <?php foreach ($extra_css as $css_file): ?>
      <link rel="stylesheet" href="<?php echo escape_html($css_file); ?>?v=<?php echo SITE_VERSION; ?>">
    <?php endforeach; ?>
  <?php endif; ?>
</head>
<body>

<header class="site-header">
  <div class="container">
    <nav class="navbar">
      <a href="/" class="brand-logo" title="<?php echo escape_html(SITE_NAME); ?>">
        <img src="/assets/images/logo.svg" alt="دکتر جواد میربلوکی" width="220" height="48">
      </a>

      <ul class="nav-links">
        <li><a href="/" class="<?php echo (!isset($active_nav) || $active_nav === 'home') ? 'active' : ''; ?>">صفحه اصلی</a></li>
        <li><a href="/tests/" class="<?php echo (isset($active_nav) && $active_nav === 'tests') ? 'active' : ''; ?>">فهرست آزمون‌ها</a></li>
        <li><a href="/#about-joma">جوما (جغد دانا) 🦉</a></li>
        <li><a href="/#philosophy">فلسفه ارزیابی علمی</a></li>
        <li><a href="/#faq">پرسش‌های متداول</a></li>
        <li><a href="<?php echo MAIN_SITE_URL; ?>" target="_blank" rel="noopener">وب‌سایت اصلی دکتر میربلوکی ↗</a></li>
      </ul>

      <div class="nav-actions">
        <?php if ($current_user): ?>
          <a href="/user/dashboard.php" class="btn btn-outline btn-sm">
            <span>آزمون‌های من</span>
            <small>(<?php echo escape_html($current_user['first_name']); ?>)</small>
          </a>
          <a href="/user/logout.php" class="btn btn-sm" style="color: #94a3b8;" title="خروج">خروج</a>
        <?php else: ?>
          <a href="/user/login.php" class="btn btn-outline btn-sm">ورود / آزمون‌های من</a>
        <?php endif; ?>
        <a href="/tests/" class="btn btn-primary btn-sm">شروع آزمون</a>
        <button class="mobile-menu-toggle" aria-label="منوی اصلی">☰</button>
      </div>
    </nav>
  </div>
</header>

<main>
  <div class="container mt-3">
    <?php echo render_flash(); ?>
  </div>
