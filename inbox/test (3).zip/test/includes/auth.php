<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * ماژول مدیریت نشست‌ها و احراز هویت کاربران و مدیران (Authentication & Authorization)
 * سازگار با PHP 7.x
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

// ==========================================
// بخش اول: احراز هویت مدیران (Admin Auth)
// ==========================================

/**
 * تلاش برای ورود مدیر به پنل مدیریت
 */
function admin_login($username, $password) {
    $username = trim($username);
    if (empty($username) || empty($password)) {
        return array('success' => false, 'message' => 'نام کاربری و کلمه عبور الزامی است.');
    }
    
    $admin = db_fetch_one("SELECT * FROM `admins` WHERE `username` = ? AND `is_active` = 1 LIMIT 1", 's', array($username));
    if (!$admin) {
        log_event('warning', 'admin_login_failed', "تلاش ناموفق برای ورود با نام کاربری: {$username}");
        return array('success' => false, 'message' => 'نام کاربری یا کلمه عبور اشتباه است.');
    }
    
    if (!password_verify($password, $admin['password_hash'])) {
        log_event('warning', 'admin_login_failed', "رمز عبور نادرست برای کاربر: {$username}");
        return array('success' => false, 'message' => 'نام کاربری یا کلمه عبور اشتباه است.');
    }
    
    // ورود موفقیت‌آمیز
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_name'] = $admin['full_name'];
    $_SESSION['admin_role'] = $admin['role'];
    $_SESSION['admin_logged_in'] = true;
    
    // بروزرسانی زمان آخرین ورود
    db_update('admins', array('last_login_at' => date('Y-m-d H:i:s')), 'id = ?', 'i', array($admin['id']));
    log_event('info', 'admin_login_success', "ورود موفق مدیر: {$username}");
    
    return array('success' => true, 'admin' => $admin);
}

/**
 * بررسی وضعیت لاگین بودن مدیر
 */
function is_admin_logged_in() {
    return !empty($_SESSION['admin_logged_in']) && !empty($_SESSION['admin_id']);
}

/**
 * دریافت اطلاعات مدیر جاری
 */
function get_current_admin() {
    if (!is_admin_logged_in()) {
        return null;
    }
    return db_fetch_one("SELECT id, username, full_name, email, role FROM `admins` WHERE `id` = ? LIMIT 1", 'i', array($_SESSION['admin_id']));
}

/**
 * حفاظت از صفحات ادمین (اجبار به ورود)
 */
function require_admin_login() {
    if (!is_admin_logged_in()) {
        set_flash('danger', 'برای دسترسی به پنل مدیریت، ابتدا باید وارد شوید.');
        redirect('/admin/login.php');
    }
}

/**
 * خروج مدیر از سامانه
 */
function admin_logout() {
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_username']);
    unset($_SESSION['admin_name']);
    unset($_SESSION['admin_role']);
    unset($_SESSION['admin_logged_in']);
    session_regenerate_id(true);
}

// ==========================================
// بخش دوم: احراز هویت کاربران (User Auth)
// ==========================================

/**
 * ورود یا ثبت کاربر بر اساس شماره همراه
 */
function user_login_by_mobile($mobile) {
    $mobile = validate_iran_mobile($mobile);
    if (!$mobile) {
        return array('success' => false, 'message' => 'شماره همراه معتبر نیست (مثال: 09123456789).');
    }
    
    $user = db_fetch_one("SELECT * FROM `users` WHERE `mobile` = ? LIMIT 1", 's', array($mobile));
    if (!$user) {
        return array('success' => false, 'message' => 'کاربری با این شماره همراه یافت نشد. لطفاً ابتدا در یکی از آزمون‌ها شرکت فرمایید.');
    }
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_mobile'] = $user['mobile'];
    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['user_logged_in'] = true;
    
    return array('success' => true, 'user' => $user);
}

/**
 * بررسی لاگین بودن کاربر عادی
 */
function is_user_logged_in() {
    return !empty($_SESSION['user_logged_in']) && !empty($_SESSION['user_id']);
}

/**
 * دریافت اطلاعات کاربر لاگین‌شده جاری
 */
function get_auth_user() {
    if (!is_user_logged_in()) {
        return null;
    }
    return db_fetch_one("SELECT id, mobile, first_name, last_name, gender, age, created_at FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($_SESSION['user_id']));
}

/**
 * حفاظت از صفحات اختصاصی کاربر (اجبار به ورود)
 */
function require_user_login() {
    if (!is_user_logged_in()) {
        set_flash('info', 'لطفاً با شماره همراه خود وارد حساب کاربری شوید.');
        redirect('/user/login.php');
    }
}

/**
 * خروج کاربر
 */
function user_logout() {
    unset($_SESSION['user_id']);
    unset($_SESSION['user_mobile']);
    unset($_SESSION['user_name']);
    unset($_SESSION['user_logged_in']);
    session_regenerate_id(true);
}
