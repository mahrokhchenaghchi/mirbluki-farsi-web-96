<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * پابرگ اصلی صفحات (Main Site Footer)
 */
?>
</main>

<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <h4>دکتر جواد میربلوکی</h4>
        <p>روانشناس، زوج‌درمانگر و مشاور تخصصی روابط عاطفی و فردی. هدف این سامانه، ارائه ابزارهای ارزیابی روان‌شناختی دقیق، استاندارد و مبتنی بر شواهد علمی برای افزایش خودآگاهی و ارتقای کیفیت روابط شماست.</p>
        <div style="margin-top: 15px; font-size: 0.85rem; color: #64748b; line-height: 1.6;">
          <strong>نکته اخلاقی و بالینی:</strong> نتایج این آزمون‌ها جنبه خودشناسی و غربالگری دارند و نباید جایگزین مصاحبه بالینی، تشخیص پزشکی یا روان‌درمانی فردی تخصصی تلقی شوند.
        </div>
      </div>

      <div class="footer-col">
        <h5>دسترسی سریع</h5>
        <ul class="footer-links">
          <li><a href="/">صفحه اصلی سامانه</a></li>
          <li><a href="/tests/">فهرست تمام آزمون‌ها</a></li>
          <li><a href="/user/login.php">ورود به حساب کاربری</a></li>
          <li><a href="/#faq">پرسش‌های متداول</a></li>
          <li><a href="<?php echo MAIN_SITE_URL; ?>" target="_blank" rel="noopener">رزرو وقت مشاوره حضوری/آنلاین</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h5>لینک‌های مفید</h5>
        <ul class="footer-links">
          <li><a href="https://joma.mirbolouki.com" target="_blank" rel="noopener" style="color: #fbbf24; font-weight: 600;">🦉 پلنر هوشمند جوما (جغد دانا) ↗</a></li>
          <li><a href="<?php echo MAIN_SITE_URL; ?>/page/couples-therapy" target="_blank" rel="noopener">زوج‌درمانی و بازسازی رابطه</a></li>
          <li><a href="<?php echo MAIN_SITE_URL; ?>/page/Schema-therapy" target="_blank" rel="noopener">طرحواره درمانی (Schema Therapy)</a></li>
          <li><a href="<?php echo MAIN_SITE_URL; ?>/page/Premarital-counseling" target="_blank" rel="noopener">مشاوره پیش از ازدواج</a></li>
          <li><a href="<?php echo MAIN_SITE_URL; ?>/page/book" target="_blank" rel="noopener">کتاب «عشق و رابطه»</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h5>ارتباط و پشتیبانی</h5>
        <div class="footer-contact-item">
          <svg width="18" height="18" fill="none" stroke="#2dd4bf" stroke-width="2" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
          <span>شماره پیامک: <?php echo to_persian_num(PAYMENT_SUPPORT_MOBILE); ?></span>
        </div>
        <div class="footer-contact-item">
          <svg width="18" height="18" fill="none" stroke="#2dd4bf" stroke-width="2" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
          <a href="<?php echo BALE_CHANNEL_URL; ?>" target="_blank" rel="noopener" style="color: #2dd4bf;">پلتفرم بله (Bale Messenger)</a>
        </div>
        <div style="margin-top: 15px;">
          <a href="<?php echo BALE_CHANNEL_URL; ?>" target="_blank" rel="noopener" class="btn btn-outline-white btn-sm" style="width: 100%; justify-content: center;">
            ارتباط مستقیم در بله
          </a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <p style="margin: 0;">© <?php echo to_persian_num(date('Y')); ?> تمامی حقوق مادی و معنوی این سامانه متعلق به <strong>دکتر جواد میربلوکی</strong> است.</p>
        <div>
          <a href="/admin/login.php" style="color: #64748b; font-size: 0.8rem; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#2dd4bf'" onmouseout="this.style.color='#64748b'">
            🔐 ورود مدیران و درمانگران (Admin Portal)
          </a>
        </div>
      </div>
    </div>
  </div>
</footer>

<!-- Scripts -->
<script src="/assets/js/main.js?v=<?php echo SITE_VERSION; ?>"></script>
<?php if (isset($extra_js)): ?>
  <?php foreach ($extra_js as $js_file): ?>
    <script src="<?php echo escape_html($js_file); ?>?v=<?php echo SITE_VERSION; ?>"></script>
  <?php endforeach; ?>
<?php endif; ?>

</body>
</html>
