<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * توابع عمومی، امنیتی و قالب‌بندی (Helper Functions)
 * سازگار با PHP 7.x
 */

require_once __DIR__ . '/db.php';

/**
 * پاکسازی داده‌های ورودی
 */
function clean_input($data) {
    if (is_array($data)) {
        return array_map('clean_input', $data);
    }
    return trim(strip_tags((string)$data));
}

/**
 * گریز دادن کدهای HTML جهت جلوگیری از XSS
 */
function escape_html($string) {
    return htmlspecialchars((string)$string, ENT_QUOTES, 'UTF-8');
}

/**
 * نسخه کوتاه شده برای escape_html
 */
function e($string) {
    return escape_html($string);
}

/**
 * تولید توکن امنیتی CSRF
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        if (function_exists('random_bytes')) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } else {
            $_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true));
        }
    }
    return $_SESSION['csrf_token'];
}

/**
 * چاپ فیلد مخفی CSRF
 */
function csrf_field() {
    $token = csrf_token();
    return '<input type="hidden" name="csrf_token" value="' . escape_html($token) . '">';
}

/**
 * اعتبارسنجی توکن CSRF
 */
function csrf_verify($token = null) {
    if ($token === null) {
        $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : (isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '');
    }
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * ثبت پیام موقت (Flash Message)
 */
function set_flash($type, $message) {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = array();
    }
    $_SESSION['flash_messages'][] = array(
        'type' => $type, // success, danger, warning, info
        'message' => $message
    );
}

/**
 * دریافت و پاکسازی پیام‌های موقت
 */
function get_flash() {
    if (isset($_SESSION['flash_messages']) && !empty($_SESSION['flash_messages'])) {
        $messages = $_SESSION['flash_messages'];
        unset($_SESSION['flash_messages']);
        return $messages;
    }
    return array();
}

/**
 * چاپ پیام‌های موقت در خروجی HTML
 */
function render_flash() {
    $flashes = get_flash();
    if (empty($flashes)) {
        return '';
    }
    $html = '<div class="flash-messages-container mb-4">';
    foreach ($flashes as $f) {
        $type_class = $f['type'] === 'error' ? 'danger' : $f['type'];
        $html .= '<div class="alert alert-' . escape_html($type_class) . ' alert-dismissible fade show" role="alert">';
        $html .= escape_html($f['message']);
        $html .= '</div>';
    }
    $html .= '</div>';
    return $html;
}

/**
 * ریدایرکت امن به آدرس مشخص
 */
function redirect($url) {
    header("Location: " . $url);
    exit;
}

/**
 * ارسال پاسخ JSON با کد وضعیت HTTP
 */
function json_response($data, $status_code = 200) {
    http_response_code($status_code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * تولید رشته تصادفی یکتا
 */
function generate_token($length = 32) {
    if (function_exists('random_bytes')) {
        return bin2hex(random_bytes(intval($length / 2)));
    }
    return substr(md5(uniqid(mt_rand(), true)), 0, $length);
}

/**
 * تولید کد رهگیری برای درخواست‌های تفسیر
 */
function generate_request_code() {
    return 'MB-' . strtoupper(substr(uniqid(), -6)) . '-' . mt_rand(100, 999);
}

/**
 * اعتبارسنجی شماره همراه ایرانی
 */
function validate_iran_mobile($mobile) {
    $mobile = preg_replace('/[^\d]/', '', (string)$mobile);
    if (preg_match('/^09[0-9]{9}$/', $mobile)) {
        return $mobile;
    }
    return false;
}

/**
 * تبدیل ارقام انگلیسی به فارسی
 */
function to_persian_num($number) {
    $en = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    $fa = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
    return str_replace($en, $fa, (string)$number);
}

/**
 * قالب‌بندی مبلغ به تومان با اعداد فارسی
 */
function format_toman($amount) {
    return to_persian_num(number_format((float)$amount, 0, '.', ',')) . ' تومان';
}

/**
 * تبدیل تاریخ میلادی به شمسی (Pure PHP Jalali Conversion)
 */
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + intval(($gy2 + 3) / 4) - intval(($gy2 + 99) / 100) + intval(($gy2 + 399) / 400) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * intval($days / 12053));
    $days %= 12053;
    $jy += 4 * intval($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += intval(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + intval($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intval(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return array($jy, $jm, $jd);
}

/**
 * قالب‌بندی تاریخ و زمان شمسی
 */
function format_jalali_date($datetime_str, $include_time = true) {
    if (empty($datetime_str) || $datetime_str === '0000-00-00 00:00:00') {
        return '-';
    }
    
    $timestamp = strtotime($datetime_str);
    if (!$timestamp) {
        return '-';
    }
    
    $gy = intval(date('Y', $timestamp));
    $gm = intval(date('n', $timestamp));
    $gd = intval(date('j', $timestamp));
    
    $j_date = gregorian_to_jalali($gy, $gm, $gd);
    $jy = $j_date[0];
    $jm = str_pad($j_date[1], 2, '0', STR_PAD_LEFT);
    $jd = str_pad($j_date[2], 2, '0', STR_PAD_LEFT);
    
    $month_names = array(
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    );
    $month_name = isset($month_names[$j_date[1]]) ? $month_names[$j_date[1]] : '';
    
    $formatted = to_persian_num($jd) . ' ' . $month_name . ' ' . to_persian_num($jy);
    
    if ($include_time) {
        $time_str = date('H:i', $timestamp);
        $formatted .= ' ساعت ' . to_persian_num($time_str);
    }
    
    return $formatted;
}

/**
 * برچسب وضعیت تفسیر کامل
 */
function format_request_status_badge($status) {
    $badges = array(
        'not_requested' => array('label' => 'درخواست نشده', 'class' => 'badge-secondary'),
        'requested' => array('label' => 'درخواست ثبت شد', 'class' => 'badge-info'),
        'awaiting_payment' => array('label' => 'در انتظار پرداخت', 'class' => 'badge-warning'),
        'receipt_submitted' => array('label' => 'فیش ارسال شد (در انتظار تایید)', 'class' => 'badge-primary'),
        'payment_pending_verification' => array('label' => 'بررسی مالی', 'class' => 'badge-warning'),
        'payment_confirmed' => array('label' => 'پرداخت تایید شد (در حال تحلیل)', 'class' => 'badge-info'),
        'interpretation_draft' => array('label' => 'پیش‌نویس تفسیر', 'class' => 'badge-secondary'),
        'interpretation_ready' => array('label' => 'تفسیر آماده انتشار', 'class' => 'badge-warning'),
        'published' => array('label' => 'تفسیر کامل منتشر شد', 'class' => 'badge-success'),
        'rejected' => array('label' => 'رد پرداخت / نیازمند اصلاح', 'class' => 'badge-danger')
    );
    
    $badge = isset($badges[$status]) ? $badges[$status] : array('label' => $status, 'class' => 'badge-secondary');
    return '<span class="custom-badge ' . escape_html($badge['class']) . '">' . escape_html($badge['label']) . '</span>';
}

/**
 * برچسب سطح شدت نتیجه آزمون
 */
function format_severity_badge($severity) {
    $severities = array(
        'normal' => array('label' => 'عادی / انطباقی', 'class' => 'badge-success'),
        'low' => array('label' => 'خفیف', 'class' => 'badge-info'),
        'moderate' => array('label' => 'متوسط', 'class' => 'badge-warning'),
        'high' => array('label' => 'بالا', 'class' => 'badge-danger'),
        'severe' => array('label' => 'بسیار شدید', 'class' => 'badge-danger-dark')
    );
    $item = isset($severities[$severity]) ? $severities[$severity] : array('label' => $severity, 'class' => 'badge-secondary');
    return '<span class="custom-badge ' . escape_html($item['class']) . '">' . escape_html($item['label']) . '</span>';
}

/**
 * ثبت رویدادهای امنیتی و سیستمی
 */
function log_event($level, $action, $message) {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    db_insert('system_logs', array(
        'log_level' => $level,
        'action' => $action,
        'message' => $message,
        'ip_address' => $ip
    ));
}
