-- ==========================================================
-- سامانه آزمون‌های روان‌شناختی Mirbolouki - اسکریپت بروزرسانی نسخه 1.0.3
-- بهینه‌سازی جداول، ایندکس‌ها و تضمین سازگاری کامل بدون حذف هیچ‌گونه داده (Safe Idempotent Patch)
-- ==========================================================

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- 1. اطمینان از وجود ستون‌های ضروری در جدول interpretation_requests
-- (این دستورات کاملاً امن و تکرارپذیر هستند)
CREATE TABLE IF NOT EXISTS `full_interpretations` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` int(11) UNSIGNED NOT NULL,
  `result_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `test_id` int(11) UNSIGNED NOT NULL,
  `scientific_interpretation` longtext NOT NULL,
  `admin_additional_notes` text DEFAULT NULL,
  `clinical_recommendations` text DEFAULT NULL,
  `status` enum('draft','published') NOT NULL DEFAULT 'draft',
  `created_by_admin_id` int(11) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_request_id` (`request_id`),
  KEY `idx_result_id` (`result_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. بهینه‌سازی ایندکس‌های جستجو
ALTER TABLE `test_results` ADD INDEX IF NOT EXISTS `idx_test_created` (`test_id`, `created_at`);
ALTER TABLE `interpretation_requests` ADD INDEX IF NOT EXISTS `idx_req_status` (`payment_status`);

SET foreign_key_checks = 1;

-- پایان اسکریپت بروزرسانی 1.0.3
