/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: mirbolouki_test1
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `admins`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(128) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `role` enum('superadmin','admin') NOT NULL DEFAULT 'admin',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `admins` VALUES (1,'admin','$2y$12$zAsBMq1ExWjwsvu.5j7OkusFFfIAhagGtH4VTlb1VngF8sT2p/FaG','مدیر سامانه میربلوکی','info@mirbolouki.com','superadmin',1,'2026-08-31 14:55:42','2026-08-30 16:08:44','2026-08-31 11:25:42');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `full_interpretations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `full_interpretations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `scientific_interpretation` longtext NOT NULL,
  `admin_additional_notes` longtext DEFAULT NULL,
  `clinical_recommendations` longtext DEFAULT NULL,
  `status` enum('draft','published','unpublished') NOT NULL DEFAULT 'draft',
  `created_by_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`),
  UNIQUE KEY `result_id` (`result_id`),
  KEY `idx_interp_req` (`request_id`),
  KEY `idx_interp_res` (`result_id`),
  KEY `idx_interp_user` (`user_id`),
  KEY `idx_interp_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `full_interpretations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `full_interpretations` VALUES (1,1,1,1,1,'تحلیل بالینی: نمرات نشان‌دهنده لزوم بازنگری در الگوهای محرومیت هیجانی است.','توصیه دکتر میربلوکی: تمرین گفت‌وگوی شفاف در روابط نزدیک.','گام ۱: تمرین ابراز نیازها.','published',1,'2026-08-30 16:22:12','2026-08-30 16:22:12');
INSERT INTO `full_interpretations` VALUES (2,2,2,3,3,'تحلیل بالینی: نمرات نشان‌دهنده لزوم بازنگری در الگوهای محرومیت هیجانی است.','توصیه دکتر میربلوکی: تمرین گفت‌وگوی شفاف در روابط نزدیک.','گام ۱: تمرین ابراز نیازها.','published',1,'2026-08-30 16:23:56','2026-08-30 16:23:56');
INSERT INTO `full_interpretations` VALUES (3,3,3,4,11,'تحلیل بالینی: نمرات نشان‌دهنده لزوم بازنگری در الگوهای محرومیت هیجانی است.','توصیه دکتر میربلوکی: تمرین گفت‌وگوی شفاف در روابط نزدیک.','گام ۱: تمرین ابراز نیازها.','published',1,'2026-08-30 17:01:17','2026-08-30 17:01:17');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `interpretation_requests`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `interpretation_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_code` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL DEFAULT 369000,
  `payment_status` enum('not_requested','requested','awaiting_payment','receipt_submitted','payment_pending_verification','payment_confirmed','interpretation_draft','interpretation_ready','published','rejected') NOT NULL DEFAULT 'requested',
  `receipt_file` varchar(255) DEFAULT NULL,
  `user_notes` text DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `requested_at` datetime DEFAULT current_timestamp(),
  `payment_verified_at` datetime DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_code` (`request_code`),
  KEY `idx_req_user` (`user_id`),
  KEY `idx_req_result` (`result_id`),
  KEY `idx_req_status` (`payment_status`),
  KEY `idx_req_code` (`request_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interpretation_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `interpretation_requests` VALUES (1,'MB-4B6A6F-730',1,1,1,369000,'payment_confirmed','/uploads/receipts/test_receipt.jpg','فیش واریزی برای بررسی',NULL,'2026-08-30 16:22:12','2026-08-30 19:52:12',NULL,'2026-08-30 16:22:12');
INSERT INTO `interpretation_requests` VALUES (2,'MB-C82D6B-417',3,2,3,369000,'payment_confirmed','/uploads/receipts/test_receipt.jpg','فیش واریزی برای بررسی',NULL,'2026-08-30 16:23:56','2026-08-30 19:53:56',NULL,'2026-08-30 16:23:56');
INSERT INTO `interpretation_requests` VALUES (3,'MB-D86CD9-127',4,3,11,369000,'payment_confirmed','/uploads/receipts/test_receipt.jpg','فیش واریزی برای بررسی',NULL,'2026-08-30 17:01:17','2026-08-30 20:31:17',NULL,'2026-08-30 17:01:17');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_level` enum('info','warning','error','security') NOT NULL DEFAULT 'info',
  `action` varchar(64) NOT NULL,
  `message` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_log_level` (`log_level`),
  KEY `idx_log_action` (`action`),
  KEY `idx_log_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `system_logs` VALUES (1,'warning','admin_login_failed','رمز عبور نادرست برای کاربر: admin','0.0.0.0','2026-08-30 16:22:12');
INSERT INTO `system_logs` VALUES (2,'info','admin_login_success','ورود موفق مدیر: admin','0.0.0.0','2026-08-30 16:22:12');
INSERT INTO `system_logs` VALUES (3,'warning','admin_login_failed','رمز عبور نادرست برای کاربر: admin','0.0.0.0','2026-08-30 16:23:40');
INSERT INTO `system_logs` VALUES (4,'info','admin_login_success','ورود موفق مدیر: admin','0.0.0.0','2026-08-30 16:23:40');
INSERT INTO `system_logs` VALUES (5,'warning','admin_login_failed','رمز عبور نادرست برای کاربر: admin','0.0.0.0','2026-08-30 16:23:56');
INSERT INTO `system_logs` VALUES (6,'info','admin_login_success','ورود موفق مدیر: admin','0.0.0.0','2026-08-30 16:23:56');
INSERT INTO `system_logs` VALUES (7,'warning','admin_login_failed','رمز عبور نادرست برای کاربر: admin','0.0.0.0','2026-08-30 17:01:17');
INSERT INTO `system_logs` VALUES (8,'info','admin_login_success','ورود موفق مدیر: admin','0.0.0.0','2026-08-30 17:01:17');
INSERT INTO `system_logs` VALUES (9,'warning','admin_login_failed','رمز عبور نادرست برای کاربر: admin','0.0.0.0','2026-08-31 11:25:42');
INSERT INTO `system_logs` VALUES (10,'info','admin_login_success','ورود موفق مدیر: admin','0.0.0.0','2026-08-31 11:25:42');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_dimensions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_dimensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `min_score` decimal(8,2) NOT NULL DEFAULT 0.00,
  `max_score` decimal(8,2) NOT NULL DEFAULT 0.00,
  `color_hex` varchar(32) NOT NULL DEFAULT '#3b82f6',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_dim_test` (`test_id`),
  KEY `idx_dim_code` (`test_id`,`code`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_dimensions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_dimensions` VALUES (1,1,'scale_l','مقیاس دروغ‌سنجی (Lie - L)','ارزیابی گرایش به مطلوب‌نمایی و انکار خطاهای جزیی انسانی',0.00,100.00,'#64748b',1);
INSERT INTO `test_dimensions` VALUES (2,1,'scale_f','مقیاس نابسامانی و روایی (Infrequency - F)','ارزیابی نشانه‌های نامتعارف، اغراق در علائم یا سردرگمی شناختی',0.00,100.00,'#ef4444',2);
INSERT INTO `test_dimensions` VALUES (3,1,'scale_k','مقیاس اصلاح و پنهان‌کاری (Correction - K)','ارزیابی میزان گارد دفاعی، خویشتن‌داری یا خودافشاگری',0.00,100.00,'#f59e0b',3);
INSERT INTO `test_dimensions` VALUES (4,1,'scale_hs','خودبیمارانگاری (Hypochondriasis - Hs)','اشتغال ذهنی مفرط به کارکرد بدنی، اضطراب بیماری و تنی‌سازی',0.00,100.00,'#e67e22',4);
INSERT INTO `test_dimensions` VALUES (5,1,'scale_d','افسردگی بالینی (Depression - D)','افت عمیق خلق، احساس ناامیدی، کاهش شدید انرژی و لذت‌نبُردن',0.00,100.00,'#3b82f6',5);
INSERT INTO `test_dimensions` VALUES (6,1,'scale_hy','هیستری و واکنش تبدیلی (Hysteria - Hy)','توسعه علائم جسمی ناخواسته در واکنش به استرس و تعارضات',0.00,100.00,'#8b5cf6',6);
INSERT INTO `test_dimensions` VALUES (7,1,'scale_pd','انحراف روانی-اجتماعی (Psychopathic Deviate - Pd)','ناسازگاری با هنجارهای اجتماعی، تکانشگری و تعارض با قانون',0.00,100.00,'#dc2626',7);
INSERT INTO `test_dimensions` VALUES (8,1,'scale_mf','زنانگی / مردانگی (Masculinity-Femininity - Mf)','انطباق با نقش‌های جنسیتی سنتی، علایق شغلی و حساسیت زیبایی',0.00,100.00,'#10b981',8);
INSERT INTO `test_dimensions` VALUES (9,1,'scale_pa','پارانویا و سوءظن (Paranoia - Pa)','حساسیت شدید بین‌فردی، احساس تحت تعقیب یا قربانی توطئه بودن',0.00,100.00,'#b45309',9);
INSERT INTO `test_dimensions` VALUES (10,1,'scale_pt','ضعف روانی و وسواس (Psychasthenia - Pt)','اضطراب مزمن، وسواس‌های فکری-عملی، تردید و احساس گناه',0.00,100.00,'#0d9488',10);
INSERT INTO `test_dimensions` VALUES (11,1,'scale_sc','اسکیزوفرنی و گسستگی (Schizophrenia - Sc)','تجارب ادراکی نامتعارف، احساس بیگانگی از واقعیت و گسست فکری',0.00,100.00,'#1e293b',11);
INSERT INTO `test_dimensions` VALUES (12,1,'scale_ma','شیدایی خفیف (Hypomania - Ma)','برانگیختگی روانی-حرکتی، افکار پرشتاب، بیش‌فعالی و تحریک‌پذیری',0.00,100.00,'#d4af37',12);
INSERT INTO `test_dimensions` VALUES (13,1,'scale_si','درون‌گرایی اجتماعی (Social Introversion - Si)','دوری‌گزینی از موقعیت‌های اجتماعی، کم‌رویی و تمایل به انزوا',0.00,100.00,'#6b7280',13);
INSERT INTO `test_dimensions` VALUES (14,2,'N1','N1: اضطراب (Anxiety)','تمایل به نگرانی، دلواپسی و پیش‌بینی رویدادهای منفی',8.00,40.00,'#ef4444',1);
INSERT INTO `test_dimensions` VALUES (15,2,'N2','N2: خشم و خصومت (Angry Hostility)','تجربه خشم، تلخی، سرخوردگی و تحریک‌پذیری',8.00,40.00,'#ef4444',2);
INSERT INTO `test_dimensions` VALUES (16,2,'N3','N3: افسردگی (Depression)','احساس غم، ناامیدی، تنهایی و افت انگیزه',8.00,40.00,'#ef4444',3);
INSERT INTO `test_dimensions` VALUES (17,2,'N4','N4: شرم و خودناباوری (Self-Consciousness)','احساس خجالت، کم‌رویی، معذب بودن در جمع و ترس از تمسخر',8.00,40.00,'#ef4444',4);
INSERT INTO `test_dimensions` VALUES (18,2,'N5','N5: تکانشگری (Impulsiveness)','دشواری در مهار هوس‌ها، وسوسه‌ها و کنترل هیجانات آنی',8.00,40.00,'#ef4444',5);
INSERT INTO `test_dimensions` VALUES (19,2,'N6','N6: آسیب‌پذیری به استرس (Vulnerability)','احساس درماندگی، شکنندگی و ناتوانی در مدیریت بحران‌های شدید',8.00,40.00,'#ef4444',6);
INSERT INTO `test_dimensions` VALUES (20,2,'E1','E1: صمیمیت و مهرورزی (Warmth)','گرما در روابط، خوش‌مشربی و محبت صمیمانه به انسان‌ها',8.00,40.00,'#f59e0b',7);
INSERT INTO `test_dimensions` VALUES (21,2,'E2','E2: جمع‌گرایی (Gregariousness)','ترجیح حضور در جمع‌ها، معاشرت گسترده و گریزان بودن از انزوا',8.00,40.00,'#f59e0b',8);
INSERT INTO `test_dimensions` VALUES (22,2,'E3','E3: قاطعیت و جسارت (Assertiveness)','شجاعت در ابراز وجود، رهبری گروه و دفاع مقتدرانه از عقاید',8.00,40.00,'#f59e0b',9);
INSERT INTO `test_dimensions` VALUES (23,2,'E4','E4: فعالیت و پویایی (Activity)','ریتم تند زندگی، پرانرژی بودن و علاقه به تکاپوی مداوم',8.00,40.00,'#f59e0b',10);
INSERT INTO `test_dimensions` VALUES (24,2,'E5','E5: هیجان‌خواهی (Excitement Seeking)','علاقه به ماجراجویی، ریسک‌پذیری و موقعیت‌های پرهیجان',8.00,40.00,'#f59e0b',11);
INSERT INTO `test_dimensions` VALUES (25,2,'E6','E6: هیجانات مثبت و شادمانی (Positive Emotions)','تجربه مکرر شادی، سرزندگی، خنده، اشتیاق و خوش‌بینی',8.00,40.00,'#f59e0b',12);
INSERT INTO `test_dimensions` VALUES (26,2,'O1','O1: تخیل و فانتزی (Fantasy)','خیال‌پردازی قوی، رویاپردازی خلاق و دنیای درونی غنی',8.00,40.00,'#8b5cf6',13);
INSERT INTO `test_dimensions` VALUES (27,2,'O2','O2: زیبایی‌خواهی (Aesthetics)','درک عمیق از هنر، موسیقی، شعر و زیبایی‌های طبیعت',8.00,40.00,'#8b5cf6',14);
INSERT INTO `test_dimensions` VALUES (28,2,'O3','O3: احساسات و عواطف (Feelings)','آگاهی عمیق از حالات هیجانی خود و پذیرش دگرگونی‌های روانی',8.00,40.00,'#8b5cf6',15);
INSERT INTO `test_dimensions` VALUES (29,2,'O4','O4: اعمال و تجارب نو (Actions)','اشتیاق به امتحان کردن غذاها، مکان‌ها و رفتارهای نوین و متنوع',8.00,40.00,'#8b5cf6',16);
INSERT INTO `test_dimensions` VALUES (30,2,'O5','O5: ایده‌ها و کنجکاوی فکری (Ideas)','علاقه به مباحث فلسفی، نظریه‌ها، حل معما و تفکر نقادانه',8.00,40.00,'#8b5cf6',17);
INSERT INTO `test_dimensions` VALUES (31,2,'O6','O6: ارزش‌ها و دگراندیشی (Values)','انعطاف در بازنگری ارزش‌های سنتی، سیاسی و اخلاقی جامعه',8.00,40.00,'#8b5cf6',18);
INSERT INTO `test_dimensions` VALUES (32,2,'A1','A1: اعتماد به دیگران (Trust)','باور به صداقت، حسن‌نیت و پاک‌طینتی همنوعان',8.00,40.00,'#10b981',19);
INSERT INTO `test_dimensions` VALUES (33,2,'A2','A2: رک‌گویی و صداقت (Straightforwardness)','صراحت و صداقت در رفتار و عدم تمایل به فریب یا چاپلوسی',8.00,40.00,'#10b981',20);
INSERT INTO `test_dimensions` VALUES (34,2,'A3','A3: نوع‌دوستی (Altruism)','کمک فعالانه به نیازمندان، فداکاری و دلسوزی اصیل',8.00,40.00,'#10b981',21);
INSERT INTO `test_dimensions` VALUES (35,2,'A4','A4: همراهی و توافق‌پذیری (Compliance)','مهار خشم، گذشت در مشاجرات و پرهیز از درگیری و لجاجت',8.00,40.00,'#10b981',22);
INSERT INTO `test_dimensions` VALUES (36,2,'A5','A5: تواضع و فروتنی (Modesty)','فروتنی اصیل و پرهیز از خودستایی و بزرگ‌نمایی توانایی‌ها',8.00,40.00,'#10b981',23);
INSERT INTO `test_dimensions` VALUES (37,2,'A6','A6: دل‌رحمی و همدلی (Tender-Mindedness)','همدلی با دردهای دیگران و حمایت از حقوق ضعیفان و حیوانات',8.00,40.00,'#10b981',24);
INSERT INTO `test_dimensions` VALUES (38,2,'C1','C1: احساس شایستگی (Competence)','باور به کارآمدی، خرد و شایستگی فردی در غلبه بر چالش‌ها',8.00,40.00,'#3b82f6',25);
INSERT INTO `test_dimensions` VALUES (39,2,'C2','C2: نظم و ترتیب (Order)','سازمان‌یافتگی، تمیزی محیط و روشمندی در انجام کارها',8.00,40.00,'#3b82f6',26);
INSERT INTO `test_dimensions` VALUES (40,2,'C3','C3: وظیفه‌شناسی و وجدان (Dutifulness)','پایبندی خدشه‌ناپذیر به تعهدات، قول‌ها و اصول اخلاقی',8.00,40.00,'#3b82f6',27);
INSERT INTO `test_dimensions` VALUES (41,2,'C4','C4: تلاش برای موفقیت (Achievement Striving)','بلندپروازی، کار سخت و هدف‌گذاری جهت رسیدن به اوج موفقیت',8.00,40.00,'#3b82f6',28);
INSERT INTO `test_dimensions` VALUES (42,2,'C5','C5: خودانضباطی (Self-Discipline)','پشتکار در ادامه کار تا پایان حتی در صورت خستگی و بی‌حوصلگی',8.00,40.00,'#3b82f6',29);
INSERT INTO `test_dimensions` VALUES (43,2,'C6','C6: تدبیر و احتیاط (Deliberation)','دوراندیشی، تفکر دقیق قبل از تصمیم‌گیری و پرهیز از تصمیم عجولانه',8.00,40.00,'#3b82f6',30);
INSERT INTO `test_dimensions` VALUES (44,3,'sch_1','۱. محرومیت هیجانی (Emotional Deprivation)','انتظار برآورده نشدن نیازهای عاطفی، مهر و محبت، نوازش و همدلی',10.00,80.00,'#ef4444',1);
INSERT INTO `test_dimensions` VALUES (45,3,'sch_2','۲. رهاشدگی / بی‌ثباتی (Abandonment/Instability)','ترس مزمن از دست دادن افراد مهم زندگی و تنهایی عاطفی',10.00,80.00,'#f97316',2);
INSERT INTO `test_dimensions` VALUES (46,3,'sch_3','۳. بی‌اعتمادی / بدرفتاری (Mistrust/Abuse)','انتظار آسیب، فریب، تحقیر، صدمه یا سوءاستفاده از سوی دیگران',10.00,80.00,'#dc2626',3);
INSERT INTO `test_dimensions` VALUES (47,3,'sch_4','۴. انزوای اجتماعی / بیگانگی (Social Isolation)','احساس تفاوت بنیادین، عدم تعلق به جمع و طردشدگی اجتماعی',10.00,80.00,'#64748b',4);
INSERT INTO `test_dimensions` VALUES (48,3,'sch_5','۵. نقص / شرم (Defectiveness/Shame)','باور به معیوب، ناقص، بی‌ارزش و دوست‌نداشتنی بودن درونی',10.00,80.00,'#8b5cf6',5);
INSERT INTO `test_dimensions` VALUES (49,3,'sch_6','۶. شکست (Failure)','باور به ناتوانی، بی‌عرضگی و عقب ماندن مداوم از همتایان در موفقیت',10.00,80.00,'#d97706',6);
INSERT INTO `test_dimensions` VALUES (50,3,'sch_7','۷. وابستگی / بی‌کفایتی (Dependence/Incompetence)','ناتوانی ادراک‌شده در انجام کارهای روزمره بدون تکیه به دیگران',10.00,80.00,'#eab308',7);
INSERT INTO `test_dimensions` VALUES (51,3,'sch_8','۸. آسیب‌پذیری به ضرر یا بیماری (Vulnerability to Harm)','ترس مداوم از وقوع فجایع پزشکی، مالی، جنایی یا روانی غیرقابل کنترل',10.00,80.00,'#ef4444',8);
INSERT INTO `test_dimensions` VALUES (52,3,'sch_9','۹. گرفتاری / خویشتن تحول‌نیافته (Enmeshment)','نزدیکی مفرط و ادغام هویت با والدین یا همسر به قیمت از دست رفتن فردیت',10.00,80.00,'#0d9488',9);
INSERT INTO `test_dimensions` VALUES (53,3,'sch_10','۱۰. اطاعت / تسلیم (Subjugation)','واگذاری مفرط کنترل و سرکوب احساسات برای اجتناب از تنبیه یا طرد',10.00,80.00,'#2563eb',10);
INSERT INTO `test_dimensions` VALUES (54,3,'sch_11','۱۱. ایثار و فداکاری (Self-Sacrifice)','فداکاری افراطی و اولویت دادن مطلق به نیازهای دیگران به بهای آسیب به خود',10.00,80.00,'#10b981',11);
INSERT INTO `test_dimensions` VALUES (55,3,'sch_12','۱۲. پذیرش‌جویی / جلب توجه (Approval-Seeking)','تلاش مفرط برای جلب توجه، تایید و تحسین دیگران به بهای از دست دادن اصالت',10.00,80.00,'#f59e0b',12);
INSERT INTO `test_dimensions` VALUES (56,3,'sch_13','۱۳. منفی‌گرایی / بدبینی (Negativity/Pessimism)','تمرکز مداوم بر جنبه‌های تلخ، فاجعه‌آمیز و ناگوار زندگی',10.00,80.00,'#475569',13);
INSERT INTO `test_dimensions` VALUES (57,3,'sch_14','۱۴. بازداری هیجانی (Emotional Inhibition)','واپس‌زنی شدید احساسات، خودانگیختگی، خشم و آسیب‌پذیری',10.00,80.00,'#334155',14);
INSERT INTO `test_dimensions` VALUES (58,3,'sch_15','۱۵. معیارهای سرسختانه (Unrelenting Standards)','کمال‌گرایی فرساینده، استانداردهای سفت و سخت و عیب‌جویی افراطی',10.00,80.00,'#d4af37',15);
INSERT INTO `test_dimensions` VALUES (59,3,'sch_16','۱۶. استحقاق / بزرگ‌منشی (Entitlement/Grandiosity)','احساس برتری، تافته جدابافته بودن و نادیده گرفتن قوانین جمع',10.00,80.00,'#9333ea',16);
INSERT INTO `test_dimensions` VALUES (60,3,'sch_17','۱۷. خویشتن‌داری ناکافی (Insufficient Self-Control)','دشواری در خودانضباطی، تحمل ناکامی و مهار تکانه‌ها و هوس‌ها',10.00,80.00,'#94a3b8',17);
INSERT INTO `test_dimensions` VALUES (61,3,'sch_18','۱۸. تنبیه‌گرایی و بی‌رحمی (Punitiveness)','باور به لزوم مجازات و تنبیه شدید خود یا دیگران در اثر کوچک‌ترین اشتباه',10.00,80.00,'#991b1b',18);
INSERT INTO `test_dimensions` VALUES (62,4,'factor_a','عامل A: مردم‌آمیزی / گرم‌خویی (Warmth)','سنجش گرما در مراودات، محبت، صمیمیت و مردم‌داری در برابر کناره‌گیری',10.00,40.00,'#f59e0b',1);
INSERT INTO `test_dimensions` VALUES (63,4,'factor_b','عامل B: استدلال و هوش سیال (Reasoning)','سنجش توانایی حل مسئله، تفکر انتزاعی و سرعت یادگیری مفاهیم نو',10.00,40.00,'#3b82f6',2);
INSERT INTO `test_dimensions` VALUES (64,4,'factor_c','عامل C: پایداری هیجانی (Emotional Stability)','سنجش قدرت ایگو، خونسردی، سازگاری و ثبات در برابر تنش‌ها',10.00,40.00,'#10b981',3);
INSERT INTO `test_dimensions` VALUES (65,4,'factor_e','عامل E: سلطه‌گری / قاطعیت (Dominance)','سنجش تمایل به رهبری، اظهار وجود، ابراز قدرت و رقابت‌جویی',10.00,40.00,'#ef4444',4);
INSERT INTO `test_dimensions` VALUES (66,4,'factor_f','عامل F: سرزندگی و نشاط (Liveliness)','سنجش خودانگیختگی، برون‌ریزی شادی، خوش‌بینی و انرژی رفتاری',10.00,40.00,'#eab308',5);
INSERT INTO `test_dimensions` VALUES (67,4,'factor_g','عامل G: قانون‌گرایی و وجدان (Rule-Consciousness)','سنجش پایبندی به قوانین، انضباط اخلاقی و مسئولیت‌پذیری شغلی',10.00,40.00,'#0d9488',6);
INSERT INTO `test_dimensions` VALUES (68,4,'factor_h','عامل H: جسارت اجتماعی (Social Boldness)','سنجش نترسیدن از جمع، شجاعت، پیشقدمی در روابط و ماجراجویی',10.00,40.00,'#8b5cf6',7);
INSERT INTO `test_dimensions` VALUES (69,4,'factor_i','عامل I: حساسیت هیجانی (Sensitivity)','سنجش لطافت طبع، درک هنری، حساسیت عاطفی و شهود در برابر عمل‌گرایی',10.00,40.00,'#ec4899',8);
INSERT INTO `test_dimensions` VALUES (70,4,'factor_l','عامل L: هوشیاری و سوءظن (Vigilance)','سنجش احتیاط در اعتماد، شکاکیت و استقلال رأی در برابر زودباوری',10.00,40.00,'#b45309',9);
INSERT INTO `test_dimensions` VALUES (71,4,'factor_m','عامل M: خیال‌پردازی (Abstractedness)','سنجش تفکر مفهومی، تخیل درونی و رویاپردازی در برابر تمرکز بر جزئیات ملموس',10.00,40.00,'#6366f1',10);
INSERT INTO `test_dimensions` VALUES (72,4,'factor_n','عامل N: کاردانی اجتماعی و محافظه‌کاری (Privateness)','سنجش سیاست‌مداری، حفظ حریم خصوصی و زیرکی اجتماعی',10.00,40.00,'#64748b',11);
INSERT INTO `test_dimensions` VALUES (73,4,'factor_o','عامل O: تمایل به حس گناه و اضطراب (Apprehension)','سنجش سرزنش خود، نگرانی از آینده و احساس گناه درونی',10.00,40.00,'#dc2626',12);
INSERT INTO `test_dimensions` VALUES (74,4,'factor_q1','عامل Q1: تجربه‌پذیری و گشودگی به تحول (Openness to Change)','سنجش نوجویی، نوآوری، تغییرپذیری و شکستن سنت‌های کهنه',10.00,40.00,'#14b8a6',13);
INSERT INTO `test_dimensions` VALUES (75,4,'factor_q2','عامل Q2: خوداتکایی و استقلال فردی (Self-Reliance)','سنجش استقلال در تصمیم‌گیری و توانایی کار و تفکر در تنهایی',10.00,40.00,'#0284c7',14);
INSERT INTO `test_dimensions` VALUES (76,4,'factor_q3','عامل Q3: کمال‌گرایی و کنترل رفتار (Perfectionism)','سنجش نظم فردی، برنامه‌ریزی دقیق، حفظ شأن و خودکنترلی قوی',10.00,40.00,'#7c3aed',15);
INSERT INTO `test_dimensions` VALUES (77,4,'factor_q4','عامل Q4: تنش و برانگیختگی (Tension)','سنجش بی‌قراری، شتاب‌زدگی، کلافگی و انرژی عصبی تخلیه‌نشده',10.00,40.00,'#e11d48',16);
INSERT INTO `test_dimensions` VALUES (78,5,'csi_satisfaction','شاخص جامع رضایت و کیفیت زناشویی (CSI-32 Total)','سنجش عمیق صمیمیت، تعهد، ثبات هیجانی، تفاهم و حل تعارضات زوجین',0.00,161.00,'#d4af37',1);
INSERT INTO `test_dimensions` VALUES (79,6,'depression','افسردگی (Depression)','سنجش ناامیدی، کاهش انگیزه، بی‌ارزشی و عدم تجربه لذت',0.00,21.00,'#4A90E2',1);
INSERT INTO `test_dimensions` VALUES (80,6,'anxiety','اضطراب (Anxiety)','سنجش برانگیختگی خودمختار، اثرات اسکلتی-عضلانی و اضطراب موقعیتی',0.00,21.00,'#D4AF37',2);
INSERT INTO `test_dimensions` VALUES (81,6,'stress','استرس و تنیدگی (Stress)','سنجش تنش مزمن، تحریک‌پذیری، بی‌قراری و ناتوانی در آرامش',0.00,21.00,'#E74C3C',3);
INSERT INTO `test_dimensions` VALUES (82,7,'gad_total','شدت اضطراب فراگیر (GAD Total)','سنجش شاخص عمومی نگرانی، برانگیختگی ذهنی و تنش جسمانی',0.00,21.00,'#D4AF37',1);
INSERT INTO `test_dimensions` VALUES (83,8,'depression_severity','شدت نشانه‌های افسردگی (Depression Severity)','سنجش علائم شناختی، خلقی و جسمانی منطبق بر معیارهای بالینی DSM-5',0.00,27.00,'#4A90E2',1);
INSERT INTO `test_dimensions` VALUES (84,9,'self_esteem','عزت‌نفس کلی (Global Self-Esteem)','سنجش باور فرد به ارزشمندی، پذیرش خویشتن و کارآمدی شخصی',10.00,40.00,'#D4AF37',1);
INSERT INTO `test_dimensions` VALUES (85,10,'life_satisfaction','رضایت کلی از زندگی (Life Satisfaction)','ارزیابی شناختی کلان از مسیر، دستاوردها و وضعیت فعلی زندگی',5.00,35.00,'#2ECC71',1);
INSERT INTO `test_dimensions` VALUES (86,11,'attachment_anxiety','اضطراب دلبستگی (Attachment Anxiety)','ترس از رهاشدگی، طرد، نیاز مداوم به تأیید و دلواپسی از دست دادن رابطه',18.00,126.00,'#E74C3C',1);
INSERT INTO `test_dimensions` VALUES (87,11,'attachment_avoidance','اجتناب دلبستگی (Attachment Avoidance)','ترس از صمیمیت عمیق، فاصله گزینی هیجانی و اتکای افراطی به خودکفایی',18.00,126.00,'#3498DB',2);
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_options`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `option_number` int(11) NOT NULL,
  `option_text` varchar(255) NOT NULL,
  `score_value` decimal(8,2) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_opt_test` (`test_id`),
  KEY `idx_opt_num` (`test_id`,`option_number`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_options`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_options` VALUES (1,1,1,'خیر / نادرست (۰)',0.00,1);
INSERT INTO `test_options` VALUES (2,1,2,'بله / درست (۱)',1.00,2);
INSERT INTO `test_options` VALUES (3,2,1,'کاملاً مخالفم (۱)',1.00,1);
INSERT INTO `test_options` VALUES (4,2,2,'مخالفم (۲)',2.00,2);
INSERT INTO `test_options` VALUES (5,2,3,'بی‌تفاوت / نظری ندارم (۳)',3.00,3);
INSERT INTO `test_options` VALUES (6,2,4,'موافقم (۴)',4.00,4);
INSERT INTO `test_options` VALUES (7,2,5,'کاملاً موافقم (۵)',5.00,5);
INSERT INTO `test_options` VALUES (8,3,1,'کاملاً غلط درباره من (۱)',1.00,1);
INSERT INTO `test_options` VALUES (9,3,2,'غالباً غلط (۲)',2.00,2);
INSERT INTO `test_options` VALUES (10,3,3,'بیشتر درست تا غلط (۳)',3.00,3);
INSERT INTO `test_options` VALUES (11,3,4,'تا حدی درست (۴)',4.00,4);
INSERT INTO `test_options` VALUES (12,3,5,'غالباً درست (۵)',5.00,5);
INSERT INTO `test_options` VALUES (13,3,6,'کاملاً درست و مشخصه من (۶)',6.00,6);
INSERT INTO `test_options` VALUES (14,4,1,'الف) درست / موافقم (۲)',2.00,1);
INSERT INTO `test_options` VALUES (15,4,2,'ب) بین این دو / تا حدی (۱)',1.00,2);
INSERT INTO `test_options` VALUES (16,4,3,'ج) نادرست / مخالفم (۰)',0.00,3);
INSERT INTO `test_options` VALUES (17,5,1,'اصلاً / بسیار ناراضی (نمره ۰)',0.00,1);
INSERT INTO `test_options` VALUES (18,5,2,'به ندرت / ناراضی (نمره ۱)',1.00,2);
INSERT INTO `test_options` VALUES (19,5,3,'گاهی / نسبتاً ناراضی (نمره ۲)',2.00,3);
INSERT INTO `test_options` VALUES (20,5,4,'تا حدی / نسبتاً راضی (نمره ۳)',3.00,4);
INSERT INTO `test_options` VALUES (21,5,5,'اغلب / راضی (نمره ۴)',4.00,5);
INSERT INTO `test_options` VALUES (22,5,6,'همیشه / کاملاً راضی (نمره ۵)',5.00,6);
INSERT INTO `test_options` VALUES (23,6,1,'اصلاً در مورد من صدق نمی‌کند (اصلاً)',0.00,1);
INSERT INTO `test_options` VALUES (24,6,2,'کمی یا گاهی اوقات در مورد من صدق می‌کند (گاهی)',1.00,2);
INSERT INTO `test_options` VALUES (25,6,3,'به میزان زیاد یا اغلب اوقات در مورد من صدق می‌کند (اغلب)',2.00,3);
INSERT INTO `test_options` VALUES (26,6,4,'کاملاً و تقریباً همیشه در مورد من صدق می‌کند (همیشه)',3.00,4);
INSERT INTO `test_options` VALUES (27,7,1,'اصلاً (Not at all)',0.00,1);
INSERT INTO `test_options` VALUES (28,7,2,'چندین روز در هفته (Several days)',1.00,2);
INSERT INTO `test_options` VALUES (29,7,3,'بیش از نیمی از روزها (More than half the days)',2.00,3);
INSERT INTO `test_options` VALUES (30,7,4,'تقریباً هر روز (Nearly every day)',3.00,4);
INSERT INTO `test_options` VALUES (31,8,1,'اصلاً (Not at all)',0.00,1);
INSERT INTO `test_options` VALUES (32,8,2,'چندین روز در هفته (Several days)',1.00,2);
INSERT INTO `test_options` VALUES (33,8,3,'بیش از نیمی از روزها (More than half the days)',2.00,3);
INSERT INTO `test_options` VALUES (34,8,4,'تقریباً هر روز (Nearly every day)',3.00,4);
INSERT INTO `test_options` VALUES (35,9,1,'کاملاً مخالفم (Strongly Disagree)',1.00,1);
INSERT INTO `test_options` VALUES (36,9,2,'مخالفم (Disagree)',2.00,2);
INSERT INTO `test_options` VALUES (37,9,3,'موافقم (Agree)',3.00,3);
INSERT INTO `test_options` VALUES (38,9,4,'کاملاً موافقم (Strongly Agree)',4.00,4);
INSERT INTO `test_options` VALUES (39,10,1,'کاملاً مخالفم',1.00,1);
INSERT INTO `test_options` VALUES (40,10,2,'مخالفم',2.00,2);
INSERT INTO `test_options` VALUES (41,10,3,'کمی مخالفم',3.00,3);
INSERT INTO `test_options` VALUES (42,10,4,'نظری ندارم / خنثی',4.00,4);
INSERT INTO `test_options` VALUES (43,10,5,'کمی موافقم',5.00,5);
INSERT INTO `test_options` VALUES (44,10,6,'موافقم',6.00,6);
INSERT INTO `test_options` VALUES (45,10,7,'کاملاً موافقم',7.00,7);
INSERT INTO `test_options` VALUES (46,11,1,'کاملاً مخالفم (۱)',1.00,1);
INSERT INTO `test_options` VALUES (47,11,2,'مخالفم (۲)',2.00,2);
INSERT INTO `test_options` VALUES (48,11,3,'کمی مخالفم (۳)',3.00,3);
INSERT INTO `test_options` VALUES (49,11,4,'نظری ندارم / خنثی (۴)',4.00,4);
INSERT INTO `test_options` VALUES (50,11,5,'کمی موافقم (۵)',5.00,5);
INSERT INTO `test_options` VALUES (51,11,6,'موافقم (۶)',6.00,6);
INSERT INTO `test_options` VALUES (52,11,7,'کاملاً موافقم (۷)',7.00,7);
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_questions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `dimension_id` int(11) DEFAULT NULL,
  `question_number` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `is_reverse_scored` tinyint(1) NOT NULL DEFAULT 0,
  `help_text` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_q_test` (`test_id`),
  KEY `idx_q_dim` (`dimension_id`),
  KEY `idx_q_num` (`test_id`,`question_number`)
) ENGINE=InnoDB AUTO_INCREMENT=1345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_questions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_questions` VALUES (1,1,1,1,'من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,1);
INSERT INTO `test_questions` VALUES (2,1,2,2,'اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,2);
INSERT INTO `test_questions` VALUES (3,1,3,3,'بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,3);
INSERT INTO `test_questions` VALUES (4,1,4,4,'فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,4);
INSERT INTO `test_questions` VALUES (5,1,5,5,'با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,5);
INSERT INTO `test_questions` VALUES (6,1,6,6,'پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,6);
INSERT INTO `test_questions` VALUES (7,1,7,7,'خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,7);
INSERT INTO `test_questions` VALUES (8,1,8,8,'دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,8);
INSERT INTO `test_questions` VALUES (9,1,9,9,'زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,9);
INSERT INTO `test_questions` VALUES (10,1,10,10,'امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,10);
INSERT INTO `test_questions` VALUES (11,1,11,11,'بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,11);
INSERT INTO `test_questions` VALUES (12,1,12,12,'در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,12);
INSERT INTO `test_questions` VALUES (13,1,13,13,'فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,13);
INSERT INTO `test_questions` VALUES (14,1,1,14,'من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,14);
INSERT INTO `test_questions` VALUES (15,1,2,15,'گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,15);
INSERT INTO `test_questions` VALUES (16,1,3,16,'هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,16);
INSERT INTO `test_questions` VALUES (17,1,4,17,'برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,17);
INSERT INTO `test_questions` VALUES (18,1,5,18,'من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,18);
INSERT INTO `test_questions` VALUES (19,1,6,19,'به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,19);
INSERT INTO `test_questions` VALUES (20,1,7,20,'اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,20);
INSERT INTO `test_questions` VALUES (21,1,8,21,'در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,21);
INSERT INTO `test_questions` VALUES (22,1,9,22,'بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,22);
INSERT INTO `test_questions` VALUES (23,1,10,23,'گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,23);
INSERT INTO `test_questions` VALUES (24,1,11,24,'ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,24);
INSERT INTO `test_questions` VALUES (25,1,12,25,'به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,25);
INSERT INTO `test_questions` VALUES (26,1,13,26,'بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,26);
INSERT INTO `test_questions` VALUES (27,1,1,27,'اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,27);
INSERT INTO `test_questions` VALUES (28,1,2,28,'حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,28);
INSERT INTO `test_questions` VALUES (29,1,3,29,'اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,29);
INSERT INTO `test_questions` VALUES (30,1,4,30,'ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,30);
INSERT INTO `test_questions` VALUES (31,1,5,31,'گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,31);
INSERT INTO `test_questions` VALUES (32,1,6,32,'معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,32);
INSERT INTO `test_questions` VALUES (33,1,7,33,'من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,33);
INSERT INTO `test_questions` VALUES (34,1,8,34,'دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,34);
INSERT INTO `test_questions` VALUES (35,1,9,35,'بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,35);
INSERT INTO `test_questions` VALUES (36,1,10,36,'گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,36);
INSERT INTO `test_questions` VALUES (37,1,11,37,'من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,37);
INSERT INTO `test_questions` VALUES (38,1,12,38,'معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,38);
INSERT INTO `test_questions` VALUES (39,1,13,39,'دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,39);
INSERT INTO `test_questions` VALUES (40,1,1,40,'گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,40);
INSERT INTO `test_questions` VALUES (41,1,2,41,'اغلب اوقات تجربه کرده‌ام که من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,41);
INSERT INTO `test_questions` VALUES (42,1,3,42,'اغلب اوقات تجربه کرده‌ام که اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,42);
INSERT INTO `test_questions` VALUES (43,1,4,43,'اغلب اوقات تجربه کرده‌ام که بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,43);
INSERT INTO `test_questions` VALUES (44,1,5,44,'اغلب اوقات تجربه کرده‌ام که فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,44);
INSERT INTO `test_questions` VALUES (45,1,6,45,'اغلب اوقات تجربه کرده‌ام که با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,45);
INSERT INTO `test_questions` VALUES (46,1,7,46,'اغلب اوقات تجربه کرده‌ام که پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,46);
INSERT INTO `test_questions` VALUES (47,1,8,47,'اغلب اوقات تجربه کرده‌ام که خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,47);
INSERT INTO `test_questions` VALUES (48,1,9,48,'اغلب اوقات تجربه کرده‌ام که دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,48);
INSERT INTO `test_questions` VALUES (49,1,10,49,'اغلب اوقات تجربه کرده‌ام که زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,49);
INSERT INTO `test_questions` VALUES (50,1,11,50,'اغلب اوقات تجربه کرده‌ام که امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,50);
INSERT INTO `test_questions` VALUES (51,1,12,51,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,51);
INSERT INTO `test_questions` VALUES (52,1,13,52,'اغلب اوقات تجربه کرده‌ام که در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,52);
INSERT INTO `test_questions` VALUES (53,1,1,53,'اغلب اوقات تجربه کرده‌ام که فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,53);
INSERT INTO `test_questions` VALUES (54,1,2,54,'اغلب اوقات تجربه کرده‌ام که من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,54);
INSERT INTO `test_questions` VALUES (55,1,3,55,'اغلب اوقات تجربه کرده‌ام که گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,55);
INSERT INTO `test_questions` VALUES (56,1,4,56,'اغلب اوقات تجربه کرده‌ام که هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,56);
INSERT INTO `test_questions` VALUES (57,1,5,57,'اغلب اوقات تجربه کرده‌ام که برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,57);
INSERT INTO `test_questions` VALUES (58,1,6,58,'اغلب اوقات تجربه کرده‌ام که من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,58);
INSERT INTO `test_questions` VALUES (59,1,7,59,'اغلب اوقات تجربه کرده‌ام که به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,59);
INSERT INTO `test_questions` VALUES (60,1,8,60,'اغلب اوقات تجربه کرده‌ام که اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,60);
INSERT INTO `test_questions` VALUES (61,1,9,61,'اغلب اوقات تجربه کرده‌ام که در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,61);
INSERT INTO `test_questions` VALUES (62,1,10,62,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,62);
INSERT INTO `test_questions` VALUES (63,1,11,63,'اغلب اوقات تجربه کرده‌ام که گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,63);
INSERT INTO `test_questions` VALUES (64,1,12,64,'اغلب اوقات تجربه کرده‌ام که ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,64);
INSERT INTO `test_questions` VALUES (65,1,13,65,'اغلب اوقات تجربه کرده‌ام که به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,65);
INSERT INTO `test_questions` VALUES (66,1,1,66,'اغلب اوقات تجربه کرده‌ام که بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,66);
INSERT INTO `test_questions` VALUES (67,1,2,67,'اغلب اوقات تجربه کرده‌ام که اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,67);
INSERT INTO `test_questions` VALUES (68,1,3,68,'اغلب اوقات تجربه کرده‌ام که حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,68);
INSERT INTO `test_questions` VALUES (69,1,4,69,'اغلب اوقات تجربه کرده‌ام که اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,69);
INSERT INTO `test_questions` VALUES (70,1,5,70,'اغلب اوقات تجربه کرده‌ام که ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,70);
INSERT INTO `test_questions` VALUES (71,1,6,71,'اغلب اوقات تجربه کرده‌ام که گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,71);
INSERT INTO `test_questions` VALUES (72,1,7,72,'اغلب اوقات تجربه کرده‌ام که معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,72);
INSERT INTO `test_questions` VALUES (73,1,8,73,'اغلب اوقات تجربه کرده‌ام که من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,73);
INSERT INTO `test_questions` VALUES (74,1,9,74,'اغلب اوقات تجربه کرده‌ام که دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,74);
INSERT INTO `test_questions` VALUES (75,1,10,75,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,75);
INSERT INTO `test_questions` VALUES (76,1,11,76,'اغلب اوقات تجربه کرده‌ام که گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,76);
INSERT INTO `test_questions` VALUES (77,1,12,77,'اغلب اوقات تجربه کرده‌ام که من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,77);
INSERT INTO `test_questions` VALUES (78,1,13,78,'اغلب اوقات تجربه کرده‌ام که معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,78);
INSERT INTO `test_questions` VALUES (79,1,1,79,'اغلب اوقات تجربه کرده‌ام که دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,79);
INSERT INTO `test_questions` VALUES (80,1,2,80,'نسبت به گذشته، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,80);
INSERT INTO `test_questions` VALUES (81,1,3,81,'نسبت به گذشته، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,81);
INSERT INTO `test_questions` VALUES (82,1,4,82,'نسبت به گذشته، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,82);
INSERT INTO `test_questions` VALUES (83,1,5,83,'نسبت به گذشته، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,83);
INSERT INTO `test_questions` VALUES (84,1,6,84,'نسبت به گذشته، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,84);
INSERT INTO `test_questions` VALUES (85,1,7,85,'نسبت به گذشته، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,85);
INSERT INTO `test_questions` VALUES (86,1,8,86,'نسبت به گذشته، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,86);
INSERT INTO `test_questions` VALUES (87,1,9,87,'نسبت به گذشته، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,87);
INSERT INTO `test_questions` VALUES (88,1,10,88,'نسبت به گذشته، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,88);
INSERT INTO `test_questions` VALUES (89,1,11,89,'نسبت به گذشته، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,89);
INSERT INTO `test_questions` VALUES (90,1,12,90,'نسبت به گذشته، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,90);
INSERT INTO `test_questions` VALUES (91,1,13,91,'نسبت به گذشته، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,91);
INSERT INTO `test_questions` VALUES (92,1,1,92,'نسبت به گذشته، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,92);
INSERT INTO `test_questions` VALUES (93,1,2,93,'نسبت به گذشته، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,93);
INSERT INTO `test_questions` VALUES (94,1,3,94,'نسبت به گذشته، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,94);
INSERT INTO `test_questions` VALUES (95,1,4,95,'نسبت به گذشته، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,95);
INSERT INTO `test_questions` VALUES (96,1,5,96,'نسبت به گذشته، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,96);
INSERT INTO `test_questions` VALUES (97,1,6,97,'نسبت به گذشته، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,97);
INSERT INTO `test_questions` VALUES (98,1,7,98,'نسبت به گذشته، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,98);
INSERT INTO `test_questions` VALUES (99,1,8,99,'نسبت به گذشته، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,99);
INSERT INTO `test_questions` VALUES (100,1,9,100,'نسبت به گذشته، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,100);
INSERT INTO `test_questions` VALUES (101,1,10,101,'نسبت به گذشته، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,101);
INSERT INTO `test_questions` VALUES (102,1,11,102,'نسبت به گذشته، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,102);
INSERT INTO `test_questions` VALUES (103,1,12,103,'نسبت به گذشته، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,103);
INSERT INTO `test_questions` VALUES (104,1,13,104,'نسبت به گذشته، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,104);
INSERT INTO `test_questions` VALUES (105,1,1,105,'نسبت به گذشته، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,105);
INSERT INTO `test_questions` VALUES (106,1,2,106,'نسبت به گذشته، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,106);
INSERT INTO `test_questions` VALUES (107,1,3,107,'نسبت به گذشته، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,107);
INSERT INTO `test_questions` VALUES (108,1,4,108,'نسبت به گذشته، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,108);
INSERT INTO `test_questions` VALUES (109,1,5,109,'نسبت به گذشته، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,109);
INSERT INTO `test_questions` VALUES (110,1,6,110,'نسبت به گذشته، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,110);
INSERT INTO `test_questions` VALUES (111,1,7,111,'نسبت به گذشته، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,111);
INSERT INTO `test_questions` VALUES (112,1,8,112,'نسبت به گذشته، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,112);
INSERT INTO `test_questions` VALUES (113,1,9,113,'نسبت به گذشته، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,113);
INSERT INTO `test_questions` VALUES (114,1,10,114,'نسبت به گذشته، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,114);
INSERT INTO `test_questions` VALUES (115,1,11,115,'نسبت به گذشته، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,115);
INSERT INTO `test_questions` VALUES (116,1,12,116,'نسبت به گذشته، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,116);
INSERT INTO `test_questions` VALUES (117,1,13,117,'نسبت به گذشته، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,117);
INSERT INTO `test_questions` VALUES (118,1,1,118,'نسبت به گذشته، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,118);
INSERT INTO `test_questions` VALUES (119,1,2,119,'نسبت به گذشته، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,119);
INSERT INTO `test_questions` VALUES (120,1,3,120,'به طور کلی در زندگی من، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,120);
INSERT INTO `test_questions` VALUES (121,1,4,121,'به طور کلی در زندگی من، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,121);
INSERT INTO `test_questions` VALUES (122,1,5,122,'به طور کلی در زندگی من، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,122);
INSERT INTO `test_questions` VALUES (123,1,6,123,'به طور کلی در زندگی من، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,123);
INSERT INTO `test_questions` VALUES (124,1,7,124,'به طور کلی در زندگی من، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,124);
INSERT INTO `test_questions` VALUES (125,1,8,125,'به طور کلی در زندگی من، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,125);
INSERT INTO `test_questions` VALUES (126,1,9,126,'به طور کلی در زندگی من، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,126);
INSERT INTO `test_questions` VALUES (127,1,10,127,'به طور کلی در زندگی من، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,127);
INSERT INTO `test_questions` VALUES (128,1,11,128,'به طور کلی در زندگی من، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,128);
INSERT INTO `test_questions` VALUES (129,1,12,129,'به طور کلی در زندگی من، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,129);
INSERT INTO `test_questions` VALUES (130,1,13,130,'به طور کلی در زندگی من، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,130);
INSERT INTO `test_questions` VALUES (131,1,1,131,'به طور کلی در زندگی من، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,131);
INSERT INTO `test_questions` VALUES (132,1,2,132,'به طور کلی در زندگی من، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,132);
INSERT INTO `test_questions` VALUES (133,1,3,133,'به طور کلی در زندگی من، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,133);
INSERT INTO `test_questions` VALUES (134,1,4,134,'به طور کلی در زندگی من، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,134);
INSERT INTO `test_questions` VALUES (135,1,5,135,'به طور کلی در زندگی من، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,135);
INSERT INTO `test_questions` VALUES (136,1,6,136,'به طور کلی در زندگی من، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,136);
INSERT INTO `test_questions` VALUES (137,1,7,137,'به طور کلی در زندگی من، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,137);
INSERT INTO `test_questions` VALUES (138,1,8,138,'به طور کلی در زندگی من، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,138);
INSERT INTO `test_questions` VALUES (139,1,9,139,'به طور کلی در زندگی من، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,139);
INSERT INTO `test_questions` VALUES (140,1,10,140,'به طور کلی در زندگی من، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,140);
INSERT INTO `test_questions` VALUES (141,1,11,141,'به طور کلی در زندگی من، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,141);
INSERT INTO `test_questions` VALUES (142,1,12,142,'به طور کلی در زندگی من، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,142);
INSERT INTO `test_questions` VALUES (143,1,13,143,'به طور کلی در زندگی من، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,143);
INSERT INTO `test_questions` VALUES (144,1,1,144,'به طور کلی در زندگی من، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,144);
INSERT INTO `test_questions` VALUES (145,1,2,145,'به طور کلی در زندگی من، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,145);
INSERT INTO `test_questions` VALUES (146,1,3,146,'به طور کلی در زندگی من، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,146);
INSERT INTO `test_questions` VALUES (147,1,4,147,'به طور کلی در زندگی من، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,147);
INSERT INTO `test_questions` VALUES (148,1,5,148,'به طور کلی در زندگی من، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,148);
INSERT INTO `test_questions` VALUES (149,1,6,149,'به طور کلی در زندگی من، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,149);
INSERT INTO `test_questions` VALUES (150,1,7,150,'به طور کلی در زندگی من، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,150);
INSERT INTO `test_questions` VALUES (151,1,8,151,'به طور کلی در زندگی من، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,151);
INSERT INTO `test_questions` VALUES (152,1,9,152,'به طور کلی در زندگی من، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,152);
INSERT INTO `test_questions` VALUES (153,1,10,153,'به طور کلی در زندگی من، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,153);
INSERT INTO `test_questions` VALUES (154,1,11,154,'به طور کلی در زندگی من، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,154);
INSERT INTO `test_questions` VALUES (155,1,12,155,'به طور کلی در زندگی من، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,155);
INSERT INTO `test_questions` VALUES (156,1,13,156,'به طور کلی در زندگی من، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,156);
INSERT INTO `test_questions` VALUES (157,1,1,157,'به طور کلی در زندگی من، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,157);
INSERT INTO `test_questions` VALUES (158,1,2,158,'به طور کلی در زندگی من، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,158);
INSERT INTO `test_questions` VALUES (159,1,3,159,'به طور کلی در زندگی من، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,159);
INSERT INTO `test_questions` VALUES (160,1,4,160,'در بیشتر موارد صادق است که گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,160);
INSERT INTO `test_questions` VALUES (161,1,5,161,'در بیشتر موارد صادق است که من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,161);
INSERT INTO `test_questions` VALUES (162,1,6,162,'در بیشتر موارد صادق است که اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,162);
INSERT INTO `test_questions` VALUES (163,1,7,163,'در بیشتر موارد صادق است که بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,163);
INSERT INTO `test_questions` VALUES (164,1,8,164,'در بیشتر موارد صادق است که فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,164);
INSERT INTO `test_questions` VALUES (165,1,9,165,'در بیشتر موارد صادق است که با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,165);
INSERT INTO `test_questions` VALUES (166,1,10,166,'در بیشتر موارد صادق است که پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,166);
INSERT INTO `test_questions` VALUES (167,1,11,167,'در بیشتر موارد صادق است که خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,167);
INSERT INTO `test_questions` VALUES (168,1,12,168,'در بیشتر موارد صادق است که دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,168);
INSERT INTO `test_questions` VALUES (169,1,13,169,'در بیشتر موارد صادق است که زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,169);
INSERT INTO `test_questions` VALUES (170,1,1,170,'در بیشتر موارد صادق است که امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,170);
INSERT INTO `test_questions` VALUES (171,1,2,171,'در بیشتر موارد صادق است که بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,171);
INSERT INTO `test_questions` VALUES (172,1,3,172,'در بیشتر موارد صادق است که در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,172);
INSERT INTO `test_questions` VALUES (173,1,4,173,'در بیشتر موارد صادق است که فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,173);
INSERT INTO `test_questions` VALUES (174,1,5,174,'در بیشتر موارد صادق است که من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,174);
INSERT INTO `test_questions` VALUES (175,1,6,175,'در بیشتر موارد صادق است که گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,175);
INSERT INTO `test_questions` VALUES (176,1,7,176,'در بیشتر موارد صادق است که هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,176);
INSERT INTO `test_questions` VALUES (177,1,8,177,'در بیشتر موارد صادق است که برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,177);
INSERT INTO `test_questions` VALUES (178,1,9,178,'در بیشتر موارد صادق است که من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,178);
INSERT INTO `test_questions` VALUES (179,1,10,179,'در بیشتر موارد صادق است که به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,179);
INSERT INTO `test_questions` VALUES (180,1,11,180,'در بیشتر موارد صادق است که اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,180);
INSERT INTO `test_questions` VALUES (181,1,12,181,'در بیشتر موارد صادق است که در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,181);
INSERT INTO `test_questions` VALUES (182,1,13,182,'در بیشتر موارد صادق است که بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,182);
INSERT INTO `test_questions` VALUES (183,1,1,183,'در بیشتر موارد صادق است که گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,183);
INSERT INTO `test_questions` VALUES (184,1,2,184,'در بیشتر موارد صادق است که ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,184);
INSERT INTO `test_questions` VALUES (185,1,3,185,'در بیشتر موارد صادق است که به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,185);
INSERT INTO `test_questions` VALUES (186,1,4,186,'در بیشتر موارد صادق است که بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,186);
INSERT INTO `test_questions` VALUES (187,1,5,187,'در بیشتر موارد صادق است که اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,187);
INSERT INTO `test_questions` VALUES (188,1,6,188,'در بیشتر موارد صادق است که حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,188);
INSERT INTO `test_questions` VALUES (189,1,7,189,'در بیشتر موارد صادق است که اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,189);
INSERT INTO `test_questions` VALUES (190,1,8,190,'در بیشتر موارد صادق است که ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,190);
INSERT INTO `test_questions` VALUES (191,1,9,191,'در بیشتر موارد صادق است که گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,191);
INSERT INTO `test_questions` VALUES (192,1,10,192,'در بیشتر موارد صادق است که معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,192);
INSERT INTO `test_questions` VALUES (193,1,11,193,'در بیشتر موارد صادق است که من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,193);
INSERT INTO `test_questions` VALUES (194,1,12,194,'در بیشتر موارد صادق است که دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,194);
INSERT INTO `test_questions` VALUES (195,1,13,195,'در بیشتر موارد صادق است که بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,195);
INSERT INTO `test_questions` VALUES (196,1,1,196,'در بیشتر موارد صادق است که گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,196);
INSERT INTO `test_questions` VALUES (197,1,2,197,'در بیشتر موارد صادق است که من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,197);
INSERT INTO `test_questions` VALUES (198,1,3,198,'در بیشتر موارد صادق است که معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,198);
INSERT INTO `test_questions` VALUES (199,1,4,199,'در بیشتر موارد صادق است که دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,199);
INSERT INTO `test_questions` VALUES (200,1,5,200,'در موقعیت‌های روزمره، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,200);
INSERT INTO `test_questions` VALUES (201,1,6,201,'در موقعیت‌های روزمره، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,201);
INSERT INTO `test_questions` VALUES (202,1,7,202,'در موقعیت‌های روزمره، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,202);
INSERT INTO `test_questions` VALUES (203,1,8,203,'در موقعیت‌های روزمره، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,203);
INSERT INTO `test_questions` VALUES (204,1,9,204,'در موقعیت‌های روزمره، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,204);
INSERT INTO `test_questions` VALUES (205,1,10,205,'در موقعیت‌های روزمره، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,205);
INSERT INTO `test_questions` VALUES (206,1,11,206,'در موقعیت‌های روزمره، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,206);
INSERT INTO `test_questions` VALUES (207,1,12,207,'در موقعیت‌های روزمره، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,207);
INSERT INTO `test_questions` VALUES (208,1,13,208,'در موقعیت‌های روزمره، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,208);
INSERT INTO `test_questions` VALUES (209,1,1,209,'در موقعیت‌های روزمره، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,209);
INSERT INTO `test_questions` VALUES (210,1,2,210,'در موقعیت‌های روزمره، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,210);
INSERT INTO `test_questions` VALUES (211,1,3,211,'در موقعیت‌های روزمره، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,211);
INSERT INTO `test_questions` VALUES (212,1,4,212,'در موقعیت‌های روزمره، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,212);
INSERT INTO `test_questions` VALUES (213,1,5,213,'در موقعیت‌های روزمره، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,213);
INSERT INTO `test_questions` VALUES (214,1,6,214,'در موقعیت‌های روزمره، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,214);
INSERT INTO `test_questions` VALUES (215,1,7,215,'در موقعیت‌های روزمره، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,215);
INSERT INTO `test_questions` VALUES (216,1,8,216,'در موقعیت‌های روزمره، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,216);
INSERT INTO `test_questions` VALUES (217,1,9,217,'در موقعیت‌های روزمره، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,217);
INSERT INTO `test_questions` VALUES (218,1,10,218,'در موقعیت‌های روزمره، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,218);
INSERT INTO `test_questions` VALUES (219,1,11,219,'در موقعیت‌های روزمره، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,219);
INSERT INTO `test_questions` VALUES (220,1,12,220,'در موقعیت‌های روزمره، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,220);
INSERT INTO `test_questions` VALUES (221,1,13,221,'در موقعیت‌های روزمره، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,221);
INSERT INTO `test_questions` VALUES (222,1,1,222,'در موقعیت‌های روزمره، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,222);
INSERT INTO `test_questions` VALUES (223,1,2,223,'در موقعیت‌های روزمره، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,223);
INSERT INTO `test_questions` VALUES (224,1,3,224,'در موقعیت‌های روزمره، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,224);
INSERT INTO `test_questions` VALUES (225,1,4,225,'در موقعیت‌های روزمره، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,225);
INSERT INTO `test_questions` VALUES (226,1,5,226,'در موقعیت‌های روزمره، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,226);
INSERT INTO `test_questions` VALUES (227,1,6,227,'در موقعیت‌های روزمره، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,227);
INSERT INTO `test_questions` VALUES (228,1,7,228,'در موقعیت‌های روزمره، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,228);
INSERT INTO `test_questions` VALUES (229,1,8,229,'در موقعیت‌های روزمره، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,229);
INSERT INTO `test_questions` VALUES (230,1,9,230,'در موقعیت‌های روزمره، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,230);
INSERT INTO `test_questions` VALUES (231,1,10,231,'در موقعیت‌های روزمره، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,231);
INSERT INTO `test_questions` VALUES (232,1,11,232,'در موقعیت‌های روزمره، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,232);
INSERT INTO `test_questions` VALUES (233,1,12,233,'در موقعیت‌های روزمره، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,233);
INSERT INTO `test_questions` VALUES (234,1,13,234,'در موقعیت‌های روزمره، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,234);
INSERT INTO `test_questions` VALUES (235,1,1,235,'در موقعیت‌های روزمره، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,235);
INSERT INTO `test_questions` VALUES (236,1,2,236,'در موقعیت‌های روزمره، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,236);
INSERT INTO `test_questions` VALUES (237,1,3,237,'در موقعیت‌های روزمره، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,237);
INSERT INTO `test_questions` VALUES (238,1,4,238,'در موقعیت‌های روزمره، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,238);
INSERT INTO `test_questions` VALUES (239,1,5,239,'در موقعیت‌های روزمره، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,239);
INSERT INTO `test_questions` VALUES (240,1,6,240,'اغلب اوقات تجربه کرده‌ام که گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,240);
INSERT INTO `test_questions` VALUES (241,1,7,241,'اغلب اوقات تجربه کرده‌ام که من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,241);
INSERT INTO `test_questions` VALUES (242,1,8,242,'اغلب اوقات تجربه کرده‌ام که اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,242);
INSERT INTO `test_questions` VALUES (243,1,9,243,'اغلب اوقات تجربه کرده‌ام که بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,243);
INSERT INTO `test_questions` VALUES (244,1,10,244,'اغلب اوقات تجربه کرده‌ام که فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,244);
INSERT INTO `test_questions` VALUES (245,1,11,245,'اغلب اوقات تجربه کرده‌ام که با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,245);
INSERT INTO `test_questions` VALUES (246,1,12,246,'اغلب اوقات تجربه کرده‌ام که پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,246);
INSERT INTO `test_questions` VALUES (247,1,13,247,'اغلب اوقات تجربه کرده‌ام که خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,247);
INSERT INTO `test_questions` VALUES (248,1,1,248,'اغلب اوقات تجربه کرده‌ام که دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,248);
INSERT INTO `test_questions` VALUES (249,1,2,249,'اغلب اوقات تجربه کرده‌ام که زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,249);
INSERT INTO `test_questions` VALUES (250,1,3,250,'اغلب اوقات تجربه کرده‌ام که امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,250);
INSERT INTO `test_questions` VALUES (251,1,4,251,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,251);
INSERT INTO `test_questions` VALUES (252,1,5,252,'اغلب اوقات تجربه کرده‌ام که در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,252);
INSERT INTO `test_questions` VALUES (253,1,6,253,'اغلب اوقات تجربه کرده‌ام که فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,253);
INSERT INTO `test_questions` VALUES (254,1,7,254,'اغلب اوقات تجربه کرده‌ام که من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,254);
INSERT INTO `test_questions` VALUES (255,1,8,255,'اغلب اوقات تجربه کرده‌ام که گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,255);
INSERT INTO `test_questions` VALUES (256,1,9,256,'اغلب اوقات تجربه کرده‌ام که هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,256);
INSERT INTO `test_questions` VALUES (257,1,10,257,'اغلب اوقات تجربه کرده‌ام که برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,257);
INSERT INTO `test_questions` VALUES (258,1,11,258,'اغلب اوقات تجربه کرده‌ام که من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,258);
INSERT INTO `test_questions` VALUES (259,1,12,259,'اغلب اوقات تجربه کرده‌ام که به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,259);
INSERT INTO `test_questions` VALUES (260,1,13,260,'اغلب اوقات تجربه کرده‌ام که اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,260);
INSERT INTO `test_questions` VALUES (261,1,1,261,'اغلب اوقات تجربه کرده‌ام که در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,261);
INSERT INTO `test_questions` VALUES (262,1,2,262,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,262);
INSERT INTO `test_questions` VALUES (263,1,3,263,'اغلب اوقات تجربه کرده‌ام که گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,263);
INSERT INTO `test_questions` VALUES (264,1,4,264,'اغلب اوقات تجربه کرده‌ام که ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,264);
INSERT INTO `test_questions` VALUES (265,1,5,265,'اغلب اوقات تجربه کرده‌ام که به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,265);
INSERT INTO `test_questions` VALUES (266,1,6,266,'اغلب اوقات تجربه کرده‌ام که بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,266);
INSERT INTO `test_questions` VALUES (267,1,7,267,'اغلب اوقات تجربه کرده‌ام که اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,267);
INSERT INTO `test_questions` VALUES (268,1,8,268,'اغلب اوقات تجربه کرده‌ام که حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,268);
INSERT INTO `test_questions` VALUES (269,1,9,269,'اغلب اوقات تجربه کرده‌ام که اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,269);
INSERT INTO `test_questions` VALUES (270,1,10,270,'اغلب اوقات تجربه کرده‌ام که ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,270);
INSERT INTO `test_questions` VALUES (271,1,11,271,'اغلب اوقات تجربه کرده‌ام که گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,271);
INSERT INTO `test_questions` VALUES (272,1,12,272,'اغلب اوقات تجربه کرده‌ام که معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,272);
INSERT INTO `test_questions` VALUES (273,1,13,273,'اغلب اوقات تجربه کرده‌ام که من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,273);
INSERT INTO `test_questions` VALUES (274,1,1,274,'اغلب اوقات تجربه کرده‌ام که دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,274);
INSERT INTO `test_questions` VALUES (275,1,2,275,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,275);
INSERT INTO `test_questions` VALUES (276,1,3,276,'اغلب اوقات تجربه کرده‌ام که گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,276);
INSERT INTO `test_questions` VALUES (277,1,4,277,'اغلب اوقات تجربه کرده‌ام که من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,277);
INSERT INTO `test_questions` VALUES (278,1,5,278,'اغلب اوقات تجربه کرده‌ام که معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,278);
INSERT INTO `test_questions` VALUES (279,1,6,279,'اغلب اوقات تجربه کرده‌ام که دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,279);
INSERT INTO `test_questions` VALUES (280,1,7,280,'نسبت به گذشته، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,280);
INSERT INTO `test_questions` VALUES (281,1,8,281,'نسبت به گذشته، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,281);
INSERT INTO `test_questions` VALUES (282,1,9,282,'نسبت به گذشته، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,282);
INSERT INTO `test_questions` VALUES (283,1,10,283,'نسبت به گذشته، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,283);
INSERT INTO `test_questions` VALUES (284,1,11,284,'نسبت به گذشته، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,284);
INSERT INTO `test_questions` VALUES (285,1,12,285,'نسبت به گذشته، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,285);
INSERT INTO `test_questions` VALUES (286,1,13,286,'نسبت به گذشته، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,286);
INSERT INTO `test_questions` VALUES (287,1,1,287,'نسبت به گذشته، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,287);
INSERT INTO `test_questions` VALUES (288,1,2,288,'نسبت به گذشته، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,288);
INSERT INTO `test_questions` VALUES (289,1,3,289,'نسبت به گذشته، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,289);
INSERT INTO `test_questions` VALUES (290,1,4,290,'نسبت به گذشته، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,290);
INSERT INTO `test_questions` VALUES (291,1,5,291,'نسبت به گذشته، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,291);
INSERT INTO `test_questions` VALUES (292,1,6,292,'نسبت به گذشته، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,292);
INSERT INTO `test_questions` VALUES (293,1,7,293,'نسبت به گذشته، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,293);
INSERT INTO `test_questions` VALUES (294,1,8,294,'نسبت به گذشته، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,294);
INSERT INTO `test_questions` VALUES (295,1,9,295,'نسبت به گذشته، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,295);
INSERT INTO `test_questions` VALUES (296,1,10,296,'نسبت به گذشته، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,296);
INSERT INTO `test_questions` VALUES (297,1,11,297,'نسبت به گذشته، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,297);
INSERT INTO `test_questions` VALUES (298,1,12,298,'نسبت به گذشته، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,298);
INSERT INTO `test_questions` VALUES (299,1,13,299,'نسبت به گذشته، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,299);
INSERT INTO `test_questions` VALUES (300,1,1,300,'نسبت به گذشته، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,300);
INSERT INTO `test_questions` VALUES (301,1,2,301,'نسبت به گذشته، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,301);
INSERT INTO `test_questions` VALUES (302,1,3,302,'نسبت به گذشته، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,302);
INSERT INTO `test_questions` VALUES (303,1,4,303,'نسبت به گذشته، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,303);
INSERT INTO `test_questions` VALUES (304,1,5,304,'نسبت به گذشته، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,304);
INSERT INTO `test_questions` VALUES (305,1,6,305,'نسبت به گذشته، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,305);
INSERT INTO `test_questions` VALUES (306,1,7,306,'نسبت به گذشته، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,306);
INSERT INTO `test_questions` VALUES (307,1,8,307,'نسبت به گذشته، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,307);
INSERT INTO `test_questions` VALUES (308,1,9,308,'نسبت به گذشته، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,308);
INSERT INTO `test_questions` VALUES (309,1,10,309,'نسبت به گذشته، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,309);
INSERT INTO `test_questions` VALUES (310,1,11,310,'نسبت به گذشته، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,310);
INSERT INTO `test_questions` VALUES (311,1,12,311,'نسبت به گذشته، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,311);
INSERT INTO `test_questions` VALUES (312,1,13,312,'نسبت به گذشته، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,312);
INSERT INTO `test_questions` VALUES (313,1,1,313,'نسبت به گذشته، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,313);
INSERT INTO `test_questions` VALUES (314,1,2,314,'نسبت به گذشته، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,314);
INSERT INTO `test_questions` VALUES (315,1,3,315,'نسبت به گذشته، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,315);
INSERT INTO `test_questions` VALUES (316,1,4,316,'نسبت به گذشته، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,316);
INSERT INTO `test_questions` VALUES (317,1,5,317,'نسبت به گذشته، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,317);
INSERT INTO `test_questions` VALUES (318,1,6,318,'نسبت به گذشته، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,318);
INSERT INTO `test_questions` VALUES (319,1,7,319,'نسبت به گذشته، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,319);
INSERT INTO `test_questions` VALUES (320,1,8,320,'به طور کلی در زندگی من، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,320);
INSERT INTO `test_questions` VALUES (321,1,9,321,'به طور کلی در زندگی من، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,321);
INSERT INTO `test_questions` VALUES (322,1,10,322,'به طور کلی در زندگی من، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,322);
INSERT INTO `test_questions` VALUES (323,1,11,323,'به طور کلی در زندگی من، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,323);
INSERT INTO `test_questions` VALUES (324,1,12,324,'به طور کلی در زندگی من، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,324);
INSERT INTO `test_questions` VALUES (325,1,13,325,'به طور کلی در زندگی من، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,325);
INSERT INTO `test_questions` VALUES (326,1,1,326,'به طور کلی در زندگی من، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,326);
INSERT INTO `test_questions` VALUES (327,1,2,327,'به طور کلی در زندگی من، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,327);
INSERT INTO `test_questions` VALUES (328,1,3,328,'به طور کلی در زندگی من، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,328);
INSERT INTO `test_questions` VALUES (329,1,4,329,'به طور کلی در زندگی من، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,329);
INSERT INTO `test_questions` VALUES (330,1,5,330,'به طور کلی در زندگی من، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,330);
INSERT INTO `test_questions` VALUES (331,1,6,331,'به طور کلی در زندگی من، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,331);
INSERT INTO `test_questions` VALUES (332,1,7,332,'به طور کلی در زندگی من، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,332);
INSERT INTO `test_questions` VALUES (333,1,8,333,'به طور کلی در زندگی من، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,333);
INSERT INTO `test_questions` VALUES (334,1,9,334,'به طور کلی در زندگی من، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,334);
INSERT INTO `test_questions` VALUES (335,1,10,335,'به طور کلی در زندگی من، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,335);
INSERT INTO `test_questions` VALUES (336,1,11,336,'به طور کلی در زندگی من، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,336);
INSERT INTO `test_questions` VALUES (337,1,12,337,'به طور کلی در زندگی من، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,337);
INSERT INTO `test_questions` VALUES (338,1,13,338,'به طور کلی در زندگی من، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,338);
INSERT INTO `test_questions` VALUES (339,1,1,339,'به طور کلی در زندگی من، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,339);
INSERT INTO `test_questions` VALUES (340,1,2,340,'به طور کلی در زندگی من، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,340);
INSERT INTO `test_questions` VALUES (341,1,3,341,'به طور کلی در زندگی من، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,341);
INSERT INTO `test_questions` VALUES (342,1,4,342,'به طور کلی در زندگی من، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,342);
INSERT INTO `test_questions` VALUES (343,1,5,343,'به طور کلی در زندگی من، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,343);
INSERT INTO `test_questions` VALUES (344,1,6,344,'به طور کلی در زندگی من، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,344);
INSERT INTO `test_questions` VALUES (345,1,7,345,'به طور کلی در زندگی من، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,345);
INSERT INTO `test_questions` VALUES (346,1,8,346,'به طور کلی در زندگی من، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,346);
INSERT INTO `test_questions` VALUES (347,1,9,347,'به طور کلی در زندگی من، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,347);
INSERT INTO `test_questions` VALUES (348,1,10,348,'به طور کلی در زندگی من، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,348);
INSERT INTO `test_questions` VALUES (349,1,11,349,'به طور کلی در زندگی من، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,349);
INSERT INTO `test_questions` VALUES (350,1,12,350,'به طور کلی در زندگی من، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,350);
INSERT INTO `test_questions` VALUES (351,1,13,351,'به طور کلی در زندگی من، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,351);
INSERT INTO `test_questions` VALUES (352,1,1,352,'به طور کلی در زندگی من، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,352);
INSERT INTO `test_questions` VALUES (353,1,2,353,'به طور کلی در زندگی من، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,353);
INSERT INTO `test_questions` VALUES (354,1,3,354,'به طور کلی در زندگی من، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,354);
INSERT INTO `test_questions` VALUES (355,1,4,355,'به طور کلی در زندگی من، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,355);
INSERT INTO `test_questions` VALUES (356,1,5,356,'به طور کلی در زندگی من، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,356);
INSERT INTO `test_questions` VALUES (357,1,6,357,'به طور کلی در زندگی من، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,357);
INSERT INTO `test_questions` VALUES (358,1,7,358,'به طور کلی در زندگی من، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,358);
INSERT INTO `test_questions` VALUES (359,1,8,359,'به طور کلی در زندگی من، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,359);
INSERT INTO `test_questions` VALUES (360,1,9,360,'در بیشتر موارد صادق است که گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,360);
INSERT INTO `test_questions` VALUES (361,1,10,361,'در بیشتر موارد صادق است که من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,361);
INSERT INTO `test_questions` VALUES (362,1,11,362,'در بیشتر موارد صادق است که اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,362);
INSERT INTO `test_questions` VALUES (363,1,12,363,'در بیشتر موارد صادق است که بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,363);
INSERT INTO `test_questions` VALUES (364,1,13,364,'در بیشتر موارد صادق است که فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,364);
INSERT INTO `test_questions` VALUES (365,1,1,365,'در بیشتر موارد صادق است که با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,365);
INSERT INTO `test_questions` VALUES (366,1,2,366,'در بیشتر موارد صادق است که پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,366);
INSERT INTO `test_questions` VALUES (367,1,3,367,'در بیشتر موارد صادق است که خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,367);
INSERT INTO `test_questions` VALUES (368,1,4,368,'در بیشتر موارد صادق است که دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,368);
INSERT INTO `test_questions` VALUES (369,1,5,369,'در بیشتر موارد صادق است که زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,369);
INSERT INTO `test_questions` VALUES (370,1,6,370,'در بیشتر موارد صادق است که امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,370);
INSERT INTO `test_questions` VALUES (371,1,7,371,'در بیشتر موارد صادق است که بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,371);
INSERT INTO `test_questions` VALUES (372,1,8,372,'در بیشتر موارد صادق است که در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,372);
INSERT INTO `test_questions` VALUES (373,1,9,373,'در بیشتر موارد صادق است که فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,373);
INSERT INTO `test_questions` VALUES (374,1,10,374,'در بیشتر موارد صادق است که من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,374);
INSERT INTO `test_questions` VALUES (375,1,11,375,'در بیشتر موارد صادق است که گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,375);
INSERT INTO `test_questions` VALUES (376,1,12,376,'در بیشتر موارد صادق است که هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,376);
INSERT INTO `test_questions` VALUES (377,1,13,377,'در بیشتر موارد صادق است که برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,377);
INSERT INTO `test_questions` VALUES (378,1,1,378,'در بیشتر موارد صادق است که من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,378);
INSERT INTO `test_questions` VALUES (379,1,2,379,'در بیشتر موارد صادق است که به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,379);
INSERT INTO `test_questions` VALUES (380,1,3,380,'در بیشتر موارد صادق است که اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,380);
INSERT INTO `test_questions` VALUES (381,1,4,381,'در بیشتر موارد صادق است که در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,381);
INSERT INTO `test_questions` VALUES (382,1,5,382,'در بیشتر موارد صادق است که بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,382);
INSERT INTO `test_questions` VALUES (383,1,6,383,'در بیشتر موارد صادق است که گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,383);
INSERT INTO `test_questions` VALUES (384,1,7,384,'در بیشتر موارد صادق است که ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,384);
INSERT INTO `test_questions` VALUES (385,1,8,385,'در بیشتر موارد صادق است که به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,385);
INSERT INTO `test_questions` VALUES (386,1,9,386,'در بیشتر موارد صادق است که بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,386);
INSERT INTO `test_questions` VALUES (387,1,10,387,'در بیشتر موارد صادق است که اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,387);
INSERT INTO `test_questions` VALUES (388,1,11,388,'در بیشتر موارد صادق است که حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,388);
INSERT INTO `test_questions` VALUES (389,1,12,389,'در بیشتر موارد صادق است که اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,389);
INSERT INTO `test_questions` VALUES (390,1,13,390,'در بیشتر موارد صادق است که ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,390);
INSERT INTO `test_questions` VALUES (391,1,1,391,'در بیشتر موارد صادق است که گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,391);
INSERT INTO `test_questions` VALUES (392,1,2,392,'در بیشتر موارد صادق است که معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,392);
INSERT INTO `test_questions` VALUES (393,1,3,393,'در بیشتر موارد صادق است که من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,393);
INSERT INTO `test_questions` VALUES (394,1,4,394,'در بیشتر موارد صادق است که دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,394);
INSERT INTO `test_questions` VALUES (395,1,5,395,'در بیشتر موارد صادق است که بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,395);
INSERT INTO `test_questions` VALUES (396,1,6,396,'در بیشتر موارد صادق است که گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,396);
INSERT INTO `test_questions` VALUES (397,1,7,397,'در بیشتر موارد صادق است که من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,397);
INSERT INTO `test_questions` VALUES (398,1,8,398,'در بیشتر موارد صادق است که معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,398);
INSERT INTO `test_questions` VALUES (399,1,9,399,'در بیشتر موارد صادق است که دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,399);
INSERT INTO `test_questions` VALUES (400,1,10,400,'در موقعیت‌های روزمره، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,400);
INSERT INTO `test_questions` VALUES (401,1,11,401,'در موقعیت‌های روزمره، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,401);
INSERT INTO `test_questions` VALUES (402,1,12,402,'در موقعیت‌های روزمره، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,402);
INSERT INTO `test_questions` VALUES (403,1,13,403,'در موقعیت‌های روزمره، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,403);
INSERT INTO `test_questions` VALUES (404,1,1,404,'در موقعیت‌های روزمره، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,404);
INSERT INTO `test_questions` VALUES (405,1,2,405,'در موقعیت‌های روزمره، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,405);
INSERT INTO `test_questions` VALUES (406,1,3,406,'در موقعیت‌های روزمره، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,406);
INSERT INTO `test_questions` VALUES (407,1,4,407,'در موقعیت‌های روزمره، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,407);
INSERT INTO `test_questions` VALUES (408,1,5,408,'در موقعیت‌های روزمره، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,408);
INSERT INTO `test_questions` VALUES (409,1,6,409,'در موقعیت‌های روزمره، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,409);
INSERT INTO `test_questions` VALUES (410,1,7,410,'در موقعیت‌های روزمره، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,410);
INSERT INTO `test_questions` VALUES (411,1,8,411,'در موقعیت‌های روزمره، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,411);
INSERT INTO `test_questions` VALUES (412,1,9,412,'در موقعیت‌های روزمره، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,412);
INSERT INTO `test_questions` VALUES (413,1,10,413,'در موقعیت‌های روزمره، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,413);
INSERT INTO `test_questions` VALUES (414,1,11,414,'در موقعیت‌های روزمره، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,414);
INSERT INTO `test_questions` VALUES (415,1,12,415,'در موقعیت‌های روزمره، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,415);
INSERT INTO `test_questions` VALUES (416,1,13,416,'در موقعیت‌های روزمره، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,416);
INSERT INTO `test_questions` VALUES (417,1,1,417,'در موقعیت‌های روزمره، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,417);
INSERT INTO `test_questions` VALUES (418,1,2,418,'در موقعیت‌های روزمره، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,418);
INSERT INTO `test_questions` VALUES (419,1,3,419,'در موقعیت‌های روزمره، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,419);
INSERT INTO `test_questions` VALUES (420,1,4,420,'در موقعیت‌های روزمره، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,420);
INSERT INTO `test_questions` VALUES (421,1,5,421,'در موقعیت‌های روزمره، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,421);
INSERT INTO `test_questions` VALUES (422,1,6,422,'در موقعیت‌های روزمره، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,422);
INSERT INTO `test_questions` VALUES (423,1,7,423,'در موقعیت‌های روزمره، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,423);
INSERT INTO `test_questions` VALUES (424,1,8,424,'در موقعیت‌های روزمره، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,424);
INSERT INTO `test_questions` VALUES (425,1,9,425,'در موقعیت‌های روزمره، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,425);
INSERT INTO `test_questions` VALUES (426,1,10,426,'در موقعیت‌های روزمره، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,426);
INSERT INTO `test_questions` VALUES (427,1,11,427,'در موقعیت‌های روزمره، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,427);
INSERT INTO `test_questions` VALUES (428,1,12,428,'در موقعیت‌های روزمره، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,428);
INSERT INTO `test_questions` VALUES (429,1,13,429,'در موقعیت‌های روزمره، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,429);
INSERT INTO `test_questions` VALUES (430,1,1,430,'در موقعیت‌های روزمره، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,430);
INSERT INTO `test_questions` VALUES (431,1,2,431,'در موقعیت‌های روزمره، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,431);
INSERT INTO `test_questions` VALUES (432,1,3,432,'در موقعیت‌های روزمره، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,432);
INSERT INTO `test_questions` VALUES (433,1,4,433,'در موقعیت‌های روزمره، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,433);
INSERT INTO `test_questions` VALUES (434,1,5,434,'در موقعیت‌های روزمره، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,434);
INSERT INTO `test_questions` VALUES (435,1,6,435,'در موقعیت‌های روزمره، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,435);
INSERT INTO `test_questions` VALUES (436,1,7,436,'در موقعیت‌های روزمره، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,436);
INSERT INTO `test_questions` VALUES (437,1,8,437,'در موقعیت‌های روزمره، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,437);
INSERT INTO `test_questions` VALUES (438,1,9,438,'در موقعیت‌های روزمره، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,438);
INSERT INTO `test_questions` VALUES (439,1,10,439,'در موقعیت‌های روزمره، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,439);
INSERT INTO `test_questions` VALUES (440,1,11,440,'اغلب اوقات تجربه کرده‌ام که گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,440);
INSERT INTO `test_questions` VALUES (441,1,12,441,'اغلب اوقات تجربه کرده‌ام که من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,441);
INSERT INTO `test_questions` VALUES (442,1,13,442,'اغلب اوقات تجربه کرده‌ام که اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,442);
INSERT INTO `test_questions` VALUES (443,1,1,443,'اغلب اوقات تجربه کرده‌ام که بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,443);
INSERT INTO `test_questions` VALUES (444,1,2,444,'اغلب اوقات تجربه کرده‌ام که فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,444);
INSERT INTO `test_questions` VALUES (445,1,3,445,'اغلب اوقات تجربه کرده‌ام که با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,445);
INSERT INTO `test_questions` VALUES (446,1,4,446,'اغلب اوقات تجربه کرده‌ام که پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,446);
INSERT INTO `test_questions` VALUES (447,1,5,447,'اغلب اوقات تجربه کرده‌ام که خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,447);
INSERT INTO `test_questions` VALUES (448,1,6,448,'اغلب اوقات تجربه کرده‌ام که دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,448);
INSERT INTO `test_questions` VALUES (449,1,7,449,'اغلب اوقات تجربه کرده‌ام که زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,449);
INSERT INTO `test_questions` VALUES (450,1,8,450,'اغلب اوقات تجربه کرده‌ام که امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,450);
INSERT INTO `test_questions` VALUES (451,1,9,451,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,451);
INSERT INTO `test_questions` VALUES (452,1,10,452,'اغلب اوقات تجربه کرده‌ام که در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,452);
INSERT INTO `test_questions` VALUES (453,1,11,453,'اغلب اوقات تجربه کرده‌ام که فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,453);
INSERT INTO `test_questions` VALUES (454,1,12,454,'اغلب اوقات تجربه کرده‌ام که من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,454);
INSERT INTO `test_questions` VALUES (455,1,13,455,'اغلب اوقات تجربه کرده‌ام که گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,455);
INSERT INTO `test_questions` VALUES (456,1,1,456,'اغلب اوقات تجربه کرده‌ام که هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,456);
INSERT INTO `test_questions` VALUES (457,1,2,457,'اغلب اوقات تجربه کرده‌ام که برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,457);
INSERT INTO `test_questions` VALUES (458,1,3,458,'اغلب اوقات تجربه کرده‌ام که من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,458);
INSERT INTO `test_questions` VALUES (459,1,4,459,'اغلب اوقات تجربه کرده‌ام که به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,459);
INSERT INTO `test_questions` VALUES (460,1,5,460,'اغلب اوقات تجربه کرده‌ام که اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,460);
INSERT INTO `test_questions` VALUES (461,1,6,461,'اغلب اوقات تجربه کرده‌ام که در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,461);
INSERT INTO `test_questions` VALUES (462,1,7,462,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,462);
INSERT INTO `test_questions` VALUES (463,1,8,463,'اغلب اوقات تجربه کرده‌ام که گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,463);
INSERT INTO `test_questions` VALUES (464,1,9,464,'اغلب اوقات تجربه کرده‌ام که ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,464);
INSERT INTO `test_questions` VALUES (465,1,10,465,'اغلب اوقات تجربه کرده‌ام که به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,465);
INSERT INTO `test_questions` VALUES (466,1,11,466,'اغلب اوقات تجربه کرده‌ام که بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,466);
INSERT INTO `test_questions` VALUES (467,1,12,467,'اغلب اوقات تجربه کرده‌ام که اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,467);
INSERT INTO `test_questions` VALUES (468,1,13,468,'اغلب اوقات تجربه کرده‌ام که حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,468);
INSERT INTO `test_questions` VALUES (469,1,1,469,'اغلب اوقات تجربه کرده‌ام که اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,469);
INSERT INTO `test_questions` VALUES (470,1,2,470,'اغلب اوقات تجربه کرده‌ام که ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,470);
INSERT INTO `test_questions` VALUES (471,1,3,471,'اغلب اوقات تجربه کرده‌ام که گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,471);
INSERT INTO `test_questions` VALUES (472,1,4,472,'اغلب اوقات تجربه کرده‌ام که معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,472);
INSERT INTO `test_questions` VALUES (473,1,5,473,'اغلب اوقات تجربه کرده‌ام که من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,473);
INSERT INTO `test_questions` VALUES (474,1,6,474,'اغلب اوقات تجربه کرده‌ام که دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,474);
INSERT INTO `test_questions` VALUES (475,1,7,475,'اغلب اوقات تجربه کرده‌ام که بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,475);
INSERT INTO `test_questions` VALUES (476,1,8,476,'اغلب اوقات تجربه کرده‌ام که گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,476);
INSERT INTO `test_questions` VALUES (477,1,9,477,'اغلب اوقات تجربه کرده‌ام که من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,477);
INSERT INTO `test_questions` VALUES (478,1,10,478,'اغلب اوقات تجربه کرده‌ام که معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,478);
INSERT INTO `test_questions` VALUES (479,1,11,479,'اغلب اوقات تجربه کرده‌ام که دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,479);
INSERT INTO `test_questions` VALUES (480,1,12,480,'نسبت به گذشته، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,480);
INSERT INTO `test_questions` VALUES (481,1,13,481,'نسبت به گذشته، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,481);
INSERT INTO `test_questions` VALUES (482,1,1,482,'نسبت به گذشته، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,482);
INSERT INTO `test_questions` VALUES (483,1,2,483,'نسبت به گذشته، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,483);
INSERT INTO `test_questions` VALUES (484,1,3,484,'نسبت به گذشته، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,484);
INSERT INTO `test_questions` VALUES (485,1,4,485,'نسبت به گذشته، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,485);
INSERT INTO `test_questions` VALUES (486,1,5,486,'نسبت به گذشته، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,486);
INSERT INTO `test_questions` VALUES (487,1,6,487,'نسبت به گذشته، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,487);
INSERT INTO `test_questions` VALUES (488,1,7,488,'نسبت به گذشته، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,488);
INSERT INTO `test_questions` VALUES (489,1,8,489,'نسبت به گذشته، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,489);
INSERT INTO `test_questions` VALUES (490,1,9,490,'نسبت به گذشته، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,490);
INSERT INTO `test_questions` VALUES (491,1,10,491,'نسبت به گذشته، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,491);
INSERT INTO `test_questions` VALUES (492,1,11,492,'نسبت به گذشته، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,492);
INSERT INTO `test_questions` VALUES (493,1,12,493,'نسبت به گذشته، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,493);
INSERT INTO `test_questions` VALUES (494,1,13,494,'نسبت به گذشته، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,494);
INSERT INTO `test_questions` VALUES (495,1,1,495,'نسبت به گذشته، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,495);
INSERT INTO `test_questions` VALUES (496,1,2,496,'نسبت به گذشته، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,496);
INSERT INTO `test_questions` VALUES (497,1,3,497,'نسبت به گذشته، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,497);
INSERT INTO `test_questions` VALUES (498,1,4,498,'نسبت به گذشته، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,498);
INSERT INTO `test_questions` VALUES (499,1,5,499,'نسبت به گذشته، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,499);
INSERT INTO `test_questions` VALUES (500,1,6,500,'نسبت به گذشته، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,500);
INSERT INTO `test_questions` VALUES (501,1,7,501,'نسبت به گذشته، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,501);
INSERT INTO `test_questions` VALUES (502,1,8,502,'نسبت به گذشته، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,502);
INSERT INTO `test_questions` VALUES (503,1,9,503,'نسبت به گذشته، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,503);
INSERT INTO `test_questions` VALUES (504,1,10,504,'نسبت به گذشته، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,504);
INSERT INTO `test_questions` VALUES (505,1,11,505,'نسبت به گذشته، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,505);
INSERT INTO `test_questions` VALUES (506,1,12,506,'نسبت به گذشته، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,506);
INSERT INTO `test_questions` VALUES (507,1,13,507,'نسبت به گذشته، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,507);
INSERT INTO `test_questions` VALUES (508,1,1,508,'نسبت به گذشته، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,508);
INSERT INTO `test_questions` VALUES (509,1,2,509,'نسبت به گذشته، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,509);
INSERT INTO `test_questions` VALUES (510,1,3,510,'نسبت به گذشته، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,510);
INSERT INTO `test_questions` VALUES (511,1,4,511,'نسبت به گذشته، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,511);
INSERT INTO `test_questions` VALUES (512,1,5,512,'نسبت به گذشته، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,512);
INSERT INTO `test_questions` VALUES (513,1,6,513,'نسبت به گذشته، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,513);
INSERT INTO `test_questions` VALUES (514,1,7,514,'نسبت به گذشته، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,514);
INSERT INTO `test_questions` VALUES (515,1,8,515,'نسبت به گذشته، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,515);
INSERT INTO `test_questions` VALUES (516,1,9,516,'نسبت به گذشته، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,516);
INSERT INTO `test_questions` VALUES (517,1,10,517,'نسبت به گذشته، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,517);
INSERT INTO `test_questions` VALUES (518,1,11,518,'نسبت به گذشته، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,518);
INSERT INTO `test_questions` VALUES (519,1,12,519,'نسبت به گذشته، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,519);
INSERT INTO `test_questions` VALUES (520,1,13,520,'به طور کلی در زندگی من، گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,520);
INSERT INTO `test_questions` VALUES (521,1,1,521,'به طور کلی در زندگی من، من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,521);
INSERT INTO `test_questions` VALUES (522,1,2,522,'به طور کلی در زندگی من، اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,522);
INSERT INTO `test_questions` VALUES (523,1,3,523,'به طور کلی در زندگی من، بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,523);
INSERT INTO `test_questions` VALUES (524,1,4,524,'به طور کلی در زندگی من، فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,524);
INSERT INTO `test_questions` VALUES (525,1,5,525,'به طور کلی در زندگی من، با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,525);
INSERT INTO `test_questions` VALUES (526,1,6,526,'به طور کلی در زندگی من، پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,526);
INSERT INTO `test_questions` VALUES (527,1,7,527,'به طور کلی در زندگی من، خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,527);
INSERT INTO `test_questions` VALUES (528,1,8,528,'به طور کلی در زندگی من، دست‌ها و پاهایم معمولاً به اندازه کافی گرم هستند.',0,NULL,528);
INSERT INTO `test_questions` VALUES (529,1,9,529,'به طور کلی در زندگی من، زندگی روزانه من پر از چیزهایی است که برایم جذاب و لذت‌بخش‌اند.',0,NULL,529);
INSERT INTO `test_questions` VALUES (530,1,10,530,'به طور کلی در زندگی من، امروز به همان اندازه گذشته توانایی کار کردن دارم.',0,NULL,530);
INSERT INTO `test_questions` VALUES (531,1,11,531,'به طور کلی در زندگی من، بیشتر اوقات گلوله‌ای در گلو یا احساس خفگی در سینه‌ام احساس می‌کنم.',0,NULL,531);
INSERT INTO `test_questions` VALUES (532,1,12,532,'به طور کلی در زندگی من، در زمینه روابط جنسی تا کنون با مشکلی مواجه نبوده‌ام.',0,NULL,532);
INSERT INTO `test_questions` VALUES (533,1,13,533,'به طور کلی در زندگی من، فکر می‌کنم دیگران قدر زحمات و کارهای مرا نمی‌دانند.',0,NULL,533);
INSERT INTO `test_questions` VALUES (534,1,1,534,'به طور کلی در زندگی من، من معمولاً دردهای شدید معده یا سوزش سردل را تجربه می‌کنم.',0,NULL,534);
INSERT INTO `test_questions` VALUES (535,1,2,535,'به طور کلی در زندگی من، گاهی دلم می‌خواهد از ته دل ناسزا بگویم یا فریاد بزنم.',0,NULL,535);
INSERT INTO `test_questions` VALUES (536,1,3,536,'به طور کلی در زندگی من، هر چند شب یک‌بار خواب‌های بسیار وحشتناک و آشفته می‌بینم.',0,NULL,536);
INSERT INTO `test_questions` VALUES (537,1,4,537,'به طور کلی در زندگی من، برایم دشوار است که حواسم را روی یک موضوع ثابت متمرکز کنم.',0,NULL,537);
INSERT INTO `test_questions` VALUES (538,1,5,538,'به طور کلی در زندگی من، من تجربه‌های حسی و روحی بسیار مخصوص و عجیبی داشته‌ام.',0,NULL,538);
INSERT INTO `test_questions` VALUES (539,1,6,539,'به طور کلی در زندگی من، به ندرت دچار سرگیجه یا از دست دادن تعادل می‌شوم.',0,NULL,539);
INSERT INTO `test_questions` VALUES (540,1,7,540,'به طور کلی در زندگی من، اگر دیگران مانع من نشده بودند، در زندگی موفقیت‌های چشمگیرتری داشتم.',0,NULL,540);
INSERT INTO `test_questions` VALUES (541,1,8,541,'به طور کلی در زندگی من، در دوران نوجوانی مرتکب خلاف‌ها یا دزدی‌های کوچکی شده‌ام.',0,NULL,541);
INSERT INTO `test_questions` VALUES (542,1,9,542,'به طور کلی در زندگی من، بیشتر اوقات گلویم خشک است یا احساس تشنگی مفرط می‌کنم.',0,NULL,542);
INSERT INTO `test_questions` VALUES (543,1,10,543,'به طور کلی در زندگی من، گاهی به قدری عصبانی می‌شوم که کنترل رفتارم را از دست می‌دهم.',0,NULL,543);
INSERT INTO `test_questions` VALUES (544,1,11,544,'به طور کلی در زندگی من، ای کاش به اندازه اطرافیانم احساس شادی و آرامش داشتم.',0,NULL,544);
INSERT INTO `test_questions` VALUES (545,1,12,545,'به طور کلی در زندگی من، به ندرت احساس تنگی نفس یا احساس خفگی ناگهانی به من دست می‌دهد.',0,NULL,545);
INSERT INTO `test_questions` VALUES (546,1,13,546,'به طور کلی در زندگی من، بارها در زندگی احساس کرده‌ام کارهایی انجام داده‌ام که چرایش را نمی‌دانم.',0,NULL,546);
INSERT INTO `test_questions` VALUES (547,1,1,547,'به طور کلی در زندگی من، اغلب مجبور شده‌ام از کسانی دستور بگیرم که کمتر از من می‌فهمیدند.',0,NULL,547);
INSERT INTO `test_questions` VALUES (548,1,2,548,'به طور کلی در زندگی من، حالم به ندرت بهتر از وضع فعلی بوده است.',0,NULL,548);
INSERT INTO `test_questions` VALUES (549,1,3,549,'به طور کلی در زندگی من، اکثر مردم برای رسیدن به اهدافشان حاضرند از راه‌های ناعادلانه استفاده کنند.',0,NULL,549);
INSERT INTO `test_questions` VALUES (550,1,4,550,'به طور کلی در زندگی من، ناراحتی‌ها و دردهای گوارشی خیلی مرا اذیت می‌کند.',0,NULL,550);
INSERT INTO `test_questions` VALUES (551,1,5,551,'به طور کلی در زندگی من، گاهی اوقات افکارم چنان سریع حرکت می‌کنند که نمی‌توانم بیانشان کنم.',0,NULL,551);
INSERT INTO `test_questions` VALUES (552,1,6,552,'به طور کلی در زندگی من، معتقدم بر ضد من در خفا نقشه کشیده می‌شود.',0,NULL,552);
INSERT INTO `test_questions` VALUES (553,1,7,553,'به طور کلی در زندگی من، من فردی بسیار حساس هستم و زودرنج‌تر از دیگرانم.',0,NULL,553);
INSERT INTO `test_questions` VALUES (554,1,8,554,'به طور کلی در زندگی من، دیدن خون یا زخم‌های عمیق حالم را دگرگون می‌کند.',0,NULL,554);
INSERT INTO `test_questions` VALUES (555,1,9,555,'به طور کلی در زندگی من، بیشتر اوقات احساس ضعف، خستگی و افت انرژی شدید در کل بدنم دارم.',0,NULL,555);
INSERT INTO `test_questions` VALUES (556,1,10,556,'به طور کلی در زندگی من، گاهی احساس می‌کنم صداهایی می‌شنوم که دیگران قادر به شنیدن آن نیستند.',0,NULL,556);
INSERT INTO `test_questions` VALUES (557,1,11,557,'به طور کلی در زندگی من، من به ندرت احساس خجالت یا کم‌رویی در جمع پیدا می‌کنم.',0,NULL,557);
INSERT INTO `test_questions` VALUES (558,1,12,558,'به طور کلی در زندگی من، معتقدم خطاهایی در گذشته مرتکب شده‌ام که بخشودنی نیستند.',0,NULL,558);
INSERT INTO `test_questions` VALUES (559,1,13,559,'به طور کلی در زندگی من، دوستان و معاشران من غالباً مورد پسند پدر و مادرم نبوده‌اند.',0,NULL,559);
INSERT INTO `test_questions` VALUES (560,1,1,560,'در بیشتر موارد صادق است که گاهی آن‌قدر بی‌قرار می‌شوم که نمی‌توانم روی یک صندلی آرام بگیرم.',0,NULL,560);
INSERT INTO `test_questions` VALUES (561,1,2,561,'در بیشتر موارد صادق است که من مجله‌های فنی یا علمی را دوست دارم.',0,NULL,561);
INSERT INTO `test_questions` VALUES (562,1,3,562,'در بیشتر موارد صادق است که اشتهای خوبی دارم و غذا خوردنم مشکلی ندارد.',0,NULL,562);
INSERT INTO `test_questions` VALUES (563,1,4,563,'در بیشتر موارد صادق است که بیشتر صبح‌ها خوش و سرحال از خواب بیدار می‌شوم.',0,NULL,563);
INSERT INTO `test_questions` VALUES (564,1,5,564,'در بیشتر موارد صادق است که فکر می‌کنم کار کتابداری یا کارهای دفتری منظم را دوست داشته باشم.',0,NULL,564);
INSERT INTO `test_questions` VALUES (565,1,6,565,'در بیشتر موارد صادق است که با کوچک‌ترین صدایی در طول شب از خواب بیدار می‌شوم.',0,NULL,565);
INSERT INTO `test_questions` VALUES (566,1,7,566,'در بیشتر موارد صادق است که پدرم مرد خوبی است (یا اگر فوت کرده، مرد خوبی بود).',0,NULL,566);
INSERT INTO `test_questions` VALUES (567,1,8,567,'در بیشتر موارد صادق است که خواندن بخش حوادث روزنامه‌ها و اخبار جنایی برایم جالب است.',0,NULL,567);
INSERT INTO `test_questions` VALUES (568,2,14,1,'من در زندگی اغلب ویژگی‌های مربوط به اضطراب را به وضوح نشان می‌دهم.',0,NULL,1);
INSERT INTO `test_questions` VALUES (569,2,15,2,'من در زندگی اغلب ویژگی‌های مربوط به خشم و خصومت را به وضوح نشان می‌دهم.',0,NULL,2);
INSERT INTO `test_questions` VALUES (570,2,16,3,'من در زندگی اغلب ویژگی‌های مربوط به افسردگی را به وضوح نشان می‌دهم.',0,NULL,3);
INSERT INTO `test_questions` VALUES (571,2,17,4,'من در زندگی اغلب ویژگی‌های مربوط به شرم و خودناباوری را به وضوح نشان می‌دهم.',0,NULL,4);
INSERT INTO `test_questions` VALUES (572,2,18,5,'من در زندگی اغلب ویژگی‌های مربوط به تکانشگری را به وضوح نشان می‌دهم.',0,NULL,5);
INSERT INTO `test_questions` VALUES (573,2,19,6,'من در زندگی اغلب ویژگی‌های مربوط به آسیب‌پذیری به استرس را به وضوح نشان می‌دهم.',0,NULL,6);
INSERT INTO `test_questions` VALUES (574,2,20,7,'من در زندگی اغلب ویژگی‌های مربوط به صمیمیت و مهرورزی را به وضوح نشان می‌دهم.',0,NULL,7);
INSERT INTO `test_questions` VALUES (575,2,21,8,'من در زندگی اغلب ویژگی‌های مربوط به جمع‌گرایی را به وضوح نشان می‌دهم.',0,NULL,8);
INSERT INTO `test_questions` VALUES (576,2,22,9,'من در زندگی اغلب ویژگی‌های مربوط به قاطعیت و جسارت را به وضوح نشان می‌دهم.',0,NULL,9);
INSERT INTO `test_questions` VALUES (577,2,23,10,'من در زندگی اغلب ویژگی‌های مربوط به فعالیت و پویایی را به وضوح نشان می‌دهم.',0,NULL,10);
INSERT INTO `test_questions` VALUES (578,2,24,11,'من در زندگی اغلب ویژگی‌های مربوط به هیجان‌خواهی را به وضوح نشان می‌دهم.',0,NULL,11);
INSERT INTO `test_questions` VALUES (579,2,25,12,'من در زندگی اغلب ویژگی‌های مربوط به هیجانات مثبت و شادمانی را به وضوح نشان می‌دهم.',0,NULL,12);
INSERT INTO `test_questions` VALUES (580,2,26,13,'من در زندگی اغلب ویژگی‌های مربوط به تخیل و فانتزی را به وضوح نشان می‌دهم.',0,NULL,13);
INSERT INTO `test_questions` VALUES (581,2,27,14,'من در زندگی اغلب ویژگی‌های مربوط به زیبایی‌خواهی را به وضوح نشان می‌دهم.',0,NULL,14);
INSERT INTO `test_questions` VALUES (582,2,28,15,'من در زندگی اغلب ویژگی‌های مربوط به احساسات و عواطف را به وضوح نشان می‌دهم.',0,NULL,15);
INSERT INTO `test_questions` VALUES (583,2,29,16,'من در زندگی اغلب ویژگی‌های مربوط به اعمال و تجارب نو را به وضوح نشان می‌دهم.',0,NULL,16);
INSERT INTO `test_questions` VALUES (584,2,30,17,'من در زندگی اغلب ویژگی‌های مربوط به ایده‌ها و کنجکاوی فکری را به وضوح نشان می‌دهم.',0,NULL,17);
INSERT INTO `test_questions` VALUES (585,2,31,18,'من در زندگی اغلب ویژگی‌های مربوط به ارزش‌ها و دگراندیشی را به وضوح نشان می‌دهم.',0,NULL,18);
INSERT INTO `test_questions` VALUES (586,2,32,19,'من در زندگی اغلب ویژگی‌های مربوط به اعتماد به دیگران را به وضوح نشان می‌دهم.',0,NULL,19);
INSERT INTO `test_questions` VALUES (587,2,33,20,'من در زندگی اغلب ویژگی‌های مربوط به رک‌گویی و صداقت را به وضوح نشان می‌دهم.',0,NULL,20);
INSERT INTO `test_questions` VALUES (588,2,34,21,'من در زندگی اغلب ویژگی‌های مربوط به نوع‌دوستی را به وضوح نشان می‌دهم.',0,NULL,21);
INSERT INTO `test_questions` VALUES (589,2,35,22,'من در زندگی اغلب ویژگی‌های مربوط به همراهی و توافق‌پذیری را به وضوح نشان می‌دهم.',0,NULL,22);
INSERT INTO `test_questions` VALUES (590,2,36,23,'من در زندگی اغلب ویژگی‌های مربوط به تواضع و فروتنی را به وضوح نشان می‌دهم.',0,NULL,23);
INSERT INTO `test_questions` VALUES (591,2,37,24,'من در زندگی اغلب ویژگی‌های مربوط به دل‌رحمی و همدلی را به وضوح نشان می‌دهم.',0,NULL,24);
INSERT INTO `test_questions` VALUES (592,2,38,25,'من در زندگی اغلب ویژگی‌های مربوط به احساس شایستگی را به وضوح نشان می‌دهم.',0,NULL,25);
INSERT INTO `test_questions` VALUES (593,2,39,26,'من در زندگی اغلب ویژگی‌های مربوط به نظم و ترتیب را به وضوح نشان می‌دهم.',0,NULL,26);
INSERT INTO `test_questions` VALUES (594,2,40,27,'من در زندگی اغلب ویژگی‌های مربوط به وظیفه‌شناسی و وجدان را به وضوح نشان می‌دهم.',0,NULL,27);
INSERT INTO `test_questions` VALUES (595,2,41,28,'من در زندگی اغلب ویژگی‌های مربوط به تلاش برای موفقیت را به وضوح نشان می‌دهم.',0,NULL,28);
INSERT INTO `test_questions` VALUES (596,2,42,29,'من در زندگی اغلب ویژگی‌های مربوط به خودانضباطی را به وضوح نشان می‌دهم.',0,NULL,29);
INSERT INTO `test_questions` VALUES (597,2,43,30,'من در زندگی اغلب ویژگی‌های مربوط به تدبیر و احتیاط را به وضوح نشان می‌دهم.',0,NULL,30);
INSERT INTO `test_questions` VALUES (598,2,14,31,'اطرافیان مرا به عنوان فردی که در زمینه اضطراب برجسته است می‌شناسند.',1,NULL,31);
INSERT INTO `test_questions` VALUES (599,2,15,32,'اطرافیان مرا به عنوان فردی که در زمینه خشم و خصومت برجسته است می‌شناسند.',1,NULL,32);
INSERT INTO `test_questions` VALUES (600,2,16,33,'اطرافیان مرا به عنوان فردی که در زمینه افسردگی برجسته است می‌شناسند.',1,NULL,33);
INSERT INTO `test_questions` VALUES (601,2,17,34,'اطرافیان مرا به عنوان فردی که در زمینه شرم و خودناباوری برجسته است می‌شناسند.',1,NULL,34);
INSERT INTO `test_questions` VALUES (602,2,18,35,'اطرافیان مرا به عنوان فردی که در زمینه تکانشگری برجسته است می‌شناسند.',1,NULL,35);
INSERT INTO `test_questions` VALUES (603,2,19,36,'اطرافیان مرا به عنوان فردی که در زمینه آسیب‌پذیری به استرس برجسته است می‌شناسند.',1,NULL,36);
INSERT INTO `test_questions` VALUES (604,2,20,37,'اطرافیان مرا به عنوان فردی که در زمینه صمیمیت و مهرورزی برجسته است می‌شناسند.',1,NULL,37);
INSERT INTO `test_questions` VALUES (605,2,21,38,'اطرافیان مرا به عنوان فردی که در زمینه جمع‌گرایی برجسته است می‌شناسند.',1,NULL,38);
INSERT INTO `test_questions` VALUES (606,2,22,39,'اطرافیان مرا به عنوان فردی که در زمینه قاطعیت و جسارت برجسته است می‌شناسند.',1,NULL,39);
INSERT INTO `test_questions` VALUES (607,2,23,40,'اطرافیان مرا به عنوان فردی که در زمینه فعالیت و پویایی برجسته است می‌شناسند.',1,NULL,40);
INSERT INTO `test_questions` VALUES (608,2,24,41,'اطرافیان مرا به عنوان فردی که در زمینه هیجان‌خواهی برجسته است می‌شناسند.',1,NULL,41);
INSERT INTO `test_questions` VALUES (609,2,25,42,'اطرافیان مرا به عنوان فردی که در زمینه هیجانات مثبت و شادمانی برجسته است می‌شناسند.',1,NULL,42);
INSERT INTO `test_questions` VALUES (610,2,26,43,'اطرافیان مرا به عنوان فردی که در زمینه تخیل و فانتزی برجسته است می‌شناسند.',1,NULL,43);
INSERT INTO `test_questions` VALUES (611,2,27,44,'اطرافیان مرا به عنوان فردی که در زمینه زیبایی‌خواهی برجسته است می‌شناسند.',1,NULL,44);
INSERT INTO `test_questions` VALUES (612,2,28,45,'اطرافیان مرا به عنوان فردی که در زمینه احساسات و عواطف برجسته است می‌شناسند.',1,NULL,45);
INSERT INTO `test_questions` VALUES (613,2,29,46,'اطرافیان مرا به عنوان فردی که در زمینه اعمال و تجارب نو برجسته است می‌شناسند.',1,NULL,46);
INSERT INTO `test_questions` VALUES (614,2,30,47,'اطرافیان مرا به عنوان فردی که در زمینه ایده‌ها و کنجکاوی فکری برجسته است می‌شناسند.',1,NULL,47);
INSERT INTO `test_questions` VALUES (615,2,31,48,'اطرافیان مرا به عنوان فردی که در زمینه ارزش‌ها و دگراندیشی برجسته است می‌شناسند.',1,NULL,48);
INSERT INTO `test_questions` VALUES (616,2,32,49,'اطرافیان مرا به عنوان فردی که در زمینه اعتماد به دیگران برجسته است می‌شناسند.',1,NULL,49);
INSERT INTO `test_questions` VALUES (617,2,33,50,'اطرافیان مرا به عنوان فردی که در زمینه رک‌گویی و صداقت برجسته است می‌شناسند.',1,NULL,50);
INSERT INTO `test_questions` VALUES (618,2,34,51,'اطرافیان مرا به عنوان فردی که در زمینه نوع‌دوستی برجسته است می‌شناسند.',1,NULL,51);
INSERT INTO `test_questions` VALUES (619,2,35,52,'اطرافیان مرا به عنوان فردی که در زمینه همراهی و توافق‌پذیری برجسته است می‌شناسند.',1,NULL,52);
INSERT INTO `test_questions` VALUES (620,2,36,53,'اطرافیان مرا به عنوان فردی که در زمینه تواضع و فروتنی برجسته است می‌شناسند.',1,NULL,53);
INSERT INTO `test_questions` VALUES (621,2,37,54,'اطرافیان مرا به عنوان فردی که در زمینه دل‌رحمی و همدلی برجسته است می‌شناسند.',1,NULL,54);
INSERT INTO `test_questions` VALUES (622,2,38,55,'اطرافیان مرا به عنوان فردی که در زمینه احساس شایستگی برجسته است می‌شناسند.',1,NULL,55);
INSERT INTO `test_questions` VALUES (623,2,39,56,'اطرافیان مرا به عنوان فردی که در زمینه نظم و ترتیب برجسته است می‌شناسند.',1,NULL,56);
INSERT INTO `test_questions` VALUES (624,2,40,57,'اطرافیان مرا به عنوان فردی که در زمینه وظیفه‌شناسی و وجدان برجسته است می‌شناسند.',1,NULL,57);
INSERT INTO `test_questions` VALUES (625,2,41,58,'اطرافیان مرا به عنوان فردی که در زمینه تلاش برای موفقیت برجسته است می‌شناسند.',1,NULL,58);
INSERT INTO `test_questions` VALUES (626,2,42,59,'اطرافیان مرا به عنوان فردی که در زمینه خودانضباطی برجسته است می‌شناسند.',1,NULL,59);
INSERT INTO `test_questions` VALUES (627,2,43,60,'اطرافیان مرا به عنوان فردی که در زمینه تدبیر و احتیاط برجسته است می‌شناسند.',1,NULL,60);
INSERT INTO `test_questions` VALUES (628,2,14,61,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول اضطراب واکنش نشان دهم.',0,NULL,61);
INSERT INTO `test_questions` VALUES (629,2,15,62,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول خشم و خصومت واکنش نشان دهم.',0,NULL,62);
INSERT INTO `test_questions` VALUES (630,2,16,63,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول افسردگی واکنش نشان دهم.',0,NULL,63);
INSERT INTO `test_questions` VALUES (631,2,17,64,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول شرم و خودناباوری واکنش نشان دهم.',0,NULL,64);
INSERT INTO `test_questions` VALUES (632,2,18,65,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول تکانشگری واکنش نشان دهم.',0,NULL,65);
INSERT INTO `test_questions` VALUES (633,2,19,66,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول آسیب‌پذیری به استرس واکنش نشان دهم.',0,NULL,66);
INSERT INTO `test_questions` VALUES (634,2,20,67,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول صمیمیت و مهرورزی واکنش نشان دهم.',0,NULL,67);
INSERT INTO `test_questions` VALUES (635,2,21,68,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول جمع‌گرایی واکنش نشان دهم.',0,NULL,68);
INSERT INTO `test_questions` VALUES (636,2,22,69,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول قاطعیت و جسارت واکنش نشان دهم.',0,NULL,69);
INSERT INTO `test_questions` VALUES (637,2,23,70,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول فعالیت و پویایی واکنش نشان دهم.',0,NULL,70);
INSERT INTO `test_questions` VALUES (638,2,24,71,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول هیجان‌خواهی واکنش نشان دهم.',0,NULL,71);
INSERT INTO `test_questions` VALUES (639,2,25,72,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول هیجانات مثبت و شادمانی واکنش نشان دهم.',0,NULL,72);
INSERT INTO `test_questions` VALUES (640,2,26,73,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول تخیل و فانتزی واکنش نشان دهم.',0,NULL,73);
INSERT INTO `test_questions` VALUES (641,2,27,74,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول زیبایی‌خواهی واکنش نشان دهم.',0,NULL,74);
INSERT INTO `test_questions` VALUES (642,2,28,75,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول احساسات و عواطف واکنش نشان دهم.',0,NULL,75);
INSERT INTO `test_questions` VALUES (643,2,29,76,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول اعمال و تجارب نو واکنش نشان دهم.',0,NULL,76);
INSERT INTO `test_questions` VALUES (644,2,30,77,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول ایده‌ها و کنجکاوی فکری واکنش نشان دهم.',0,NULL,77);
INSERT INTO `test_questions` VALUES (645,2,31,78,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول ارزش‌ها و دگراندیشی واکنش نشان دهم.',0,NULL,78);
INSERT INTO `test_questions` VALUES (646,2,32,79,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول اعتماد به دیگران واکنش نشان دهم.',0,NULL,79);
INSERT INTO `test_questions` VALUES (647,2,33,80,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول رک‌گویی و صداقت واکنش نشان دهم.',0,NULL,80);
INSERT INTO `test_questions` VALUES (648,2,34,81,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول نوع‌دوستی واکنش نشان دهم.',0,NULL,81);
INSERT INTO `test_questions` VALUES (649,2,35,82,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول همراهی و توافق‌پذیری واکنش نشان دهم.',0,NULL,82);
INSERT INTO `test_questions` VALUES (650,2,36,83,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول تواضع و فروتنی واکنش نشان دهم.',0,NULL,83);
INSERT INTO `test_questions` VALUES (651,2,37,84,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول دل‌رحمی و همدلی واکنش نشان دهم.',0,NULL,84);
INSERT INTO `test_questions` VALUES (652,2,38,85,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول احساس شایستگی واکنش نشان دهم.',0,NULL,85);
INSERT INTO `test_questions` VALUES (653,2,39,86,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول نظم و ترتیب واکنش نشان دهم.',0,NULL,86);
INSERT INTO `test_questions` VALUES (654,2,40,87,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول وظیفه‌شناسی و وجدان واکنش نشان دهم.',0,NULL,87);
INSERT INTO `test_questions` VALUES (655,2,41,88,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول تلاش برای موفقیت واکنش نشان دهم.',0,NULL,88);
INSERT INTO `test_questions` VALUES (656,2,42,89,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول خودانضباطی واکنش نشان دهم.',0,NULL,89);
INSERT INTO `test_questions` VALUES (657,2,43,90,'وقتی موقعیتی پیش می‌آید، تمایل دارم بر اساس اصول تدبیر و احتیاط واکنش نشان دهم.',0,NULL,90);
INSERT INTO `test_questions` VALUES (658,2,14,91,'برای من دشوار است که در امور روزمره از الگوهای اضطراب پیروی نکنم.',1,NULL,91);
INSERT INTO `test_questions` VALUES (659,2,15,92,'برای من دشوار است که در امور روزمره از الگوهای خشم و خصومت پیروی نکنم.',1,NULL,92);
INSERT INTO `test_questions` VALUES (660,2,16,93,'برای من دشوار است که در امور روزمره از الگوهای افسردگی پیروی نکنم.',1,NULL,93);
INSERT INTO `test_questions` VALUES (661,2,17,94,'برای من دشوار است که در امور روزمره از الگوهای شرم و خودناباوری پیروی نکنم.',1,NULL,94);
INSERT INTO `test_questions` VALUES (662,2,18,95,'برای من دشوار است که در امور روزمره از الگوهای تکانشگری پیروی نکنم.',1,NULL,95);
INSERT INTO `test_questions` VALUES (663,2,19,96,'برای من دشوار است که در امور روزمره از الگوهای آسیب‌پذیری به استرس پیروی نکنم.',1,NULL,96);
INSERT INTO `test_questions` VALUES (664,2,20,97,'برای من دشوار است که در امور روزمره از الگوهای صمیمیت و مهرورزی پیروی نکنم.',1,NULL,97);
INSERT INTO `test_questions` VALUES (665,2,21,98,'برای من دشوار است که در امور روزمره از الگوهای جمع‌گرایی پیروی نکنم.',1,NULL,98);
INSERT INTO `test_questions` VALUES (666,2,22,99,'برای من دشوار است که در امور روزمره از الگوهای قاطعیت و جسارت پیروی نکنم.',1,NULL,99);
INSERT INTO `test_questions` VALUES (667,2,23,100,'برای من دشوار است که در امور روزمره از الگوهای فعالیت و پویایی پیروی نکنم.',1,NULL,100);
INSERT INTO `test_questions` VALUES (668,2,24,101,'برای من دشوار است که در امور روزمره از الگوهای هیجان‌خواهی پیروی نکنم.',1,NULL,101);
INSERT INTO `test_questions` VALUES (669,2,25,102,'برای من دشوار است که در امور روزمره از الگوهای هیجانات مثبت و شادمانی پیروی نکنم.',1,NULL,102);
INSERT INTO `test_questions` VALUES (670,2,26,103,'برای من دشوار است که در امور روزمره از الگوهای تخیل و فانتزی پیروی نکنم.',1,NULL,103);
INSERT INTO `test_questions` VALUES (671,2,27,104,'برای من دشوار است که در امور روزمره از الگوهای زیبایی‌خواهی پیروی نکنم.',1,NULL,104);
INSERT INTO `test_questions` VALUES (672,2,28,105,'برای من دشوار است که در امور روزمره از الگوهای احساسات و عواطف پیروی نکنم.',1,NULL,105);
INSERT INTO `test_questions` VALUES (673,2,29,106,'برای من دشوار است که در امور روزمره از الگوهای اعمال و تجارب نو پیروی نکنم.',1,NULL,106);
INSERT INTO `test_questions` VALUES (674,2,30,107,'برای من دشوار است که در امور روزمره از الگوهای ایده‌ها و کنجکاوی فکری پیروی نکنم.',1,NULL,107);
INSERT INTO `test_questions` VALUES (675,2,31,108,'برای من دشوار است که در امور روزمره از الگوهای ارزش‌ها و دگراندیشی پیروی نکنم.',1,NULL,108);
INSERT INTO `test_questions` VALUES (676,2,32,109,'برای من دشوار است که در امور روزمره از الگوهای اعتماد به دیگران پیروی نکنم.',1,NULL,109);
INSERT INTO `test_questions` VALUES (677,2,33,110,'برای من دشوار است که در امور روزمره از الگوهای رک‌گویی و صداقت پیروی نکنم.',1,NULL,110);
INSERT INTO `test_questions` VALUES (678,2,34,111,'برای من دشوار است که در امور روزمره از الگوهای نوع‌دوستی پیروی نکنم.',1,NULL,111);
INSERT INTO `test_questions` VALUES (679,2,35,112,'برای من دشوار است که در امور روزمره از الگوهای همراهی و توافق‌پذیری پیروی نکنم.',1,NULL,112);
INSERT INTO `test_questions` VALUES (680,2,36,113,'برای من دشوار است که در امور روزمره از الگوهای تواضع و فروتنی پیروی نکنم.',1,NULL,113);
INSERT INTO `test_questions` VALUES (681,2,37,114,'برای من دشوار است که در امور روزمره از الگوهای دل‌رحمی و همدلی پیروی نکنم.',1,NULL,114);
INSERT INTO `test_questions` VALUES (682,2,38,115,'برای من دشوار است که در امور روزمره از الگوهای احساس شایستگی پیروی نکنم.',1,NULL,115);
INSERT INTO `test_questions` VALUES (683,2,39,116,'برای من دشوار است که در امور روزمره از الگوهای نظم و ترتیب پیروی نکنم.',1,NULL,116);
INSERT INTO `test_questions` VALUES (684,2,40,117,'برای من دشوار است که در امور روزمره از الگوهای وظیفه‌شناسی و وجدان پیروی نکنم.',1,NULL,117);
INSERT INTO `test_questions` VALUES (685,2,41,118,'برای من دشوار است که در امور روزمره از الگوهای تلاش برای موفقیت پیروی نکنم.',1,NULL,118);
INSERT INTO `test_questions` VALUES (686,2,42,119,'برای من دشوار است که در امور روزمره از الگوهای خودانضباطی پیروی نکنم.',1,NULL,119);
INSERT INTO `test_questions` VALUES (687,2,43,120,'برای من دشوار است که در امور روزمره از الگوهای تدبیر و احتیاط پیروی نکنم.',1,NULL,120);
INSERT INTO `test_questions` VALUES (688,2,14,121,'احساس می‌کنم گرایش من به اضطراب بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,121);
INSERT INTO `test_questions` VALUES (689,2,15,122,'احساس می‌کنم گرایش من به خشم و خصومت بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,122);
INSERT INTO `test_questions` VALUES (690,2,16,123,'احساس می‌کنم گرایش من به افسردگی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,123);
INSERT INTO `test_questions` VALUES (691,2,17,124,'احساس می‌کنم گرایش من به شرم و خودناباوری بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,124);
INSERT INTO `test_questions` VALUES (692,2,18,125,'احساس می‌کنم گرایش من به تکانشگری بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,125);
INSERT INTO `test_questions` VALUES (693,2,19,126,'احساس می‌کنم گرایش من به آسیب‌پذیری به استرس بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,126);
INSERT INTO `test_questions` VALUES (694,2,20,127,'احساس می‌کنم گرایش من به صمیمیت و مهرورزی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,127);
INSERT INTO `test_questions` VALUES (695,2,21,128,'احساس می‌کنم گرایش من به جمع‌گرایی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,128);
INSERT INTO `test_questions` VALUES (696,2,22,129,'احساس می‌کنم گرایش من به قاطعیت و جسارت بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,129);
INSERT INTO `test_questions` VALUES (697,2,23,130,'احساس می‌کنم گرایش من به فعالیت و پویایی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,130);
INSERT INTO `test_questions` VALUES (698,2,24,131,'احساس می‌کنم گرایش من به هیجان‌خواهی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,131);
INSERT INTO `test_questions` VALUES (699,2,25,132,'احساس می‌کنم گرایش من به هیجانات مثبت و شادمانی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,132);
INSERT INTO `test_questions` VALUES (700,2,26,133,'احساس می‌کنم گرایش من به تخیل و فانتزی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,133);
INSERT INTO `test_questions` VALUES (701,2,27,134,'احساس می‌کنم گرایش من به زیبایی‌خواهی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,134);
INSERT INTO `test_questions` VALUES (702,2,28,135,'احساس می‌کنم گرایش من به احساسات و عواطف بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,135);
INSERT INTO `test_questions` VALUES (703,2,29,136,'احساس می‌کنم گرایش من به اعمال و تجارب نو بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,136);
INSERT INTO `test_questions` VALUES (704,2,30,137,'احساس می‌کنم گرایش من به ایده‌ها و کنجکاوی فکری بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,137);
INSERT INTO `test_questions` VALUES (705,2,31,138,'احساس می‌کنم گرایش من به ارزش‌ها و دگراندیشی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,138);
INSERT INTO `test_questions` VALUES (706,2,32,139,'احساس می‌کنم گرایش من به اعتماد به دیگران بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,139);
INSERT INTO `test_questions` VALUES (707,2,33,140,'احساس می‌کنم گرایش من به رک‌گویی و صداقت بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,140);
INSERT INTO `test_questions` VALUES (708,2,34,141,'احساس می‌کنم گرایش من به نوع‌دوستی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,141);
INSERT INTO `test_questions` VALUES (709,2,35,142,'احساس می‌کنم گرایش من به همراهی و توافق‌پذیری بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,142);
INSERT INTO `test_questions` VALUES (710,2,36,143,'احساس می‌کنم گرایش من به تواضع و فروتنی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,143);
INSERT INTO `test_questions` VALUES (711,2,37,144,'احساس می‌کنم گرایش من به دل‌رحمی و همدلی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,144);
INSERT INTO `test_questions` VALUES (712,2,38,145,'احساس می‌کنم گرایش من به احساس شایستگی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,145);
INSERT INTO `test_questions` VALUES (713,2,39,146,'احساس می‌کنم گرایش من به نظم و ترتیب بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,146);
INSERT INTO `test_questions` VALUES (714,2,40,147,'احساس می‌کنم گرایش من به وظیفه‌شناسی و وجدان بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,147);
INSERT INTO `test_questions` VALUES (715,2,41,148,'احساس می‌کنم گرایش من به تلاش برای موفقیت بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,148);
INSERT INTO `test_questions` VALUES (716,2,42,149,'احساس می‌کنم گرایش من به خودانضباطی بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,149);
INSERT INTO `test_questions` VALUES (717,2,43,150,'احساس می‌کنم گرایش من به تدبیر و احتیاط بخش مهمی از هویت فردی‌ام را تشکیل می‌دهد.',0,NULL,150);
INSERT INTO `test_questions` VALUES (718,2,14,151,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد اضطراب دارم.',1,NULL,151);
INSERT INTO `test_questions` VALUES (719,2,15,152,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد خشم و خصومت دارم.',1,NULL,152);
INSERT INTO `test_questions` VALUES (720,2,16,153,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد افسردگی دارم.',1,NULL,153);
INSERT INTO `test_questions` VALUES (721,2,17,154,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد شرم و خودناباوری دارم.',1,NULL,154);
INSERT INTO `test_questions` VALUES (722,2,18,155,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد تکانشگری دارم.',1,NULL,155);
INSERT INTO `test_questions` VALUES (723,2,19,156,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد آسیب‌پذیری به استرس دارم.',1,NULL,156);
INSERT INTO `test_questions` VALUES (724,2,20,157,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد صمیمیت و مهرورزی دارم.',1,NULL,157);
INSERT INTO `test_questions` VALUES (725,2,21,158,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد جمع‌گرایی دارم.',1,NULL,158);
INSERT INTO `test_questions` VALUES (726,2,22,159,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد قاطعیت و جسارت دارم.',1,NULL,159);
INSERT INTO `test_questions` VALUES (727,2,23,160,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد فعالیت و پویایی دارم.',1,NULL,160);
INSERT INTO `test_questions` VALUES (728,2,24,161,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد هیجان‌خواهی دارم.',1,NULL,161);
INSERT INTO `test_questions` VALUES (729,2,25,162,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد هیجانات مثبت و شادمانی دارم.',1,NULL,162);
INSERT INTO `test_questions` VALUES (730,2,26,163,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد تخیل و فانتزی دارم.',1,NULL,163);
INSERT INTO `test_questions` VALUES (731,2,27,164,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد زیبایی‌خواهی دارم.',1,NULL,164);
INSERT INTO `test_questions` VALUES (732,2,28,165,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد احساسات و عواطف دارم.',1,NULL,165);
INSERT INTO `test_questions` VALUES (733,2,29,166,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد اعمال و تجارب نو دارم.',1,NULL,166);
INSERT INTO `test_questions` VALUES (734,2,30,167,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد ایده‌ها و کنجکاوی فکری دارم.',1,NULL,167);
INSERT INTO `test_questions` VALUES (735,2,31,168,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد ارزش‌ها و دگراندیشی دارم.',1,NULL,168);
INSERT INTO `test_questions` VALUES (736,2,32,169,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد اعتماد به دیگران دارم.',1,NULL,169);
INSERT INTO `test_questions` VALUES (737,2,33,170,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد رک‌گویی و صداقت دارم.',1,NULL,170);
INSERT INTO `test_questions` VALUES (738,2,34,171,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد نوع‌دوستی دارم.',1,NULL,171);
INSERT INTO `test_questions` VALUES (739,2,35,172,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد همراهی و توافق‌پذیری دارم.',1,NULL,172);
INSERT INTO `test_questions` VALUES (740,2,36,173,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد تواضع و فروتنی دارم.',1,NULL,173);
INSERT INTO `test_questions` VALUES (741,2,37,174,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد دل‌رحمی و همدلی دارم.',1,NULL,174);
INSERT INTO `test_questions` VALUES (742,2,38,175,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد احساس شایستگی دارم.',1,NULL,175);
INSERT INTO `test_questions` VALUES (743,2,39,176,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد نظم و ترتیب دارم.',1,NULL,176);
INSERT INTO `test_questions` VALUES (744,2,40,177,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد وظیفه‌شناسی و وجدان دارم.',1,NULL,177);
INSERT INTO `test_questions` VALUES (745,2,41,178,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد تلاش برای موفقیت دارم.',1,NULL,178);
INSERT INTO `test_questions` VALUES (746,2,42,179,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد خودانضباطی دارم.',1,NULL,179);
INSERT INTO `test_questions` VALUES (747,2,43,180,'در مقایسه با اکثر مردم، من توجه بیشتری به ابعاد تدبیر و احتیاط دارم.',1,NULL,180);
INSERT INTO `test_questions` VALUES (748,2,14,181,'تجارب زندگی به من نشان داده که در زمینه اضطراب همواره ثبات رفتار دارم.',0,NULL,181);
INSERT INTO `test_questions` VALUES (749,2,15,182,'تجارب زندگی به من نشان داده که در زمینه خشم و خصومت همواره ثبات رفتار دارم.',0,NULL,182);
INSERT INTO `test_questions` VALUES (750,2,16,183,'تجارب زندگی به من نشان داده که در زمینه افسردگی همواره ثبات رفتار دارم.',0,NULL,183);
INSERT INTO `test_questions` VALUES (751,2,17,184,'تجارب زندگی به من نشان داده که در زمینه شرم و خودناباوری همواره ثبات رفتار دارم.',0,NULL,184);
INSERT INTO `test_questions` VALUES (752,2,18,185,'تجارب زندگی به من نشان داده که در زمینه تکانشگری همواره ثبات رفتار دارم.',0,NULL,185);
INSERT INTO `test_questions` VALUES (753,2,19,186,'تجارب زندگی به من نشان داده که در زمینه آسیب‌پذیری به استرس همواره ثبات رفتار دارم.',0,NULL,186);
INSERT INTO `test_questions` VALUES (754,2,20,187,'تجارب زندگی به من نشان داده که در زمینه صمیمیت و مهرورزی همواره ثبات رفتار دارم.',0,NULL,187);
INSERT INTO `test_questions` VALUES (755,2,21,188,'تجارب زندگی به من نشان داده که در زمینه جمع‌گرایی همواره ثبات رفتار دارم.',0,NULL,188);
INSERT INTO `test_questions` VALUES (756,2,22,189,'تجارب زندگی به من نشان داده که در زمینه قاطعیت و جسارت همواره ثبات رفتار دارم.',0,NULL,189);
INSERT INTO `test_questions` VALUES (757,2,23,190,'تجارب زندگی به من نشان داده که در زمینه فعالیت و پویایی همواره ثبات رفتار دارم.',0,NULL,190);
INSERT INTO `test_questions` VALUES (758,2,24,191,'تجارب زندگی به من نشان داده که در زمینه هیجان‌خواهی همواره ثبات رفتار دارم.',0,NULL,191);
INSERT INTO `test_questions` VALUES (759,2,25,192,'تجارب زندگی به من نشان داده که در زمینه هیجانات مثبت و شادمانی همواره ثبات رفتار دارم.',0,NULL,192);
INSERT INTO `test_questions` VALUES (760,2,26,193,'تجارب زندگی به من نشان داده که در زمینه تخیل و فانتزی همواره ثبات رفتار دارم.',0,NULL,193);
INSERT INTO `test_questions` VALUES (761,2,27,194,'تجارب زندگی به من نشان داده که در زمینه زیبایی‌خواهی همواره ثبات رفتار دارم.',0,NULL,194);
INSERT INTO `test_questions` VALUES (762,2,28,195,'تجارب زندگی به من نشان داده که در زمینه احساسات و عواطف همواره ثبات رفتار دارم.',0,NULL,195);
INSERT INTO `test_questions` VALUES (763,2,29,196,'تجارب زندگی به من نشان داده که در زمینه اعمال و تجارب نو همواره ثبات رفتار دارم.',0,NULL,196);
INSERT INTO `test_questions` VALUES (764,2,30,197,'تجارب زندگی به من نشان داده که در زمینه ایده‌ها و کنجکاوی فکری همواره ثبات رفتار دارم.',0,NULL,197);
INSERT INTO `test_questions` VALUES (765,2,31,198,'تجارب زندگی به من نشان داده که در زمینه ارزش‌ها و دگراندیشی همواره ثبات رفتار دارم.',0,NULL,198);
INSERT INTO `test_questions` VALUES (766,2,32,199,'تجارب زندگی به من نشان داده که در زمینه اعتماد به دیگران همواره ثبات رفتار دارم.',0,NULL,199);
INSERT INTO `test_questions` VALUES (767,2,33,200,'تجارب زندگی به من نشان داده که در زمینه رک‌گویی و صداقت همواره ثبات رفتار دارم.',0,NULL,200);
INSERT INTO `test_questions` VALUES (768,2,34,201,'تجارب زندگی به من نشان داده که در زمینه نوع‌دوستی همواره ثبات رفتار دارم.',0,NULL,201);
INSERT INTO `test_questions` VALUES (769,2,35,202,'تجارب زندگی به من نشان داده که در زمینه همراهی و توافق‌پذیری همواره ثبات رفتار دارم.',0,NULL,202);
INSERT INTO `test_questions` VALUES (770,2,36,203,'تجارب زندگی به من نشان داده که در زمینه تواضع و فروتنی همواره ثبات رفتار دارم.',0,NULL,203);
INSERT INTO `test_questions` VALUES (771,2,37,204,'تجارب زندگی به من نشان داده که در زمینه دل‌رحمی و همدلی همواره ثبات رفتار دارم.',0,NULL,204);
INSERT INTO `test_questions` VALUES (772,2,38,205,'تجارب زندگی به من نشان داده که در زمینه احساس شایستگی همواره ثبات رفتار دارم.',0,NULL,205);
INSERT INTO `test_questions` VALUES (773,2,39,206,'تجارب زندگی به من نشان داده که در زمینه نظم و ترتیب همواره ثبات رفتار دارم.',0,NULL,206);
INSERT INTO `test_questions` VALUES (774,2,40,207,'تجارب زندگی به من نشان داده که در زمینه وظیفه‌شناسی و وجدان همواره ثبات رفتار دارم.',0,NULL,207);
INSERT INTO `test_questions` VALUES (775,2,41,208,'تجارب زندگی به من نشان داده که در زمینه تلاش برای موفقیت همواره ثبات رفتار دارم.',0,NULL,208);
INSERT INTO `test_questions` VALUES (776,2,42,209,'تجارب زندگی به من نشان داده که در زمینه خودانضباطی همواره ثبات رفتار دارم.',0,NULL,209);
INSERT INTO `test_questions` VALUES (777,2,43,210,'تجارب زندگی به من نشان داده که در زمینه تدبیر و احتیاط همواره ثبات رفتار دارم.',0,NULL,210);
INSERT INTO `test_questions` VALUES (778,2,14,211,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد اضطراب است.',0,NULL,211);
INSERT INTO `test_questions` VALUES (779,2,15,212,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد خشم و خصومت است.',0,NULL,212);
INSERT INTO `test_questions` VALUES (780,2,16,213,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد افسردگی است.',0,NULL,213);
INSERT INTO `test_questions` VALUES (781,2,17,214,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد شرم و خودناباوری است.',0,NULL,214);
INSERT INTO `test_questions` VALUES (782,2,18,215,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد تکانشگری است.',0,NULL,215);
INSERT INTO `test_questions` VALUES (783,2,19,216,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد آسیب‌پذیری به استرس است.',0,NULL,216);
INSERT INTO `test_questions` VALUES (784,2,20,217,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد صمیمیت و مهرورزی است.',0,NULL,217);
INSERT INTO `test_questions` VALUES (785,2,21,218,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد جمع‌گرایی است.',0,NULL,218);
INSERT INTO `test_questions` VALUES (786,2,22,219,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد قاطعیت و جسارت است.',0,NULL,219);
INSERT INTO `test_questions` VALUES (787,2,23,220,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد فعالیت و پویایی است.',0,NULL,220);
INSERT INTO `test_questions` VALUES (788,2,24,221,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد هیجان‌خواهی است.',0,NULL,221);
INSERT INTO `test_questions` VALUES (789,2,25,222,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد هیجانات مثبت و شادمانی است.',0,NULL,222);
INSERT INTO `test_questions` VALUES (790,2,26,223,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد تخیل و فانتزی است.',0,NULL,223);
INSERT INTO `test_questions` VALUES (791,2,27,224,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد زیبایی‌خواهی است.',0,NULL,224);
INSERT INTO `test_questions` VALUES (792,2,28,225,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد احساسات و عواطف است.',0,NULL,225);
INSERT INTO `test_questions` VALUES (793,2,29,226,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد اعمال و تجارب نو است.',0,NULL,226);
INSERT INTO `test_questions` VALUES (794,2,30,227,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد ایده‌ها و کنجکاوی فکری است.',0,NULL,227);
INSERT INTO `test_questions` VALUES (795,2,31,228,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد ارزش‌ها و دگراندیشی است.',0,NULL,228);
INSERT INTO `test_questions` VALUES (796,2,32,229,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد اعتماد به دیگران است.',0,NULL,229);
INSERT INTO `test_questions` VALUES (797,2,33,230,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد رک‌گویی و صداقت است.',0,NULL,230);
INSERT INTO `test_questions` VALUES (798,2,34,231,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد نوع‌دوستی است.',0,NULL,231);
INSERT INTO `test_questions` VALUES (799,2,35,232,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد همراهی و توافق‌پذیری است.',0,NULL,232);
INSERT INTO `test_questions` VALUES (800,2,36,233,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد تواضع و فروتنی است.',0,NULL,233);
INSERT INTO `test_questions` VALUES (801,2,37,234,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد دل‌رحمی و همدلی است.',0,NULL,234);
INSERT INTO `test_questions` VALUES (802,2,38,235,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد احساس شایستگی است.',0,NULL,235);
INSERT INTO `test_questions` VALUES (803,2,39,236,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد نظم و ترتیب است.',0,NULL,236);
INSERT INTO `test_questions` VALUES (804,2,40,237,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد وظیفه‌شناسی و وجدان است.',0,NULL,237);
INSERT INTO `test_questions` VALUES (805,2,41,238,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد تلاش برای موفقیت است.',0,NULL,238);
INSERT INTO `test_questions` VALUES (806,2,42,239,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد خودانضباطی است.',0,NULL,239);
INSERT INTO `test_questions` VALUES (807,2,43,240,'ارزیابی کلی من از رفتار خودم نشان‌دهنده انطباق عمیق با رویکرد تدبیر و احتیاط است.',0,NULL,240);
INSERT INTO `test_questions` VALUES (808,3,44,1,'در طول زندگی احساس کرده‌ام که موضوع محرومیت هیجانی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,1);
INSERT INTO `test_questions` VALUES (809,3,45,2,'در طول زندگی احساس کرده‌ام که موضوع رهاشدگی / بی‌ثباتی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,2);
INSERT INTO `test_questions` VALUES (810,3,46,3,'در طول زندگی احساس کرده‌ام که موضوع بی‌اعتمادی / بدرفتاری مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,3);
INSERT INTO `test_questions` VALUES (811,3,47,4,'در طول زندگی احساس کرده‌ام که موضوع انزوای اجتماعی / بیگانگی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,4);
INSERT INTO `test_questions` VALUES (812,3,48,5,'در طول زندگی احساس کرده‌ام که موضوع نقص / شرم مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,5);
INSERT INTO `test_questions` VALUES (813,3,49,6,'در طول زندگی احساس کرده‌ام که موضوع شکست مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,6);
INSERT INTO `test_questions` VALUES (814,3,50,7,'در طول زندگی احساس کرده‌ام که موضوع وابستگی / بی‌کفایتی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,7);
INSERT INTO `test_questions` VALUES (815,3,51,8,'در طول زندگی احساس کرده‌ام که موضوع آسیب‌پذیری به ضرر یا بیماری مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,8);
INSERT INTO `test_questions` VALUES (816,3,52,9,'در طول زندگی احساس کرده‌ام که موضوع گرفتاری / خویشتن تحول‌نیافته مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,9);
INSERT INTO `test_questions` VALUES (817,3,53,10,'در طول زندگی احساس کرده‌ام که موضوع اطاعت / تسلیم مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,10);
INSERT INTO `test_questions` VALUES (818,3,54,11,'در طول زندگی احساس کرده‌ام که موضوع ایثار و فداکاری مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,11);
INSERT INTO `test_questions` VALUES (819,3,55,12,'در طول زندگی احساس کرده‌ام که موضوع پذیرش‌جویی / جلب توجه مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,12);
INSERT INTO `test_questions` VALUES (820,3,56,13,'در طول زندگی احساس کرده‌ام که موضوع منفی‌گرایی / بدبینی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,13);
INSERT INTO `test_questions` VALUES (821,3,57,14,'در طول زندگی احساس کرده‌ام که موضوع بازداری هیجانی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,14);
INSERT INTO `test_questions` VALUES (822,3,58,15,'در طول زندگی احساس کرده‌ام که موضوع معیارهای سرسختانه مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,15);
INSERT INTO `test_questions` VALUES (823,3,59,16,'در طول زندگی احساس کرده‌ام که موضوع استحقاق / بزرگ‌منشی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,16);
INSERT INTO `test_questions` VALUES (824,3,60,17,'در طول زندگی احساس کرده‌ام که موضوع خویشتن‌داری ناکافی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,17);
INSERT INTO `test_questions` VALUES (825,3,61,18,'در طول زندگی احساس کرده‌ام که موضوع تنبیه‌گرایی و بی‌رحمی مکرراً بر تجارب و روابط من سایه افکنده است.',0,NULL,18);
INSERT INTO `test_questions` VALUES (826,3,44,19,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی محرومیت هیجانی است.',0,NULL,19);
INSERT INTO `test_questions` VALUES (827,3,45,20,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی رهاشدگی / بی‌ثباتی است.',0,NULL,20);
INSERT INTO `test_questions` VALUES (828,3,46,21,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی بی‌اعتمادی / بدرفتاری است.',0,NULL,21);
INSERT INTO `test_questions` VALUES (829,3,47,22,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی انزوای اجتماعی / بیگانگی است.',0,NULL,22);
INSERT INTO `test_questions` VALUES (830,3,48,23,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی نقص / شرم است.',0,NULL,23);
INSERT INTO `test_questions` VALUES (831,3,49,24,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی شکست است.',0,NULL,24);
INSERT INTO `test_questions` VALUES (832,3,50,25,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی وابستگی / بی‌کفایتی است.',0,NULL,25);
INSERT INTO `test_questions` VALUES (833,3,51,26,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی آسیب‌پذیری به ضرر یا بیماری است.',0,NULL,26);
INSERT INTO `test_questions` VALUES (834,3,52,27,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی گرفتاری / خویشتن تحول‌نیافته است.',0,NULL,27);
INSERT INTO `test_questions` VALUES (835,3,53,28,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی اطاعت / تسلیم است.',0,NULL,28);
INSERT INTO `test_questions` VALUES (836,3,54,29,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی ایثار و فداکاری است.',0,NULL,29);
INSERT INTO `test_questions` VALUES (837,3,55,30,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی پذیرش‌جویی / جلب توجه است.',0,NULL,30);
INSERT INTO `test_questions` VALUES (838,3,56,31,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی منفی‌گرایی / بدبینی است.',0,NULL,31);
INSERT INTO `test_questions` VALUES (839,3,57,32,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی بازداری هیجانی است.',0,NULL,32);
INSERT INTO `test_questions` VALUES (840,3,58,33,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی معیارهای سرسختانه است.',0,NULL,33);
INSERT INTO `test_questions` VALUES (841,3,59,34,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی استحقاق / بزرگ‌منشی است.',0,NULL,34);
INSERT INTO `test_questions` VALUES (842,3,60,35,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی خویشتن‌داری ناکافی است.',0,NULL,35);
INSERT INTO `test_questions` VALUES (843,3,61,36,'باورها و واکنش‌های من در بسیاری از موقعیت‌ها نشان‌دهنده حضور قوی تنبیه‌گرایی و بی‌رحمی است.',0,NULL,36);
INSERT INTO `test_questions` VALUES (844,3,44,37,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای محرومیت هیجانی در ذهنم فعال می‌شوند.',0,NULL,37);
INSERT INTO `test_questions` VALUES (845,3,45,38,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای رهاشدگی / بی‌ثباتی در ذهنم فعال می‌شوند.',0,NULL,38);
INSERT INTO `test_questions` VALUES (846,3,46,39,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای بی‌اعتمادی / بدرفتاری در ذهنم فعال می‌شوند.',0,NULL,39);
INSERT INTO `test_questions` VALUES (847,3,47,40,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای انزوای اجتماعی / بیگانگی در ذهنم فعال می‌شوند.',0,NULL,40);
INSERT INTO `test_questions` VALUES (848,3,48,41,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای نقص / شرم در ذهنم فعال می‌شوند.',0,NULL,41);
INSERT INTO `test_questions` VALUES (849,3,49,42,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای شکست در ذهنم فعال می‌شوند.',0,NULL,42);
INSERT INTO `test_questions` VALUES (850,3,50,43,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای وابستگی / بی‌کفایتی در ذهنم فعال می‌شوند.',0,NULL,43);
INSERT INTO `test_questions` VALUES (851,3,51,44,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای آسیب‌پذیری به ضرر یا بیماری در ذهنم فعال می‌شوند.',0,NULL,44);
INSERT INTO `test_questions` VALUES (852,3,52,45,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای گرفتاری / خویشتن تحول‌نیافته در ذهنم فعال می‌شوند.',0,NULL,45);
INSERT INTO `test_questions` VALUES (853,3,53,46,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای اطاعت / تسلیم در ذهنم فعال می‌شوند.',0,NULL,46);
INSERT INTO `test_questions` VALUES (854,3,54,47,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای ایثار و فداکاری در ذهنم فعال می‌شوند.',0,NULL,47);
INSERT INTO `test_questions` VALUES (855,3,55,48,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای پذیرش‌جویی / جلب توجه در ذهنم فعال می‌شوند.',0,NULL,48);
INSERT INTO `test_questions` VALUES (856,3,56,49,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای منفی‌گرایی / بدبینی در ذهنم فعال می‌شوند.',0,NULL,49);
INSERT INTO `test_questions` VALUES (857,3,57,50,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای بازداری هیجانی در ذهنم فعال می‌شوند.',0,NULL,50);
INSERT INTO `test_questions` VALUES (858,3,58,51,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای معیارهای سرسختانه در ذهنم فعال می‌شوند.',0,NULL,51);
INSERT INTO `test_questions` VALUES (859,3,59,52,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای استحقاق / بزرگ‌منشی در ذهنم فعال می‌شوند.',0,NULL,52);
INSERT INTO `test_questions` VALUES (860,3,60,53,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای خویشتن‌داری ناکافی در ذهنم فعال می‌شوند.',0,NULL,53);
INSERT INTO `test_questions` VALUES (861,3,61,54,'هنگامی که با چالش یا موقعیت جدیدی روبرو می‌شوم، الگوهای تنبیه‌گرایی و بی‌رحمی در ذهنم فعال می‌شوند.',0,NULL,54);
INSERT INTO `test_questions` VALUES (862,3,44,55,'برایم بسیار دشوار است که باورهای منفی مرتبط با محرومیت هیجانی را نادیده بگیرم.',0,NULL,55);
INSERT INTO `test_questions` VALUES (863,3,45,56,'برایم بسیار دشوار است که باورهای منفی مرتبط با رهاشدگی / بی‌ثباتی را نادیده بگیرم.',0,NULL,56);
INSERT INTO `test_questions` VALUES (864,3,46,57,'برایم بسیار دشوار است که باورهای منفی مرتبط با بی‌اعتمادی / بدرفتاری را نادیده بگیرم.',0,NULL,57);
INSERT INTO `test_questions` VALUES (865,3,47,58,'برایم بسیار دشوار است که باورهای منفی مرتبط با انزوای اجتماعی / بیگانگی را نادیده بگیرم.',0,NULL,58);
INSERT INTO `test_questions` VALUES (866,3,48,59,'برایم بسیار دشوار است که باورهای منفی مرتبط با نقص / شرم را نادیده بگیرم.',0,NULL,59);
INSERT INTO `test_questions` VALUES (867,3,49,60,'برایم بسیار دشوار است که باورهای منفی مرتبط با شکست را نادیده بگیرم.',0,NULL,60);
INSERT INTO `test_questions` VALUES (868,3,50,61,'برایم بسیار دشوار است که باورهای منفی مرتبط با وابستگی / بی‌کفایتی را نادیده بگیرم.',0,NULL,61);
INSERT INTO `test_questions` VALUES (869,3,51,62,'برایم بسیار دشوار است که باورهای منفی مرتبط با آسیب‌پذیری به ضرر یا بیماری را نادیده بگیرم.',0,NULL,62);
INSERT INTO `test_questions` VALUES (870,3,52,63,'برایم بسیار دشوار است که باورهای منفی مرتبط با گرفتاری / خویشتن تحول‌نیافته را نادیده بگیرم.',0,NULL,63);
INSERT INTO `test_questions` VALUES (871,3,53,64,'برایم بسیار دشوار است که باورهای منفی مرتبط با اطاعت / تسلیم را نادیده بگیرم.',0,NULL,64);
INSERT INTO `test_questions` VALUES (872,3,54,65,'برایم بسیار دشوار است که باورهای منفی مرتبط با ایثار و فداکاری را نادیده بگیرم.',0,NULL,65);
INSERT INTO `test_questions` VALUES (873,3,55,66,'برایم بسیار دشوار است که باورهای منفی مرتبط با پذیرش‌جویی / جلب توجه را نادیده بگیرم.',0,NULL,66);
INSERT INTO `test_questions` VALUES (874,3,56,67,'برایم بسیار دشوار است که باورهای منفی مرتبط با منفی‌گرایی / بدبینی را نادیده بگیرم.',0,NULL,67);
INSERT INTO `test_questions` VALUES (875,3,57,68,'برایم بسیار دشوار است که باورهای منفی مرتبط با بازداری هیجانی را نادیده بگیرم.',0,NULL,68);
INSERT INTO `test_questions` VALUES (876,3,58,69,'برایم بسیار دشوار است که باورهای منفی مرتبط با معیارهای سرسختانه را نادیده بگیرم.',0,NULL,69);
INSERT INTO `test_questions` VALUES (877,3,59,70,'برایم بسیار دشوار است که باورهای منفی مرتبط با استحقاق / بزرگ‌منشی را نادیده بگیرم.',0,NULL,70);
INSERT INTO `test_questions` VALUES (878,3,60,71,'برایم بسیار دشوار است که باورهای منفی مرتبط با خویشتن‌داری ناکافی را نادیده بگیرم.',0,NULL,71);
INSERT INTO `test_questions` VALUES (879,3,61,72,'برایم بسیار دشوار است که باورهای منفی مرتبط با تنبیه‌گرایی و بی‌رحمی را نادیده بگیرم.',0,NULL,72);
INSERT INTO `test_questions` VALUES (880,3,44,73,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از محرومیت هیجانی کنترلی ندارم.',0,NULL,73);
INSERT INTO `test_questions` VALUES (881,3,45,74,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از رهاشدگی / بی‌ثباتی کنترلی ندارم.',0,NULL,74);
INSERT INTO `test_questions` VALUES (882,3,46,75,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از بی‌اعتمادی / بدرفتاری کنترلی ندارم.',0,NULL,75);
INSERT INTO `test_questions` VALUES (883,3,47,76,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از انزوای اجتماعی / بیگانگی کنترلی ندارم.',0,NULL,76);
INSERT INTO `test_questions` VALUES (884,3,48,77,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از نقص / شرم کنترلی ندارم.',0,NULL,77);
INSERT INTO `test_questions` VALUES (885,3,49,78,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از شکست کنترلی ندارم.',0,NULL,78);
INSERT INTO `test_questions` VALUES (886,3,50,79,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از وابستگی / بی‌کفایتی کنترلی ندارم.',0,NULL,79);
INSERT INTO `test_questions` VALUES (887,3,51,80,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از آسیب‌پذیری به ضرر یا بیماری کنترلی ندارم.',0,NULL,80);
INSERT INTO `test_questions` VALUES (888,3,52,81,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از گرفتاری / خویشتن تحول‌نیافته کنترلی ندارم.',0,NULL,81);
INSERT INTO `test_questions` VALUES (889,3,53,82,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از اطاعت / تسلیم کنترلی ندارم.',0,NULL,82);
INSERT INTO `test_questions` VALUES (890,3,54,83,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از ایثار و فداکاری کنترلی ندارم.',0,NULL,83);
INSERT INTO `test_questions` VALUES (891,3,55,84,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از پذیرش‌جویی / جلب توجه کنترلی ندارم.',0,NULL,84);
INSERT INTO `test_questions` VALUES (892,3,56,85,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از منفی‌گرایی / بدبینی کنترلی ندارم.',0,NULL,85);
INSERT INTO `test_questions` VALUES (893,3,57,86,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از بازداری هیجانی کنترلی ندارم.',0,NULL,86);
INSERT INTO `test_questions` VALUES (894,3,58,87,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از معیارهای سرسختانه کنترلی ندارم.',0,NULL,87);
INSERT INTO `test_questions` VALUES (895,3,59,88,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از استحقاق / بزرگ‌منشی کنترلی ندارم.',0,NULL,88);
INSERT INTO `test_questions` VALUES (896,3,60,89,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از خویشتن‌داری ناکافی کنترلی ندارم.',0,NULL,89);
INSERT INTO `test_questions` VALUES (897,3,61,90,'اغلب احساس می‌کنم در برابر الگوهای رفتاری ناشی از تنبیه‌گرایی و بی‌رحمی کنترلی ندارم.',0,NULL,90);
INSERT INTO `test_questions` VALUES (898,3,44,91,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای محرومیت هیجانی تعبیر می‌کنم.',0,NULL,91);
INSERT INTO `test_questions` VALUES (899,3,45,92,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای رهاشدگی / بی‌ثباتی تعبیر می‌کنم.',0,NULL,92);
INSERT INTO `test_questions` VALUES (900,3,46,93,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای بی‌اعتمادی / بدرفتاری تعبیر می‌کنم.',0,NULL,93);
INSERT INTO `test_questions` VALUES (901,3,47,94,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای انزوای اجتماعی / بیگانگی تعبیر می‌کنم.',0,NULL,94);
INSERT INTO `test_questions` VALUES (902,3,48,95,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای نقص / شرم تعبیر می‌کنم.',0,NULL,95);
INSERT INTO `test_questions` VALUES (903,3,49,96,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای شکست تعبیر می‌کنم.',0,NULL,96);
INSERT INTO `test_questions` VALUES (904,3,50,97,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای وابستگی / بی‌کفایتی تعبیر می‌کنم.',0,NULL,97);
INSERT INTO `test_questions` VALUES (905,3,51,98,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای آسیب‌پذیری به ضرر یا بیماری تعبیر می‌کنم.',0,NULL,98);
INSERT INTO `test_questions` VALUES (906,3,52,99,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای گرفتاری / خویشتن تحول‌نیافته تعبیر می‌کنم.',0,NULL,99);
INSERT INTO `test_questions` VALUES (907,3,53,100,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای اطاعت / تسلیم تعبیر می‌کنم.',0,NULL,100);
INSERT INTO `test_questions` VALUES (908,3,54,101,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای ایثار و فداکاری تعبیر می‌کنم.',0,NULL,101);
INSERT INTO `test_questions` VALUES (909,3,55,102,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای پذیرش‌جویی / جلب توجه تعبیر می‌کنم.',0,NULL,102);
INSERT INTO `test_questions` VALUES (910,3,56,103,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای منفی‌گرایی / بدبینی تعبیر می‌کنم.',0,NULL,103);
INSERT INTO `test_questions` VALUES (911,3,57,104,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای بازداری هیجانی تعبیر می‌کنم.',0,NULL,104);
INSERT INTO `test_questions` VALUES (912,3,58,105,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای معیارهای سرسختانه تعبیر می‌کنم.',0,NULL,105);
INSERT INTO `test_questions` VALUES (913,3,59,106,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای استحقاق / بزرگ‌منشی تعبیر می‌کنم.',0,NULL,106);
INSERT INTO `test_questions` VALUES (914,3,60,107,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای خویشتن‌داری ناکافی تعبیر می‌کنم.',0,NULL,107);
INSERT INTO `test_questions` VALUES (915,3,61,108,'رفتار دیگران را غالباً از عینک تجارب دوران کودکی و الگوهای تنبیه‌گرایی و بی‌رحمی تعبیر می‌کنم.',0,NULL,108);
INSERT INTO `test_questions` VALUES (916,3,44,109,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع محرومیت هیجانی پیوند خورده است.',0,NULL,109);
INSERT INTO `test_questions` VALUES (917,3,45,110,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع رهاشدگی / بی‌ثباتی پیوند خورده است.',0,NULL,110);
INSERT INTO `test_questions` VALUES (918,3,46,111,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع بی‌اعتمادی / بدرفتاری پیوند خورده است.',0,NULL,111);
INSERT INTO `test_questions` VALUES (919,3,47,112,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع انزوای اجتماعی / بیگانگی پیوند خورده است.',0,NULL,112);
INSERT INTO `test_questions` VALUES (920,3,48,113,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع نقص / شرم پیوند خورده است.',0,NULL,113);
INSERT INTO `test_questions` VALUES (921,3,49,114,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع شکست پیوند خورده است.',0,NULL,114);
INSERT INTO `test_questions` VALUES (922,3,50,115,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع وابستگی / بی‌کفایتی پیوند خورده است.',0,NULL,115);
INSERT INTO `test_questions` VALUES (923,3,51,116,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع آسیب‌پذیری به ضرر یا بیماری پیوند خورده است.',0,NULL,116);
INSERT INTO `test_questions` VALUES (924,3,52,117,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع گرفتاری / خویشتن تحول‌نیافته پیوند خورده است.',0,NULL,117);
INSERT INTO `test_questions` VALUES (925,3,53,118,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع اطاعت / تسلیم پیوند خورده است.',0,NULL,118);
INSERT INTO `test_questions` VALUES (926,3,54,119,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع ایثار و فداکاری پیوند خورده است.',0,NULL,119);
INSERT INTO `test_questions` VALUES (927,3,55,120,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع پذیرش‌جویی / جلب توجه پیوند خورده است.',0,NULL,120);
INSERT INTO `test_questions` VALUES (928,3,56,121,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع منفی‌گرایی / بدبینی پیوند خورده است.',0,NULL,121);
INSERT INTO `test_questions` VALUES (929,3,57,122,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع بازداری هیجانی پیوند خورده است.',0,NULL,122);
INSERT INTO `test_questions` VALUES (930,3,58,123,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع معیارهای سرسختانه پیوند خورده است.',0,NULL,123);
INSERT INTO `test_questions` VALUES (931,3,59,124,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع استحقاق / بزرگ‌منشی پیوند خورده است.',0,NULL,124);
INSERT INTO `test_questions` VALUES (932,3,60,125,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع خویشتن‌داری ناکافی پیوند خورده است.',0,NULL,125);
INSERT INTO `test_questions` VALUES (933,3,61,126,'احساس ناامنی و فشار درونی من تا حد زیادی با موضوع تنبیه‌گرایی و بی‌رحمی پیوند خورده است.',0,NULL,126);
INSERT INTO `test_questions` VALUES (934,3,44,127,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به محرومیت هیجانی در من زنده است.',0,NULL,127);
INSERT INTO `test_questions` VALUES (935,3,45,128,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به رهاشدگی / بی‌ثباتی در من زنده است.',0,NULL,128);
INSERT INTO `test_questions` VALUES (936,3,46,129,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به بی‌اعتمادی / بدرفتاری در من زنده است.',0,NULL,129);
INSERT INTO `test_questions` VALUES (937,3,47,130,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به انزوای اجتماعی / بیگانگی در من زنده است.',0,NULL,130);
INSERT INTO `test_questions` VALUES (938,3,48,131,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به نقص / شرم در من زنده است.',0,NULL,131);
INSERT INTO `test_questions` VALUES (939,3,49,132,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به شکست در من زنده است.',0,NULL,132);
INSERT INTO `test_questions` VALUES (940,3,50,133,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به وابستگی / بی‌کفایتی در من زنده است.',0,NULL,133);
INSERT INTO `test_questions` VALUES (941,3,51,134,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به آسیب‌پذیری به ضرر یا بیماری در من زنده است.',0,NULL,134);
INSERT INTO `test_questions` VALUES (942,3,52,135,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به گرفتاری / خویشتن تحول‌نیافته در من زنده است.',0,NULL,135);
INSERT INTO `test_questions` VALUES (943,3,53,136,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به اطاعت / تسلیم در من زنده است.',0,NULL,136);
INSERT INTO `test_questions` VALUES (944,3,54,137,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به ایثار و فداکاری در من زنده است.',0,NULL,137);
INSERT INTO `test_questions` VALUES (945,3,55,138,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به پذیرش‌جویی / جلب توجه در من زنده است.',0,NULL,138);
INSERT INTO `test_questions` VALUES (946,3,56,139,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به منفی‌گرایی / بدبینی در من زنده است.',0,NULL,139);
INSERT INTO `test_questions` VALUES (947,3,57,140,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به بازداری هیجانی در من زنده است.',0,NULL,140);
INSERT INTO `test_questions` VALUES (948,3,58,141,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به معیارهای سرسختانه در من زنده است.',0,NULL,141);
INSERT INTO `test_questions` VALUES (949,3,59,142,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به استحقاق / بزرگ‌منشی در من زنده است.',0,NULL,142);
INSERT INTO `test_questions` VALUES (950,3,60,143,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به خویشتن‌داری ناکافی در من زنده است.',0,NULL,143);
INSERT INTO `test_questions` VALUES (951,3,61,144,'حتی زمانی که اوضاع آرام است، نگرانی‌ها و تله‌های فکری مربوط به تنبیه‌گرایی و بی‌رحمی در من زنده است.',0,NULL,144);
INSERT INTO `test_questions` VALUES (952,3,44,145,'به طور عمیق احساس می‌کنم تله زندگی محرومیت هیجانی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,145);
INSERT INTO `test_questions` VALUES (953,3,45,146,'به طور عمیق احساس می‌کنم تله زندگی رهاشدگی / بی‌ثباتی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,146);
INSERT INTO `test_questions` VALUES (954,3,46,147,'به طور عمیق احساس می‌کنم تله زندگی بی‌اعتمادی / بدرفتاری بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,147);
INSERT INTO `test_questions` VALUES (955,3,47,148,'به طور عمیق احساس می‌کنم تله زندگی انزوای اجتماعی / بیگانگی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,148);
INSERT INTO `test_questions` VALUES (956,3,48,149,'به طور عمیق احساس می‌کنم تله زندگی نقص / شرم بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,149);
INSERT INTO `test_questions` VALUES (957,3,49,150,'به طور عمیق احساس می‌کنم تله زندگی شکست بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,150);
INSERT INTO `test_questions` VALUES (958,3,50,151,'به طور عمیق احساس می‌کنم تله زندگی وابستگی / بی‌کفایتی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,151);
INSERT INTO `test_questions` VALUES (959,3,51,152,'به طور عمیق احساس می‌کنم تله زندگی آسیب‌پذیری به ضرر یا بیماری بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,152);
INSERT INTO `test_questions` VALUES (960,3,52,153,'به طور عمیق احساس می‌کنم تله زندگی گرفتاری / خویشتن تحول‌نیافته بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,153);
INSERT INTO `test_questions` VALUES (961,3,53,154,'به طور عمیق احساس می‌کنم تله زندگی اطاعت / تسلیم بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,154);
INSERT INTO `test_questions` VALUES (962,3,54,155,'به طور عمیق احساس می‌کنم تله زندگی ایثار و فداکاری بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,155);
INSERT INTO `test_questions` VALUES (963,3,55,156,'به طور عمیق احساس می‌کنم تله زندگی پذیرش‌جویی / جلب توجه بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,156);
INSERT INTO `test_questions` VALUES (964,3,56,157,'به طور عمیق احساس می‌کنم تله زندگی منفی‌گرایی / بدبینی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,157);
INSERT INTO `test_questions` VALUES (965,3,57,158,'به طور عمیق احساس می‌کنم تله زندگی بازداری هیجانی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,158);
INSERT INTO `test_questions` VALUES (966,3,58,159,'به طور عمیق احساس می‌کنم تله زندگی معیارهای سرسختانه بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,159);
INSERT INTO `test_questions` VALUES (967,3,59,160,'به طور عمیق احساس می‌کنم تله زندگی استحقاق / بزرگ‌منشی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,160);
INSERT INTO `test_questions` VALUES (968,3,60,161,'به طور عمیق احساس می‌کنم تله زندگی خویشتن‌داری ناکافی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,161);
INSERT INTO `test_questions` VALUES (969,3,61,162,'به طور عمیق احساس می‌کنم تله زندگی تنبیه‌گرایی و بی‌رحمی بخش مهمی از چالش‌های فردی من را شکل می‌دهد.',0,NULL,162);
INSERT INTO `test_questions` VALUES (970,3,44,163,'تغییر دادن هیجانات و افکار ریشه‌داری که به محرومیت هیجانی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,163);
INSERT INTO `test_questions` VALUES (971,3,45,164,'تغییر دادن هیجانات و افکار ریشه‌داری که به رهاشدگی / بی‌ثباتی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,164);
INSERT INTO `test_questions` VALUES (972,3,46,165,'تغییر دادن هیجانات و افکار ریشه‌داری که به بی‌اعتمادی / بدرفتاری مربوط می‌شوند برایم بسیار سخت است.',0,NULL,165);
INSERT INTO `test_questions` VALUES (973,3,47,166,'تغییر دادن هیجانات و افکار ریشه‌داری که به انزوای اجتماعی / بیگانگی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,166);
INSERT INTO `test_questions` VALUES (974,3,48,167,'تغییر دادن هیجانات و افکار ریشه‌داری که به نقص / شرم مربوط می‌شوند برایم بسیار سخت است.',0,NULL,167);
INSERT INTO `test_questions` VALUES (975,3,49,168,'تغییر دادن هیجانات و افکار ریشه‌داری که به شکست مربوط می‌شوند برایم بسیار سخت است.',0,NULL,168);
INSERT INTO `test_questions` VALUES (976,3,50,169,'تغییر دادن هیجانات و افکار ریشه‌داری که به وابستگی / بی‌کفایتی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,169);
INSERT INTO `test_questions` VALUES (977,3,51,170,'تغییر دادن هیجانات و افکار ریشه‌داری که به آسیب‌پذیری به ضرر یا بیماری مربوط می‌شوند برایم بسیار سخت است.',0,NULL,170);
INSERT INTO `test_questions` VALUES (978,3,52,171,'تغییر دادن هیجانات و افکار ریشه‌داری که به گرفتاری / خویشتن تحول‌نیافته مربوط می‌شوند برایم بسیار سخت است.',0,NULL,171);
INSERT INTO `test_questions` VALUES (979,3,53,172,'تغییر دادن هیجانات و افکار ریشه‌داری که به اطاعت / تسلیم مربوط می‌شوند برایم بسیار سخت است.',0,NULL,172);
INSERT INTO `test_questions` VALUES (980,3,54,173,'تغییر دادن هیجانات و افکار ریشه‌داری که به ایثار و فداکاری مربوط می‌شوند برایم بسیار سخت است.',0,NULL,173);
INSERT INTO `test_questions` VALUES (981,3,55,174,'تغییر دادن هیجانات و افکار ریشه‌داری که به پذیرش‌جویی / جلب توجه مربوط می‌شوند برایم بسیار سخت است.',0,NULL,174);
INSERT INTO `test_questions` VALUES (982,3,56,175,'تغییر دادن هیجانات و افکار ریشه‌داری که به منفی‌گرایی / بدبینی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,175);
INSERT INTO `test_questions` VALUES (983,3,57,176,'تغییر دادن هیجانات و افکار ریشه‌داری که به بازداری هیجانی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,176);
INSERT INTO `test_questions` VALUES (984,3,58,177,'تغییر دادن هیجانات و افکار ریشه‌داری که به معیارهای سرسختانه مربوط می‌شوند برایم بسیار سخت است.',0,NULL,177);
INSERT INTO `test_questions` VALUES (985,3,59,178,'تغییر دادن هیجانات و افکار ریشه‌داری که به استحقاق / بزرگ‌منشی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,178);
INSERT INTO `test_questions` VALUES (986,3,60,179,'تغییر دادن هیجانات و افکار ریشه‌داری که به خویشتن‌داری ناکافی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,179);
INSERT INTO `test_questions` VALUES (987,3,61,180,'تغییر دادن هیجانات و افکار ریشه‌داری که به تنبیه‌گرایی و بی‌رحمی مربوط می‌شوند برایم بسیار سخت است.',0,NULL,180);
INSERT INTO `test_questions` VALUES (988,3,44,181,'در خلوت خود حس می‌کنم اثرات محرومیت هیجانی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,181);
INSERT INTO `test_questions` VALUES (989,3,45,182,'در خلوت خود حس می‌کنم اثرات رهاشدگی / بی‌ثباتی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,182);
INSERT INTO `test_questions` VALUES (990,3,46,183,'در خلوت خود حس می‌کنم اثرات بی‌اعتمادی / بدرفتاری مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,183);
INSERT INTO `test_questions` VALUES (991,3,47,184,'در خلوت خود حس می‌کنم اثرات انزوای اجتماعی / بیگانگی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,184);
INSERT INTO `test_questions` VALUES (992,3,48,185,'در خلوت خود حس می‌کنم اثرات نقص / شرم مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,185);
INSERT INTO `test_questions` VALUES (993,3,49,186,'در خلوت خود حس می‌کنم اثرات شکست مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,186);
INSERT INTO `test_questions` VALUES (994,3,50,187,'در خلوت خود حس می‌کنم اثرات وابستگی / بی‌کفایتی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,187);
INSERT INTO `test_questions` VALUES (995,3,51,188,'در خلوت خود حس می‌کنم اثرات آسیب‌پذیری به ضرر یا بیماری مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,188);
INSERT INTO `test_questions` VALUES (996,3,52,189,'در خلوت خود حس می‌کنم اثرات گرفتاری / خویشتن تحول‌نیافته مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,189);
INSERT INTO `test_questions` VALUES (997,3,53,190,'در خلوت خود حس می‌کنم اثرات اطاعت / تسلیم مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,190);
INSERT INTO `test_questions` VALUES (998,3,54,191,'در خلوت خود حس می‌کنم اثرات ایثار و فداکاری مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,191);
INSERT INTO `test_questions` VALUES (999,3,55,192,'در خلوت خود حس می‌کنم اثرات پذیرش‌جویی / جلب توجه مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,192);
INSERT INTO `test_questions` VALUES (1000,3,56,193,'در خلوت خود حس می‌کنم اثرات منفی‌گرایی / بدبینی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,193);
INSERT INTO `test_questions` VALUES (1001,3,57,194,'در خلوت خود حس می‌کنم اثرات بازداری هیجانی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,194);
INSERT INTO `test_questions` VALUES (1002,3,58,195,'در خلوت خود حس می‌کنم اثرات معیارهای سرسختانه مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,195);
INSERT INTO `test_questions` VALUES (1003,3,59,196,'در خلوت خود حس می‌کنم اثرات استحقاق / بزرگ‌منشی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,196);
INSERT INTO `test_questions` VALUES (1004,3,60,197,'در خلوت خود حس می‌کنم اثرات خویشتن‌داری ناکافی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,197);
INSERT INTO `test_questions` VALUES (1005,3,61,198,'در خلوت خود حس می‌کنم اثرات تنبیه‌گرایی و بی‌رحمی مانع از تجربه آرامش و آزادی کامل درونم می‌شود.',0,NULL,198);
INSERT INTO `test_questions` VALUES (1006,3,44,199,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر محرومیت هیجانی قرار داشته است.',0,NULL,199);
INSERT INTO `test_questions` VALUES (1007,3,45,200,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر رهاشدگی / بی‌ثباتی قرار داشته است.',0,NULL,200);
INSERT INTO `test_questions` VALUES (1008,3,46,201,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر بی‌اعتمادی / بدرفتاری قرار داشته است.',0,NULL,201);
INSERT INTO `test_questions` VALUES (1009,3,47,202,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر انزوای اجتماعی / بیگانگی قرار داشته است.',0,NULL,202);
INSERT INTO `test_questions` VALUES (1010,3,48,203,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر نقص / شرم قرار داشته است.',0,NULL,203);
INSERT INTO `test_questions` VALUES (1011,3,49,204,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر شکست قرار داشته است.',0,NULL,204);
INSERT INTO `test_questions` VALUES (1012,3,50,205,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر وابستگی / بی‌کفایتی قرار داشته است.',0,NULL,205);
INSERT INTO `test_questions` VALUES (1013,3,51,206,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر آسیب‌پذیری به ضرر یا بیماری قرار داشته است.',0,NULL,206);
INSERT INTO `test_questions` VALUES (1014,3,52,207,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر گرفتاری / خویشتن تحول‌نیافته قرار داشته است.',0,NULL,207);
INSERT INTO `test_questions` VALUES (1015,3,53,208,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر اطاعت / تسلیم قرار داشته است.',0,NULL,208);
INSERT INTO `test_questions` VALUES (1016,3,54,209,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر ایثار و فداکاری قرار داشته است.',0,NULL,209);
INSERT INTO `test_questions` VALUES (1017,3,55,210,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر پذیرش‌جویی / جلب توجه قرار داشته است.',0,NULL,210);
INSERT INTO `test_questions` VALUES (1018,3,56,211,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر منفی‌گرایی / بدبینی قرار داشته است.',0,NULL,211);
INSERT INTO `test_questions` VALUES (1019,3,57,212,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر بازداری هیجانی قرار داشته است.',0,NULL,212);
INSERT INTO `test_questions` VALUES (1020,3,58,213,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر معیارهای سرسختانه قرار داشته است.',0,NULL,213);
INSERT INTO `test_questions` VALUES (1021,3,59,214,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر استحقاق / بزرگ‌منشی قرار داشته است.',0,NULL,214);
INSERT INTO `test_questions` VALUES (1022,3,60,215,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر خویشتن‌داری ناکافی قرار داشته است.',0,NULL,215);
INSERT INTO `test_questions` VALUES (1023,3,61,216,'روابط عاطفی و شغلی من به گونه‌ای تکرارشونده تحت تأثیر تنبیه‌گرایی و بی‌رحمی قرار داشته است.',0,NULL,216);
INSERT INTO `test_questions` VALUES (1024,3,44,217,'شناخت و درمان الگوهای ناشی از محرومیت هیجانی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,217);
INSERT INTO `test_questions` VALUES (1025,3,45,218,'شناخت و درمان الگوهای ناشی از رهاشدگی / بی‌ثباتی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,218);
INSERT INTO `test_questions` VALUES (1026,3,46,219,'شناخت و درمان الگوهای ناشی از بی‌اعتمادی / بدرفتاری را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,219);
INSERT INTO `test_questions` VALUES (1027,3,47,220,'شناخت و درمان الگوهای ناشی از انزوای اجتماعی / بیگانگی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,220);
INSERT INTO `test_questions` VALUES (1028,3,48,221,'شناخت و درمان الگوهای ناشی از نقص / شرم را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,221);
INSERT INTO `test_questions` VALUES (1029,3,49,222,'شناخت و درمان الگوهای ناشی از شکست را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,222);
INSERT INTO `test_questions` VALUES (1030,3,50,223,'شناخت و درمان الگوهای ناشی از وابستگی / بی‌کفایتی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,223);
INSERT INTO `test_questions` VALUES (1031,3,51,224,'شناخت و درمان الگوهای ناشی از آسیب‌پذیری به ضرر یا بیماری را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,224);
INSERT INTO `test_questions` VALUES (1032,3,52,225,'شناخت و درمان الگوهای ناشی از گرفتاری / خویشتن تحول‌نیافته را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,225);
INSERT INTO `test_questions` VALUES (1033,3,53,226,'شناخت و درمان الگوهای ناشی از اطاعت / تسلیم را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,226);
INSERT INTO `test_questions` VALUES (1034,3,54,227,'شناخت و درمان الگوهای ناشی از ایثار و فداکاری را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,227);
INSERT INTO `test_questions` VALUES (1035,3,55,228,'شناخت و درمان الگوهای ناشی از پذیرش‌جویی / جلب توجه را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,228);
INSERT INTO `test_questions` VALUES (1036,3,56,229,'شناخت و درمان الگوهای ناشی از منفی‌گرایی / بدبینی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,229);
INSERT INTO `test_questions` VALUES (1037,3,57,230,'شناخت و درمان الگوهای ناشی از بازداری هیجانی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,230);
INSERT INTO `test_questions` VALUES (1038,3,58,231,'شناخت و درمان الگوهای ناشی از معیارهای سرسختانه را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,231);
INSERT INTO `test_questions` VALUES (1039,3,59,232,'شناخت و درمان الگوهای ناشی از استحقاق / بزرگ‌منشی را یک نیاز حیاتی برای رشد شخصی خود می‌دانم.',0,NULL,232);
INSERT INTO `test_questions` VALUES (1040,4,62,1,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با مردم‌آمیزی / گرم‌خویی است.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1041,4,63,2,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با استدلال و هوش سیال است.',0,NULL,2);
INSERT INTO `test_questions` VALUES (1042,4,64,3,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با پایداری هیجانی است.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1043,4,65,4,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با سلطه‌گری / قاطعیت است.',0,NULL,4);
INSERT INTO `test_questions` VALUES (1044,4,66,5,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با سرزندگی و نشاط است.',0,NULL,5);
INSERT INTO `test_questions` VALUES (1045,4,67,6,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با قانون‌گرایی و وجدان است.',0,NULL,6);
INSERT INTO `test_questions` VALUES (1046,4,68,7,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با جسارت اجتماعی است.',0,NULL,7);
INSERT INTO `test_questions` VALUES (1047,4,69,8,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با حساسیت هیجانی است.',0,NULL,8);
INSERT INTO `test_questions` VALUES (1048,4,70,9,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با هوشیاری و سوءظن است.',0,NULL,9);
INSERT INTO `test_questions` VALUES (1049,4,71,10,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با خیال‌پردازی است.',0,NULL,10);
INSERT INTO `test_questions` VALUES (1050,4,72,11,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با کاردانی اجتماعی و محافظه‌کاری است.',0,NULL,11);
INSERT INTO `test_questions` VALUES (1051,4,73,12,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با تمایل به حس گناه و اضطراب است.',0,NULL,12);
INSERT INTO `test_questions` VALUES (1052,4,74,13,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با تجربه‌پذیری و گشودگی به تحول است.',0,NULL,13);
INSERT INTO `test_questions` VALUES (1053,4,75,14,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با خوداتکایی و استقلال فردی است.',0,NULL,14);
INSERT INTO `test_questions` VALUES (1054,4,76,15,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با کمال‌گرایی و کنترل رفتار است.',0,NULL,15);
INSERT INTO `test_questions` VALUES (1055,4,77,16,'در بیشتر موقعیت‌های شغلی و اجتماعی، ترجیح من تطابق کامل با تنش و برانگیختگی است.',0,NULL,16);
INSERT INTO `test_questions` VALUES (1056,4,62,17,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه مردم‌آمیزی / گرم‌خویی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,17);
INSERT INTO `test_questions` VALUES (1057,4,63,18,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه استدلال و هوش سیال نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,18);
INSERT INTO `test_questions` VALUES (1058,4,64,19,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه پایداری هیجانی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,19);
INSERT INTO `test_questions` VALUES (1059,4,65,20,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه سلطه‌گری / قاطعیت نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,20);
INSERT INTO `test_questions` VALUES (1060,4,66,21,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه سرزندگی و نشاط نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,21);
INSERT INTO `test_questions` VALUES (1061,4,67,22,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه قانون‌گرایی و وجدان نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,22);
INSERT INTO `test_questions` VALUES (1062,4,68,23,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه جسارت اجتماعی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,23);
INSERT INTO `test_questions` VALUES (1063,4,69,24,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه حساسیت هیجانی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,24);
INSERT INTO `test_questions` VALUES (1064,4,70,25,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه هوشیاری و سوءظن نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,25);
INSERT INTO `test_questions` VALUES (1065,4,71,26,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه خیال‌پردازی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,26);
INSERT INTO `test_questions` VALUES (1066,4,72,27,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه کاردانی اجتماعی و محافظه‌کاری نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,27);
INSERT INTO `test_questions` VALUES (1067,4,73,28,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه تمایل به حس گناه و اضطراب نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,28);
INSERT INTO `test_questions` VALUES (1068,4,74,29,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه تجربه‌پذیری و گشودگی به تحول نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,29);
INSERT INTO `test_questions` VALUES (1069,4,75,30,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه خوداتکایی و استقلال فردی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,30);
INSERT INTO `test_questions` VALUES (1070,4,76,31,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه کمال‌گرایی و کنترل رفتار نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,31);
INSERT INTO `test_questions` VALUES (1071,4,77,32,'هنگام تصمیم‌گیری در شرایط دشوار، مؤلفه تنش و برانگیختگی نقش تعیین‌کننده‌ای در رفتار من دارد.',0,NULL,32);
INSERT INTO `test_questions` VALUES (1072,4,62,33,'به نظر من داشتن رویکرد مردم‌آمیزی / گرم‌خویی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,33);
INSERT INTO `test_questions` VALUES (1073,4,63,34,'به نظر من داشتن رویکرد استدلال و هوش سیال نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,34);
INSERT INTO `test_questions` VALUES (1074,4,64,35,'به نظر من داشتن رویکرد پایداری هیجانی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,35);
INSERT INTO `test_questions` VALUES (1075,4,65,36,'به نظر من داشتن رویکرد سلطه‌گری / قاطعیت نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,36);
INSERT INTO `test_questions` VALUES (1076,4,66,37,'به نظر من داشتن رویکرد سرزندگی و نشاط نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,37);
INSERT INTO `test_questions` VALUES (1077,4,67,38,'به نظر من داشتن رویکرد قانون‌گرایی و وجدان نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,38);
INSERT INTO `test_questions` VALUES (1078,4,68,39,'به نظر من داشتن رویکرد جسارت اجتماعی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,39);
INSERT INTO `test_questions` VALUES (1079,4,69,40,'به نظر من داشتن رویکرد حساسیت هیجانی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,40);
INSERT INTO `test_questions` VALUES (1080,4,70,41,'به نظر من داشتن رویکرد هوشیاری و سوءظن نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,41);
INSERT INTO `test_questions` VALUES (1081,4,71,42,'به نظر من داشتن رویکرد خیال‌پردازی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,42);
INSERT INTO `test_questions` VALUES (1082,4,72,43,'به نظر من داشتن رویکرد کاردانی اجتماعی و محافظه‌کاری نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,43);
INSERT INTO `test_questions` VALUES (1083,4,73,44,'به نظر من داشتن رویکرد تمایل به حس گناه و اضطراب نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,44);
INSERT INTO `test_questions` VALUES (1084,4,74,45,'به نظر من داشتن رویکرد تجربه‌پذیری و گشودگی به تحول نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,45);
INSERT INTO `test_questions` VALUES (1085,4,75,46,'به نظر من داشتن رویکرد خوداتکایی و استقلال فردی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,46);
INSERT INTO `test_questions` VALUES (1086,4,76,47,'به نظر من داشتن رویکرد کمال‌گرایی و کنترل رفتار نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,47);
INSERT INTO `test_questions` VALUES (1087,4,77,48,'به نظر من داشتن رویکرد تنش و برانگیختگی نشانه بلوغ و قدرت شخصیتی یک فرد است.',0,NULL,48);
INSERT INTO `test_questions` VALUES (1088,4,62,49,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه مردم‌آمیزی / گرم‌خویی الگوی مشخصی دارد.',0,NULL,49);
INSERT INTO `test_questions` VALUES (1089,4,63,50,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه استدلال و هوش سیال الگوی مشخصی دارد.',0,NULL,50);
INSERT INTO `test_questions` VALUES (1090,4,64,51,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه پایداری هیجانی الگوی مشخصی دارد.',0,NULL,51);
INSERT INTO `test_questions` VALUES (1091,4,65,52,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه سلطه‌گری / قاطعیت الگوی مشخصی دارد.',0,NULL,52);
INSERT INTO `test_questions` VALUES (1092,4,66,53,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه سرزندگی و نشاط الگوی مشخصی دارد.',0,NULL,53);
INSERT INTO `test_questions` VALUES (1093,4,67,54,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه قانون‌گرایی و وجدان الگوی مشخصی دارد.',0,NULL,54);
INSERT INTO `test_questions` VALUES (1094,4,68,55,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه جسارت اجتماعی الگوی مشخصی دارد.',0,NULL,55);
INSERT INTO `test_questions` VALUES (1095,4,69,56,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه حساسیت هیجانی الگوی مشخصی دارد.',0,NULL,56);
INSERT INTO `test_questions` VALUES (1096,4,70,57,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه هوشیاری و سوءظن الگوی مشخصی دارد.',0,NULL,57);
INSERT INTO `test_questions` VALUES (1097,4,71,58,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه خیال‌پردازی الگوی مشخصی دارد.',0,NULL,58);
INSERT INTO `test_questions` VALUES (1098,4,72,59,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه کاردانی اجتماعی و محافظه‌کاری الگوی مشخصی دارد.',0,NULL,59);
INSERT INTO `test_questions` VALUES (1099,4,73,60,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه تمایل به حس گناه و اضطراب الگوی مشخصی دارد.',0,NULL,60);
INSERT INTO `test_questions` VALUES (1100,4,74,61,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه تجربه‌پذیری و گشودگی به تحول الگوی مشخصی دارد.',0,NULL,61);
INSERT INTO `test_questions` VALUES (1101,4,75,62,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه خوداتکایی و استقلال فردی الگوی مشخصی دارد.',0,NULL,62);
INSERT INTO `test_questions` VALUES (1102,4,76,63,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه کمال‌گرایی و کنترل رفتار الگوی مشخصی دارد.',0,NULL,63);
INSERT INTO `test_questions` VALUES (1103,4,77,64,'بیشتر دوستانم مرا فردی توصیف می‌کنند که در زمینه تنش و برانگیختگی الگوی مشخصی دارد.',0,NULL,64);
INSERT INTO `test_questions` VALUES (1104,4,62,65,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه مردم‌آمیزی / گرم‌خویی واکنش نشان می‌دهم.',0,NULL,65);
INSERT INTO `test_questions` VALUES (1105,4,63,66,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه استدلال و هوش سیال واکنش نشان می‌دهم.',0,NULL,66);
INSERT INTO `test_questions` VALUES (1106,4,64,67,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه پایداری هیجانی واکنش نشان می‌دهم.',0,NULL,67);
INSERT INTO `test_questions` VALUES (1107,4,65,68,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه سلطه‌گری / قاطعیت واکنش نشان می‌دهم.',0,NULL,68);
INSERT INTO `test_questions` VALUES (1108,4,66,69,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه سرزندگی و نشاط واکنش نشان می‌دهم.',0,NULL,69);
INSERT INTO `test_questions` VALUES (1109,4,67,70,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه قانون‌گرایی و وجدان واکنش نشان می‌دهم.',0,NULL,70);
INSERT INTO `test_questions` VALUES (1110,4,68,71,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه جسارت اجتماعی واکنش نشان می‌دهم.',0,NULL,71);
INSERT INTO `test_questions` VALUES (1111,4,69,72,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه حساسیت هیجانی واکنش نشان می‌دهم.',0,NULL,72);
INSERT INTO `test_questions` VALUES (1112,4,70,73,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه هوشیاری و سوءظن واکنش نشان می‌دهم.',0,NULL,73);
INSERT INTO `test_questions` VALUES (1113,4,71,74,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه خیال‌پردازی واکنش نشان می‌دهم.',0,NULL,74);
INSERT INTO `test_questions` VALUES (1114,4,72,75,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه کاردانی اجتماعی و محافظه‌کاری واکنش نشان می‌دهم.',0,NULL,75);
INSERT INTO `test_questions` VALUES (1115,4,73,76,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه تمایل به حس گناه و اضطراب واکنش نشان می‌دهم.',0,NULL,76);
INSERT INTO `test_questions` VALUES (1116,4,74,77,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه تجربه‌پذیری و گشودگی به تحول واکنش نشان می‌دهم.',0,NULL,77);
INSERT INTO `test_questions` VALUES (1117,4,75,78,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه خوداتکایی و استقلال فردی واکنش نشان می‌دهم.',0,NULL,78);
INSERT INTO `test_questions` VALUES (1118,4,76,79,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه کمال‌گرایی و کنترل رفتار واکنش نشان می‌دهم.',0,NULL,79);
INSERT INTO `test_questions` VALUES (1119,4,77,80,'در مواجهه با تغییرات پیش‌بینی‌نشده، معمولاً بر پایه تنش و برانگیختگی واکنش نشان می‌دهم.',0,NULL,80);
INSERT INTO `test_questions` VALUES (1120,4,62,81,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه مردم‌آمیزی / گرم‌خویی من سازگارتر است.',0,NULL,81);
INSERT INTO `test_questions` VALUES (1121,4,63,82,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه استدلال و هوش سیال من سازگارتر است.',0,NULL,82);
INSERT INTO `test_questions` VALUES (1122,4,64,83,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه پایداری هیجانی من سازگارتر است.',0,NULL,83);
INSERT INTO `test_questions` VALUES (1123,4,65,84,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه سلطه‌گری / قاطعیت من سازگارتر است.',0,NULL,84);
INSERT INTO `test_questions` VALUES (1124,4,66,85,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه سرزندگی و نشاط من سازگارتر است.',0,NULL,85);
INSERT INTO `test_questions` VALUES (1125,4,67,86,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه قانون‌گرایی و وجدان من سازگارتر است.',0,NULL,86);
INSERT INTO `test_questions` VALUES (1126,4,68,87,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه جسارت اجتماعی من سازگارتر است.',0,NULL,87);
INSERT INTO `test_questions` VALUES (1127,4,69,88,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه حساسیت هیجانی من سازگارتر است.',0,NULL,88);
INSERT INTO `test_questions` VALUES (1128,4,70,89,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه هوشیاری و سوءظن من سازگارتر است.',0,NULL,89);
INSERT INTO `test_questions` VALUES (1129,4,71,90,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه خیال‌پردازی من سازگارتر است.',0,NULL,90);
INSERT INTO `test_questions` VALUES (1130,4,72,91,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه کاردانی اجتماعی و محافظه‌کاری من سازگارتر است.',0,NULL,91);
INSERT INTO `test_questions` VALUES (1131,4,73,92,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه تمایل به حس گناه و اضطراب من سازگارتر است.',0,NULL,92);
INSERT INTO `test_questions` VALUES (1132,4,74,93,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه تجربه‌پذیری و گشودگی به تحول من سازگارتر است.',0,NULL,93);
INSERT INTO `test_questions` VALUES (1133,4,75,94,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه خوداتکایی و استقلال فردی من سازگارتر است.',0,NULL,94);
INSERT INTO `test_questions` VALUES (1134,4,76,95,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه کمال‌گرایی و کنترل رفتار من سازگارتر است.',0,NULL,95);
INSERT INTO `test_questions` VALUES (1135,4,77,96,'من ترجیح می‌دهم فعالیت‌هایی را انتخاب کنم که با روحیه تنش و برانگیختگی من سازگارتر است.',0,NULL,96);
INSERT INTO `test_questions` VALUES (1136,4,62,97,'در کار تیمی و مدیریت وظایف، حفظ تعادل در مردم‌آمیزی / گرم‌خویی را بسیار حیاتی می‌دانم.',0,NULL,97);
INSERT INTO `test_questions` VALUES (1137,4,63,98,'در کار تیمی و مدیریت وظایف، حفظ تعادل در استدلال و هوش سیال را بسیار حیاتی می‌دانم.',0,NULL,98);
INSERT INTO `test_questions` VALUES (1138,4,64,99,'در کار تیمی و مدیریت وظایف، حفظ تعادل در پایداری هیجانی را بسیار حیاتی می‌دانم.',0,NULL,99);
INSERT INTO `test_questions` VALUES (1139,4,65,100,'در کار تیمی و مدیریت وظایف، حفظ تعادل در سلطه‌گری / قاطعیت را بسیار حیاتی می‌دانم.',0,NULL,100);
INSERT INTO `test_questions` VALUES (1140,4,66,101,'در کار تیمی و مدیریت وظایف، حفظ تعادل در سرزندگی و نشاط را بسیار حیاتی می‌دانم.',0,NULL,101);
INSERT INTO `test_questions` VALUES (1141,4,67,102,'در کار تیمی و مدیریت وظایف، حفظ تعادل در قانون‌گرایی و وجدان را بسیار حیاتی می‌دانم.',0,NULL,102);
INSERT INTO `test_questions` VALUES (1142,4,68,103,'در کار تیمی و مدیریت وظایف، حفظ تعادل در جسارت اجتماعی را بسیار حیاتی می‌دانم.',0,NULL,103);
INSERT INTO `test_questions` VALUES (1143,4,69,104,'در کار تیمی و مدیریت وظایف، حفظ تعادل در حساسیت هیجانی را بسیار حیاتی می‌دانم.',0,NULL,104);
INSERT INTO `test_questions` VALUES (1144,4,70,105,'در کار تیمی و مدیریت وظایف، حفظ تعادل در هوشیاری و سوءظن را بسیار حیاتی می‌دانم.',0,NULL,105);
INSERT INTO `test_questions` VALUES (1145,4,71,106,'در کار تیمی و مدیریت وظایف، حفظ تعادل در خیال‌پردازی را بسیار حیاتی می‌دانم.',0,NULL,106);
INSERT INTO `test_questions` VALUES (1146,4,72,107,'در کار تیمی و مدیریت وظایف، حفظ تعادل در کاردانی اجتماعی و محافظه‌کاری را بسیار حیاتی می‌دانم.',0,NULL,107);
INSERT INTO `test_questions` VALUES (1147,4,73,108,'در کار تیمی و مدیریت وظایف، حفظ تعادل در تمایل به حس گناه و اضطراب را بسیار حیاتی می‌دانم.',0,NULL,108);
INSERT INTO `test_questions` VALUES (1148,4,74,109,'در کار تیمی و مدیریت وظایف، حفظ تعادل در تجربه‌پذیری و گشودگی به تحول را بسیار حیاتی می‌دانم.',0,NULL,109);
INSERT INTO `test_questions` VALUES (1149,4,75,110,'در کار تیمی و مدیریت وظایف، حفظ تعادل در خوداتکایی و استقلال فردی را بسیار حیاتی می‌دانم.',0,NULL,110);
INSERT INTO `test_questions` VALUES (1150,4,76,111,'در کار تیمی و مدیریت وظایف، حفظ تعادل در کمال‌گرایی و کنترل رفتار را بسیار حیاتی می‌دانم.',0,NULL,111);
INSERT INTO `test_questions` VALUES (1151,4,77,112,'در کار تیمی و مدیریت وظایف، حفظ تعادل در تنش و برانگیختگی را بسیار حیاتی می‌دانم.',0,NULL,112);
INSERT INTO `test_questions` VALUES (1152,4,62,113,'تجارب حرفه‌ای من نشان داده است که توجه به مردم‌آمیزی / گرم‌خویی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,113);
INSERT INTO `test_questions` VALUES (1153,4,63,114,'تجارب حرفه‌ای من نشان داده است که توجه به استدلال و هوش سیال باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,114);
INSERT INTO `test_questions` VALUES (1154,4,64,115,'تجارب حرفه‌ای من نشان داده است که توجه به پایداری هیجانی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,115);
INSERT INTO `test_questions` VALUES (1155,4,65,116,'تجارب حرفه‌ای من نشان داده است که توجه به سلطه‌گری / قاطعیت باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,116);
INSERT INTO `test_questions` VALUES (1156,4,66,117,'تجارب حرفه‌ای من نشان داده است که توجه به سرزندگی و نشاط باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,117);
INSERT INTO `test_questions` VALUES (1157,4,67,118,'تجارب حرفه‌ای من نشان داده است که توجه به قانون‌گرایی و وجدان باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,118);
INSERT INTO `test_questions` VALUES (1158,4,68,119,'تجارب حرفه‌ای من نشان داده است که توجه به جسارت اجتماعی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,119);
INSERT INTO `test_questions` VALUES (1159,4,69,120,'تجارب حرفه‌ای من نشان داده است که توجه به حساسیت هیجانی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,120);
INSERT INTO `test_questions` VALUES (1160,4,70,121,'تجارب حرفه‌ای من نشان داده است که توجه به هوشیاری و سوءظن باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,121);
INSERT INTO `test_questions` VALUES (1161,4,71,122,'تجارب حرفه‌ای من نشان داده است که توجه به خیال‌پردازی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,122);
INSERT INTO `test_questions` VALUES (1162,4,72,123,'تجارب حرفه‌ای من نشان داده است که توجه به کاردانی اجتماعی و محافظه‌کاری باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,123);
INSERT INTO `test_questions` VALUES (1163,4,73,124,'تجارب حرفه‌ای من نشان داده است که توجه به تمایل به حس گناه و اضطراب باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,124);
INSERT INTO `test_questions` VALUES (1164,4,74,125,'تجارب حرفه‌ای من نشان داده است که توجه به تجربه‌پذیری و گشودگی به تحول باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,125);
INSERT INTO `test_questions` VALUES (1165,4,75,126,'تجارب حرفه‌ای من نشان داده است که توجه به خوداتکایی و استقلال فردی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,126);
INSERT INTO `test_questions` VALUES (1166,4,76,127,'تجارب حرفه‌ای من نشان داده است که توجه به کمال‌گرایی و کنترل رفتار باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,127);
INSERT INTO `test_questions` VALUES (1167,4,77,128,'تجارب حرفه‌ای من نشان داده است که توجه به تنش و برانگیختگی باعث نتایج مطلوب‌تر می‌گردد.',0,NULL,128);
INSERT INTO `test_questions` VALUES (1168,4,62,129,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با مردم‌آمیزی / گرم‌خویی قائل هستم.',0,NULL,129);
INSERT INTO `test_questions` VALUES (1169,4,63,130,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با استدلال و هوش سیال قائل هستم.',0,NULL,130);
INSERT INTO `test_questions` VALUES (1170,4,64,131,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با پایداری هیجانی قائل هستم.',0,NULL,131);
INSERT INTO `test_questions` VALUES (1171,4,65,132,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با سلطه‌گری / قاطعیت قائل هستم.',0,NULL,132);
INSERT INTO `test_questions` VALUES (1172,4,66,133,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با سرزندگی و نشاط قائل هستم.',0,NULL,133);
INSERT INTO `test_questions` VALUES (1173,4,67,134,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با قانون‌گرایی و وجدان قائل هستم.',0,NULL,134);
INSERT INTO `test_questions` VALUES (1174,4,68,135,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با جسارت اجتماعی قائل هستم.',0,NULL,135);
INSERT INTO `test_questions` VALUES (1175,4,69,136,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با حساسیت هیجانی قائل هستم.',0,NULL,136);
INSERT INTO `test_questions` VALUES (1176,4,70,137,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با هوشیاری و سوءظن قائل هستم.',0,NULL,137);
INSERT INTO `test_questions` VALUES (1177,4,71,138,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با خیال‌پردازی قائل هستم.',0,NULL,138);
INSERT INTO `test_questions` VALUES (1178,4,72,139,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با کاردانی اجتماعی و محافظه‌کاری قائل هستم.',0,NULL,139);
INSERT INTO `test_questions` VALUES (1179,4,73,140,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با تمایل به حس گناه و اضطراب قائل هستم.',0,NULL,140);
INSERT INTO `test_questions` VALUES (1180,4,74,141,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با تجربه‌پذیری و گشودگی به تحول قائل هستم.',0,NULL,141);
INSERT INTO `test_questions` VALUES (1181,4,75,142,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با خوداتکایی و استقلال فردی قائل هستم.',0,NULL,142);
INSERT INTO `test_questions` VALUES (1182,4,76,143,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با کمال‌گرایی و کنترل رفتار قائل هستم.',0,NULL,143);
INSERT INTO `test_questions` VALUES (1183,4,77,144,'من در زندگی روزمره اهمیت فوق‌العاده‌ای برای اصول مرتبط با تنش و برانگیختگی قائل هستم.',0,NULL,144);
INSERT INTO `test_questions` VALUES (1184,4,62,145,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به مردم‌آمیزی / گرم‌خویی یکی از پایه‌های آن است.',0,NULL,145);
INSERT INTO `test_questions` VALUES (1185,4,63,146,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به استدلال و هوش سیال یکی از پایه‌های آن است.',0,NULL,146);
INSERT INTO `test_questions` VALUES (1186,4,64,147,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به پایداری هیجانی یکی از پایه‌های آن است.',0,NULL,147);
INSERT INTO `test_questions` VALUES (1187,4,65,148,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به سلطه‌گری / قاطعیت یکی از پایه‌های آن است.',0,NULL,148);
INSERT INTO `test_questions` VALUES (1188,4,66,149,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به سرزندگی و نشاط یکی از پایه‌های آن است.',0,NULL,149);
INSERT INTO `test_questions` VALUES (1189,4,67,150,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به قانون‌گرایی و وجدان یکی از پایه‌های آن است.',0,NULL,150);
INSERT INTO `test_questions` VALUES (1190,4,68,151,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به جسارت اجتماعی یکی از پایه‌های آن است.',0,NULL,151);
INSERT INTO `test_questions` VALUES (1191,4,69,152,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به حساسیت هیجانی یکی از پایه‌های آن است.',0,NULL,152);
INSERT INTO `test_questions` VALUES (1192,4,70,153,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به هوشیاری و سوءظن یکی از پایه‌های آن است.',0,NULL,153);
INSERT INTO `test_questions` VALUES (1193,4,71,154,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به خیال‌پردازی یکی از پایه‌های آن است.',0,NULL,154);
INSERT INTO `test_questions` VALUES (1194,4,72,155,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به کاردانی اجتماعی و محافظه‌کاری یکی از پایه‌های آن است.',0,NULL,155);
INSERT INTO `test_questions` VALUES (1195,4,73,156,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به تمایل به حس گناه و اضطراب یکی از پایه‌های آن است.',0,NULL,156);
INSERT INTO `test_questions` VALUES (1196,4,74,157,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به تجربه‌پذیری و گشودگی به تحول یکی از پایه‌های آن است.',0,NULL,157);
INSERT INTO `test_questions` VALUES (1197,4,75,158,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به خوداتکایی و استقلال فردی یکی از پایه‌های آن است.',0,NULL,158);
INSERT INTO `test_questions` VALUES (1198,4,76,159,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به کمال‌گرایی و کنترل رفتار یکی از پایه‌های آن است.',0,NULL,159);
INSERT INTO `test_questions` VALUES (1199,4,77,160,'اگر بخواهم سبک شخصی خودم را توصیف کنم، گرایش به تنش و برانگیختگی یکی از پایه‌های آن است.',0,NULL,160);
INSERT INTO `test_questions` VALUES (1200,4,62,161,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر مردم‌آمیزی / گرم‌خویی حفظ می‌کنم.',0,NULL,161);
INSERT INTO `test_questions` VALUES (1201,4,63,162,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر استدلال و هوش سیال حفظ می‌کنم.',0,NULL,162);
INSERT INTO `test_questions` VALUES (1202,4,64,163,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر پایداری هیجانی حفظ می‌کنم.',0,NULL,163);
INSERT INTO `test_questions` VALUES (1203,4,65,164,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر سلطه‌گری / قاطعیت حفظ می‌کنم.',0,NULL,164);
INSERT INTO `test_questions` VALUES (1204,4,66,165,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر سرزندگی و نشاط حفظ می‌کنم.',0,NULL,165);
INSERT INTO `test_questions` VALUES (1205,4,67,166,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر قانون‌گرایی و وجدان حفظ می‌کنم.',0,NULL,166);
INSERT INTO `test_questions` VALUES (1206,4,68,167,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر جسارت اجتماعی حفظ می‌کنم.',0,NULL,167);
INSERT INTO `test_questions` VALUES (1207,4,69,168,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر حساسیت هیجانی حفظ می‌کنم.',0,NULL,168);
INSERT INTO `test_questions` VALUES (1208,4,70,169,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر هوشیاری و سوءظن حفظ می‌کنم.',0,NULL,169);
INSERT INTO `test_questions` VALUES (1209,4,71,170,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر خیال‌پردازی حفظ می‌کنم.',0,NULL,170);
INSERT INTO `test_questions` VALUES (1210,4,72,171,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر کاردانی اجتماعی و محافظه‌کاری حفظ می‌کنم.',0,NULL,171);
INSERT INTO `test_questions` VALUES (1211,4,73,172,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر تمایل به حس گناه و اضطراب حفظ می‌کنم.',0,NULL,172);
INSERT INTO `test_questions` VALUES (1212,4,74,173,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر تجربه‌پذیری و گشودگی به تحول حفظ می‌کنم.',0,NULL,173);
INSERT INTO `test_questions` VALUES (1213,4,75,174,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر خوداتکایی و استقلال فردی حفظ می‌کنم.',0,NULL,174);
INSERT INTO `test_questions` VALUES (1214,4,76,175,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر کمال‌گرایی و کنترل رفتار حفظ می‌کنم.',0,NULL,175);
INSERT INTO `test_questions` VALUES (1215,4,77,176,'در شرایط پرفشار، کنترل درونی خود را از طریق تکیه بر تنش و برانگیختگی حفظ می‌کنم.',0,NULL,176);
INSERT INTO `test_questions` VALUES (1216,4,62,177,'برداشت کلی من از جهان و انسان‌ها با مفهوم مردم‌آمیزی / گرم‌خویی همسویی عمیقی دارد.',0,NULL,177);
INSERT INTO `test_questions` VALUES (1217,4,63,178,'برداشت کلی من از جهان و انسان‌ها با مفهوم استدلال و هوش سیال همسویی عمیقی دارد.',0,NULL,178);
INSERT INTO `test_questions` VALUES (1218,4,64,179,'برداشت کلی من از جهان و انسان‌ها با مفهوم پایداری هیجانی همسویی عمیقی دارد.',0,NULL,179);
INSERT INTO `test_questions` VALUES (1219,4,65,180,'برداشت کلی من از جهان و انسان‌ها با مفهوم سلطه‌گری / قاطعیت همسویی عمیقی دارد.',0,NULL,180);
INSERT INTO `test_questions` VALUES (1220,4,66,181,'برداشت کلی من از جهان و انسان‌ها با مفهوم سرزندگی و نشاط همسویی عمیقی دارد.',0,NULL,181);
INSERT INTO `test_questions` VALUES (1221,4,67,182,'برداشت کلی من از جهان و انسان‌ها با مفهوم قانون‌گرایی و وجدان همسویی عمیقی دارد.',0,NULL,182);
INSERT INTO `test_questions` VALUES (1222,4,68,183,'برداشت کلی من از جهان و انسان‌ها با مفهوم جسارت اجتماعی همسویی عمیقی دارد.',0,NULL,183);
INSERT INTO `test_questions` VALUES (1223,4,69,184,'برداشت کلی من از جهان و انسان‌ها با مفهوم حساسیت هیجانی همسویی عمیقی دارد.',0,NULL,184);
INSERT INTO `test_questions` VALUES (1224,4,70,185,'برداشت کلی من از جهان و انسان‌ها با مفهوم هوشیاری و سوءظن همسویی عمیقی دارد.',0,NULL,185);
INSERT INTO `test_questions` VALUES (1225,5,78,1,'لطفاً درجه کلی خوشبختی و شادی در رابطه مشترک خود را مشخص کنید.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1226,5,78,2,'در کل، چقدر از رابطه با شریک عاطفی‌تان احساس رضایت دارید؟',0,NULL,2);
INSERT INTO `test_questions` VALUES (1227,5,78,3,'ما چقدر با یکدیگر گرم، صمیمی و مهربان هستیم؟',0,NULL,3);
INSERT INTO `test_questions` VALUES (1228,5,78,4,'چقدر رابطه شما توانسته انتظارات و آرزوهای قلبی شما را برآورده سازد؟',0,NULL,4);
INSERT INTO `test_questions` VALUES (1229,5,78,5,'چقدر احساس می‌کنید پیوند شما با شریک زندگی‌تان مستحکم و استوار است؟',0,NULL,5);
INSERT INTO `test_questions` VALUES (1230,5,78,6,'من و شریکم علایق، اهداف و سرگرمی‌های مشترک زیادی داریم.',0,NULL,6);
INSERT INTO `test_questions` VALUES (1231,5,78,7,'میزان اطمینان و اعتماد متقابل در رابطه ما در بالاترین سطح است.',0,NULL,7);
INSERT INTO `test_questions` VALUES (1232,5,78,8,'من از تصمیم خود برای انتخاب این شریک عاطفی کاملاً خشنودم.',0,NULL,8);
INSERT INTO `test_questions` VALUES (1233,5,78,9,'شریک عاطفی من احساسات و نیازهای عاطفی مرا به خوبی می‌فهمد.',0,NULL,9);
INSERT INTO `test_questions` VALUES (1234,5,78,10,'ما به خوبی قادریم تعارضات و اختلافات نظر را با گفتگو حل کنیم.',0,NULL,10);
INSERT INTO `test_questions` VALUES (1235,5,78,11,'رابطه با شریک عاطفی‌ام به من احساس امنیت و آرامش روانی می‌دهد.',0,NULL,11);
INSERT INTO `test_questions` VALUES (1236,5,78,12,'تا چه حد به پایداری این رابطه در تمام طول عمر متعهد هستید؟',0,NULL,12);
INSERT INTO `test_questions` VALUES (1237,5,78,13,'ابراز عشق و کلمات محبت‌آمیز در زندگی مشترک ما مداوم و پرشور است.',0,NULL,13);
INSERT INTO `test_questions` VALUES (1238,5,78,14,'در روزهای بحرانی و سخت، شریکم بهترین پناه و تکیه‌گاه من است.',0,NULL,14);
INSERT INTO `test_questions` VALUES (1239,5,78,15,'بودن در کنار شریک عاطفی‌ام برایم لذت‌بخش و نشاط‌آور است.',0,NULL,15);
INSERT INTO `test_questions` VALUES (1240,5,78,16,'احترام متقابل و پذیرش بی‌قید و شرط در پیوند ما حاکم است.',0,NULL,16);
INSERT INTO `test_questions` VALUES (1241,5,78,17,'در حضور شریک عاطفی‌ام می‌توانم کاملاً خود واقعی‌ام باشم.',0,NULL,17);
INSERT INTO `test_questions` VALUES (1242,5,78,18,'کیفیت روابط عاطفی و صمیمانه ما بسیار بالاست.',0,NULL,18);
INSERT INTO `test_questions` VALUES (1243,5,78,19,'ما به عنوان یک تیم هماهنگ برنامه‌های زندگی را پیش می‌بریم.',0,NULL,19);
INSERT INTO `test_questions` VALUES (1244,5,78,20,'شریک زندگی‌ام به رشد شخصی و حرفه‌ای من صمیمانه بها می‌دهد.',0,NULL,20);
INSERT INTO `test_questions` VALUES (1245,5,78,21,'شور، نشاط و هیجان عاشقانه در رابطه ما هنوز زنده و در جریان است.',0,NULL,21);
INSERT INTO `test_questions` VALUES (1246,5,78,22,'حتی اگر فرصت انتخاب دوباره داشتم، باز هم همین فرد را برمی‌گزیدم.',0,NULL,22);
INSERT INTO `test_questions` VALUES (1247,5,78,23,'ما یکدیگر را عمیقاً درک کرده و نقاط ضعف هم را سرزنش نمی‌کنیم.',0,NULL,23);
INSERT INTO `test_questions` VALUES (1248,5,78,24,'میزان لذتی که از گفتگو و همنشینی با شریک عاطفی‌ام می‌برم بسیار زیاد است.',0,NULL,24);
INSERT INTO `test_questions` VALUES (1249,5,78,25,'ما برای آینده و اهداف مشترکمان چشم‌انداز روشن و امیدبخشی داریم.',0,NULL,25);
INSERT INTO `test_questions` VALUES (1250,5,78,26,'سطح درک متقابل در مسائل مالی و اداره امور خانه بسیار بالاست.',0,NULL,26);
INSERT INTO `test_questions` VALUES (1251,5,78,27,'رابطه ما به من انگیزه و امید فراوان برای کار و زندگی می‌بخشد.',0,NULL,27);
INSERT INTO `test_questions` VALUES (1252,5,78,28,'شریک عاطفی من بهترین دوست و محرم‌ترین رازدار من است.',0,NULL,28);
INSERT INTO `test_questions` VALUES (1253,5,78,29,'ما وقت‌های دونفره باکیفیتی را برای گردش و گفتگو اختصاص می‌دهیم.',0,NULL,29);
INSERT INTO `test_questions` VALUES (1254,5,78,30,'میزان گذشت و بخشش اشتباهات در رابطه ما چشمگیر است.',0,NULL,30);
INSERT INTO `test_questions` VALUES (1255,5,78,31,'من و شریکم احساس وابستگی و تعلق عاطفی سالمی به یکدیگر داریم.',0,NULL,31);
INSERT INTO `test_questions` VALUES (1256,5,78,32,'در یک نگاه جامع و نهایی، کیفیت رابطه زناشویی من در اوج شکوفایی است.',0,NULL,32);
INSERT INTO `test_questions` VALUES (1257,6,81,1,'برقرار کردن آرامش برایم دشوار بود.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1258,6,80,2,'متوجه خشکی دهانم شدم.',0,NULL,2);
INSERT INTO `test_questions` VALUES (1259,6,79,3,'اصلاً نمی‌توانستم هیچ احساس مثبتی را تجربه کنم.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1260,6,80,4,'دچار اختلال در تنفس شدم (مثلاً نفس نفس زدن مفرط بدون فعالیت بدنی).',0,NULL,4);
INSERT INTO `test_questions` VALUES (1261,6,79,5,'شروع کردن کارها برایم دشوار بود.',0,NULL,5);
INSERT INTO `test_questions` VALUES (1262,6,81,6,'تمایل داشتم نسبت به موقعیت‌ها واکنش بیش از حد نشان دهم.',0,NULL,6);
INSERT INTO `test_questions` VALUES (1263,6,80,7,'احساس لرزش می‌کردم (مثلاً در دستان).',0,NULL,7);
INSERT INTO `test_questions` VALUES (1264,6,81,8,'احساس می‌کردم انرژی عصبی زیادی مصرف می‌کنم.',0,NULL,8);
INSERT INTO `test_questions` VALUES (1265,6,80,9,'نگران موقعیت‌هایی بودم که ممکن بود دچار وحشت شده و مایه شرمساری‌ام شود.',0,NULL,9);
INSERT INTO `test_questions` VALUES (1266,6,79,10,'احساس می‌کردم چیزی برای امیدواری به آینده وجود ندارد.',0,NULL,10);
INSERT INTO `test_questions` VALUES (1267,6,81,11,'احساس می‌کردم بی‌قرار و کلافه هستم.',0,NULL,11);
INSERT INTO `test_questions` VALUES (1268,6,81,12,'آرام گرفتن برایم بسیار سخت بود.',0,NULL,12);
INSERT INTO `test_questions` VALUES (1269,6,79,13,'احساس غمگینی و دلمردگی می‌کردم.',0,NULL,13);
INSERT INTO `test_questions` VALUES (1270,6,81,14,'نسبت به هر چیزی که مانع ادامه کارم می‌شد ناشکیبا و کم‌تحمل بودم.',0,NULL,14);
INSERT INTO `test_questions` VALUES (1271,6,80,15,'احساس می‌کردم به مرز وحشت‌زدگی نزدیک شده‌ام.',0,NULL,15);
INSERT INTO `test_questions` VALUES (1272,6,79,16,'نمی‌توانستم نسبت به هیچ چیزی مشتاق و علاقه‌مند شوم.',0,NULL,16);
INSERT INTO `test_questions` VALUES (1273,6,79,17,'احساس می‌کردم به عنوان یک انسان ارزش زیادی ندارم.',0,NULL,17);
INSERT INTO `test_questions` VALUES (1274,6,81,18,'احساس می‌کردم خیلی زودرنج و حساس شده‌ام.',0,NULL,18);
INSERT INTO `test_questions` VALUES (1275,6,80,19,'بدون هیچ فعالیت بدنی، متوجه تپش قلب و ضربان شدید خود شدم.',0,NULL,19);
INSERT INTO `test_questions` VALUES (1276,6,80,20,'بی‌دلیل و بدون توجیه منطقی احساس ترس می‌کردم.',0,NULL,20);
INSERT INTO `test_questions` VALUES (1277,6,79,21,'احساس می‌کردم زندگی اصلاً معنا و ارزشی ندارد.',0,NULL,21);
INSERT INTO `test_questions` VALUES (1278,7,82,1,'احساس عصبی بودن، اضطراب، یا در لبه پرتگاه بودن.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1279,7,82,2,'عدم توانایی در متوقف کردن نگرانی یا کنترل آن.',0,NULL,2);
INSERT INTO `test_questions` VALUES (1280,7,82,3,'نگرانی بیش از حد در مورد مسائل مختلف.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1281,7,82,4,'دشواری در آرام گرفتن و احساس آرامش بدنی.',0,NULL,4);
INSERT INTO `test_questions` VALUES (1282,7,82,5,'آن‌قدر بی‌قرار بودن که آرام نشستن برایم سخت باشد.',0,NULL,5);
INSERT INTO `test_questions` VALUES (1283,7,82,6,'به آسانی رنجیدن یا تحریک‌پذیر و کلافه شدن.',0,NULL,6);
INSERT INTO `test_questions` VALUES (1284,7,82,7,'احساس ترس، انگار که قرار است اتفاق وحشتناکی رخ دهد.',0,NULL,7);
INSERT INTO `test_questions` VALUES (1285,8,83,1,'کاهش علاقه یا لذت بردن از انجام کارها و فعالیت‌ها.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1286,8,83,2,'احساس غمگینی، دلمردگی، یأس یا ناامیدی.',0,NULL,2);
INSERT INTO `test_questions` VALUES (1287,8,83,3,'دشواری در به خواب رفتن، بیدار شدن مکرر یا بیش از حد خوابیدن.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1288,8,83,4,'احساس خستگی مفرط یا کمبود شدید انرژی.',0,NULL,4);
INSERT INTO `test_questions` VALUES (1289,8,83,5,'کم‌اشتهایی شدید یا پرخوری افراطی.',0,NULL,5);
INSERT INTO `test_questions` VALUES (1290,8,83,6,'احساس بد نسبت به خود؛ اینکه یک بازنده هستید یا خود و خانواده‌تان را ناامید کرده‌اید.',0,NULL,6);
INSERT INTO `test_questions` VALUES (1291,8,83,7,'دشواری در تمرکز بر روی کارها، مثل مطالعه روزنامه یا تماشای تلویزیون.',0,NULL,7);
INSERT INTO `test_questions` VALUES (1292,8,83,8,'کند شدن حرکات یا تکلم به نحوی که دیگران متوجه شوند؛ یا برعکس، بی‌قراری و جنب‌وجوش مفرط.',0,NULL,8);
INSERT INTO `test_questions` VALUES (1293,8,83,9,'افکاری مبنی بر اینکه کاش مرده بودید یا اینکه به طریقی به خودتان آسیب برسانید.',0,NULL,9);
INSERT INTO `test_questions` VALUES (1294,9,84,1,'در کل احساس می‌کنم فردی ارزشمند هستم، دست‌کم هم‌پایه دیگران.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1295,9,84,2,'گاهی احساس می‌کنم در هیچ کاری مهارت و شایستگی ندارم.',1,NULL,2);
INSERT INTO `test_questions` VALUES (1296,9,84,3,'احساس می‌کنم ویژگی‌ها و خصوصیات مثبت متعددی دارم.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1297,9,84,4,'قادرم کارها را به همان خوبی که اکثر مردم انجام می‌دهند، به انجام برسانم.',0,NULL,4);
INSERT INTO `test_questions` VALUES (1298,9,84,5,'احساس می‌کنم چیزهای زیادی در من وجود ندارد که به آن‌ها افتخار کنم.',1,NULL,5);
INSERT INTO `test_questions` VALUES (1299,9,84,6,'گاهی اوقات حتماً احساس می‌کنم بی‌فایده و بی‌مصرف هستم.',1,NULL,6);
INSERT INTO `test_questions` VALUES (1300,9,84,7,'احساس می‌کنم دست‌کم به اندازه دیگران فردی محترم و ارزشمند هستم.',0,NULL,7);
INSERT INTO `test_questions` VALUES (1301,9,84,8,'ای کاش می‌توانستم احترام و پذیرش بیشتری نسبت به خودم قائل شوم.',1,NULL,8);
INSERT INTO `test_questions` VALUES (1302,9,84,9,'همه شواهد مرا به این فکر می‌اندازد که فرد شکست‌خورده‌ای هستم.',1,NULL,9);
INSERT INTO `test_questions` VALUES (1303,9,84,10,'من نگرش مثبت و سازنده‌ای نسبت به خودم دارم.',0,NULL,10);
INSERT INTO `test_questions` VALUES (1304,10,85,1,'در اکثر جنبه‌ها، زندگی من به شرایط ایده‌آل و مطلوبم نزدیک است.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1305,10,85,2,'شرایط زندگی من عالی و رضایت‌بخش است.',0,NULL,2);
INSERT INTO `test_questions` VALUES (1306,10,85,3,'من از کیفیت و روند کلی زندگی‌ام کاملاً راضی هستم.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1307,10,85,4,'تاکنون چیزهای مهمی را که در زندگی می‌خواسته‌ام به دست آورده‌ام.',0,NULL,4);
INSERT INTO `test_questions` VALUES (1308,10,85,5,'اگر می‌توانستم زندگی‌ام را دوباره زندگی کنم، تقریباً هیچ‌چیز را تغییر نمی‌دادم.',0,NULL,5);
INSERT INTO `test_questions` VALUES (1309,11,86,1,'من نگرانم که مبادا شریک عاطفی‌ام مرا به اندازه من دوست نداشته باشد.',0,NULL,1);
INSERT INTO `test_questions` VALUES (1310,11,86,2,'غالباً نگرانم که شریک زندگی‌ام مرا ترک کند یا از رابطه با من دلسرد شود.',0,NULL,2);
INSERT INTO `test_questions` VALUES (1311,11,86,3,'خیلی نگرانم که شریک عاطفی‌ام به من اهمیتی ندهد یا مرا نادیده بگیرد.',0,NULL,3);
INSERT INTO `test_questions` VALUES (1312,11,86,4,'وقتی شریک عاطفی‌ام در دسترسم نیست، احساس ناامنی و ترس شدیدی می‌کنم.',0,NULL,4);
INSERT INTO `test_questions` VALUES (1313,11,86,5,'احساس می‌کنم اشتیاق من به صمیمیت، بیشتر از اشتیاق طرف مقابلم است.',0,NULL,5);
INSERT INTO `test_questions` VALUES (1314,11,86,6,'غالباً احساس می‌کنم که برای شریک عاطفی‌ام کافی و کامل نیستم.',0,NULL,6);
INSERT INTO `test_questions` VALUES (1315,11,86,7,'من به اطمینان‌بخشی و تأیید مکرر از سوی شریک عاطفی‌ام نیاز دارم.',0,NULL,7);
INSERT INTO `test_questions` VALUES (1316,11,86,8,'اگر متوجه کوچک‌ترین تغییری در رفتار او شوم، فوراً وحشت‌زده می‌شوم.',0,NULL,8);
INSERT INTO `test_questions` VALUES (1317,11,86,9,'وقتی احساساتم را ابراز می‌کنم، می‌ترسم او حس کند من خیلی وابسته‌ام.',0,NULL,9);
INSERT INTO `test_questions` VALUES (1318,11,86,10,'ترس از تنهایی و طرد شدن بر بسیاری از تصمیمات عاطفی‌ام سایه افکنده است.',0,NULL,10);
INSERT INTO `test_questions` VALUES (1319,11,86,11,'ذهنم دائماً درگیر این است که آیا رابطه ما در آینده دوام خواهد داشت یا خیر.',0,NULL,11);
INSERT INTO `test_questions` VALUES (1320,11,86,12,'وقتی اختلافی پیش می‌آید، احساس می‌کنم تمام دنیای من در خطر فروپاشی است.',0,NULL,12);
INSERT INTO `test_questions` VALUES (1321,11,86,13,'تمایل دارم در رابطه خودم را فدا کنم تا شریکم مرا رها نکند.',0,NULL,13);
INSERT INTO `test_questions` VALUES (1322,11,86,14,'خیلی زود احساس می‌کنم طرد یا بی‌ارزش شده‌ام.',0,NULL,14);
INSERT INTO `test_questions` VALUES (1323,11,86,15,'نیاز دارم که شریک عاطفی‌ام مداوم به من بگوید که چقدر برایش مهم هستم.',0,NULL,15);
INSERT INTO `test_questions` VALUES (1324,11,86,16,'نسبت به رفتارهای کوچک یا سردی احتمالی شریکم بسیار حساس و دلواپسم.',0,NULL,16);
INSERT INTO `test_questions` VALUES (1325,11,86,17,'گاهی احساس می‌کنم ارزش من کاملاً وابسته به رضایت شریک عاطفی‌ام است.',0,NULL,17);
INSERT INTO `test_questions` VALUES (1326,11,86,18,'ترس از دست دادن پیوند عاطفی‌ام مانع از آرامش فکری‌ام می‌شود.',0,NULL,18);
INSERT INTO `test_questions` VALUES (1327,11,87,19,'من ترجیح می‌دهم احساسات و آسیب‌پذیری‌های درونی‌ام را با شریکم در میان نگذارم.',0,NULL,19);
INSERT INTO `test_questions` VALUES (1328,11,87,20,'وقتی کسی در رابطه خیلی به من نزدیک می‌شود، احساس معذب بودن و خفگی می‌کنم.',0,NULL,20);
INSERT INTO `test_questions` VALUES (1329,11,87,21,'برای من دشوار است که به شریک عاطفی‌ام عمیقاً اعتماد کرده و به او تکیه کنم.',0,NULL,21);
INSERT INTO `test_questions` VALUES (1330,11,87,22,'ترجیح می‌دهم مشکلاتم را تنهایی حل کنم تا اینکه از شریک عاطفی‌ام کمک بخواهم.',0,NULL,22);
INSERT INTO `test_questions` VALUES (1331,11,87,23,'وقتی شریک عاطفی‌ام انتظار صمیمیت بیش از حد دارد، عقب‌نشینی می‌کنم.',0,NULL,23);
INSERT INTO `test_questions` VALUES (1332,11,87,24,'من حس استقلال و خودکفایی‌ام را به هرگونه وابستگی عاطفی ترجیح می‌دهم.',0,NULL,24);
INSERT INTO `test_questions` VALUES (1333,11,87,25,'ابراز احساسات عمیق و واگویه کردن نیازهای عاطفی برایم کاری سخت و ناخوشایند است.',0,NULL,25);
INSERT INTO `test_questions` VALUES (1334,11,87,26,'به ندرت احساس می‌کنم نیاز دارم تمام افکار و احساساتم را با شریکم در میان بگذارم.',0,NULL,26);
INSERT INTO `test_questions` VALUES (1335,11,87,27,'وقتی شریکم ابراز نیاز به نزدیکی زیاد می‌کند، احساس تنش و فاصله می‌کنم.',0,NULL,27);
INSERT INTO `test_questions` VALUES (1336,11,87,28,'ترجیح می‌دهم بین دنیای شخصی خودم و رابطه عاطفی دیوارهای مشخصی بکشم.',0,NULL,28);
INSERT INTO `test_questions` VALUES (1337,11,87,29,'وابستگی عاطفی را نوعی نقطه‌ضعف یا خطر برای خودم می‌دانم.',0,NULL,29);
INSERT INTO `test_questions` VALUES (1338,11,87,30,'به سختی می‌توانم در برابر شریک عاطفی‌ام گریه کنم یا ضعف نشان دهم.',0,NULL,30);
INSERT INTO `test_questions` VALUES (1339,11,87,31,'اگر شریکم نباشد، مشکلی ندارم و می‌توانم به راحتی بدون او به زندگی ادامه دهم.',0,NULL,31);
INSERT INTO `test_questions` VALUES (1340,11,87,32,'گاهی احساس می‌کنم صمیمیت عاطفی آزادی و هویت فردی مرا سلب می‌کند.',0,NULL,32);
INSERT INTO `test_questions` VALUES (1341,11,87,33,'در گفتگوهای صمیمانه عاطفی معمولاً موضع دفاعی یا خونسرد می‌گیرم.',0,NULL,33);
INSERT INTO `test_questions` VALUES (1342,11,87,34,'ترجیح می‌دهم فاصله ایمن را همیشه در رابطه عاشقانه حفظ کنم.',0,NULL,34);
INSERT INTO `test_questions` VALUES (1343,11,87,35,'برایم سخت است که بپذیرم در مسائل عاطفی به حضور شریکم احتیاج دارم.',0,NULL,35);
INSERT INTO `test_questions` VALUES (1344,11,87,36,'حفظ خودمختاری فردی را بسیار مهم‌تر از نزدیکی و ادغام عاطفی می‌دانم.',0,NULL,36);
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_results`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `test_version` varchar(32) NOT NULL,
  `total_score` decimal(8,2) NOT NULL,
  `dimension_scores_json` text NOT NULL,
  `overall_category` varchar(128) NOT NULL,
  `overall_severity` varchar(32) NOT NULL,
  `short_interpretation` text NOT NULL,
  `scientific_audit_trail_json` longtext NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_res_user` (`user_id`),
  KEY `idx_res_test` (`test_id`),
  KEY `idx_res_session` (`session_id`),
  KEY `idx_res_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_results`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_results` VALUES (1,1,1,1,'1.0',20.00,'[{\"id\":1,\"code\":\"ED\",\"title\":\"محرومیت هیجانی (Emotional Deprivation)\",\"description\":null,\"min_score\":2,\"max_score\":12,\"color_hex\":\"#0d9488\",\"raw_score\":10,\"item_count\":2,\"average_score\":5,\"category_name\":\"فعال و پررنگ\",\"severity_level\":\"high\",\"interpretation\":\"طرحواره محرومیت هیجانی در شما فعال است.\"},{\"id\":2,\"code\":\"AB\",\"title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\",\"description\":null,\"min_score\":2,\"max_score\":12,\"color_hex\":\"#d97706\",\"raw_score\":10,\"item_count\":2,\"average_score\":5,\"category_name\":\"ارزیابی شده\",\"severity_level\":\"normal\",\"interpretation\":\"نمره کسب‌شده در بازه هنجار قرار دارد.\"}]','الگوهای هیجانی متوسط','moderate','ارزیابی کلی نشان‌دهنده الگوهای هیجانی در سطح متوسط است.','[{\"question_number\":1,\"question_text\":\"سوال اول - مستقیم بعد ۱\",\"selected_option_number\":5,\"selected_option_text\":\"گزینه 5\",\"option_raw_score\":5,\"is_reverse_scored\":false,\"item_final_score\":5,\"dimension_id\":1,\"dimension_title\":\"محرومیت هیجانی (Emotional Deprivation)\"},{\"question_number\":2,\"question_text\":\"سوال دوم - معکوس بعد ۱\",\"selected_option_number\":2,\"selected_option_text\":\"گزینه 2\",\"option_raw_score\":2,\"is_reverse_scored\":true,\"item_final_score\":5,\"dimension_id\":1,\"dimension_title\":\"محرومیت هیجانی (Emotional Deprivation)\"},{\"question_number\":3,\"question_text\":\"سوال سوم - مستقیم بعد ۲\",\"selected_option_number\":4,\"selected_option_text\":\"گزینه 4\",\"option_raw_score\":4,\"is_reverse_scored\":false,\"item_final_score\":4,\"dimension_id\":2,\"dimension_title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\"},{\"question_number\":4,\"question_text\":\"سوال چهارم - مستقیم بعد ۲\",\"selected_option_number\":6,\"selected_option_text\":\"گزینه 6\",\"option_raw_score\":6,\"is_reverse_scored\":false,\"item_final_score\":6,\"dimension_id\":2,\"dimension_title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\"}]','2026-08-30 16:22:12');
INSERT INTO `test_results` VALUES (2,2,3,3,'1.0',20.00,'[{\"id\":5,\"code\":\"ED\",\"title\":\"محرومیت هیجانی (Emotional Deprivation)\",\"description\":null,\"min_score\":2,\"max_score\":12,\"color_hex\":\"#0d9488\",\"raw_score\":10,\"item_count\":2,\"average_score\":5,\"category_name\":\"فعال و پررنگ\",\"severity_level\":\"high\",\"interpretation\":\"طرحواره محرومیت هیجانی در شما فعال است.\"},{\"id\":6,\"code\":\"AB\",\"title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\",\"description\":null,\"min_score\":2,\"max_score\":12,\"color_hex\":\"#d97706\",\"raw_score\":10,\"item_count\":2,\"average_score\":5,\"category_name\":\"ارزیابی شده\",\"severity_level\":\"normal\",\"interpretation\":\"نمره کسب‌شده در بازه هنجار قرار دارد.\"}]','الگوهای هیجانی متوسط','moderate','ارزیابی کلی نشان‌دهنده الگوهای هیجانی در سطح متوسط است.','[{\"question_number\":1,\"question_text\":\"سوال اول - مستقیم بعد ۱\",\"selected_option_number\":5,\"selected_option_text\":\"گزینه 5\",\"option_raw_score\":5,\"is_reverse_scored\":false,\"item_final_score\":5,\"dimension_id\":5,\"dimension_title\":\"محرومیت هیجانی (Emotional Deprivation)\"},{\"question_number\":2,\"question_text\":\"سوال دوم - معکوس بعد ۱\",\"selected_option_number\":2,\"selected_option_text\":\"گزینه 2\",\"option_raw_score\":2,\"is_reverse_scored\":true,\"item_final_score\":5,\"dimension_id\":5,\"dimension_title\":\"محرومیت هیجانی (Emotional Deprivation)\"},{\"question_number\":3,\"question_text\":\"سوال سوم - مستقیم بعد ۲\",\"selected_option_number\":4,\"selected_option_text\":\"گزینه 4\",\"option_raw_score\":4,\"is_reverse_scored\":false,\"item_final_score\":4,\"dimension_id\":6,\"dimension_title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\"},{\"question_number\":4,\"question_text\":\"سوال چهارم - مستقیم بعد ۲\",\"selected_option_number\":6,\"selected_option_text\":\"گزینه 6\",\"option_raw_score\":6,\"is_reverse_scored\":false,\"item_final_score\":6,\"dimension_id\":6,\"dimension_title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\"}]','2026-08-30 16:23:56');
INSERT INTO `test_results` VALUES (3,3,4,11,'1.0',20.00,'[{\"id\":41,\"code\":\"ED\",\"title\":\"محرومیت هیجانی (Emotional Deprivation)\",\"description\":null,\"min_score\":2,\"max_score\":12,\"color_hex\":\"#0d9488\",\"raw_score\":10,\"item_count\":2,\"average_score\":5,\"category_name\":\"فعال و پررنگ\",\"severity_level\":\"high\",\"interpretation\":\"طرحواره محرومیت هیجانی در شما فعال است.\"},{\"id\":42,\"code\":\"AB\",\"title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\",\"description\":null,\"min_score\":2,\"max_score\":12,\"color_hex\":\"#d97706\",\"raw_score\":10,\"item_count\":2,\"average_score\":5,\"category_name\":\"ارزیابی شده\",\"severity_level\":\"normal\",\"interpretation\":\"نمره کسب‌شده در بازه هنجار قرار دارد.\"}]','الگوهای هیجانی متوسط','moderate','ارزیابی کلی نشان‌دهنده الگوهای هیجانی در سطح متوسط است.','[{\"question_number\":1,\"question_text\":\"سوال اول - مستقیم بعد ۱\",\"selected_option_number\":5,\"selected_option_text\":\"گزینه 5\",\"option_raw_score\":5,\"is_reverse_scored\":false,\"item_final_score\":5,\"dimension_id\":41,\"dimension_title\":\"محرومیت هیجانی (Emotional Deprivation)\"},{\"question_number\":2,\"question_text\":\"سوال دوم - معکوس بعد ۱\",\"selected_option_number\":2,\"selected_option_text\":\"گزینه 2\",\"option_raw_score\":2,\"is_reverse_scored\":true,\"item_final_score\":5,\"dimension_id\":41,\"dimension_title\":\"محرومیت هیجانی (Emotional Deprivation)\"},{\"question_number\":3,\"question_text\":\"سوال سوم - مستقیم بعد ۲\",\"selected_option_number\":4,\"selected_option_text\":\"گزینه 4\",\"option_raw_score\":4,\"is_reverse_scored\":false,\"item_final_score\":4,\"dimension_id\":42,\"dimension_title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\"},{\"question_number\":4,\"question_text\":\"سوال چهارم - مستقیم بعد ۲\",\"selected_option_number\":6,\"selected_option_text\":\"گزینه 6\",\"option_raw_score\":6,\"is_reverse_scored\":false,\"item_final_score\":6,\"dimension_id\":42,\"dimension_title\":\"رهاشدگی و بی‌ثباتی (Abandonment)\"}]','2026-08-30 17:01:17');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_scoring_rules`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_scoring_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `dimension_id` int(11) DEFAULT NULL,
  `category_name` varchar(128) NOT NULL,
  `min_range` decimal(8,2) NOT NULL,
  `max_range` decimal(8,2) NOT NULL,
  `severity_level` enum('normal','low','moderate','high','severe') NOT NULL DEFAULT 'normal',
  `short_interpretation` text NOT NULL,
  `full_interpretation_template` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rule_test` (`test_id`),
  KEY `idx_rule_dim` (`dimension_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_scoring_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_scoring_rules` VALUES (1,1,NULL,'نیمرخ بالینی جامع MMPI-2',0.00,567.00,'normal','پاسخ‌های شما در ۵۶۷ گویه ثبت و نمرات تراز شده T-Score در مقیاس‌های اعتباری (L, F, K) و مقیاس‌های ده‌گانه بالینی با تفکیک کامل استخراج گردید.',NULL);
INSERT INTO `test_scoring_rules` VALUES (2,2,NULL,'پروفایل جامع ۳۰ عاملی NEO-PI-R',240.00,1200.00,'normal','نمرات شما در ۲۴۰ گویه محاسبه و پروفایل روان‌شناختی در ۵ دامنه اصلی و ۳۰ صفت زیرمجموعه شخصیت ترسیم گردید.',NULL);
INSERT INTO `test_scoring_rules` VALUES (3,3,NULL,'پروفایل جامع ۱۸ طرحواره یانگ',232.00,1392.00,'normal','نمرات شما در ۲۳۲ گویه تحلیل شده و نقشه حرارتی تله‌های فعال، نیمه‌فعال و خاموش روان‌شناختی شما مشخص گردید.',NULL);
INSERT INTO `test_scoring_rules` VALUES (4,4,NULL,'پروفایل استاندارد ۱۶ عاملی کتل (استن - Sten)',0.00,370.00,'normal','نمرات شما در ۱۸۵ گویه محاسبه و نمرات استاندارد ۱۰ درجه‌ای استن (Sten Scores) در ۱۶ عامل شخصیت رسم گردید.',NULL);
INSERT INTO `test_scoring_rules` VALUES (5,5,NULL,'نارضایتی و آشفتگی زناشویی (Distress Cutoff < 104.5)',0.00,104.40,'severe','نمره شما زیر نقطه برش بالینی استاندارد (۱۰۴.۵) قرار دارد و بیانگر چالش‌های جدی در تفاهم، امنیت عاطفی و صمیمیت است. مشاوره و زوج‌درمانی تخصصی مؤکداً پیشنهاد می‌گردد.',NULL);
INSERT INTO `test_scoring_rules` VALUES (6,5,NULL,'رضایت مطلوب و پیوند پایدار (Satisfied)',104.50,135.00,'normal','رابطه شما در محدوده سلامت، همبستگی و رضایت بهنجار ارزیابی می‌شود.',NULL);
INSERT INTO `test_scoring_rules` VALUES (7,5,NULL,'صمیمیت عالی و کیفیت فوق‌العاده (High Quality)',135.10,161.00,'normal','پیوند عاطفی بسیار عمیق، غنی، تاب‌آور و سرشار از عشق و درک متقابل.',NULL);
INSERT INTO `test_scoring_rules` VALUES (8,6,NULL,'وضعیت بهنجار و پایدار',0.00,20.00,'normal','نمرات شما در مقیاس‌های سه‌گانه در بازه طبیعی قرار دارد و تعادل هیجانی مناسبی گزارش شده است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (9,6,NULL,'علائم هیجانی خفیف تا متوسط',21.00,40.00,'low','برخی نشانه‌های خستگی روانی یا فشار هیجانی مشاهده می‌شود که با خودمراقبتی و تکنیک‌های مدیریت ذهن قابل بهبود است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (10,6,NULL,'پریشانی هیجانی قابل توجه',41.00,63.00,'severe','شدت نشانه‌های گزارش‌شده بالا است و توصیه اکید می‌شود جهت بررسی دقیق و دریافت راهکارهای تخصصی، تفسیر کامل بالینی را دریافت نمایید.',NULL);
INSERT INTO `test_scoring_rules` VALUES (11,6,79,'طبیعی (Normal)',0.00,9.00,'normal','خلق و انگیزه در سطح بهنجار است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (12,6,79,'افسردگی خفیف (Mild)',10.00,13.00,'low','افت اندک خلق و احساس خستگی هیجانی گذرا.',NULL);
INSERT INTO `test_scoring_rules` VALUES (13,6,79,'افسردگی متوسط (Moderate)',14.00,20.00,'moderate','کاهش انرژی و احساس ناامیدی نیازمند توجه روان‌شناختی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (14,6,79,'افسردگی شدید (Severe)',21.00,27.00,'severe','نشانه‌های برجسته افسردگی با تأثیر منفی بر کارکرد روزمره.',NULL);
INSERT INTO `test_scoring_rules` VALUES (15,6,79,'افسردگی بسیار شدید (Extremely Severe)',28.00,63.00,'severe','پریشانی شدید بالینی و ضرورت مداخله تخصصی روان‌درمانی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (16,6,80,'طبیعی (Normal)',0.00,7.00,'normal','سطح اضطراب در محدوده بهنجار است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (17,6,80,'اضطراب خفیف (Mild)',8.00,9.00,'low','دلواپسی و تحریک‌پذیری ملایم جسمانی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (18,6,80,'اضطراب متوسط (Moderate)',10.00,14.00,'moderate','برانگیختگی جسمی و نشخوار نگرانی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (19,6,80,'اضطراب شدید (Severe)',15.00,19.00,'severe','ترس، تپش قلب و علائم جسمانی مداوم اضطراب.',NULL);
INSERT INTO `test_scoring_rules` VALUES (20,6,80,'اضطراب بسیار شدید (Extremely Severe)',20.00,63.00,'severe','حملات پانیک یا اضطراب فراگیر مختل‌کننده.',NULL);
INSERT INTO `test_scoring_rules` VALUES (21,6,81,'طبیعی (Normal)',0.00,14.00,'normal','توان سازگاری و تحمل فشار در محدوده مناسب است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (22,6,81,'استرس خفیف (Mild)',15.00,18.00,'low','فشار کاری یا روانی مقطعی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (23,6,81,'استرس متوسط (Moderate)',19.00,25.00,'moderate','ناشکیبایی، تنش بدنی و احساس تحت فشار بودن.',NULL);
INSERT INTO `test_scoring_rules` VALUES (24,6,81,'استرس شدید (Severe)',26.00,33.00,'severe','فرسودگی روانی و کاهش آستانه تحمل روانی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (25,6,81,'استرس بسیار شدید (Extremely Severe)',34.00,63.00,'severe','تنش فرساینده و آسیب‌رسان به سلامت جسم و روان.',NULL);
INSERT INTO `test_scoring_rules` VALUES (26,7,NULL,'اضطراب حداقلی و بهنجار (Minimal Anxiety)',0.00,4.00,'normal','سطح اضطراب شما در محدوده بسیار مطلوب و طبیعی قرار دارد و نشانه‌ای از اضطراب مزمن وجود ندارد.',NULL);
INSERT INTO `test_scoring_rules` VALUES (27,7,NULL,'اضطراب خفیف (Mild Anxiety)',5.00,9.00,'low','نشانه‌های خفیف نگرانی و تنش ذهنی گزارش شده است. تمرین‌های تن‌آرامی و مدیریت زمان بسیار سودمند است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (28,7,NULL,'اضطراب متوسط (Moderate Anxiety)',10.00,14.00,'moderate','سطح اضطراب نیازمند ارزیابی بالینی است و ممکن است بر تمرکز یا کیفیت خواب تأثیر بگذارد.',NULL);
INSERT INTO `test_scoring_rules` VALUES (29,7,NULL,'اضطراب شدید بالینی (Severe Anxiety)',15.00,21.00,'severe','نشانه‌های اضطراب شدید بالینی مشاهده می‌شود. توصیه جدی جهت دریافت پروتکل درمانی و مشاوره تخصصی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (30,8,NULL,'طبیعی / بدون افسردگی (None-Minimal)',0.00,4.00,'normal','نشانه‌ای از افسردگی بالینی وجود ندارد و سلامت روانی در وضعیت بهنجار ارزیابی می‌شود.',NULL);
INSERT INTO `test_scoring_rules` VALUES (31,8,NULL,'افسردگی خفیف (Mild Depression)',5.00,9.00,'low','نشانه‌های خفیف افت انگیزه وجود دارد؛ پایش الگوهای خواب و خودمراقبتی توصیه می‌شود.',NULL);
INSERT INTO `test_scoring_rules` VALUES (32,8,NULL,'افسردگی متوسط (Moderate Depression)',10.00,14.00,'moderate','سطح علائم متوسط است و نیازمند مشاوره و مداخلات حمایتی روان‌شناختی می‌باشد.',NULL);
INSERT INTO `test_scoring_rules` VALUES (33,8,NULL,'افسردگی نسبتاً شدید (Moderately Severe)',15.00,19.00,'severe','افت مشهود کارکرد روزمره و علائم مشهود بالینی که نیاز به درمان فعال دارد.',NULL);
INSERT INTO `test_scoring_rules` VALUES (34,8,NULL,'افسردگی شدید بالینی (Severe Depression)',20.00,27.00,'severe','شدت بالای نشانه‌ها؛ ارزیابی تخصصی بالینی و آغاز پروتکل‌های درمانی ضروری است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (35,9,NULL,'عزت‌نفس پایین و شکننده (Low Self-Esteem)',10.00,25.00,'low','تمایل به انتقاد شدید از خود، احساس ناکافی بودن و وابستگی خودارزشمندی به تأیید دیگران مشاهده می‌شود.',NULL);
INSERT INTO `test_scoring_rules` VALUES (36,9,NULL,'عزت‌نفس متوسط و بهنجار (Average Self-Esteem)',26.00,32.00,'normal','دیدگاه شما نسبت به توانمندی‌ها و نقاط ضعف خود در تعادل نسبی و در بازه هنجار جامعه قرار دارد.',NULL);
INSERT INTO `test_scoring_rules` VALUES (37,9,NULL,'عزت‌نفس بالا و تاب‌آور (High Self-Esteem)',33.00,40.00,'normal','شما از خودپذیری اصیل، حس خودارزشمندی استوار و باور مستحکم به توانایی‌های درونی خود برخوردارید.',NULL);
INSERT INTO `test_scoring_rules` VALUES (38,10,NULL,'نارضایتی شدید از زندگی (Extremely Dissatisfied)',5.00,9.00,'severe','ناخشنودی عمیق از شرایط کنونی و احساس شکاف عمیق بین وضعیت موجود و مطلوب زندگی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (39,10,NULL,'نارضایتی از زندگی (Dissatisfied)',10.00,14.00,'moderate','احساس ناکامی و نارضایتی در بخش‌های کلیدی زندگی که نیازمند بازنگری اهداف و اولویت‌هاست.',NULL);
INSERT INTO `test_scoring_rules` VALUES (40,10,NULL,'کمی زیر میانگین (Slightly Below Average)',15.00,19.00,'low','رضایت نسبی وجود دارد اما چالش‌هایی در برخی حوزه‌ها مانع تجربه آرامش کامل است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (41,10,NULL,'رضایت متوسط و طبیعی (Average)',20.00,24.00,'normal','سطح رضایت شما در بازه هنجار و متداول جامعه ارزیابی می‌شود.',NULL);
INSERT INTO `test_scoring_rules` VALUES (42,10,NULL,'رضایت بالا و مطلوب (High Satisfaction)',25.00,29.00,'normal','ارزیابی بسیار مثبت و شکرگزارانه از سیر زندگی، روابط و دستاوردهای فردی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (43,10,NULL,'رضایت بسیار بالا و شکوفایی (Highly Satisfied)',30.00,35.00,'normal','تجربه حداکثری بهزیستی روان‌شناختی، همسویی عمیق با اهداف زندگی و احساس شکوفایی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (44,11,NULL,'پروفایل سبک دلبستگی',36.00,252.00,'normal','نمرات شما در دو بعد اضطراب و اجتناب مشخص‌کننده یکی از ۴ سبک اصلی دلبستگی (ایمن، مضطرب، اجتنابی-هراسناک، اجتنابی-طعنه‌زن) است.',NULL);
INSERT INTO `test_scoring_rules` VALUES (45,11,86,'اضطراب دلبستگی پایین (ایمن)',18.00,63.00,'normal','احساس امنیت در رابطه و عدم نگرانی وسواس‌گونه از رهاشدگی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (46,11,86,'اضطراب دلبستگی بالا (ناایمن)',64.00,126.00,'severe','اشتغال ذهنی شدید با رابطه، ترس از طرد و نیاز مداوم به دلگرمی و تأیید طرف مقابل.',NULL);
INSERT INTO `test_scoring_rules` VALUES (47,11,87,'اجتناب دلبستگی پایین (راحت با صمیمیت)',18.00,63.00,'normal','راحتی با نزدیکی عاطفی، ابراز آزادانه احساسات و اعتماد به شریک عاطفی.',NULL);
INSERT INTO `test_scoring_rules` VALUES (48,11,87,'اجتناب دلبستگی بالا (دوری‌گزین)',64.00,126.00,'severe','فاصله‌گیری عاطفی در مواجهه با صمیمیت و اجتناب از ابراز آسیب‌پذیری و نیاز به دیگری.',NULL);
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_sessions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_token` varchar(64) NOT NULL,
  `test_id` int(11) NOT NULL,
  `test_version` varchar(32) NOT NULL DEFAULT '1.0',
  `user_id` int(11) DEFAULT NULL,
  `status` enum('started','completed','abandoned') NOT NULL DEFAULT 'started',
  `started_at` datetime DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `idx_sess_token` (`session_token`),
  KEY `idx_sess_test` (`test_id`),
  KEY `idx_sess_user` (`user_id`),
  KEY `idx_sess_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_sessions` VALUES (1,'994c675ace4d6843621ee322a1c71d275c5db178',1,'1.0',1,'completed','2026-08-30 16:22:12','2026-08-30 19:52:12','0.0.0.0','');
INSERT INTO `test_sessions` VALUES (2,'0f308ac8e3fcfe1c9ee28286b68f65b81e974140',3,'1.0',3,'completed','2026-08-30 16:23:56','2026-08-30 19:53:56','0.0.0.0','');
INSERT INTO `test_sessions` VALUES (3,'7216e9888648a87f1407850976eee1ba711295b5',11,'1.0',4,'completed','2026-08-30 17:01:17','2026-08-30 20:31:17','0.0.0.0','');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `test_sources`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `citation_title` varchar(255) NOT NULL,
  `authors` varchar(255) DEFAULT NULL,
  `year` varchar(16) DEFAULT NULL,
  `doi` varchar(128) DEFAULT NULL,
  `pmid` varchar(64) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_source_test` (`test_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_sources`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `test_sources` VALUES (1,1,'Minnesota Multiphasic Personality Inventory-2 (MMPI-2 Full Form - 567 Items)','Butcher, J. N., Dahlstrom, W. G., Graham, J. R., Tellegen, A., & Kaemmer, B.','2000',NULL,NULL,'https://mirbolouki.com','Butcher, J. N., Dahlstrom, W. G., Graham, J. R., Tellegen, A., & Kaemmer, B. (1989). MMPI-2: Manual for administration and scoring. University of Minnesota Press. هنجاریابی ایرانی: دکتر پوراعتماد، دکتر براهنی، دکتر منصور و دکتر دادستان');
INSERT INTO `test_sources` VALUES (2,2,'Revised NEO Personality Inventory (NEO-PI-R Full 240-Item Form)','Costa, P. T., & McCrae, R. R.','2000',NULL,NULL,'https://mirbolouki.com','Costa, P. T., & McCrae, R. R. (1992). Revised NEO Personality Inventory (NEO PI-R) and NEO Five-Factor Inventory (NEO-FFI) professional manual. Psychological Assessment Resources. هنجاریابی ایرانی: دکتر حق‌شناس (۱۳۸۵) و دکتر گروسی فرشی');
INSERT INTO `test_sources` VALUES (3,3,'Young Schema Questionnaire - Long Form 3 (YSQ-L3 Full 232-Item Form)','Young, J. E., Klosko, J. S., & Weishaar, M. E.','2000',NULL,NULL,'https://mirbolouki.com','Young, J. E., Klosko, J. S., & Weishaar, M. E. (2003). Schema therapy: A practitioner\'s guide. Guilford Press. هنجاریابی ایرانی: دکتر یوسفی، دکتر بهرامی و همکاران (۱۳۸۸)');
INSERT INTO `test_sources` VALUES (4,4,'Cattell 16 Personality Factor Questionnaire (16PF Fifth Edition - 185 Items)','Russell, M. T., & Karol, D. L.','2000',NULL,NULL,'https://mirbolouki.com','Russell, M. T., & Karol, D. L. (1994). 16PF Fifth Edition Administrator\'s Manual. Institute for Personality and Ability Testing. هنجاریابی ایرانی: دکتر کرمی و دکتر طباطبایی (۱۳۸۵)');
INSERT INTO `test_sources` VALUES (5,5,'Couples Satisfaction Index (CSI-32 Full 32-Item Form)','Funk, J. L., & Rogge, R. D.','2000',NULL,NULL,'https://mirbolouki.com','Funk, J. L., & Rogge, R. D. (2007). Testing the ruler with item response theory: Increasing precision of measurement for relationship satisfaction with the Couples Satisfaction Index. Journal of Family Psychology, 21(4), 572-583. هنجاریابی ایرانی: فروزش یکتا و همکاران (۲۰۱۷)');
INSERT INTO `test_sources` VALUES (6,6,'Depression Anxiety Stress Scales (DASS-21)','Lovibond, S.H. & Lovibond, P.F.','2000',NULL,NULL,'https://mirbolouki.com','Lovibond, S.H. & Lovibond, P.F. (1995). Manual for the Depression Anxiety Stress Scales. (2nd. Ed.) Sydney: Psychology Foundation. هنجاریابی ایرانی: دکتر صاحبی و همکاران (۱۳۸۴)');
INSERT INTO `test_sources` VALUES (7,7,'Generalized Anxiety Disorder 7-item Scale (GAD-7)','Spitzer, R. L., Kroenke, K., Williams, J. B., & Löwe, B.','2000',NULL,NULL,'https://mirbolouki.com','Spitzer, R. L., Kroenke, K., Williams, J. B., & Löwe, B. (2006). A brief measure for assessing generalized anxiety disorder: the GAD-7. Archives of Internal Medicine, 166(10), 1092-1097. هنجاریابی ایرانی: نائینیان و همکاران (۱۳۹۰)');
INSERT INTO `test_sources` VALUES (8,8,'Patient Health Questionnaire-9 (PHQ-9)','Kroenke, K., Spitzer, R. L., & Williams, J. B.','2000',NULL,NULL,'https://mirbolouki.com','Kroenke, K., Spitzer, R. L., & Williams, J. B. (2001). The PHQ-9: validity of a brief depression severity measure. Journal of General Internal Medicine, 16(9), 606-613. هنجاریابی ایرانی: خمسه و همکاران (۱۳۹۰) و دادفر و همکاران (۲۰۱۸)');
INSERT INTO `test_sources` VALUES (9,9,'Rosenberg Self-Esteem Scale (RSES)','Rosenberg, M.','2000',NULL,NULL,'https://mirbolouki.com','Rosenberg, M. (1965). Society and the adolescent self-image. Princeton, NJ: Princeton University Press. هنجاریابی ایرانی: محمدی (۱۳۸۴) و رجبی و بهلول (۱۳۸۶)');
INSERT INTO `test_sources` VALUES (10,10,'Satisfaction with Life Scale (SWLS)','Diener, E., Emmons, R. A., Larsen, R. J., & Griffin, S.','2000',NULL,NULL,'https://mirbolouki.com','Diener, E., Emmons, R. A., Larsen, R. J., & Griffin, S. (1985). The Satisfaction with Life Scale. Journal of Personality Assessment, 49(1), 71-75. هنجاریابی ایرانی: بیانی، کوچکی و گودرزی (۱۳۸۶) و معروف‌زاده و همکاران (۲۰۱۶)');
INSERT INTO `test_sources` VALUES (11,11,'Experiences in Close Relationships-Revised (ECR-R)','Fraley, R. C., Waller, N. G., & Brennan, K. A.','2000',NULL,NULL,'https://mirbolouki.com','Fraley, R. C., Waller, N. G., & Brennan, K. A. (2000). An item response theory analysis of the Experiences in Close Relationships-Revised (ECR-R) measure of adult attachment. Journal of Personality and Social Psychology, 78(2), 350-365. هنجاریابی ایرانی: دکتر بشارت (۱۳۹۰) و دهقانی و همکاران');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tests`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) NOT NULL,
  `title` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `version` varchar(32) NOT NULL DEFAULT '1.0',
  `description` text DEFAULT NULL,
  `intro_text` text DEFAULT NULL,
  `scientific_profile` text DEFAULT NULL,
  `estimated_minutes` int(11) NOT NULL DEFAULT 15,
  `accent_color` varchar(32) NOT NULL DEFAULT '#0d9488',
  `banner_image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_original_instrument` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_test_slug` (`slug`),
  KEY `idx_test_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `tests` VALUES (1,'mmpi-2-full','پرسشنامه جامع شخصیت مینه سوتا فرم ۵۶۷ سوالی (MMPI-2)','Minnesota Multiphasic Personality Inventory-2 (MMPI-2 Full Form - 567 Items)','2.0','جامع‌ترین، معتبرترین و دقیق‌ترین آزمون تشخیصی روان‌شناسی بالینی و روان‌پزشکی جهان با ۵۶۷ گویه، ۳ مقیاس اعتباری و ۱۰ مقیاس بالینی استاندارد.','جامع‌ترین، معتبرترین و دقیق‌ترین آزمون تشخیصی روان‌شناسی بالینی و روان‌پزشکی جهان با ۵۶۷ گویه، ۳ مقیاس اعتباری و ۱۰ مقیاس بالینی استاندارد.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Butcher, J. N., Dahlstrom, W. G., Graham, J. R., Tellegen, A., & Kaemmer, B. (1989). MMPI-2: Manual for administration and scoring. University of Minnesota Press. هنجاریابی ایرانی: دکتر پوراعتماد، دکتر براهنی، دکتر منصور و دکتر دادستان',75,'#D4AF37',NULL,1,1,1,'2026-08-30 17:39:01','2026-08-30 17:39:01');
INSERT INTO `tests` VALUES (2,'neo-pi-r-full','پرسشنامه جامع شخصیت نئو فرم بلند ۲۴۰ سوالی (NEO-PI-R)','Revised NEO Personality Inventory (NEO-PI-R Full 240-Item Form)','2.0','کامل‌ترین، دقیق‌ترین و معتبرترین ابزار ارزیابی ۵ عامل بزرگ شخصیت و ۳۰ خرده‌مقیاس تخصصی شخصیت بر مبنای مدل کستا و مک‌کری.','کامل‌ترین، دقیق‌ترین و معتبرترین ابزار ارزیابی ۵ عامل بزرگ شخصیت و ۳۰ خرده‌مقیاس تخصصی شخصیت بر مبنای مدل کستا و مک‌کری.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Costa, P. T., & McCrae, R. R. (1992). Revised NEO Personality Inventory (NEO PI-R) and NEO Five-Factor Inventory (NEO-FFI) professional manual. Psychological Assessment Resources. هنجاریابی ایرانی: دکتر حق‌شناس (۱۳۸۵) و دکتر گروسی فرشی',45,'#D4AF37',NULL,1,1,2,'2026-08-30 17:39:01','2026-08-30 17:39:01');
INSERT INTO `tests` VALUES (3,'young-schema-full-l3','پرسشنامه جامع طرحواره‌های یانگ فرم بلند ۲۳۲ سوالی (YSQ-L3)','Young Schema Questionnaire - Long Form 3 (YSQ-L3 Full 232-Item Form)','2.0','کامل‌ترین و اصیل‌ترین ابزار تشخیصی طرحواره‌درمانی جهت ارزیابی عمیق ۱۸ طرحواره ناسازگار اولیه در ۵ حوزه بنیادین تحولی روان انسان.','کامل‌ترین و اصیل‌ترین ابزار تشخیصی طرحواره‌درمانی جهت ارزیابی عمیق ۱۸ طرحواره ناسازگار اولیه در ۵ حوزه بنیادین تحولی روان انسان.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Young, J. E., Klosko, J. S., & Weishaar, M. E. (2003). Schema therapy: A practitioner\'s guide. Guilford Press. هنجاریابی ایرانی: دکتر یوسفی، دکتر بهرامی و همکاران (۱۳۸۸)',50,'#D4AF37',NULL,1,1,3,'2026-08-30 17:39:01','2026-08-30 17:39:01');
INSERT INTO `tests` VALUES (4,'cattell-16pf-full','آزمون جامع ۱۶ عاملی شخصیت کتل ویرایش پنجم (16PF Full Form)','Cattell 16 Personality Factor Questionnaire (16PF Fifth Edition - 185 Items)','2.0','کامل‌ترین نسخه رسمی آزمون ۱۶ عاملی ریموند کتل جهت ارزیابی ۱۶ صفت ریشه‌ای شخصیت و ۵ عامل مرتبه دوم (عوامل جهان‌شمول).','کامل‌ترین نسخه رسمی آزمون ۱۶ عاملی ریموند کتل جهت ارزیابی ۱۶ صفت ریشه‌ای شخصیت و ۵ عامل مرتبه دوم (عوامل جهان‌شمول).\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Russell, M. T., & Karol, D. L. (1994). 16PF Fifth Edition Administrator\'s Manual. Institute for Personality and Ability Testing. هنجاریابی ایرانی: دکتر کرمی و دکتر طباطبایی (۱۳۸۵)',35,'#D4AF37',NULL,1,1,4,'2026-08-30 17:39:01','2026-08-30 17:39:01');
INSERT INTO `tests` VALUES (5,'csi-32-full','شاخص جامع رضایت و پایداری رابطه زوجین فرم ۳۲ سوالی (CSI-32)','Couples Satisfaction Index (CSI-32 Full 32-Item Form)','2.0','دقیق‌ترین و معتبرترین ابزار اندازه‌گیری کیفیت روابط عاشقانه و زناشویی در جهان، تدوین شده با روش نظریه پاسخ گویه (IRT).','دقیق‌ترین و معتبرترین ابزار اندازه‌گیری کیفیت روابط عاشقانه و زناشویی در جهان، تدوین شده با روش نظریه پاسخ گویه (IRT).\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Funk, J. L., & Rogge, R. D. (2007). Testing the ruler with item response theory: Increasing precision of measurement for relationship satisfaction with the Couples Satisfaction Index. Journal of Family Psychology, 21(4), 572-583. هنجاریابی ایرانی: فروزش یکتا و همکاران (۲۰۱۷)',10,'#D4AF37',NULL,1,1,5,'2026-08-30 17:39:02','2026-08-30 17:39:02');
INSERT INTO `tests` VALUES (6,'dass-21','مقیاس افسردگی، اضطراب و استرس (DASS-21)','Depression Anxiety Stress Scales (DASS-21)','2.0','ابزار استاندارد بین‌المللی جهت سنجش و تفکیک شدت سه حالت عاطفی منفی: افسردگی، اضطراب و استرس مزمن بر مبنای هنجارهای بالینی معتبر.','ابزار استاندارد بین‌المللی جهت سنجش و تفکیک شدت سه حالت عاطفی منفی: افسردگی، اضطراب و استرس مزمن بر مبنای هنجارهای بالینی معتبر.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Lovibond, S.H. & Lovibond, P.F. (1995). Manual for the Depression Anxiety Stress Scales. (2nd. Ed.) Sydney: Psychology Foundation. هنجاریابی ایرانی: دکتر صاحبی و همکاران (۱۳۸۴)',7,'#D4AF37',NULL,1,1,6,'2026-08-30 17:39:02','2026-08-30 17:39:02');
INSERT INTO `tests` VALUES (7,'gad-7','غربالگری اضطراب فراگیر (GAD-7)','Generalized Anxiety Disorder 7-item Scale (GAD-7)','2.0','پرسشنامه استاندارد و بین‌المللی سنجش شدت اختلال اضطراب فراگیر و نگرانی مزمن مورد تأیید APA و راهنمای تشخیصی DSM.','پرسشنامه استاندارد و بین‌المللی سنجش شدت اختلال اضطراب فراگیر و نگرانی مزمن مورد تأیید APA و راهنمای تشخیصی DSM.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Spitzer, R. L., Kroenke, K., Williams, J. B., & Löwe, B. (2006). A brief measure for assessing generalized anxiety disorder: the GAD-7. Archives of Internal Medicine, 166(10), 1092-1097. هنجاریابی ایرانی: نائینیان و همکاران (۱۳۹۰)',4,'#D4AF37',NULL,1,1,7,'2026-08-30 17:39:02','2026-08-30 17:39:02');
INSERT INTO `tests` VALUES (8,'phq-9','پرسشنامه سنجش سلامت روان و غربالگری افسردگی (PHQ-9)','Patient Health Questionnaire-9 (PHQ-9)','2.0','معیار طلایی تشخیصی و ارزیابی شدت علائم افسردگی بر اساس ملاک‌های ۹ گانه راهنمای تشخیصی و آماری اختلالات روانی (DSM-5).','معیار طلایی تشخیصی و ارزیابی شدت علائم افسردگی بر اساس ملاک‌های ۹ گانه راهنمای تشخیصی و آماری اختلالات روانی (DSM-5).\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Kroenke, K., Spitzer, R. L., & Williams, J. B. (2001). The PHQ-9: validity of a brief depression severity measure. Journal of General Internal Medicine, 16(9), 606-613. هنجاریابی ایرانی: خمسه و همکاران (۱۳۹۰) و دادفر و همکاران (۲۰۱۸)',4,'#D4AF37',NULL,1,1,8,'2026-08-30 17:39:02','2026-08-30 17:39:02');
INSERT INTO `tests` VALUES (9,'rosenberg-self-esteem','آزمون عزت‌نفس و خودارزشمندی روزنبرگ (RSES)','Rosenberg Self-Esteem Scale (RSES)','2.0','معتبرترین و پرکاربردترین مقیاس استاندارد روان‌شناسی در سطح جهان برای سنجش میزان خودارزشمندی کلی و احساس شایستگی درونی.','معتبرترین و پرکاربردترین مقیاس استاندارد روان‌شناسی در سطح جهان برای سنجش میزان خودارزشمندی کلی و احساس شایستگی درونی.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Rosenberg, M. (1965). Society and the adolescent self-image. Princeton, NJ: Princeton University Press. هنجاریابی ایرانی: محمدی (۱۳۸۴) و رجبی و بهلول (۱۳۸۶)',4,'#D4AF37',NULL,1,1,9,'2026-08-30 17:39:02','2026-08-30 17:39:02');
INSERT INTO `tests` VALUES (10,'satisfaction-with-life','مقیاس رضایت از زندگی و بهزیستی ذهنی (SWLS)','Satisfaction with Life Scale (SWLS)','2.0','ابزار استاندارد و بنیادین روان‌شناسی مثبت‌گرا برای ارزیابی شناختی و قضاوتی فرد از کیفیت کلی زندگی خویش.','ابزار استاندارد و بنیادین روان‌شناسی مثبت‌گرا برای ارزیابی شناختی و قضاوتی فرد از کیفیت کلی زندگی خویش.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Diener, E., Emmons, R. A., Larsen, R. J., & Griffin, S. (1985). The Satisfaction with Life Scale. Journal of Personality Assessment, 49(1), 71-75. هنجاریابی ایرانی: بیانی، کوچکی و گودرزی (۱۳۸۶) و معروف‌زاده و همکاران (۲۰۱۶)',3,'#D4AF37',NULL,1,1,10,'2026-08-30 17:39:02','2026-08-30 17:39:02');
INSERT INTO `tests` VALUES (11,'attachment-style','آزمون جامع سبک‌های دلبستگی عاطفی (ECR-R)','Experiences in Close Relationships-Revised (ECR-R)','2.0','معیار معتبر جهانی برای سنجش دو مؤلفه اضطراب دلبستگی (ترس از طرد) و اجتناب دلبستگی (ترس از صمیمیت) در روابط عاطفی و ازدواج.','معیار معتبر جهانی برای سنجش دو مؤلفه اضطراب دلبستگی (ترس از طرد) و اجتناب دلبستگی (ترس از صمیمیت) در روابط عاطفی و ازدواج.\n\nاین آزمون نسخه کامل و رسمی تشخیصی بالینی بوده و بر اساس مراجع استاندارد بین‌المللی روان‌سنجی تدوین شده است.','Fraley, R. C., Waller, N. G., & Brennan, K. A. (2000). An item response theory analysis of the Experiences in Close Relationships-Revised (ECR-R) measure of adult attachment. Journal of Personality and Social Psychology, 78(2), 350-365. هنجاریابی ایرانی: دکتر بشارت (۱۳۹۰) و دهقانی و همکاران',8,'#D4AF37',NULL,1,1,11,'2026-08-30 17:39:02','2026-08-30 17:39:02');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_answers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `calculated_score` decimal(8,2) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ans_session` (`session_id`),
  KEY `idx_ans_q` (`question_id`),
  KEY `idx_ans_opt` (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_answers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `user_answers` VALUES (1,1,1,5,5.00,'2026-08-30 16:22:12');
INSERT INTO `user_answers` VALUES (2,1,2,2,5.00,'2026-08-30 16:22:12');
INSERT INTO `user_answers` VALUES (3,1,3,4,4.00,'2026-08-30 16:22:12');
INSERT INTO `user_answers` VALUES (4,1,4,6,6.00,'2026-08-30 16:22:12');
INSERT INTO `user_answers` VALUES (5,2,9,17,5.00,'2026-08-30 16:23:56');
INSERT INTO `user_answers` VALUES (6,2,10,14,5.00,'2026-08-30 16:23:56');
INSERT INTO `user_answers` VALUES (7,2,11,16,4.00,'2026-08-30 16:23:56');
INSERT INTO `user_answers` VALUES (8,2,12,18,6.00,'2026-08-30 16:23:56');
INSERT INTO `user_answers` VALUES (9,3,295,54,5.00,'2026-08-30 17:01:17');
INSERT INTO `user_answers` VALUES (10,3,296,51,5.00,'2026-08-30 17:01:17');
INSERT INTO `user_answers` VALUES (11,3,297,53,4.00,'2026-08-30 17:01:17');
INSERT INTO `user_answers` VALUES (12,3,298,55,6.00,'2026-08-30 17:01:17');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(20) NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `gender` enum('female','male','other') NOT NULL,
  `age` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile` (`mobile`),
  KEY `idx_user_mobile` (`mobile`),
  KEY `idx_user_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
INSERT INTO `users` VALUES (1,'09129998877','سارا','احمدی','female',29,NULL,'2026-08-30 16:22:12','2026-08-30 16:22:12');
INSERT INTO `users` VALUES (3,'09125004336','سارا','احمدی','female',29,NULL,'2026-08-30 16:23:56','2026-08-30 16:23:56');
INSERT INTO `users` VALUES (4,'09121657400','سارا','احمدی','female',29,NULL,'2026-08-30 17:01:17','2026-08-30 17:01:17');
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-31 11:25:47
