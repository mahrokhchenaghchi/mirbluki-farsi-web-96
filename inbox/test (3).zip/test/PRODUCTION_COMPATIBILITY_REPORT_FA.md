# گزارش جامع ممیزی، سازگاری و امنیت برای محیط عملیاتی (Production)
## ارزیابی استقرار سامانه آزمون‌های روان‌سنجی میربلوکی روی `test.mirbolouki.com`

---

## 📊 چک‌لیست وضعیت آمادگی عملیاتی (Production Readiness Status)

| شاخص ارزیابی | نتیجه ارزیابی | توضیحات فنی و جزئیات |
|---|:---:|---|
| **وضعیت کلی سیستم** | 🟢 **READY (آماده استقرار)** | تمامی اجزای سیستم و بانک آزمون‌های بالینی آماده استقرار هستند. |
| **سازگاری با PHP** | 🟢 **Compatible** | سازگار با PHP 7.0 تا 8.4 (تست شده بدون خطای Syntax و بدون Deprecated functions). |
| **سازگاری با MySQL / MariaDB** | 🟢 **Compatible** | سازگار با MySQL 5.7+ و MariaDB 10.x+ با انکودینگ کامل utf8mb4. |
| **سازگاری با mysqli** | 🟢 **Compatible** | ارتباط ۱۰۰٪ مبتنی بر Pure mysqli و بدون نیاز به درایورهای متفرقه. |
| **محیط هاست اشتراکی (Shared Hosting)** | 🟢 **Compatible** | کاملاً مستقل و هماهنگ با کنترل‌پنل‌های cPanel / DirectAdmin / Plesk. |
| **نیاز به Composer** | ⚪ **Not Required (عدم نیاز)** | بدون هیچ‌گونه پکیج یا وابستگی خارجی. |
| **نیاز به دسترسی SSH** | ⚪ **Not Required (عدم نیاز)** | بدون نیاز به ترمینال یا دسترسی روت. |
| **نیاز به دستورات Shell / CLI** | ⚪ **Not Required (عدم نیاز)** | نصب و اجرا ۱۰۰٪ از طریق File Manager و رابط وب. |
| **نیاز به Node.js / NPM** | ⚪ **Not Required (عدم نیاز)** | استایل‌ها و اسکریپت‌ها Pure Vanilla JS و CSS3 هستند. |
| **تداخل در دیتابیس (Database Conflict)** | 🟢 **No (بدون تداخل)** | جداول با اسامی تفکیک‌شده و دستور `CREATE TABLE IF NOT EXISTS`. |
| **تداخل فایلی با سایت اصلی** | 🟢 **No (بدون تداخل)** | به دلیل نصب روی ساب‌دامین مجزا (`test.mirbolouki.com`) یا پوشه اختصاصی. |
| **تداخل فایل .htaccess** | 🟢 **No (بدون تداخل)** | فایل `.htaccess` سامانه تنها درون روت ساب‌دامین اجرا می‌شود. |
| **تداخل استایل‌های CSS** | 🟢 **No (بدون تداخل)** | تمامی کلاس‌های CSS با پیشوند و ساختار ایزوله طراحی شده‌اند. |
| **تداخل اسکریپت‌های JavaScript** | 🟢 **No (بدون تداخل)** | کدهای جاوااسکریپت درون IIFE و Scope بسته کپسوله‌سازی شده‌اند. |
| **تداخل نشست‌ها (Session Conflict)** | 🟢 **No (بدون تداخل)** | کوکی‌های نشست با نام مستقل و HttpOnly مدیریت می‌شوند. |
| **سطح ریسک امنیتی (Security Risk)** | 🛡️ **LOW (بسیار امن و پایین)** | مجهز به Prepared Statements، توکن CSRF و فیلتر چندلایه آپلود. |

---

## 🔍 ممیزی کامل فایل‌های درون بسته (Project Inventory)

| ردیف | مسیر فایل | نوع فایل | کاربرد و وظیفه | وابستگی‌ها |
|:---:|---|:---:|---|---|
| ۱ | `index.php` | PHP Controller | صفحه فرود اصلی، معرفی آزمون‌ها و هویت بصری برند | `includes/header.php`, `includes/footer.php`, `includes/db.php` |
| ۲ | `install.php` | Standalone Installer | اسکریپت تحت وب نصب اولیه و قفل امنیتی | `includes/db.php`, `config/config.php` |
| ۳ | `.htaccess` | Apache Config | مدیریت هدرهای امنیتی، جلوگیری از ایندکس دایرکتوری و محافظت فایل‌ها | وب‌سرور Apache / LiteSpeed |
| ۴ | `config/config.php` | Config File | پارامترهای اتصال دیتابیس، تنظیمات پرداخت، آدرس‌ها و ثابت‌های سامانه | - |
| ۵ | `config/config.example.php` | Template File | الگوی راهنمای تنظیمات اولیه | - |
| ۶ | `includes/db.php` | DB Layer | مدیریت نشست‌های MySQLi و Prepared Statements امن | درایور mysqli |
| ۷ | `includes/functions.php` | Helpers | توابع امنیتی (CSRF/XSS)، تبدیل تاریخ شمسی، فرمت تومان | `includes/db.php` |
| ۸ | `includes/auth.php` | Auth Layer | مدیریت احراز هویت مدیران و نشست‌های کاربران | `includes/db.php`, `includes/functions.php` |
| ۹ | `includes/engine.php` | Scoring Engine | موتور مرکزی و سرورساید محاسبه نمرات و ردپای استناد علمی | `includes/db.php`, `includes/functions.php` |
| ۱۰ | `includes/header.php` | View Template | سربرگ عمومی سایت، منوی ناوبری و متاتگ‌های سئو | `includes/functions.php`, `includes/auth.php` |
| ۱۱ | `includes/footer.php` | View Template | پاورقی عمومی سایت، شبکه‌های اجتماعی، حق کپی‌رایت | - |
| ۱۲ | `tests/index.php` | Page | فهرست و دسته‌بندی ۱۱ آزمون بالینی | `includes/header.php`, `includes/engine.php` |
| ۱۳ | `tests/intro.php` | Page | صفحه معرفی، رفرنس‌های علمی و پیش‌نیازهای آزمون انتخابی | `includes/engine.php` |
| ۱۴ | `tests/take.php` | Interactive Engine | رابط کاربری اجرای تعاملی آزمون (تک‌انتخابی، ماتریس پرش) | `includes/engine.php`, `assets/js/test-runner.js` |
| ۱۵ | `ajax/submit-test.php` | AJAX Endpoint | پردازش سرورساید پاسخ‌ها، نمره‌دهی و صدور نشست | `includes/engine.php` |
| ۱۶ | `ajax/save-info.php` | AJAX Endpoint | ثبت مشخصات فردی شرکت‌کننده (نام، موبایل، سن، جنسیت) | `includes/db.php`, `includes/functions.php` |
| ۱۷ | `ajax/submit-receipt.php` | AJAX Endpoint | آپلود امن فیش واریزی و ثبت درخواست تفسیر تفصیلی | `includes/db.php`, `includes/functions.php` |
| ۱۸ | `user/complete-info.php` | Page | فرم دریافت اطلاعات تماس بعد از آزمون | `includes/header.php` |
| ۱۹ | `user/result.php` | Page | کارنامه تشخیصی، نمودارهای علمی و وضعیت تحلیل | `includes/header.php`, `assets/js/charts.js` |
| ۲۰ | `user/request-interpretation.php` | Page | درگاه ثبت درخواست تفسیر تفصیلی و بارگذاری فیش | `includes/header.php` |
| ۲۱ | `user/login.php` | Page | ورود کاربران از طریق شماره همراه جهت مشاهده سوابق | `includes/auth.php` |
| ۲۲ | `user/dashboard.php` | Page | پورتال اختصاصی سوابق آزمون‌های مراجع | `includes/auth.php` |
| ۲۳ | `admin/index.php` | Dashboard | داشبورد آمار تحلیلی و وضعیت مراجعین | `admin/header.php`, `includes/auth.php` |
| ۲۴ | `admin/login.php` | Auth Page | فرم لاگین امنیتی مدیریت با کنترل Brute-force | `includes/auth.php` |
| ۲۵ | `admin/requests.php` | Page | مدیریت درخواست‌های تفسیر و بررسی فیش‌ها | `includes/db.php` |
| ۲۶ | `admin/request-detail.php` | Page | نگارش و انتشار تفسیر بالینی با ادیتور غنی | `includes/db.php` |
| ۲۷ | `admin/tests.php` | Page | مدیریت آزمون‌ها، ابعاد و گویه‌ها | `includes/db.php` |
| ۲۸ | `admin/export.php` | Exporter | خروجی استاندارد CSV با BOM جهت تحلیل آماری | `includes/auth.php` |
| ۲۹ | `assets/css/*` | Stylesheets | فایل‌های CSS اختصاصی و ایزوله (style, test, result, admin) | - |
| ۳۰ | `assets/js/*` | Scripts | فایل‌های جاوااسکریپت (test-runner, charts, admin, main) | - |
| ۳۱ | `database/install_safe.sql` | SQL Schema | اسکریپت امن دیتابیس با دستور CREATE TABLE IF NOT EXISTS | پایگاه داده MySQL |

---

## 🔒 اعتبارسنجی امنیتی عدم تداخل (Zero-Conflict Audit)

1. **دامنه و آدرس‌دهی:** به دلیل نصب روی ساب‌دامین مستقل `test.mirbolouki.com`، هیچ‌یک از فایل‌های وب‌سایت اصلی `mirbolouki.com` بازنویسی (Overwrite) نمی‌شوند.
2. **پایگاه داده:** اسکریپت `install_safe.sql` حاوی هیچ دستور مخربی (`DROP DATABASE`، `DROP TABLE`، `TRUNCATE`) نبوده و فقط جداول اختصاصی سامانه را در صورت عدم وجود ایجاد می‌نماید.
3. **متغیرهای سراسری و سشن‌ها:** تمامی توابع و ثوابت با پیشوند اختصاصی و ساختار کپسوله‌شده ایجاد شده‌اند و هیچ تداخلی با سایر اسکریپت‌های احتمالی هاست نخواهند داشت.
