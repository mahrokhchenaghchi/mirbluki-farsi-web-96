<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * صفحه اصلی سامانه ارزیابی بالینی و اکوسیستم هوشمند جوما (Luxury Landing Page)
 * منطبق بر استانداردهای روان‌سنجی، سئو، هویت برند و تجربه کاربری پریمیوم
 */

$page_title = 'سامانه جامع ارزیابی‌های روان‌شناختی و طرحواره‌ای | دکتر جواد میربلوکی';
$meta_description = 'پلتفرم تخصصی ارزیابی‌های روان‌شناختی، پرسشنامه جامع طرحواره‌های یانگ (YSQ-L3)، تست‌های شخصیت و زوج‌درمانی به همراه پلنر هوشمند خودمدیریتی جوما (جغد دانا) زیر نظر دکتر جواد میربلوکی.';
$active_nav = 'home';
$extra_css = array('/assets/css/luxury-home.css');

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/engine.php';

// دریافت فهرست آزمون‌های فعال از پایگاه داده (فقط آزمون‌های فعال و معتبر)
$active_tests = db_fetch_all(
    "SELECT t.*, 
     (SELECT COUNT(*) FROM `test_questions` q WHERE q.test_id = t.id) as question_count,
     (SELECT COUNT(*) FROM `test_dimensions` d WHERE d.test_id = t.id) as dimension_count
     FROM `tests` t 
     WHERE t.is_active = 1 
     ORDER BY t.sort_order ASC, t.id ASC"
);

// تفکیک آزمون گل سرسبد ۲۳۲ سوالی یانگ و سایر آزمون‌ها
$flagship_test = null;
$catalog_tests = array();
foreach ($active_tests as $t) {
    if ($t['slug'] === 'young-schema-full') {
        $flagship_test = $t;
    } else {
        $catalog_tests[] = $t;
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- =========================================================================
     1. HERO LUXURY SECTION
     ========================================================================= -->
<section class="hero-luxury" id="hero">
  <div class="hero-luxury-bg-orb-1"></div>
  <div class="hero-luxury-bg-orb-2"></div>
  
  <div class="container">
    <div class="hero-luxury-grid">
      
      <!-- Right Content: Value Proposition & CTAs -->
      <div>
        <div class="hero-tag-badge">
          <span class="hero-tag-pulse"></span>
          <span>پلتفرم تخصصی سنجش روان‌شناختی و خودمدیریتی رفتاری</span>
        </div>

        <h1 class="hero-luxury-title">
          سنجش علمی الگوهای ناهشیار ذهن؛
          <span class="highlight-teal">از خودآگاهی عمیق</span>
          <span class="highlight-gold">تا تغییر پایدار</span>
        </h1>

        <p class="hero-luxury-lead">
          رابطه‌ها، تصمیم‌ها و کیفیت زندگی ما بر پایه الگوها و طرحواره‌های هیجانی شکل می‌گیرند. در این سامانه، با استفاده از معتبرترین ابزارهای روان‌سنجی بالینی، نیمرخ روانی خود را شفاف ببینید و با هدایت هوشمندانه <strong>جوما (جغد دانا)</strong>، آگاهی را به رفتارهای پایدار روزمره تبدیل کنید.
        </p>

        <!-- 3 Micro Metrics -->
        <div class="hero-micro-metrics">
          <div class="hero-metric-item">
            <div class="hero-metric-val">۱۸ طرحواره</div>
            <div class="hero-metric-lbl">ارزیابی در ۵ حوزه نیازهای تحولی</div>
          </div>
          <div class="hero-metric-item">
            <div class="hero-metric-val">محاسبه متمرکز</div>
            <div class="hero-metric-lbl">نمره‌دهی قطعی در هسته سرور</div>
          </div>
          <div class="hero-metric-item">
            <div class="hero-metric-val">۱۰۰٪ محرمانه</div>
            <div class="hero-metric-lbl">حفظ کامل حریم خصوصی داده‌ها</div>
          </div>
        </div>

        <!-- Hero Actions -->
        <div class="hero-luxury-actions">
          <a href="#flagship-assessment" class="btn-hero-primary">
            <span>شروع ارزیابی ۲۳۲ سوالی یانگ</span>
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7"/></svg>
          </a>
          <a href="#about-joma" class="btn-hero-secondary">
            <span>🦉 آشنایی با پلنر هوشمند جوما</span>
          </a>
        </div>
      </div>

      <!-- Left Visual: Dr. Mirbolouki with JOMA showcase -->
      <div class="hero-visual-card">
        <div class="hero-visual-frame">
          <img src="/assets/images/mirbolouki-joma.jpg" alt="دکتر جواد میربلوکی در کنار جوما؛ جغد دانا" class="hero-showcase-img">
          
          <!-- Floating Badge 1 -->
          <div class="hero-floating-chip-1">
            <span style="font-size: 1.2rem;">✨</span>
            <div style="text-align: right;">
              <strong style="display: block; font-size: 0.82rem; color: #2dd4bf;">YSQ-L3 Gold Standard</strong>
              <small style="color: #cbd5e1;">۲۳۲ گویه بالینی استاندارد</small>
            </div>
          </div>

          <!-- Floating Badge 2 -->
          <div class="hero-floating-chip-2">
            <span style="font-size: 1.2rem;">🦉</span>
            <div style="text-align: right;">
              <strong style="display: block; font-size: 0.82rem; color: #fbbf24;">پلنر روان‌شناسی جوما</strong>
              <small style="color: #cbd5e1;">برنامه • اجرا • فهم • بهبود</small>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================================
     2. TRUST & CREDIBILITY RIBBON
     ========================================================================= -->
<section class="trust-ribbon">
  <div class="container">
    <div class="trust-grid">
      
      <div class="trust-item">
        <div class="trust-icon-box">
          <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
        </div>
        <div class="trust-text">
          <h4>موتور نمره‌دهی متمرکز</h4>
          <p>محاسبه ضد دستکاری در سرور</p>
        </div>
      </div>

      <div class="trust-item">
        <div class="trust-icon-box">
          <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
        </div>
        <div class="trust-text">
          <h4>انطباق بر هنجار ایرانی</h4>
          <p>مبتنی بر اعتبارسنجی دانشگاهی</p>
        </div>
      </div>

      <div class="trust-item">
        <div class="trust-icon-box">
          <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
        </div>
        <div class="trust-text">
          <h4>گزارش‌های ۴ لایه‌ای</h4>
          <p>فرضیه‌سازی بالینی و نقشه درمان</p>
        </div>
      </div>

      <div class="trust-item">
        <div class="trust-icon-box">
          <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
        </div>
        <div class="trust-text">
          <h4>مرزبندی حرفه‌ای و اخلاقی</h4>
          <p>پروتکل‌های مصاحبه بالینی</p>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================================
     3. TESTS CATALOG & BATTERY (ORIGINAL LUXURY CARDS DESIGN)
     ========================================================================= -->
<section class="section-padding" id="tests-catalog" style="background: var(--bg-soft);">
  <div class="container">
    <div class="section-header">
      <span class="section-subtitle">ارزیابی و خودشناسی علمی</span>
      <h2 class="section-title">فهرست آزمون‌های روان‌شناختی سامانه</h2>
      <p class="section-desc">هر آزمون بر پایه سازه‌های روان‌سنجی معتبر و هنجار دانشگاهی طراحی شده و پس از پاسخ‌دهی، کارنامه کمّی و نمودار تفکیکی ابعاد بلافاصله در اختیار شما قرار می‌گیرد.</p>
    </div>

    <?php if (empty($active_tests)): ?>
      <div class="feature-box text-center" style="max-width: 650px; margin: 0 auto; text-align: center;">
        <div class="feature-icon" style="margin: 0 auto 20px;">ℹ️</div>
        <h3 class="feature-title">آزمون‌های سامانه در حال بارگذاری هستند</h3>
        <p class="feature-desc">به زودی عناوین آزمون‌های روان‌شناختی به همراه مشخصات کامل و سوالات استاندارد در این بخش منتشر خواهند شد.</p>
      </div>
    <?php else: ?>
      <div class="tests-grid">
        <?php foreach ($active_tests as $test): ?>
          <div class="test-card">
            <div class="test-card-media">
              <?php if (!empty($test['banner_image']) && file_exists(ROOT_PATH . $test['banner_image'])): ?>
                <img src="<?php echo escape_html($test['banner_image']); ?>" alt="<?php echo escape_html($test['title']); ?>" loading="lazy">
              <?php else: ?>
                <img src="/assets/images/placeholder-test.svg" alt="<?php echo escape_html($test['title']); ?>" loading="lazy">
              <?php endif; ?>
              <div class="test-badge-time">
                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" style="vertical-align: middle; margin-left: 4px;"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                <?php echo to_persian_num($test['estimated_minutes']); ?> دقیقه
              </div>
            </div>

            <div class="test-card-body">
              <h3 class="test-card-title"><?php echo escape_html($test['title']); ?></h3>
              <?php if (!empty($test['original_name'])): ?>
                <div style="font-size: 0.82rem; color: var(--primary-teal); margin-bottom: 10px; font-weight: 600;">
                  (<?php echo escape_html($test['original_name']); ?>)
                </div>
              <?php endif; ?>

              <p class="test-card-desc"><?php echo escape_html($test['description']); ?></p>

              <div class="test-meta-items">
                <div class="test-meta-item">
                  <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                  <span><?php echo to_persian_num($test['question_count']); ?> سؤال</span>
                </div>
                <div class="test-meta-item">
                  <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                  <span><?php echo to_persian_num($test['dimension_count']); ?> بعد تحلیلی</span>
                </div>
                <div class="test-meta-item">
                  <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                  <span>نسخه <?php echo to_persian_num($test['version']); ?></span>
                </div>
              </div>

              <div style="margin-top: auto;">
                <a href="/tests/intro.php?slug=<?php echo urlencode($test['slug']); ?>" class="btn btn-primary btn-block">
                  <span>مشاهده مشخصات و شروع</span>
                  <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<!-- =========================================================================
     5. THE 4-STEP PSYCHOLOGICAL WORKFLOW
     ========================================================================= -->
<section class="workflow-section" id="clinical-workflow">
  <div class="container">
    <div class="section-header">
      <span class="section-subtitle">مسیر تحول و خودمدیریتی</span>
      <h2 class="section-title">چرخه یکپارچه: از ارزیابی تا تغییر پایدار رفتاری</h2>
      <p class="section-desc">فرآیند علمی ۴ مرحله‌ای سامانه برای مشاهده الگوها، فهم ریشه‌ها و ساختن عادات سالم</p>
    </div>

    <div class="workflow-grid">
      
      <!-- Step 1 -->
      <div class="workflow-card">
        <span class="workflow-step-num">۱</span>
        <div class="workflow-icon">
          <svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
        </div>
        <h4>ارزیابی استاندارد (Assessment)</h4>
        <p>پاسخ‌دهی به گویه‌های طبیعی و روزمره بدون قضاوت؛ شناسایی بدون سوگیری الگوهای فکری و هیجانی.</p>
      </div>

      <!-- Step 2 -->
      <div class="workflow-card">
        <span class="workflow-step-num">۲</span>
        <div class="workflow-icon">
          <svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
        </div>
        <h4>کارنامه و درک ابعاد (Insight)</h4>
        <p>محاسبه آنی نمرات خام، شدت ابعاد و نمودارهای گرافیکی ۵ حوزه و ۱۸ طرحواره در هسته امن سرور.</p>
      </div>

      <!-- Step 3 -->
      <div class="workflow-card">
        <span class="workflow-step-num">۳</span>
        <div class="workflow-icon">
          <svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
        </div>
        <h4>فرمول‌بندی بالینی (Formulation)</h4>
        <p>تفسیر چندبعدی، تحلیل الگوهای تعاملی (Tier C) و نقشه درمانی تصمیم‌یار برای بهبود روابط و روان.</p>
      </div>

      <!-- Step 4 -->
      <div class="workflow-card" style="border-color: var(--lux-gold-400); background: #fefce8;">
        <span class="workflow-step-num" style="background: var(--lux-gold-500);">۴</span>
        <div class="workflow-icon" style="color: #d97706;">
          <svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2a5 5 0 00-5 5c0 2.5 1.5 4.5 3 5.5v2.5a2 2 0 002 2h0a2 2 0 002-2V12.5c1.5-1 3-3 3-5.5a5 5 0 00-5-5z"/><circle cx="9" cy="7" r="1"/><circle cx="15" cy="7" r="1"/></svg>
        </div>
        <h4 style="color: #92400e;">خودمدیریتی با جوما (Action)</h4>
        <p>تبدیل آگاهی به عمل با پلنر هوشمند <strong>جوما</strong>؛ ثبت حال روزانه، ساخت عادات پایدار و پایش پیوسته.</p>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================================
     6. JOMA SPOTLIGHT & STORYTELLING (EMBLEM + FOUNDER PHOTO)
     ========================================================================= -->
<section class="joma-showcase-section" id="about-joma">
  <div class="container">
    <div class="joma-card-wrapper">
      
      <!-- Dual Media Grid (Emblem Medallion + Dr. Mirbolouki Photo) -->
      <div class="joma-dual-media-grid">
        <div class="joma-emblem-frame">
          <img src="/assets/images/joma-emblem-logo.jpg" alt="لوگوی پلتفرم روانشناسی جغد دانا (جوما)" class="joma-emblem-img" loading="lazy">
        </div>
        <div class="joma-image-frame">
          <img src="/assets/images/mirbolouki-joma.jpg" alt="دکتر جواد میربلوکی در کنار جوما؛ جغد دانا" class="joma-img" loading="lazy">
        </div>
      </div>

      <!-- Narrative & Real Joma Product Features -->
      <div class="joma-content">
        <div class="joma-badge-top">
          <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24" style="margin-left: 6px;"><path d="M12 2a5 5 0 00-5 5c0 2.5 1.5 4.5 3 5.5v2.5a2 2 0 002 2h0a2 2 0 002-2V12.5c1.5-1 3-3 3-5.5a5 5 0 00-5-5z"/></svg>
          <span>اکوسیستم اختصاصی خودمدیریتی و عادت‌سازی</span>
        </div>

        <h2 class="joma-title">
          پلنر هوشمند روان‌شناسی <span>جوما (جغد دانا)</span>
        </h2>

        <p class="joma-lead">
          آزمون‌های روان‌شناختی، الگوهای فکری و تله‌های ناهشیار ذهن را شفاف می‌کنند؛ اما در روان‌شناسی، <strong>«دانستن» فقط نیمی از مسیر است</strong>. فاصله میان دانستن و تغییر واقعی، تنها با مشاهده‌گری، گام‌های کوچک و استمرار هوشمندانه روزمره پر می‌شود.
        </p>

        <div class="joma-quote-box">
          «جغد دانا (جوما) نماد دانایی، مشاهده‌گری و نگاه عمیق است؛ قبل از اینکه برای تغییر عجله کنیم، خودمان را ببینیم، رفتارمان را مشاهده کنیم و آگاهانه انتخاب کنیم.»
          <div style="font-size: 0.84rem; color: #fbbf24; margin-top: 6px; font-weight: 700;">— جواد میربلوکی | طراح و بنیان‌گذار جوما در ایران</div>
        </div>

        <!-- Real Product Features from joma.mirbolouki.com -->
        <div class="joma-live-features-grid">
          <div class="joma-live-feat">
            <strong style="display: flex; align-items: center; gap: 6px; color: #fbbf24; margin-bottom: 4px;">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></svg>
              ثبت حال روزانه با استیکر
            </strong>
            <span>پایش نوسانات هیجانی و ارتباط حال روحی با رفتارهای روز</span>
          </div>
          <div class="joma-live-feat">
            <strong style="display: flex; align-items: center; gap: 6px; color: #fbbf24; margin-bottom: 4px;">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
              کتابخانه ۴۵ فعالیت آماده
            </strong>
            <span>ورزش، خواب، مطالعه، تنظیم عاطفی، مرزبندی و رشد فردی</span>
          </div>
          <div class="joma-live-feat">
            <strong style="display: flex; align-items: center; gap: 6px; color: #fbbf24; margin-bottom: 4px;">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              دوره‌های شمسی مستقل
            </strong>
            <span>نگهداری تاریخچه مستقل هر ماه شمسی برای مشاهده پیشرفت</span>
          </div>
          <div class="joma-live-feat">
            <strong style="display: flex; align-items: center; gap: 6px; color: #fbbf24; margin-bottom: 4px;">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              گزارش فقط از داده واقعی
            </strong>
            <span>مشاهده روند واقعی و پایبندی بدون فشار کمال‌گرایی کاذب</span>
          </div>
        </div>

        <!-- Joma CTAs -->
        <div class="joma-buttons">
          <a href="https://joma.mirbolouki.com" target="_blank" rel="noopener" class="btn-joma-primary">
            <span>ورود به پلنر هوشمند جوما (joma.mirbolouki.com)</span>
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
          </a>
          <a href="https://mirbolouki.com" target="_blank" rel="noopener" class="btn-joma-outline">
            <span>درباره خدمات دکتر جواد میربلوکی</span>
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================================
     7. CLINICIANS & THERAPISTS HUB
     ========================================================================= -->
<section class="therapists-hub-section" id="therapists-hub">
  <div class="container">
    <div class="therapists-card">
      <div>
        <span class="custom-badge badge-primary" style="margin-bottom: 12px;">ویژه متخصصان سلامت روان</span>
        <h3 style="font-size: 1.45rem; font-weight: 800; color: var(--lux-navy-900); margin-bottom: 12px;">ابزار تصمیم‌یار بالینی برای روانشناسان و زوج‌درمانگران</h3>
        <p style="color: var(--lux-slate-500); font-size: 0.92rem; line-height: 1.8; margin-bottom: 20px;">
          این سامانه فراتر از یک آزمون‌گیر عمومی است؛ داده‌های خروجی به عنوان ابزار غربالگری و داده کمکی ساختاریافته در اختیار روان‌درمانگران قرار می‌گیرد تا سرعت و کیفیت فرمول‌بندی بالینی در جلسات افزایش یابد.
        </p>

        <div class="therapists-list-item">
          <span style="color: var(--lux-teal-600); font-weight: 800;">✓</span>
          <span><strong>تحلیل ۱۸ بعد و ۵ حوزه:</strong> شناسایی دقیق تله‌های روانی مراجع قبل یا حین درمان.</span>
        </div>
        <div class="therapists-list-item">
          <span style="color: var(--lux-teal-600); font-weight: 800;">✓</span>
          <span><strong>مسیر استناد اتمیک (Audit Trail):</strong> مشاهده نحوه پاسخ‌دهی مراجع به تک‌تک ۲۳۲ سوال.</span>
        </div>
        <div class="therapists-list-item">
          <span style="color: var(--lux-teal-600); font-weight: 800;">✓</span>
          <span><strong>تکالیف بین‌جلسه‌ای با جوما:</strong> امکان پایش پیگیری تمرین‌های رفتاری مراجع در پلنر هوشمند.</span>
        </div>
      </div>

      <div style="background: var(--lux-slate-50); border: 1px dashed var(--lux-slate-300); border-radius: 16px; padding: 24px; text-align: center;">
        <div style="margin-bottom: 10px; color: var(--lux-teal-600);">
          <svg width="38" height="38" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
        </div>
        <h4 style="font-size: 1.05rem; font-weight: 700; color: var(--lux-navy-900); margin-bottom: 8px;">مرزبندی تصمیم‌یار بالینی</h4>
        <p style="font-size: 0.82rem; color: var(--lux-slate-500); line-height: 1.6; margin-bottom: 16px;">
          این پلتفرم نقش تصمیم‌یار تشخیصی (Decision Support) را ایفا می‌کند و هیچ‌گاه جایگزین مصاحبه بالینی و قضاوت تخصصی متخصص نخواهد بود.
        </p>
        <a href="#tests-catalog" class="btn btn-outline btn-sm btn-block">
          مشاهده باتری آزمون‌های بالینی
        </a>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     8. INTERACTIVE FAQ SECTION
     ========================================================================= -->
<section class="section-padding" id="faq" style="background: #ffffff;">
  <div class="container">
    <div class="section-header">
      <span class="section-subtitle">راهنمای مراجعین</span>
      <h2 class="section-title">پرسش‌های متداول</h2>
      <p class="section-desc">پاسخ به سوالات رایج پیرامون نحوه پاسخ‌دهی، تفسیر کارنامه و امنیت داده‌ها</p>
    </div>

    <div class="faq-container">
      <div class="faq-item">
        <button class="faq-question">
          <span>آیا انجام این آزمون‌ها برای تشخیص قطعی اختلالات روان‌شناختی کافی است؟</span>
          <span class="faq-icon">▼</span>
        </button>
        <div class="faq-answer">
          خیر؛ آزمون‌های خودسنجی روان‌شناختی ابزاری استاندارد برای غربالگری، شناخت الگوهای ذهنی و افزایش خودآگاهی هستند. هرگونه تشخیص نهایی، ارزیابی بالینی و طرح درمان نیازمند مصاحبه تخصصی و بررسی جامع توسط روان‌درمانگر است.
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-question">
          <span>تفسیر کامل آزمون چه تفاوتی با نتیجه کوتاه اولیه دارد؟</span>
          <span class="faq-icon">▼</span>
        </button>
        <div class="faq-answer">
          نتیجه اولیه بلافاصله شامل نمرات عددی، رتبه‌بندی ابعاد و نمودارهای گرافیکی صادر می‌شود. اما در تفسیر کامل، نمرات شما توسط متخصص تحلیل شده و ارتباط الگوها، ریشه‌های احتمالی در تجارب زیسته و توصیه‌های اختصاصی برای بهبود روابط و کیفیت زندگی به آن افزوده می‌شود.
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-question">
          <span>چگونه می‌توانم در آینده به نتایج آزمون‌های قبلی خود دسترسی داشته باشم؟</span>
          <span class="faq-icon">▼</span>
        </button>
        <div class="faq-answer">
          شما در هر زمان می‌توانید با مراجعه به بخش «ورود / آزمون‌های من» و وارد کردن شماره همراهی که در پایان آزمون ثبت کرده‌اید، به تاریخچه کارنامه‌ها و تفاسیر منتشرشده خود دسترسی داشته باشید.
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-question">
          <span>پلنر جوما (جغد دانا) چه ارتباطی با این آزمون‌ها دارد؟</span>
          <span class="faq-icon">▼</span>
        </button>
        <div class="faq-answer">
          آزمون‌ها به شما کمک می‌کنند تله‌های فکری و طرحواره‌ها را بشناسید (دانستن). پلنر هوشمند جوما (joma.mirbolouki.com) ابزاری است برای ثبت احوال روزانه، تمرینات رفتاری و عادت‌سازی تا بتوانید یافته‌های آزمون را به رفتارهای سالم و پایدار در زندگی تبدیل کنید (عمل کردن).
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-question">
          <span>فرایند پرداخت و ارسال فیش برای تفسیر کامل چگونه است؟</span>
          <span class="faq-icon">▼</span>
        </button>
        <div class="faq-answer">
          هزینه تفسیر کامل ۳۶۹,۰۰۰ تومان است که به شماره کارت ۵۸۵۹۸۳۱۸۵۴۴۰۵۸۳۳ (به نام جواد میربلوکی) واریز می‌شود. سپس تصویر فیش را در سامانه بارگذاری نموده یا از طریق پیامک / پیام‌رسان بله به شماره ۰۹۹۶۷۹۷۹۴۷۱ ارسال می‌فرمایید تا پس از تایید، تفسیر شما نگارش و منتشر گردد.
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     9. DEDICATED ADMIN QUICK GATEWAY BANNER
     ========================================================================= -->
<section class="admin-gateway-bar">
  <div class="container">
    <div class="admin-gateway-flex">
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="font-size: 1.1rem;">🔐</span>
        <span><strong>بخش دسترسی مدیریت و درمانگران:</strong> ورود به پنل پایش کارنامه‌ها، بررسی مالی و صدور تفاسیر بالینی</span>
      </div>
      <div>
        <a href="/admin/login.php" class="btn-admin-gate">
          <span>ورود به پنل مدیریت سامانه (Admin Portal) ↗</span>
        </a>
      </div>
    </div>
  </div>
</section>

<!-- Category Filtering Vanilla JS Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const filterButtons = document.querySelectorAll('.cat-tab-btn');
  const testCards = document.querySelectorAll('.lux-test-card');

  filterButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      filterButtons.forEach(b => b.classList.remove('active'));
      this.classList.add('active');

      const filterValue = this.getAttribute('data-filter');

      testCards.forEach(card => {
        if (filterValue === 'all' || card.getAttribute('data-category') === filterValue) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
