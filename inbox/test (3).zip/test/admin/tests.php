<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * مدیریت آزمون‌ها (Tests Manager)
 */

$admin_page_title = 'مدیریت آزمون‌ها';
$active_tab = 'tests';

require_once __DIR__ . '/header.php';

// عملیات فعال/غیرفعال‌سازی آزمون
if (isset($_GET['toggle_id'])) {
    $toggle_id = intval($_GET['toggle_id']);
    $t = db_fetch_one("SELECT id, is_active FROM `tests` WHERE `id` = ? LIMIT 1", 'i', array($toggle_id));
    if ($t) {
        $new_status = intval($t['is_active']) === 1 ? 0 : 1;
        db_update('tests', array('is_active' => $new_status), 'id = ?', 'i', array($toggle_id));
        set_flash('success', 'وضعیت آزمون تغییر یافت.');
    }
    redirect('/admin/tests.php');
}

$tests = db_fetch_all(
    "SELECT t.*, 
     (SELECT COUNT(*) FROM `test_questions` q WHERE q.test_id = t.id) as question_count,
     (SELECT COUNT(*) FROM `test_dimensions` d WHERE d.test_id = t.id) as dimension_count,
     (SELECT COUNT(*) FROM `test_sources` s WHERE s.test_id = t.id) as source_count,
     (SELECT COUNT(*) FROM `test_results` r WHERE r.test_id = t.id) as results_count
     FROM `tests` t 
     ORDER BY t.sort_order ASC, t.id ASC"
);
?>

<div class="admin-card">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.25rem; margin-bottom: 4px;">فهرست آزمون‌های بالینی و روان‌سنجی سامانه</h3>
      <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 0;">مدیریت کامل مشخصات، گویه‌ها، ابعاد و منابع علمی هر آزمون</p>
    </div>

    <div>
      <a href="/admin/test-edit.php" class="btn btn-primary">
        <span>+ ایجاد آزمون جدید</span>
      </a>
    </div>
  </div>

  <?php if (empty($tests)): ?>
    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
      هنوز آزمونی تعریف نشده است. جهت ایجاد اولین آزمون، دکمه بالا را انتخاب فرمایید.
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>شناسه</th>
            <th>عنوان آزمون</th>
            <th>نام اختصاری</th>
            <th>سؤالات</th>
            <th>ابعاد</th>
            <th>منابع علمی</th>
            <th>نتایج ثبت‌شده</th>
            <th>وضعیت</th>
            <th>عملیات و پیکربندی تخصصی</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tests as $t): ?>
            <tr>
              <td><code>#<?php echo $t['id']; ?></code></td>
              <td><strong><?php echo escape_html($t['title']); ?></strong></td>
              <td><?php echo escape_html($t['original_name'] ? $t['original_name'] : '-'); ?></td>
              <td><span class="custom-badge badge-primary"><?php echo to_persian_num($t['question_count']); ?> گویه</span></td>
              <td><?php echo to_persian_num($t['dimension_count']); ?> بعد</td>
              <td>
                <a href="/admin/sources.php?test_id=<?php echo $t['id']; ?>" class="custom-badge badge-secondary" title="مشاهده منابع علمی">
                  📚 <?php echo to_persian_num($t['source_count']); ?> منبع
                </a>
              </td>
              <td>
                <a href="/admin/results.php?test_id=<?php echo $t['id']; ?>" class="custom-badge badge-success" title="مشاهده نتایج این آزمون">
                  📊 <?php echo to_persian_num($t['results_count']); ?> نتیجه
                </a>
              </td>
              <td>
                <?php if (intval($t['is_active']) === 1): ?>
                  <span class="custom-badge badge-success">فعال (در سایت)</span>
                <?php else: ?>
                  <span class="custom-badge badge-secondary">آرشیو (سوابق محفوظ)</span>
                <?php endif; ?>
              </td>
              <td>
                <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                  <a href="/admin/test-edit.php?id=<?php echo $t['id']; ?>" class="btn btn-outline btn-sm" title="ویرایش مشخصات">
                    ویرایش آزمون
                  </a>
                  <a href="/admin/questions.php?test_id=<?php echo $t['id']; ?>" class="btn btn-primary btn-sm" title="مدیریت سؤالات">
                    مشاهده سؤالات (<?php echo to_persian_num($t['question_count']); ?>)
                  </a>
                  <a href="/admin/scoring-rules.php?test_id=<?php echo $t['id']; ?>" class="btn btn-luxury btn-sm" title="ابعاد و قوانین نمره‌دهی">
                    ابعاد و نمرات
                  </a>
                  <a href="/admin/sources.php?test_id=<?php echo $t['id']; ?>" class="btn btn-sm" style="background: #e0f2fe; color: #0369a1;" title="منابع و مراجع علمی">
                    مشاهده منابع
                  </a>
                  <a href="/admin/results.php?test_id=<?php echo $t['id']; ?>" class="btn btn-sm" style="background: #f0fdf4; color: #166534;" title="مشاهده نتایج ثبت‌شده این آزمون">
                    مشاهده نتایج
                  </a>
                  <a href="/tests/intro.php?slug=<?php echo urlencode($t['slug']); ?>" target="_blank" class="btn btn-sm" style="background: #f8fafc; color: #475569;" title="پیش‌نمایش در سایت">
                    پیش‌نمایش ↗
                  </a>
                  <a href="/admin/tests.php?toggle_id=<?php echo $t['id']; ?>" class="btn btn-sm" style="background: #f1f5f9; color: #475569;">
                    <?php echo intval($t['is_active']) === 1 ? 'غیرفعال‌سازی' : 'فعال‌سازی'; ?>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
