<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * جزئیات کامل کارنامه و استنادپذیری نمرات برای ادمین (Result Audit & Detailed View)
 */

$admin_page_title = 'استناد و جزئیات کارنامه';
$active_tab = 'results';
$admin_extra_js = array('/assets/js/charts.js');

require_once __DIR__ . '/header.php';

$result_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($result_id <= 0) {
    redirect('/admin/results.php');
}

$result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($result_id));
if (!$result) {
    set_flash('danger', 'کارنامه یافت نشد.');
    redirect('/admin/results.php');
}

$user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($result['user_id']));
$test = engine_get_test($result['test_id']);
$dimension_scores = json_decode($result['dimension_scores_json'], true);
$audit_trail = json_decode($result['scientific_audit_trail_json'], true);

// بررسی وجود درخواست تفسیر
$interp_request = db_fetch_one("SELECT * FROM `interpretation_requests` WHERE `result_id` = ? LIMIT 1", 'i', array($result_id));

// امکان ایجاد مستقیم پرونده تفسیر توسط مدیر در صورت عدم وجود درخواست
if (isset($_GET['action']) && $_GET['action'] === 'create_direct_interpretation' && !$interp_request) {
    $req_code = 'DIR-' . strtoupper(generate_token(8));
    $req_id = db_insert('interpretation_requests', array(
        'result_id' => $result_id,
        'user_id' => $result['user_id'],
        'test_id' => $result['test_id'],
        'request_code' => $req_code,
        'amount' => INTERPRETATION_PRICE,
        'payment_status' => 'payment_confirmed',
        'requested_at' => date('Y-m-d H:i:s'),
        'payment_verified_at' => date('Y-m-d H:i:s'),
        'admin_notes' => 'ایجاد مستقیم توسط مدیر در پنل مدیریت'
    ));
    set_flash('success', 'میز کار تفسیر کامل ایجاد گردید.');
    redirect('/admin/request-detail.php?id=' . $req_id);
}
?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
  <a href="/admin/results.php" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; color: #64748b; font-weight: 600;">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
    <span>بازگشت به فهرست کارنامه‌ها</span>
  </a>

  <div style="display: flex; gap: 8px; flex-wrap: wrap;">
    <a href="/user/download_report.php?id=<?php echo $result_id; ?>&type=initial&action=view" target="_blank" class="btn btn-outline btn-sm">
      📄 مشاهده PDF کارنامه اولیه
    </a>
    
    <?php if ($interp_request): ?>
      <a href="/admin/request-detail.php?id=<?php echo $interp_request['id']; ?>" class="btn btn-luxury btn-sm">
        ورود به میز کار تفسیر کامل ↗
      </a>
    <?php else: ?>
      <a href="/admin/result-detail.php?id=<?php echo $result_id; ?>&action=create_direct_interpretation" class="btn btn-luxury btn-sm">
        + ایجاد میز کار و نگارش تفسیر ↗
      </a>
    <?php endif; ?>
  </div>
</div>

<!-- Header Info Card -->
<div class="admin-card" style="margin-bottom: 24px;">
  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 16px;">
    <div>
      <span class="custom-badge badge-primary">کارنامه شماره #<?php echo $result['id']; ?></span>
      <h2 style="font-size: 1.4rem; margin-top: 8px; margin-bottom: 4px;"><?php echo escape_html($test['title']); ?> (نسخه <?php echo to_persian_num($result['test_version']); ?>)</h2>
      <div style="font-size: 0.88rem; color: #64748b;">تاریخ انجام آزمون: <?php echo format_jalali_date($result['created_at']); ?></div>
    </div>

    <div style="text-align: left; background: #f8fafc; padding: 16px 20px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
      <div>مراجع: <strong><?php echo escape_html($user['first_name'] . ' ' . $user['last_name']); ?></strong></div>
      <div>همراه: <strong><?php echo to_persian_num($user['mobile']); ?></strong></div>
      <div>سن: <?php echo to_persian_num($user['age']); ?> سال (<?php echo $user['gender'] === 'female' ? 'زن' : 'مرد'; ?>)</div>
    </div>
  </div>
</div>

<!-- Scores Summary & Canvas Chart -->
<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; margin-bottom: 30px;">
  <div class="admin-card">
    <h3 style="font-size: 1.15rem; margin-bottom: 16px;">خلاصه نمرات کل</h3>
    <div style="text-align: center; padding: 20px; background: #f8fafc; border-radius: var(--radius-md); margin-bottom: 16px;">
      <div style="font-size: 2.5rem; font-weight: 900; color: var(--primary-teal);"><?php echo to_persian_num($result['total_score']); ?></div>
      <div style="color: #64748b; font-size: 0.85rem;">نمره کل حاصل از پردازش بک‌اند</div>
    </div>
    <div style="font-size: 0.92rem; line-height: 2;">
      <div>طبقه‌بندی: <strong><?php echo escape_html($result['overall_category']); ?></strong></div>
      <div>سطح شدت: <?php echo format_severity_badge($result['overall_severity']); ?></div>
      <div style="margin-top: 10px; font-size: 0.88rem; color: #475569; background: #ffffff; padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-light);">
        <?php echo nl2br(escape_html($result['short_interpretation'])); ?>
      </div>
    </div>
  </div>

  <div class="admin-card">
    <h3 style="font-size: 1.15rem; margin-bottom: 16px;">نمودار تحلیلی ابعاد (Dimensions Profile)</h3>
    <div style="position: relative; width: 100%; min-height: 280px;">
      <canvas id="adminDimChart" style="width: 100%; height: 280px;"></canvas>
    </div>
  </div>
</div>

<?php 
$is_young_test = (strpos($test['slug'], 'young') !== false || strpos($test['slug'], 'schema') !== false);
if ($is_young_test): 
  $schema_domains = engine_calculate_schema_domains($dimension_scores);
  $schema_patterns = engine_evaluate_schema_patterns($dimension_scores);
  $treatment_map = engine_generate_treatment_map($dimension_scores, $schema_patterns);
  $sci_trace = engine_get_interpretation_trace($result_id);
?>
<!-- 5 Domains & Clinical Hypotheses Panel (YSQ Specific) -->
<div class="admin-card" style="margin-bottom: 30px; border: 1.5px solid #0d9488;">
  <div class="card-header-flex" style="border-bottom: 1px solid var(--border-light); padding-bottom: 12px; margin-bottom: 16px;">
    <div>
      <h3 style="font-size: 1.2rem; margin-bottom: 4px; color: #0f766e;">🧠 حوزه‌های پنج‌گانه مرتبه دوم و فرضیه‌سازی بالینی (5 Domains & Clinical Hypotheses)</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 0;">تفکیک سطوح تحلیل بر پایه مدل استاندارد جفری یانگ و پروتکل‌های چندبعدی</p>
    </div>
    <div>
      <span class="custom-badge badge-primary">Tier A / B / C / D</span>
    </div>
  </div>

  <!-- 5 Domains Grid -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 24px;">
    <?php foreach ($schema_domains as $d_key => $dom): ?>
      <div style="background: #f8fafc; border-radius: var(--radius-sm); border-right: 4px solid <?php echo $dom['color']; ?>; padding: 12px 14px;">
        <div style="font-size: 0.82rem; color: #64748b; font-weight: 600;"><?php echo escape_html($dom['title']); ?></div>
        <div style="font-size: 1.3rem; font-weight: 800; color: #0f172a; margin: 4px 0;">
          <?php echo to_persian_num($dom['percentage']); ?>٪
        </div>
        <div>
          <?php echo format_severity_badge($dom['severity']); ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Patterns (Tier C) -->
  <?php if (!empty($schema_patterns)): ?>
    <div style="margin-bottom: 20px; background: #fffbeb; border: 1px solid #fde68a; border-radius: var(--radius-sm); padding: 16px;">
      <h4 style="font-size: 1rem; color: #92400e; margin-bottom: 10px;">🔍 الگوهای فعال فرضیه‌سازی بالینی (Tier C Patterns):</h4>
      <?php foreach ($schema_patterns as $pat): ?>
        <div style="margin-bottom: 10px; font-size: 0.9rem; line-height: 1.8;">
          <strong>• <?php echo escape_html($pat['title']); ?>:</strong>
          <span style="color: #451a03;"><?php echo escape_html($pat['description']); ?></span>
          <span style="font-size: 0.8rem; color: #78350f;">(استناد: <?php echo escape_html($pat['source']); ?>)</span>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <!-- Treatment Map (Tier D) -->
  <?php if (!empty($treatment_map)): ?>
    <div>
      <h4 style="font-size: 1rem; color: #0f766e; margin-bottom: 10px;">🎯 اولویت‌های مداخله و پرسش‌های پیشنهادی درمانگر (Tier D Treatment Support):</h4>
      <div style="display: flex; flex-direction: column; gap: 10px;">
        <?php foreach ($treatment_map as $tm): ?>
          <div style="background: #ffffff; border: 1px solid var(--border-light); border-radius: var(--radius-sm); padding: 14px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <strong>حوزه: <?php echo escape_html($tm['schema_title']); ?> (شدت <?php echo to_persian_num($tm['percentage']); ?>٪)</strong>
              <span class="custom-badge badge-warning">اولویت: <?php echo escape_html($tm['priority']); ?></span>
            </div>
            <div style="font-size: 0.88rem; color: #334155; margin-bottom: 4px;"><strong>هدف درمانی:</strong> <?php echo escape_html($tm['treatment_target']); ?></div>
            <div style="font-size: 0.88rem; color: #334155; margin-bottom: 4px;"><strong>تکنیک‌های مداخله:</strong> <?php echo escape_html($tm['intervention_domain']); ?></div>
            <?php if (!empty($tm['explore_questions'])): ?>
              <div style="font-size: 0.85rem; color: #64748b; margin-top: 6px;">
                <strong>پرسش‌های اکتشافی درمانگر:</strong>
                <ul style="margin: 4px 0 0 16px; padding: 0;">
                  <?php foreach ($tm['explore_questions'] as $eq): ?>
                    <li><?php echo escape_html($eq); ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Full Scientific Audit Trail Table -->
<div class="admin-card">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.2rem; margin-bottom: 4px;">مسیر کامل استناد و پاسخ‌های داده‌شده (Scientific Audit Trail)</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 0;">ردیابی اتمیک تمام سؤالات، گزینه‌ها، مقادیر عددی خام و اعمال معکوس‌سازی</p>
    </div>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>شماره</th>
          <th>متن کامل سؤال</th>
          <th>گزینه انتخابی کاربر</th>
          <th>نمره خام گزینه</th>
          <th>نمره‌گذاری معکوس؟</th>
          <th>نمره نهایی گویه</th>
          <th>بعد / مؤلفه</th>
        </tr>
      </thead>
      <tbody>
        <?php if (is_array($audit_trail)): ?>
          <?php foreach ($audit_trail as $item): ?>
            <tr>
              <td><strong><?php echo to_persian_num($item['question_number']); ?></strong></td>
              <td><?php echo escape_html($item['question_text']); ?></td>
              <td><?php echo escape_html($item['selected_option_text']); ?> (گزینه <?php echo to_persian_num($item['selected_option_number']); ?>)</td>
              <td><?php echo to_persian_num($item['option_raw_score']); ?></td>
              <td>
                <?php echo $item['is_reverse_scored'] ? '<span class="custom-badge badge-warning">بله (معکوس)</span>' : 'خیر'; ?>
              </td>
              <td style="font-weight: 800; color: var(--primary-teal);"><?php echo to_persian_num($item['item_final_score']); ?></td>
              <td><span class="custom-badge badge-primary"><?php echo escape_html($item['dimension_title']); ?></span></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const dimData = <?php echo json_encode($dimension_scores ? $dimension_scores : array(), JSON_UNESCAPED_UNICODE); ?>;
  if (typeof MirboloukiCharts !== 'undefined') {
    MirboloukiCharts.renderDimensionBarChart('adminDimChart', dimData);
  }
});
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
