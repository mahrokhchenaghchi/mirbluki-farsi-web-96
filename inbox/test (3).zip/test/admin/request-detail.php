<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * میز کار بررسی مالی، تولید خودکار، نگارش، پیش‌نمایش و انتشار تفسیر کامل (Interpretation Workspace & Editor)
 */

$admin_page_title = 'میز کار تدوین و انتشار تفسیر کامل';
$active_tab = 'requests';

require_once __DIR__ . '/header.php';

$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($request_id <= 0) {
    set_flash('danger', 'شناسه درخواست نامعتبر است.');
    redirect('/admin/requests.php');
}

$request = db_fetch_one("SELECT * FROM `interpretation_requests` WHERE `id` = ? LIMIT 1", 'i', array($request_id));
if (!$request) {
    set_flash('danger', 'درخواست مورد نظر یافت نشد.');
    redirect('/admin/requests.php');
}

$user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($request['user_id']));
$result = db_fetch_one("SELECT * FROM `test_results` WHERE `id` = ? LIMIT 1", 'i', array($request['result_id']));
$test = engine_get_test($request['test_id']);
$dimension_scores = json_decode($result['dimension_scores_json'], true);

// دریافت رکورد تفسیر کامل
$interp = db_fetch_one("SELECT * FROM `full_interpretations` WHERE `request_id` = ? LIMIT 1", 'i', array($request_id));

// پردازش فرم‌های ادمین
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی نشست. لطفاً دوباره تلاش فرمایید.');
        redirect('/admin/request-detail.php?id=' . $request_id);
    }

    $action = isset($_POST['action']) ? clean_input($_POST['action']) : '';

    // ۱. عملیات تغییر وضعیت پرداخت (تایید یا رد)
    if ($action === 'verify_payment') {
        $payment_status = clean_input($_POST['payment_status']);
        $admin_notes = clean_input($_POST['admin_notes']);
        $now = date('Y-m-d H:i:s');
        
        $verified_at = ($payment_status === 'payment_confirmed') ? $now : null;

        db_update('interpretation_requests', array(
            'payment_status' => $payment_status,
            'admin_notes' => $admin_notes,
            'payment_verified_at' => $verified_at
        ), 'id = ?', 'i', array($request_id));

        // اگر پرداخت تایید شد و تفسیری وجود نداشت، موتور تفسیر را خودکار فراخوانی کن
        if ($payment_status === 'payment_confirmed' && !$interp) {
            $gen = engine_generate_full_interpretation($result['id']);
            if ($gen) {
                db_insert('full_interpretations', array(
                    'request_id' => $request_id,
                    'result_id' => intval($request['result_id']),
                    'user_id' => intval($request['user_id']),
                    'test_id' => intval($request['test_id']),
                    'scientific_interpretation' => $gen['scientific_interpretation'],
                    'admin_additional_notes' => '',
                    'clinical_recommendations' => $gen['clinical_recommendations'],
                    'status' => 'draft',
                    'created_by_admin_id' => $admin['id'],
                    'created_at' => $now
                ));
            }
        }

        log_event('info', 'payment_status_updated', "وضعیت مالی درخواست {$request['request_code']} به {$payment_status} تغییر یافت.");
        set_flash('success', 'وضعیت مالی با موفقیت بروزرسانی شد.');
        redirect('/admin/request-detail.php?id=' . $request_id);
    }

    // ۲. بازتولید تفسیر توسط موتور علمی (Regenerate by Engine)
    if ($action === 'regenerate_engine') {
        $gen = engine_generate_full_interpretation($result['id']);
        if ($gen) {
            $now = date('Y-m-d H:i:s');
            if ($interp) {
                db_update('full_interpretations', array(
                    'scientific_interpretation' => $gen['scientific_interpretation'],
                    'clinical_recommendations' => $gen['clinical_recommendations'],
                    'updated_at' => $now
                ), 'id = ?', 'i', array($interp['id']));
            } else {
                db_insert('full_interpretations', array(
                    'request_id' => $request_id,
                    'result_id' => intval($request['result_id']),
                    'user_id' => intval($request['user_id']),
                    'test_id' => intval($request['test_id']),
                    'scientific_interpretation' => $gen['scientific_interpretation'],
                    'admin_additional_notes' => '',
                    'clinical_recommendations' => $gen['clinical_recommendations'],
                    'status' => 'draft',
                    'created_by_admin_id' => $admin['id'],
                    'created_at' => $now
                ));
            }
            log_event('info', 'interpretation_regenerated', "تفسیر علمی آزمون با موفقیت توسط موتور روان‌سنجی بازتولید شد.");
            set_flash('success', 'تفسیر علمی استاندارد توسط موتور هوشمند سامانه بازتولید شد.');
        } else {
            set_flash('danger', 'خطا در تولید تفسیر توسط موتور علمی.');
        }
        redirect('/admin/request-detail.php?id=' . $request_id);
    }

    // ۳. عملیات ذخیره پیش‌نویس و انتشار تفسیر کامل
    if ($action === 'save_interpretation') {
        $scientific_interpretation = clean_input($_POST['scientific_interpretation']);
        $admin_additional_notes = clean_input($_POST['admin_additional_notes']);
        $clinical_recommendations = clean_input($_POST['clinical_recommendations']);
        $publish_status = clean_input($_POST['status']); // draft, published

        $now = date('Y-m-d H:i:s');

        if ($interp) {
            db_update('full_interpretations', array(
                'scientific_interpretation' => $scientific_interpretation,
                'admin_additional_notes' => $admin_additional_notes,
                'clinical_recommendations' => $clinical_recommendations,
                'status' => $publish_status,
                'created_by_admin_id' => $admin['id'],
                'updated_at' => $now
            ), 'id = ?', 'i', array($interp['id']));
        } else {
            db_insert('full_interpretations', array(
                'request_id' => $request_id,
                'result_id' => intval($request['result_id']),
                'user_id' => intval($request['user_id']),
                'test_id' => intval($request['test_id']),
                'scientific_interpretation' => $scientific_interpretation,
                'admin_additional_notes' => $admin_additional_notes,
                'clinical_recommendations' => $clinical_recommendations,
                'status' => $publish_status,
                'created_by_admin_id' => $admin['id'],
                'created_at' => $now
            ));
        }

        // در صورت انتشار، وضعیت پرداخت تایید و تاریخ انتشار ثبت می‌شود
        if ($publish_status === 'published') {
            db_update('interpretation_requests', array(
                'payment_status' => 'payment_confirmed',
                'published_at' => $now
            ), 'id = ?', 'i', array($request_id));
            log_event('info', 'interpretation_published', "تفسیر درخواست {$request['request_code']} برای کاربر منتشر شد.");
            
            // باطل‌سازی کش گزارش PDF جهت به‌روزرسانی آنی
            require_once dirname(__DIR__) . '/includes/pdf_engine.php';
            pdf_invalidate_cache($result['id']);

            set_flash('success', 'تفسیر جامع با موفقیت ذخیره و برای مراجع منتشر گردید.');
        } else {
            require_once dirname(__DIR__) . '/includes/pdf_engine.php';
            pdf_invalidate_cache($result['id']);
            
            set_flash('info', 'پیش‌نویس تفسیر با موفقیت ذخیره شد (فقط در پنل مدیریت قابل مشاهده است).');
        }

        redirect('/admin/request-detail.php?id=' . $request_id);
    }
}

// در صورت خالی بودن تفسیر، تولید اولیه خودکار توسط موتور علمی
$generated_defaults = null;
if (!$interp || empty($interp['scientific_interpretation'])) {
    $generated_defaults = engine_generate_full_interpretation($result['id']);
}

$default_scientific_text = ($interp && !empty($interp['scientific_interpretation'])) 
    ? $interp['scientific_interpretation'] 
    : ($generated_defaults ? $generated_defaults['scientific_interpretation'] : '');

$default_admin_notes = ($interp && !empty($interp['admin_additional_notes'])) 
    ? $interp['admin_additional_notes'] 
    : '';

$default_recs = ($interp && !empty($interp['clinical_recommendations'])) 
    ? $interp['clinical_recommendations'] 
    : ($generated_defaults ? $generated_defaults['clinical_recommendations'] : '');

$current_interp_status = $interp ? $interp['status'] : 'draft';
?>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; margin-bottom: 40px;">
  
  <!-- Left Column: User & Financial Card -->
  <div>
    <!-- User Info Box -->
    <div class="admin-card" style="margin-bottom: 24px;">
      <h3 style="font-size: 1.15rem; margin-bottom: 16px;">مشخصات مراجع</h3>
      <div style="font-size: 0.92rem; line-height: 2;">
        <div>👤 نام: <strong><?php echo escape_html($user['first_name'] . ' ' . $user['last_name']); ?></strong></div>
        <div>📱 همراه: <strong><?php echo to_persian_num($user['mobile']); ?></strong></div>
        <div>🎂 سن: <?php echo to_persian_num($user['age']); ?> سال (<?php echo $user['gender'] === 'female' ? 'زن' : 'مرد'; ?>)</div>
        <div>📋 آزمون: <?php echo escape_html($test['title']); ?></div>
        <div>🎯 نمره کل: <strong style="color: var(--primary-teal);"><?php echo to_persian_num($result['total_score']); ?></strong> (<?php echo escape_html($result['overall_category']); ?>)</div>
        <div>📅 تاریخ آزمون: <?php echo format_jalali_date($result['created_at']); ?></div>
      </div>
      <div style="margin-top: 15px;">
        <a href="/admin/result-detail.php?id=<?php echo $result['id']; ?>" class="btn btn-outline btn-sm btn-block" target="_blank">
          مشاهده کارنامه و سوالات ↗
        </a>
      </div>
    </div>

    <!-- Financial Review Box -->
    <div class="admin-card">
      <h3 style="font-size: 1.15rem; margin-bottom: 16px;">بررسی مالی و فیش واریز</h3>
      
      <div style="margin-bottom: 14px;">
        <span style="font-size: 0.85rem; color: #64748b;">کد پیگیری:</span>
        <code style="font-size: 1rem;"><?php echo escape_html($request['request_code']); ?></code>
      </div>

      <div style="margin-bottom: 14px;">
        <span style="font-size: 0.85rem; color: #64748b;">مبلغ مقرر:</span>
        <strong><?php echo format_toman($request['amount']); ?></strong>
      </div>

      <div style="margin-bottom: 16px;">
        <span style="font-size: 0.85rem; color: #64748b; display: block; margin-bottom: 6px;">تصویر فیش ارسالی:</span>
        <?php if (!empty($request['receipt_file'])): ?>
          <div class="receipt-preview-box">
            <?php if (preg_match('/\.pdf$/i', $request['receipt_file'])): ?>
              <a href="<?php echo escape_html($request['receipt_file']); ?>" target="_blank" rel="noopener" class="btn btn-primary btn-sm">
                📄 دانلود فایل PDF فیش
              </a>
            <?php else: ?>
              <a href="<?php echo escape_html($request['receipt_file']); ?>" target="_blank" rel="noopener">
                <img src="<?php echo escape_html($request['receipt_file']); ?>" alt="فیش واریزی">
              </a>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <div class="alert alert-warning" style="font-size: 0.85rem;">هنوز فایلی بارگذاری نشده است.</div>
        <?php endif; ?>
      </div>

      <?php if (!empty($request['user_notes'])): ?>
        <div style="background: #f8fafc; padding: 12px; border-radius: var(--radius-sm); font-size: 0.88rem; margin-bottom: 16px;">
          <strong>توضیح مراجع:</strong> <?php echo escape_html($request['user_notes']); ?>
        </div>
      <?php endif; ?>

      <!-- Payment Verification Form -->
      <form method="POST" action="/admin/request-detail.php?id=<?php echo $request_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="verify_payment">

        <div class="form-group">
          <label class="form-label" for="payment_status">وضعیت تایید فیش</label>
          <select id="payment_status" name="payment_status" class="form-control" required>
            <option value="receipt_submitted" <?php echo $request['payment_status'] === 'receipt_submitted' ? 'selected' : ''; ?>>فیش ارسال شد (در انتظار تایید)</option>
            <option value="payment_confirmed" <?php echo $request['payment_status'] === 'payment_confirmed' ? 'selected' : ''; ?>>تایید پرداخت و فعال‌سازی تفسیر</option>
            <option value="rejected" <?php echo $request['payment_status'] === 'rejected' ? 'selected' : ''; ?>>رد پرداخت (عدم وضوح یا مغایرت)</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="admin_notes">یادداشت مالی / علت رد (در صورت نیاز)</label>
          <input type="text" id="admin_notes" name="admin_notes" class="form-control" value="<?php echo escape_html($request['admin_notes']); ?>" placeholder="علت یا شماره پیگیری...">
        </div>

        <button type="submit" class="btn btn-primary btn-block">
          ثبت تغییر وضعیت مالی
        </button>
      </form>
    </div>

    <!-- Scientific Trace & Tier Overview Box -->
    <?php 
    $trace = engine_get_interpretation_trace($result['id']);
    if (!empty($trace)):
    ?>
    <div class="admin-card" style="margin-top: 24px; border: 1.5px solid #0284c7;">
      <h3 style="font-size: 1.05rem; margin-bottom: 12px; color: #0369a1;">🔬 ردیابی سطوح استناد علمی (Traceability)</h3>
      <div style="font-size: 0.82rem; line-height: 1.8; color: #334155;">
        <div><strong>تعداد ابعاد:</strong> <?php echo to_persian_num($trace['dimensions_count']); ?> مؤلفه استاندارد</div>
        <div><strong>الگوهای فعال (Tier C):</strong> <?php echo to_persian_num($trace['patterns_triggered']); ?> فرضیه بالینی</div>
        <div><strong>اهداف درمانی (Tier D):</strong> <?php echo to_persian_num($trace['treatment_targets_count']); ?> اولویت مداخله</div>
        <div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--border-light);">
          <div style="font-weight: 700; margin-bottom: 4px; color: #0284c7;">سطوح استناد و شواهد:</div>
          <?php foreach ($trace['evidence_tiers'] as $t_name => $t_desc): ?>
            <div style="margin-bottom: 4px;">• <strong><?php echo $t_name; ?>:</strong> <?php echo $t_desc; ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>

  <!-- Right Column: Interpretation Editor & Publication -->
  <div>
    <div class="admin-card">
      <div class="card-header-flex">
        <div>
          <h3 style="font-size: 1.25rem; margin-bottom: 4px;">میز کار تدوین و انتشار تفسیر تخصصی</h3>
          <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 0;">تولیدشده توسط موتور روان‌سنجی + یادداشت‌های اختصاصی درمانگر</p>
        </div>
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
          <form method="POST" action="/admin/request-detail.php?id=<?php echo $request_id; ?>" style="display: inline;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="regenerate_engine">
            <button type="submit" class="btn btn-outline btn-sm btn-confirm-action" data-confirm="آیا از بازتولید تفسیر توسط موتور علمی اطمینان دارید؟ متن علمی فعلی با نسخه استاندارد جدید جایگزین خواهد شد.">
              ⚡ بازتولید تفسیر علمی
            </button>
          </form>

          <button type="button" class="btn btn-outline btn-sm" id="btnPreviewInterp">
            👁️ پیش‌نمایش وب
          </button>

          <!-- دکمه‌های دانلود PDF برای ادمین -->
          <a href="/user/download_report.php?id=<?php echo $result['id']; ?>&type=initial&action=view" target="_blank" class="btn btn-outline btn-sm" title="مشاهده PDF کارنامه اولیه">
            📄 PDF اولیه
          </a>

          <?php if ($current_interp_status === 'published'): ?>
            <a href="/user/download_report.php?id=<?php echo $result['id']; ?>&type=advanced&action=view" target="_blank" class="btn btn-luxury btn-sm" style="background: #0f766e; color: #fff;" title="مشاهده PDF تفسیر پیشرفته">
              📑 PDF پیشرفته
            </a>
            <span class="custom-badge badge-success" style="font-size: 0.9rem; padding: 6px 14px;">منتشر شده ✓</span>
          <?php else: ?>
            <span class="custom-badge badge-warning" style="font-size: 0.9rem; padding: 6px 14px;">پیش‌نویس</span>
          <?php endif; ?>
        </div>
      </div>

      <form id="interpretationForm" method="POST" action="/admin/request-detail.php?id=<?php echo $request_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_interpretation">

        <!-- 1. Scientific Interpretation (Engine Generated) -->
        <div class="form-group">
          <label class="form-label" for="scientific_interpretation">
            ۱. تحلیل علمی و ساختاریافته ابعاد (تولید خودکار موتور روان‌سنجی)
          </label>
          <textarea id="scientific_interpretation" name="scientific_interpretation" class="form-control" rows="12" required style="font-family: inherit; font-size: 0.92rem; line-height: 1.8;"><?php echo escape_html($default_scientific_text); ?></textarea>
        </div>

        <!-- 2. Admin Personalized Notes with Toolbar -->
        <div class="form-group">
          <label class="form-label" for="adminNotesTextarea">
            ۲. یادداشت‌ها و مشاهدات تکمیلی اختصاصی درمانگر (Admin Additional Clinical Notes)
          </label>
          
          <div class="editor-toolbar">
            <button type="button" class="editor-btn" data-target="adminNotesTextarea" data-format="bold"><strong>B</strong> برجسته</button>
            <button type="button" class="editor-btn" data-target="adminNotesTextarea" data-format="italic"><em>I</em> مورب</button>
            <button type="button" class="editor-btn" data-target="adminNotesTextarea" data-format="h3">H3 تیتر</button>
            <button type="button" class="editor-btn" data-target="adminNotesTextarea" data-format="list">• لیست</button>
            <button type="button" class="editor-btn" data-target="adminNotesTextarea" data-format="quote">” نقل‌قول</button>
          </div>

          <textarea id="adminNotesTextarea" name="admin_additional_notes" class="form-control editor-textarea" placeholder="تحلیل اختصاصی، ریشه‌یابی تعارضات و نکات متمایز برای این مراجع را اینجا وارد نمایید..."><?php echo escape_html($default_admin_notes); ?></textarea>
        </div>

        <!-- 3. Clinical Recommendations -->
        <div class="form-group">
          <label class="form-label" for="clinical_recommendations">
            ۳. راهکارهای عملی و گام‌های درمانی پیشنهادی (Clinical Recommendations)
          </label>
          <textarea id="clinical_recommendations" name="clinical_recommendations" class="form-control" rows="5"><?php echo escape_html($default_recs); ?></textarea>
        </div>

        <!-- Publication Status Selection -->
        <div style="background: #f8fafc; border: 1.5px solid var(--border-light); border-radius: var(--radius-md); padding: 20px; margin-bottom: 24px;">
          <label class="form-label" style="font-size: 1rem; margin-bottom: 12px;">وضعیت دسترسی مراجع به گزارش:</label>
          
          <div style="display: flex; flex-direction: column; gap: 10px;">
            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
              <input type="radio" name="status" value="published" <?php echo $current_interp_status === 'published' ? 'checked' : ''; ?>>
              <strong style="color: #059669;">انتشار رسمی برای مراجع (کاربر بلافاصله در پنل خود تفسیر را مشاهده می‌کند)</strong>
            </label>
            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
              <input type="radio" name="status" value="draft" <?php echo $current_interp_status === 'draft' ? 'checked' : ''; ?>>
              <span>ذخیره به عنوان پیش‌نویس (فقط در پنل مدیریت قابل ویرایش است و مراجع هنوز آن را نمی‌بیند)</span>
            </label>
          </div>
        </div>

        <div style="display: flex; gap: 12px;">
          <button type="submit" class="btn btn-luxury btn-lg btn-confirm-action" data-confirm="آیا از ذخیره و اعمال وضعیت تفسیر اطمینان دارید؟">
            <span>ذخیره و اعمال وضعیت تفسیر</span>
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
          </button>
        </div>

      </form>
    </div>
  </div>

</div>

<!-- Modal Live Preview for Admin -->
<div id="previewModal" class="matrix-modal-overlay">
  <div class="matrix-modal-card" style="max-width: 750px;">
    <div class="matrix-modal-header">
      <h4>پیش‌نمایش خروجی تفسیر برای مراجع (<?php echo escape_html($user['first_name'] . ' ' . $user['last_name']); ?>)</h4>
      <button type="button" id="btnClosePreview" style="background: none; border: none; font-size: 1.4rem; cursor: pointer;">&times;</button>
    </div>
    <div class="matrix-modal-body" style="padding: 24px; line-height: 1.9; font-size: 0.95rem;">
      
      <div style="border-bottom: 1px solid #e2e8f0; padding-bottom: 14px; margin-bottom: 18px;">
        <span class="custom-badge badge-success">گزارش تفسیر تخصصی تأییدشده</span>
        <h3 style="margin-top: 8px; margin-bottom: 0;">تحلیل بالینی آزمون <?php echo escape_html($test['title']); ?></h3>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="color: var(--primary-navy); margin-bottom: 8px;">۱. تحلیل روان‌سنجی و تشخیصی:</h4>
        <div id="prevSciContent" style="background: #f8fafc; padding: 16px; border-radius: 8px; white-space: pre-line;"></div>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="color: var(--primary-navy); margin-bottom: 8px;">۲. یادداشت‌های اختصاصی درمانگر (دکتر میربلوکی):</h4>
        <div id="prevNotesContent" style="background: #f0fdf4; border-right: 4px solid #10b981; padding: 16px; border-radius: 8px; white-space: pre-line;"></div>
      </div>

      <div>
        <h4 style="color: var(--primary-navy); margin-bottom: 8px;">۳. راهکارهای درمانی پیشنهادی:</h4>
        <div id="prevRecsContent" style="background: #fffbeb; border-right: 4px solid #f59e0b; padding: 16px; border-radius: 8px; white-space: pre-line;"></div>
      </div>

    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const btnPreview = document.getElementById('btnPreviewInterp');
  const modal = document.getElementById('previewModal');
  const btnClose = document.getElementById('btnClosePreview');

  if (btnPreview && modal) {
    btnPreview.addEventListener('click', function() {
      const sci = document.getElementById('scientific_interpretation').value;
      const notes = document.getElementById('adminNotesTextarea').value;
      const recs = document.getElementById('clinical_recommendations').value;

      document.getElementById('prevSciContent').innerText = sci || '(متنی وارد نشده است)';
      document.getElementById('prevNotesContent').innerText = notes || '(یادداشت تکمیلی ثبت نشده است)';
      document.getElementById('prevRecsContent').innerText = recs || '(راهکاری ثبت نشده است)';

      modal.classList.add('open');
    });
  }

  if (btnClose && modal) {
    btnClose.addEventListener('click', function() {
      modal.classList.remove('open');
    });
  }
});
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
