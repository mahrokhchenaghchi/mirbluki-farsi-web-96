<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * ورود به پنل مدیریت (Admin Login)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

if (is_admin_logged_in()) {
    redirect('/admin/index.php');
}

$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error_msg = 'خطای امنیتی نشست. لطفاً دوباره تلاش فرمایید.';
    } else {
        $username = isset($_POST['username']) ? clean_input($_POST['username']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        
        $login_result = admin_login($username, $password);
        if ($login_result['success']) {
            redirect('/admin/index.php');
        } else {
            $error_msg = $login_result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ورود به پنل مدیریت | دکتر جواد میربلوکی</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="stylesheet" href="/assets/css/style.css?v=<?php echo SITE_VERSION; ?>">
  <link rel="stylesheet" href="/assets/css/admin.css?v=<?php echo SITE_VERSION; ?>">
</head>
<body style="background: #091424; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px;">

  <div style="width: 100%; max-width: 440px; background: #ffffff; border-radius: var(--radius-xl); padding: 40px; box-shadow: var(--shadow-luxury);">
    
    <div style="text-align: center; margin-bottom: 30px;">
      <img src="/assets/images/logo.svg" alt="دکتر میربلوکی" style="max-height: 50px; margin: 0 auto 16px;">
      <h1 style="font-size: 1.5rem; margin-bottom: 6px;">پنل مدیریت سامانه</h1>
      <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 0;">ورود اختصاصی مدیریت و درمانگران</p>
    </div>

    <?php if (!empty($error_msg)): ?>
      <div class="alert alert-danger" style="font-size: 0.9rem;">
        <?php echo escape_html($error_msg); ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="/admin/login.php">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label" for="username">نام کاربری ادمین</label>
        <input type="text" id="username" name="username" class="form-control" dir="ltr" style="text-align: left;" required autofocus>
      </div>

      <div class="form-group">
        <label class="form-label" for="password">کلمه عبور</label>
        <input type="password" id="password" name="password" class="form-control" dir="ltr" style="text-align: left;" required>
      </div>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 24px;">
        <span>ورود امن به پنل</span>
      </button>
    </form>

    <div style="margin-top: 24px; text-align: center;">
      <a href="/" style="font-size: 0.88rem; color: #64748b;">بازگشت به صفحه اصلی سایت ↗</a>
    </div>

  </div>

</body>
</html>
