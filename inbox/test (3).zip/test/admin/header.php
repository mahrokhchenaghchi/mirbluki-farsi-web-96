<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * سربرگ پنل مدیریت (Admin Header & Navigation)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/engine.php';

require_admin_login();
$admin = get_current_admin();

$admin_page_title = isset($admin_page_title) ? $admin_page_title : 'داشبورد مدیریت';
$active_tab = isset($active_tab) ? $active_tab : 'dashboard';

if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo escape_html($admin_page_title); ?> | مدیریت آزمون‌های میربلوکی</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="stylesheet" href="/assets/css/style.css?v=<?php echo SITE_VERSION; ?>">
  <link rel="stylesheet" href="/assets/css/admin.css?v=<?php echo SITE_VERSION; ?>">
</head>
<body class="admin-body">

<div class="admin-layout">
  
  <!-- Admin Sidebar -->
  <aside class="admin-sidebar">
    <div class="sidebar-header">
      <img src="/assets/images/logo.svg" alt="دکتر میربلوکی" style="filter: brightness(0) invert(1); max-height: 40px; margin-bottom: 10px;">
      <h3>پنل مدیریت سامانه</h3>
      <small>مرکز ارزیابی روان‌شناختی</small>
    </div>

    <ul class="sidebar-menu">
      <li>
        <a href="/admin/index.php" class="<?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
          <span>داشبورد و آمار</span>
        </a>
      </li>
      <li>
        <a href="/admin/requests.php" class="<?php echo $active_tab === 'requests' ? 'active' : ''; ?>">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
          <span>درخواست‌های تفسیر کامل</span>
        </a>
      </li>
      <li>
        <a href="/admin/results.php" class="<?php echo $active_tab === 'results' ? 'active' : ''; ?>">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
          <span>نتایج و کارنامه‌ها</span>
        </a>
      </li>
      <li>
        <a href="/admin/tests.php" class="<?php echo $active_tab === 'tests' ? 'active' : ''; ?>">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
          <span>مدیریت آزمون‌ها</span>
        </a>
      </li>
      <li>
        <a href="/admin/users.php" class="<?php echo $active_tab === 'users' ? 'active' : ''; ?>">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
          <span>کاربران و مراجعین</span>
        </a>
      </li>
    </ul>

    <div class="sidebar-footer">
      <a href="/" target="_blank" rel="noopener" style="color: #94a3b8; font-size: 0.88rem; display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
        <span>مشاهده سایت اصلی</span>
      </a>
      <a href="/admin/logout.php" style="color: #ef4444; font-size: 0.88rem; display: flex; align-items: center; gap: 8px;">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
        <span>خروج از مدیریت</span>
      </a>
    </div>
  </aside>

  <!-- Admin Main Wrapper -->
  <div class="admin-main">
    
    <!-- Topbar -->
    <header class="admin-topbar">
      <div class="topbar-title">
        <?php echo escape_html($admin_page_title); ?>
      </div>
      <div class="topbar-user">
        <span style="font-size: 0.9rem; color: #475569;">
          👤 مدیر: <strong><?php echo escape_html($admin['full_name']); ?></strong>
        </span>
      </div>
    </header>

    <!-- Content Area -->
    <main class="admin-content-area">
      <?php echo render_flash(); ?>
