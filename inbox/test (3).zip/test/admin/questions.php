<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * مدیریت سوالات و گزینه‌های آزمون (Questions & Options Manager)
 */

$admin_page_title = 'مدیریت سؤالات آزمون';
$active_tab = 'tests';

require_once __DIR__ . '/header.php';

$test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : 0;
if ($test_id <= 0) {
    redirect('/admin/tests.php');
}

$test = engine_get_test($test_id);
if (!$test) {
    set_flash('danger', 'آزمون یافت نشد.');
    redirect('/admin/tests.php');
}

$admin_page_title = 'مدیریت سؤالات: ' . $test['title'];

// ابعاد آزمون جهت انتساب سوال به بعد
$dimensions = db_fetch_all("SELECT * FROM `test_dimensions` WHERE `test_id` = ? ORDER BY `sort_order` ASC, `id` ASC", 'i', array($test_id));

// افزودن یا ویرایش سوال
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_question') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی نشست.');
        redirect('/admin/questions.php?test_id=' . $test_id);
    }

    $q_id = isset($_POST['question_id']) ? intval($_POST['question_id']) : 0;
    $q_num = intval($_POST['question_number']);
    $q_text = clean_input($_POST['question_text']);
    $dim_id = !empty($_POST['dimension_id']) ? intval($_POST['dimension_id']) : null;
    $is_reverse = isset($_POST['is_reverse_scored']) ? 1 : 0;
    $help_text = clean_input($_POST['help_text']);
    $sort_order = intval($_POST['sort_order']);

    $q_data = array(
        'test_id' => $test_id,
        'dimension_id' => $dim_id,
        'question_number' => $q_num,
        'question_text' => $q_text,
        'is_reverse_scored' => $is_reverse,
        'help_text' => $help_text,
        'sort_order' => $sort_order ? $sort_order : $q_num
    );

    if ($q_id > 0) {
        db_update('test_questions', $q_data, 'id = ? AND test_id = ?', 'ii', array($q_id, $test_id));
        set_flash('success', 'سؤال ویرایش شد.');
    } else {
        db_insert('test_questions', $q_data);
        set_flash('success', 'سؤال جدید افزوده شد.');
    }
    redirect('/admin/questions.php?test_id=' . $test_id);
}

// حذف سوال
if (isset($_GET['delete_q'])) {
    $del_id = intval($_GET['delete_q']);
    db_query("DELETE FROM `test_questions` WHERE `id` = ? AND `test_id` = ?", 'ii', array($del_id, $test_id));
    set_flash('info', 'سؤال حذف گردید.');
    redirect('/admin/questions.php?test_id=' . $test_id);
}

// افزودن یا بروزرسانی گزینه‌ها
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_options') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای نشست.');
        redirect('/admin/questions.php?test_id=' . $test_id);
    }

    $option_texts = isset($_POST['opt_text']) && is_array($_POST['opt_text']) ? $_POST['opt_text'] : array();
    $option_values = isset($_POST['opt_val']) && is_array($_POST['opt_val']) ? $_POST['opt_val'] : array();

    // حذف گزینه‌های قبلی و درج گزینه‌های جدید
    db_query("DELETE FROM `test_options` WHERE `test_id` = ?", 'i', array($test_id));

    $opt_num = 1;
    foreach ($option_texts as $k => $text) {
        $text = clean_input($text);
        if (!empty($text)) {
            $val = isset($option_values[$k]) ? floatval($option_values[$k]) : $opt_num;
            db_insert('test_options', array(
                'test_id' => $test_id,
                'option_number' => $opt_num,
                'option_text' => $text,
                'score_value' => $val,
                'sort_order' => $opt_num
            ));
            $opt_num++;
        }
    }
    set_flash('success', 'گزینه‌های مقیاس با موفقیت ذخیره شدند.');
    redirect('/admin/questions.php?test_id=' . $test_id);
}

$questions = db_fetch_all(
    "SELECT q.*, d.title as dim_title 
     FROM `test_questions` q 
     LEFT JOIN `test_dimensions` d ON q.dimension_id = d.id 
     WHERE q.test_id = ? 
     ORDER BY q.sort_order ASC, q.question_number ASC, q.id ASC",
    'i',
    array($test_id)
);

$options = db_fetch_all("SELECT * FROM `test_options` WHERE `test_id` = ? ORDER BY `sort_order` ASC, `option_number` ASC", 'i', array($test_id));
$next_q_num = count($questions) + 1;
?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
  <a href="/admin/tests.php" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; color: #64748b; font-weight: 600;">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
    <span>بازگشت به آزمون‌ها</span>
  </a>
  <div style="display: flex; gap: 10px;">
    <a href="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>" class="btn btn-luxury btn-sm">
      تنظیم ابعاد و نمره‌دهی ↗
    </a>
    <a href="/tests/intro.php?slug=<?php echo urlencode($test['slug']); ?>" target="_blank" class="btn btn-outline btn-sm">
      پیش‌نمایش آزمون ↗
    </a>
  </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 24px;">
  
  <!-- Questions List Table -->
  <div class="admin-card">
    <div class="card-header-flex">
      <h3 style="font-size: 1.15rem; margin-bottom: 0;">بانک سؤالات آزمون (<?php echo to_persian_num(count($questions)); ?> سؤال)</h3>
    </div>

    <?php if (empty($questions)): ?>
      <div style="text-align: center; padding: 40px; color: var(--text-muted);">
        هنوز سؤالی برای این آزمون ثبت نشده است. از فرم سمت چپ جهت افزودن سؤال استفاده نمایید.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="admin-table">
          <thead>
            <tr>
              <th style="width: 50px;">#</th>
              <th>متن سؤال</th>
              <th>بعد / مؤلفه</th>
              <th>نمره‌گذاری معکوس</th>
              <th>عملیات</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($questions as $q): ?>
              <tr>
                <td><strong><?php echo to_persian_num($q['question_number']); ?></strong></td>
                <td><?php echo escape_html($q['question_text']); ?></td>
                <td>
                  <?php if (!empty($q['dim_title'])): ?>
                    <span class="custom-badge badge-primary"><?php echo escape_html($q['dim_title']); ?></span>
                  <?php else: ?>
                    <span style="color: #94a3b8; font-size: 0.8rem;">عمومی / کل</span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php echo intval($q['is_reverse_scored']) === 1 ? '<span class="custom-badge badge-warning">معکوس ✓</span>' : 'عادی'; ?>
                </td>
                <td>
                  <a href="/admin/questions.php?test_id=<?php echo $test_id; ?>&delete_q=<?php echo $q['id']; ?>" class="btn-confirm-action" data-confirm="آیا از حذف این سؤال اطمینان دارید؟" style="color: #ef4444; font-size: 0.85rem;">
                    حذف
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <!-- Add Question & Options Forms -->
  <div>
    <!-- Add Question Card -->
    <div class="admin-card" style="margin-bottom: 24px;">
      <h3 style="font-size: 1.15rem; margin-bottom: 16px;">افزودن سؤال جدید</h3>
      <form method="POST" action="/admin/questions.php?test_id=<?php echo $test_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_question">

        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 12px;">
          <div class="form-group">
            <label class="form-label" for="question_number">شماره سؤال</label>
            <input type="number" id="question_number" name="question_number" class="form-control" value="<?php echo $next_q_num; ?>" required>
          </div>

          <div class="form-group">
            <label class="form-label" for="dimension_id">بعد متناظر</label>
            <select id="dimension_id" name="dimension_id" class="form-control">
              <option value="">(نمره کل / عمومی)</option>
              <?php foreach ($dimensions as $dim): ?>
                <option value="<?php echo $dim['id']; ?>"><?php echo escape_html($dim['title']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="question_text">متن فارسی سؤال <span style="color: #dc2626;">*</span></label>
          <textarea id="question_text" name="question_text" class="form-control" rows="3" required placeholder="متن گویه یا عبارت مورد ارزیابی..."></textarea>
        </div>

        <div class="form-group">
          <label class="form-label" for="help_text">توضیح یا راهنمای کوتاه (اختیاری)</label>
          <input type="text" id="help_text" name="help_text" class="form-control" placeholder="نکته کمکی...">
        </div>

        <div class="form-group">
          <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
            <input type="checkbox" name="is_reverse_scored" value="1">
            <span style="font-size: 0.9rem;">نمره‌گذاری معکوس اعمال شود (Reverse Scored)</span>
          </label>
        </div>

        <button type="submit" class="btn btn-primary btn-block">
          + ثبت سؤال در آزمون
        </button>
      </form>
    </div>

    <!-- Options / Response Scale Manager -->
    <div class="admin-card">
      <h3 style="font-size: 1.15rem; margin-bottom: 8px;">مقیاس گزینه‌های پاسخ</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 16px;">گزینه‌های پیش‌فرض پاسخ‌دهی برای تمام سوالات این آزمون</p>

      <form method="POST" action="/admin/questions.php?test_id=<?php echo $test_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_options">

        <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 16px;">
          <?php 
            $opts_to_show = !empty($options) ? $options : array(
              array('option_text' => 'کاملاً نادرست', 'score_value' => 1),
              array('option_text' => 'تقریباً نادرست', 'score_value' => 2),
              array('option_text' => 'بیشتر درست تا نادرست', 'score_value' => 3),
              array('option_text' => 'نسبتاً درست', 'score_value' => 4),
              array('option_text' => 'تقریباً درست', 'score_value' => 5),
              array('option_text' => 'کاملاً درست', 'score_value' => 6)
            );
          ?>
          <?php foreach ($opts_to_show as $i => $opt): ?>
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 8px; align-items: center;">
              <input type="text" name="opt_text[]" class="form-control" style="padding: 8px;" value="<?php echo escape_html($opt['option_text']); ?>" placeholder="متن گزینه...">
              <input type="number" step="0.1" name="opt_val[]" class="form-control" style="padding: 8px;" value="<?php echo escape_html($opt['score_value']); ?>" placeholder="ارزش عددی">
            </div>
          <?php endforeach; ?>
        </div>

        <button type="submit" class="btn btn-outline btn-block btn-sm">
          ذخیره مقیاس پاسخ‌ها
        </button>
      </form>
    </div>

  </div>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>
