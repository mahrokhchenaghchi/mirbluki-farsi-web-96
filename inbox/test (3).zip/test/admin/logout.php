<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * خروج مدیر از پنل (Admin Logout)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/auth.php';

admin_logout();
set_flash('info', 'با موفقیت از پنل مدیریت خارج شدید.');
redirect('/admin/login.php');
