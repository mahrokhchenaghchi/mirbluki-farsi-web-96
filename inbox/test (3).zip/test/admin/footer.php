<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * پابرگ پنل مدیریت (Admin Footer)
 */
?>
    </main>
  </div>
</div>

<script src="/assets/js/main.js?v=<?php echo SITE_VERSION; ?>"></script>
<script src="/assets/js/admin.js?v=<?php echo SITE_VERSION; ?>"></script>
<?php if (isset($admin_extra_js)): ?>
  <?php foreach ($admin_extra_js as $js): ?>
    <script src="<?php echo escape_html($js); ?>?v=<?php echo SITE_VERSION; ?>"></script>
  <?php endforeach; ?>
<?php endif; ?>

</body>
</html>
