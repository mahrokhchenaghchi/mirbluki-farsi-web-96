<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * مدیریت درخواست‌های تفسیر کامل و بررسی مالی فیش‌ها (Interpretation Requests Manager)
 */

$admin_page_title = 'مدیریت درخواست‌های تفسیر کامل';
$active_tab = 'requests';

require_once __DIR__ . '/header.php';

$filter_status = isset($_GET['status']) ? clean_input($_GET['status']) : '';
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';

$sql = "SELECT req.*, u.first_name, u.last_name, u.mobile, t.title as test_title, fi.status as interp_status 
        FROM `interpretation_requests` req 
        JOIN `users` u ON req.user_id = u.id 
        JOIN `tests` t ON req.test_id = t.id 
        LEFT JOIN `full_interpretations` fi ON req.result_id = fi.result_id 
        WHERE 1=1";

$types = '';
$params = array();

if (!empty($filter_status)) {
    $sql .= " AND req.payment_status = ?";
    $types .= 's';
    $params[] = $filter_status;
}

if (!empty($search)) {
    $sql .= " AND (u.mobile LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR req.request_code LIKE ?)";
    $search_like = '%' . $search . '%';
    $types .= 'ssss';
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
}

$sql .= " ORDER BY req.requested_at DESC";

$requests = db_fetch_all($sql, $types, $params);
?>

<div class="admin-card">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.25rem; margin-bottom: 4px;">فهرست درخواست‌های تفسیر کامل</h3>
      <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 0;">بررسی فیش‌های واریزی، تایید پرداخت و نگارش تفسیر تخصصی</p>
    </div>

    <!-- Filters & Search Form -->
    <form method="GET" action="/admin/requests.php" style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">
      <select name="status" class="form-control" style="width: auto; padding: 8px 12px;" onchange="this.form.submit();">
        <option value="">همه وضعیت‌ها</option>
        <option value="receipt_submitted" <?php echo $filter_status === 'receipt_submitted' ? 'selected' : ''; ?>>فیش ارسال شد (در انتظار بررسی)</option>
        <option value="payment_confirmed" <?php echo $filter_status === 'payment_confirmed' ? 'selected' : ''; ?>>پرداخت تایید شد (در حال نگارش)</option>
        <option value="published" <?php echo $filter_status === 'published' ? 'selected' : ''; ?>>تفسیر منتشر شد</option>
        <option value="rejected" <?php echo $filter_status === 'rejected' ? 'selected' : ''; ?>>رد پرداخت</option>
      </select>

      <input type="text" name="search" class="form-control" style="width: 220px; padding: 8px 12px;" placeholder="جستجوی نام، همراه، کد..." value="<?php echo escape_html($search); ?>">

      <button type="submit" class="btn btn-primary btn-sm">فیلتر</button>
      <?php if (!empty($filter_status) || !empty($search)): ?>
        <a href="/admin/requests.php" class="btn btn-outline btn-sm">پاکسازی</a>
      <?php endif; ?>
    </form>
  </div>

  <?php if (empty($requests)): ?>
    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
      درخواستی منطبق با معیارهای جستجو یافت نشد.
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>کد پیگیری</th>
            <th>مراجع</th>
            <th>شماره همراه</th>
            <th>آزمون</th>
            <th>مبلغ</th>
            <th>فیش واریز</th>
            <th>تاریخ درخواست</th>
            <th>وضعیت مالی</th>
            <th>وضعیت انتشار</th>
            <th>عملیات</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($requests as $req): ?>
            <tr>
              <td><code><?php echo escape_html($req['request_code']); ?></code></td>
              <td><strong><?php echo escape_html($req['first_name'] . ' ' . $req['last_name']); ?></strong></td>
              <td><?php echo to_persian_num($req['mobile']); ?></td>
              <td><?php echo escape_html($req['test_title']); ?></td>
              <td><?php echo format_toman($req['amount']); ?></td>
              <td>
                <?php if (!empty($req['receipt_file'])): ?>
                  <a href="<?php echo escape_html($req['receipt_file']); ?>" target="_blank" rel="noopener" class="custom-badge badge-primary" style="text-decoration: underline;">
                    مشاهده فیش ↗
                  </a>
                <?php else: ?>
                  <span style="color: #94a3b8; font-size: 0.85rem;">ارسال نشده</span>
                <?php endif; ?>
              </td>
              <td><?php echo format_jalali_date($req['requested_at']); ?></td>
              <td><?php echo format_request_status_badge($req['payment_status']); ?></td>
              <td>
                <?php if ($req['interp_status'] === 'published'): ?>
                  <span class="custom-badge badge-success">منتشر شده ✓</span>
                <?php else: ?>
                  <span class="custom-badge badge-secondary">منتشر نشده</span>
                <?php endif; ?>
              </td>
              <td>
                <a href="/admin/request-detail.php?id=<?php echo $req['id']; ?>" class="btn btn-primary btn-sm">
                  بررسی و تدوین تفسیر
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
