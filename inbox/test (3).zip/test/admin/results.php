<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * گزارش کلیه نتایج و کارنامه‌های صادرشده (Results & Audit Registry)
 */

$admin_page_title = 'کارنامه‌ها و نتایج آزمون‌ها';
$active_tab = 'results';

require_once __DIR__ . '/header.php';

$test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : 0;
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';

$filtered_user = null;
if ($user_id > 0) {
    $filtered_user = db_fetch_one("SELECT * FROM `users` WHERE `id` = ? LIMIT 1", 'i', array($user_id));
}

$filtered_test = null;
if ($test_id > 0) {
    $filtered_test = db_fetch_one("SELECT * FROM `tests` WHERE `id` = ? LIMIT 1", 'i', array($test_id));
}

$sql = "SELECT r.*, u.first_name, u.last_name, u.mobile, u.age, u.gender,
        t.title as test_title, t.slug as test_slug,
        req.id as request_id, req.payment_status,
        fi.status as interp_status
        FROM `test_results` r 
        JOIN `users` u ON r.user_id = u.id 
        JOIN `tests` t ON r.test_id = t.id 
        LEFT JOIN `interpretation_requests` req ON r.id = req.result_id 
        LEFT JOIN `full_interpretations` fi ON r.id = fi.result_id 
        WHERE 1=1";

$types = '';
$params = array();

if ($test_id > 0) {
    $sql .= " AND r.test_id = ?";
    $types .= 'i';
    $params[] = $test_id;
}

if ($user_id > 0) {
    $sql .= " AND r.user_id = ?";
    $types .= 'i';
    $params[] = $user_id;
}

if (!empty($search)) {
    $sql .= " AND (u.mobile LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $like = '%' . $search . '%';
    $types .= 'sss';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY r.created_at DESC";

$results = db_fetch_all($sql, $types, $params);
$all_tests = db_fetch_all("SELECT id, title FROM `tests` ORDER BY `sort_order` ASC");
?>

<div class="admin-card">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.25rem; margin-bottom: 4px;">فهرست کارنامه‌های ارزیابی روان‌شناختی</h3>
      <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 0;">ردیابی نمرات، ابعاد و وضعیت تفاسیر بالینی مراجعین</p>
    </div>

    <div style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">
      <!-- Export CSV Button -->
      <a href="/admin/export.php?test_id=<?php echo $test_id; ?>&user_id=<?php echo $user_id; ?>" class="btn btn-outline btn-sm">
        <span>خروجی اکسل (CSV Export) 📥</span>
      </a>

      <!-- Filters -->
      <form method="GET" action="/admin/results.php" style="display: flex; flex-wrap: wrap; gap: 8px;">
        <?php if ($user_id > 0): ?>
          <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
        <?php endif; ?>

        <select name="test_id" class="form-control" style="width: auto; padding: 6px 12px;" onchange="this.form.submit();">
          <option value="">همه آزمون‌ها</option>
          <?php foreach ($all_tests as $t): ?>
            <option value="<?php echo $t['id']; ?>" <?php echo $test_id === intval($t['id']) ? 'selected' : ''; ?>>
              <?php echo escape_html($t['title']); ?>
            </option>
          <?php endforeach; ?>
        </select>

        <input type="text" name="search" class="form-control" style="width: 180px; padding: 6px 12px;" placeholder="جستجوی مراجع..." value="<?php echo escape_html($search); ?>">
        <button type="submit" class="btn btn-primary btn-sm">فیلتر</button>

        <?php if ($test_id > 0 || $user_id > 0 || !empty($search)): ?>
          <a href="/admin/results.php" class="btn btn-outline btn-sm">پاکسازی فیلترها</a>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <?php if ($filtered_user): ?>
    <div class="alert alert-info" style="margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
      <div>
        👤 نتایج آزمون‌های مراجع: <strong><?php echo escape_html($filtered_user['first_name'] . ' ' . $filtered_user['last_name']); ?></strong> (تلفن همراه: <?php echo to_persian_num($filtered_user['mobile']); ?>)
      </div>
      <a href="/admin/results.php" class="btn btn-outline btn-sm" style="background: white;">مشاهده همه مراجعین</a>
    </div>
  <?php endif; ?>

  <?php if ($filtered_test): ?>
    <div class="alert alert-warning" style="margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
      <div>
        📋 فیلتر بر اساس آزمون: <strong><?php echo escape_html($filtered_test['title']); ?></strong>
      </div>
      <a href="/admin/results.php" class="btn btn-outline btn-sm" style="background: white;">مشاهده همه آزمون‌ها</a>
    </div>
  <?php endif; ?>

  <?php if (empty($results)): ?>
    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
      نتیجه‌ای یافت نشد.
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>شماره</th>
            <th>نام و نام خانوادگی مراجع</th>
            <th>شماره همراه</th>
            <th>سن</th>
            <th>عنوان آزمون</th>
            <th>نمره کل</th>
            <th>طبقه‌بندی</th>
            <th>سطح شدت</th>
            <th>وضعیت تفسیر</th>
            <th>تاریخ ثبت</th>
            <th>عملیات</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($results as $r): ?>
            <tr>
              <td><code>#<?php echo $r['id']; ?></code></td>
              <td><strong><?php echo escape_html($r['first_name'] . ' ' . $r['last_name']); ?></strong></td>
              <td><?php echo to_persian_num($r['mobile']); ?></td>
              <td><?php echo to_persian_num($r['age']); ?></td>
              <td><?php echo escape_html($r['test_title']); ?> <small>(v<?php echo to_persian_num($r['test_version']); ?>)</small></td>
              <td style="font-weight: 800; color: var(--primary-teal);"><?php echo to_persian_num($r['total_score']); ?></td>
              <td><?php echo escape_html($r['overall_category']); ?></td>
              <td><?php echo format_severity_badge($r['overall_severity']); ?></td>
              <td>
                <?php if ($r['interp_status'] === 'published'): ?>
                  <span class="custom-badge badge-success">منتشر شده ✓</span>
                <?php elseif ($r['interp_status'] === 'draft'): ?>
                  <span class="custom-badge badge-warning">پیش‌نویس</span>
                <?php elseif (!empty($r['payment_status'])): ?>
                  <?php echo format_request_status_badge($r['payment_status']); ?>
                <?php else: ?>
                  <span style="color: #94a3b8; font-size: 0.8rem;">درخواست نشده</span>
                <?php endif; ?>
              </td>
              <td><?php echo format_jalali_date($r['created_at']); ?></td>
              <td>
                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                  <a href="/admin/result-detail.php?id=<?php echo $r['id']; ?>" class="btn btn-outline btn-sm" title="مشاهده کارنامه، سوالات و استناد علمی">
                    مشاهده نتیجه و استناد
                  </a>
                  <?php if (!empty($r['request_id'])): ?>
                    <a href="/admin/request-detail.php?id=<?php echo $r['request_id']; ?>" class="btn btn-primary btn-sm" title="ورود به میز کار نگارش و انتشار تفسیر">
                      بررسی و تدوین تفسیر
                    </a>
                  <?php else: ?>
                    <a href="/admin/result-detail.php?id=<?php echo $r['id']; ?>&action=create_direct_interpretation" class="btn btn-luxury btn-sm" title="ایجاد مستقیم پرونده تفسیر برای این مراجع">
                      تدوین تفسیر
                    </a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
