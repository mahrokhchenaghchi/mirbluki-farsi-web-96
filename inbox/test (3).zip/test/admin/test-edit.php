<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * افزودن یا ویرایش مشخصات آزمون (Add / Edit Test)
 */

$admin_page_title = 'مشخصات آزمون';
$active_tab = 'tests';

require_once __DIR__ . '/header.php';

$test_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$test = null;
if ($test_id > 0) {
    $test = engine_get_test($test_id);
    if (!$test) {
        set_flash('danger', 'آزمون یافت نشد.');
        redirect('/admin/tests.php');
    }
}

$admin_page_title = $test_id > 0 ? 'ویرایش مشخصات آزمون: ' . $test['title'] : 'ایجاد آزمون جدید';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی نشست.');
        redirect('/admin/tests.php');
    }

    $title = clean_input($_POST['title']);
    $slug = clean_input($_POST['slug']);
    $original_name = clean_input($_POST['original_name']);
    $version = clean_input($_POST['version']);
    $estimated_minutes = intval($_POST['estimated_minutes']);
    $accent_color = clean_input($_POST['accent_color']);
    $description = clean_input($_POST['description']);
    $intro_text = clean_input($_POST['intro_text']);
    $scientific_profile = clean_input($_POST['scientific_profile']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $sort_order = intval($_POST['sort_order']);

    // ایجاد اسلاگ یکتا در صورت خالی بودن
    if (empty($slug)) {
        $slug = 'test-' . time();
    }

    $banner_image = $test ? $test['banner_image'] : null;

    // آپلود تصویر بنر آزمون در صورت ارسال
    if (isset($_FILES['banner_file']) && $_FILES['banner_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['banner_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (in_array($ext, array('jpg', 'jpeg', 'png', 'webp'), true)) {
            if (!is_dir(TEST_IMAGES_DIR)) {
                mkdir(TEST_IMAGES_DIR, 0755, true);
            }
            $img_name = 'test_' . time() . '_' . generate_token(8) . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], TEST_IMAGES_DIR . '/' . $img_name)) {
                $banner_image = '/uploads/tests/' . $img_name;
            }
        }
    }

    $data = array(
        'title' => $title,
        'slug' => $slug,
        'original_name' => $original_name,
        'version' => $version,
        'estimated_minutes' => $estimated_minutes,
        'accent_color' => $accent_color,
        'description' => $description,
        'intro_text' => $intro_text,
        'scientific_profile' => $scientific_profile,
        'banner_image' => $banner_image,
        'is_active' => $is_active,
        'sort_order' => $sort_order
    );

    if ($test_id > 0) {
        db_update('tests', $data, 'id = ?', 'i', array($test_id));
        set_flash('success', 'مشخصات آزمون با موفقیت ویرایش شد.');
    } else {
        $new_id = db_insert('tests', $data);
        set_flash('success', 'آزمون جدید با موفقیت ایجاد شد.');
        redirect('/admin/questions.php?test_id=' . $new_id);
    }

    redirect('/admin/tests.php');
}
?>

<div class="admin-card container-narrow" style="margin: 0 auto;">
  <div class="card-header-flex">
    <h3 style="font-size: 1.25rem; margin-bottom: 0;"><?php echo $admin_page_title; ?></h3>
    <a href="/admin/tests.php" class="btn btn-outline btn-sm">بازگشت به فهرست آزمون‌ها</a>
  </div>

  <form method="POST" action="/admin/test-edit.php<?php echo $test_id > 0 ? '?id=' . $test_id : ''; ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 16px;">
      <div class="form-group">
        <label class="form-label" for="title">عنوان آزمون به فارسی <span style="color: #dc2626;">*</span></label>
        <input type="text" id="title" name="title" class="form-control" value="<?php echo escape_html($test ? $test['title'] : ''); ?>" required placeholder="مثال: مقیاس ارزیابی طرحواره‌های ناسازگار">
      </div>

      <div class="form-group">
        <label class="form-label" for="slug">اسلاگ یکتای آدرس (Slug) <span style="color: #dc2626;">*</span></label>
        <input type="text" id="slug" name="slug" class="form-control" dir="ltr" value="<?php echo escape_html($test ? $test['slug'] : ''); ?>" required placeholder="مثال: schema-test">
      </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px;">
      <div class="form-group">
        <label class="form-label" for="original_name">نام اختصاری / نام اصلی لاتین</label>
        <input type="text" id="original_name" name="original_name" class="form-control" dir="ltr" value="<?php echo escape_html($test ? $test['original_name'] : ''); ?>" placeholder="YSQ-S3">
      </div>

      <div class="form-group">
        <label class="form-label" for="version">نسخه ابزار</label>
        <input type="text" id="version" name="version" class="form-control" dir="ltr" value="<?php echo escape_html($test ? $test['version'] : '1.0'); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label" for="estimated_minutes">مدت زمان تقریبی (دقیقه)</label>
        <input type="number" id="estimated_minutes" name="estimated_minutes" class="form-control" value="<?php echo escape_html($test ? $test['estimated_minutes'] : 15); ?>" min="1" required>
      </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
      <div class="form-group">
        <label class="form-label" for="accent_color">رنگ سازمانی شاخص (Hex Color)</label>
        <input type="color" id="accent_color" name="accent_color" class="form-control" style="height: 48px; padding: 4px;" value="<?php echo escape_html($test ? $test['accent_color'] : '#0d9488'); ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="sort_order">ترتیب نمایش در صفحه اصلی</label>
        <input type="number" id="sort_order" name="sort_order" class="form-control" value="<?php echo escape_html($test ? $test['sort_order'] : 0); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label" for="banner_file">تصویر بنر یا کاور آزمون</label>
      <input type="file" id="banner_file" name="banner_file" class="form-control" accept="image/jpeg,image/png,image/webp">
      <?php if ($test && !empty($test['banner_image'])): ?>
        <small style="color: #64748b; margin-top: 4px; display: block;">تصویر فعلی: <?php echo escape_html($test['banner_image']); ?></small>
      <?php endif; ?>
    </div>

    <div class="form-group">
      <label class="form-label" for="description">توضیح کوتاه کارت آزمون (Description)</label>
      <textarea id="description" name="description" class="form-control" rows="3" placeholder="خلاصه کوتاه معرفی و هدف آزمون جهت نمایش در صفحه اول..."><?php echo escape_html($test ? $test['description'] : ''); ?></textarea>
    </div>

    <div class="form-group">
      <label class="form-label" for="intro_text">متن راهنمای شروع و دستورالعمل پاسخ‌دهی (Intro Text)</label>
      <textarea id="intro_text" name="intro_text" class="form-control" rows="4" placeholder="نحوه پاسخ‌دهی و راهنمای شرکت‌کننده..."><?php echo escape_html($test ? $test['intro_text'] : ''); ?></textarea>
    </div>

    <div class="form-group">
      <label class="form-label" for="scientific_profile">مشخصات روان‌سنجی و پیشینه علمی (Scientific Profile)</label>
      <textarea id="scientific_profile" name="scientific_profile" class="form-control" rows="4" placeholder="سازنده، پایایی، روایی و اعتباریابی در جامعه ایرانی..."><?php echo escape_html($test ? $test['scientific_profile'] : ''); ?></textarea>
    </div>

    <div class="form-group">
      <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
        <input type="checkbox" name="is_active" value="1" <?php echo (!$test || intval($test['is_active']) === 1) ? 'checked' : ''; ?>>
        <strong style="color: var(--primary-navy);">آزمون فعال و برای عموم قابل مشاهده باشد</strong>
      </label>
    </div>

    <button type="submit" class="btn btn-primary btn-lg btn-block" style="margin-top: 24px;">
      <span>ذخیره مشخصات آزمون</span>
      <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
    </button>
  </form>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
