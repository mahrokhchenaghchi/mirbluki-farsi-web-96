<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * مدیریت منابع و رفرنس‌های علمی آزمون (Scientific Sources Manager)
 */

$admin_page_title = 'مدیریت منابع علمی آزمون';
$active_tab = 'tests';

require_once __DIR__ . '/header.php';

$test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : 0;
if ($test_id <= 0) {
    set_flash('danger', 'شناسه آزمون نامعتبر است.');
    redirect('/admin/tests.php');
}

$test = engine_get_test($test_id);
if (!$test) {
    set_flash('danger', 'آزمون یافت نشد.');
    redirect('/admin/tests.php');
}

$admin_page_title = 'مدیریت منابع علمی: ' . $test['title'];

// عملیات حذف منبع
if (isset($_GET['delete_id'])) {
    $del_id = intval($_GET['delete_id']);
    db_query("DELETE FROM `test_sources` WHERE `id` = ? AND `test_id` = ?", 'ii', array($del_id, $test_id));
    set_flash('success', 'منبع علمی با موفقیت حذف شد.');
    redirect('/admin/sources.php?test_id=' . $test_id);
}

// عملیات افزودن یا ویرایش منبع
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی نشست.');
        redirect('/admin/sources.php?test_id=' . $test_id);
    }

    $source_id = isset($_POST['source_id']) ? intval($_POST['source_id']) : 0;
    $citation_title = clean_input($_POST['citation_title']);
    $authors = clean_input($_POST['authors']);
    $year = clean_input($_POST['year']);
    $doi = clean_input($_POST['doi']);
    $url = clean_input($_POST['url']);
    $notes = clean_input($_POST['notes']);

    if (empty($citation_title)) {
        set_flash('danger', 'عنوان مقاله یا منبع الزامی است.');
    } else {
        $data = array(
            'test_id' => $test_id,
            'citation_title' => $citation_title,
            'authors' => $authors,
            'year' => $year,
            'doi' => $doi,
            'url' => $url,
            'notes' => $notes
        );

        if ($source_id > 0) {
            db_update('test_sources', $data, 'id = ? AND test_id = ?', 'ii', array($source_id, $test_id));
            set_flash('success', 'منبع علمی با موفقیت بروزرسانی شد.');
        } else {
            db_insert('test_sources', $data);
            set_flash('success', 'منبع علمی جدید با موفقیت اضافه شد.');
        }
        redirect('/admin/sources.php?test_id=' . $test_id);
    }
}

$sources = db_fetch_all("SELECT * FROM `test_sources` WHERE `test_id` = ? ORDER BY `id` ASC", 'i', array($test_id));
$edit_source = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $edit_source = db_fetch_one("SELECT * FROM `test_sources` WHERE `id` = ? AND `test_id` = ? LIMIT 1", 'ii', array($edit_id, $test_id));
}
?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
  <div>
    <h2 style="font-size: 1.4rem; color: var(--primary-navy); margin-bottom: 4px;">
      منابع و مستندات علمی: <?php echo escape_html($test['title']); ?>
    </h2>
    <span style="color: #64748b; font-size: 0.9rem;">مدیریت مراجع پژوهشی و هنجاریابی‌های دانشگاهی</span>
  </div>
  <div style="display: flex; gap: 8px;">
    <a href="/admin/tests.php" class="btn btn-outline btn-sm">بازگشت به آزمون‌ها</a>
    <a href="/tests/intro.php?slug=<?php echo urlencode($test['slug']); ?>" target="_blank" class="btn btn-primary btn-sm">مشاهده در سایت ↗</a>
  </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1.5fr; gap: 24px;">
  
  <!-- Add / Edit Form -->
  <div class="admin-card">
    <h3 style="font-size: 1.15rem; margin-bottom: 16px;">
      <?php echo $edit_source ? 'ویرایش منبع علمی' : '+ افزودن منبع علمی جدید'; ?>
    </h3>

    <form method="POST" action="/admin/sources.php?test_id=<?php echo $test_id; ?>">
      <?php echo csrf_field(); ?>
      <?php if ($edit_source): ?>
        <input type="hidden" name="source_id" value="<?php echo $edit_source['id']; ?>">
      <?php endif; ?>

      <div class="form-group">
        <label class="form-label" for="citation_title">عنوان منبع یا مقاله <span style="color: #dc2626;">*</span></label>
        <input type="text" id="citation_title" name="citation_title" class="form-control" value="<?php echo escape_html($edit_source ? $edit_source['citation_title'] : ''); ?>" required placeholder="مثال: The Satisfaction with Life Scale">
      </div>

      <div class="form-group">
        <label class="form-label" for="authors">نویسندگان / پژوهشگران</label>
        <input type="text" id="authors" name="authors" class="form-control" value="<?php echo escape_html($edit_source ? $edit_source['authors'] : ''); ?>" placeholder="Diener, E., Emmons, R. A.">
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <div class="form-group">
          <label class="form-label" for="year">سال انتشار</label>
          <input type="text" id="year" name="year" class="form-control" dir="ltr" value="<?php echo escape_html($edit_source ? $edit_source['year'] : '2000'); ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="doi">شناسه DOI یا PMID</label>
          <input type="text" id="doi" name="doi" class="form-control" dir="ltr" value="<?php echo escape_html($edit_source ? $edit_source['doi'] : ''); ?>" placeholder="10.1207/...">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="url">لینک مرجع یا پایگاه</label>
        <input type="url" id="url" name="url" class="form-control" dir="ltr" value="<?php echo escape_html($edit_source ? $edit_source['url'] : 'https://mirbolouki.com'); ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="notes">توضیحات و مشخصات هنجاریابی ایرانی</label>
        <textarea id="notes" name="notes" class="form-control" rows="3" placeholder="اطلاعات روایی، پایایی و ترجمه استاندارد..."><?php echo escape_html($edit_source ? $edit_source['notes'] : ''); ?></textarea>
      </div>

      <div style="display: flex; gap: 8px;">
        <button type="submit" class="btn btn-primary btn-block">
          <?php echo $edit_source ? 'ذخیره تغییرات منبع' : 'افزودن منبع به آزمون'; ?>
        </button>
        <?php if ($edit_source): ?>
          <a href="/admin/sources.php?test_id=<?php echo $test_id; ?>" class="btn btn-outline">انصراف</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Sources List -->
  <div class="admin-card">
    <h3 style="font-size: 1.15rem; margin-bottom: 16px;">فهرست منابع علمی ثبت‌شده (<?php echo to_persian_num(count($sources)); ?>)</h3>

    <?php if (empty($sources)): ?>
      <div style="text-align: center; padding: 30px; color: #64748b;">
        هنوز منبعی ثبت نشده است. از فرم روبرو می‌توانید منابع آزمون را اضافه فرمایید.
      </div>
    <?php else: ?>
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <?php foreach ($sources as $src): ?>
          <div style="background: #f8fafc; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 14px;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px;">
              <strong style="font-size: 0.98rem; color: var(--primary-navy);">
                <?php echo escape_html($src['citation_title']); ?>
              </strong>
              <div style="display: flex; gap: 6px;">
                <a href="/admin/sources.php?test_id=<?php echo $test_id; ?>&edit_id=<?php echo $src['id']; ?>" class="btn btn-outline btn-sm">ویرایش</a>
                <a href="/admin/sources.php?test_id=<?php echo $test_id; ?>&delete_id=<?php echo $src['id']; ?>" class="btn btn-sm btn-confirm-action" data-confirm="آیا از حذف این منبع اطمینان دارید؟" style="color: #ef4444;">حذف</a>
              </div>
            </div>

            <div style="font-size: 0.85rem; color: #475569; line-height: 1.6;">
              <?php if (!empty($src['authors'])): ?>
                <div>✍️ <strong>نویسندگان:</strong> <?php echo escape_html($src['authors']); ?> (<?php echo escape_html($src['year']); ?>)</div>
              <?php endif; ?>
              <?php if (!empty($src['notes'])): ?>
                <div style="margin-top: 4px; color: #334155;">📖 <?php echo escape_html($src['notes']); ?></div>
              <?php endif; ?>
              <?php if (!empty($src['doi'])): ?>
                <div style="margin-top: 4px;"><code style="font-size: 0.8rem;">DOI: <?php echo escape_html($src['doi']); ?></code></div>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>
