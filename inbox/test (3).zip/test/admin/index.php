<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * داشبورد اصلی پنل مدیریت (Admin Dashboard & KPI Metrics)
 */

$admin_page_title = 'داشبورد و آمار کلی';
$active_tab = 'dashboard';

require_once __DIR__ . '/header.php';

// محاسبات آماری داشبورد
$count_users = db_fetch_one("SELECT COUNT(*) as c FROM `users`")['c'];
$count_tests = db_fetch_one("SELECT COUNT(*) as c FROM `tests`")['c'];
$count_results = db_fetch_one("SELECT COUNT(*) as c FROM `test_results`")['c'];
$count_requests = db_fetch_one("SELECT COUNT(*) as c FROM `interpretation_requests`")['c'];

$count_pending_receipts = db_fetch_one("SELECT COUNT(*) as c FROM `interpretation_requests` WHERE `payment_status` = 'receipt_submitted'")['c'];
$count_pending_interpretations = db_fetch_one(
    "SELECT COUNT(*) as c FROM `interpretation_requests` req 
     LEFT JOIN `full_interpretations` fi ON req.result_id = fi.result_id 
     WHERE req.payment_status = 'payment_confirmed' AND (fi.status IS NULL OR fi.status != 'published')"
)['c'];

// ۵ درخواست اخیر نیازمند بررسی
$recent_requests = db_fetch_all(
    "SELECT req.*, u.first_name, u.last_name, u.mobile, t.title as test_title 
     FROM `interpretation_requests` req 
     JOIN `users` u ON req.user_id = u.id 
     JOIN `tests` t ON req.test_id = t.id 
     ORDER BY req.requested_at DESC 
     LIMIT 5"
);

// ۵ آزمون اخیر انجام‌شده
$recent_results = db_fetch_all(
    "SELECT r.*, u.first_name, u.last_name, u.mobile, u.age, t.title as test_title,
     req.id as request_id 
     FROM `test_results` r 
     JOIN `users` u ON r.user_id = u.id 
     JOIN `tests` t ON r.test_id = t.id 
     LEFT JOIN `interpretation_requests` req ON r.id = req.result_id 
     ORDER BY r.created_at DESC 
     LIMIT 5"
);
?>

<!-- KPI Cards Grid -->
<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-icon teal">👥</div>
    <div class="kpi-info">
      <h4><?php echo to_persian_num($count_users); ?></h4>
      <span>کل مراجعین / کاربران</span>
    </div>
  </div>

  <div class="kpi-card">
    <div class="kpi-icon blue">📝</div>
    <div class="kpi-info">
      <h4><?php echo to_persian_num($count_results); ?></h4>
      <span>آزمون‌های انجام‌شده</span>
    </div>
  </div>

  <div class="kpi-card">
    <div class="kpi-icon gold">💳</div>
    <div class="kpi-info">
      <h4><?php echo to_persian_num($count_pending_receipts); ?></h4>
      <span>فیش‌های در انتظار بررسی مالی</span>
    </div>
  </div>

  <div class="kpi-card">
    <div class="kpi-icon purple">✍️</div>
    <div class="kpi-info">
      <h4><?php echo to_persian_num($count_pending_interpretations); ?></h4>
      <span>تفسیرهای در حال نگارش / منتشرنشده</span>
    </div>
  </div>
</div>

<!-- Pending Requests Alert Banner if any -->
<?php if ($count_pending_receipts > 0): ?>
  <div class="alert alert-warning" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
      ⚠️ شما <strong><?php echo to_persian_num($count_pending_receipts); ?></strong> فیش واریزی در انتظار تایید دارید.
    </div>
    <a href="/admin/requests.php?status=receipt_submitted" class="btn btn-primary btn-sm">مشاهده و بررسی فیش‌ها</a>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr; gap: 30px;">
  
  <!-- Recent Interpretation Requests Table -->
  <div class="admin-card">
    <div class="card-header-flex">
      <h3 style="font-size: 1.15rem; margin-bottom: 0;">آخرین درخواست‌های تفسیر کامل</h3>
      <a href="/admin/requests.php" class="btn btn-outline btn-sm">مشاهده همه درخواست‌ها</a>
    </div>

    <?php if (empty($recent_requests)): ?>
      <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 0;">هنوز درخواستی ثبت نشده است.</p>
    <?php else: ?>
      <div class="table-responsive">
        <table class="admin-table">
          <thead>
            <tr>
              <th>کد رهگیری</th>
              <th>نام مراجع</th>
              <th>شماره تماس</th>
              <th>آزمون</th>
              <th>مبلغ</th>
              <th>تاریخ درخواست</th>
              <th>وضعیت</th>
              <th>عملیات</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_requests as $req): ?>
              <tr>
                <td><code><?php echo escape_html($req['request_code']); ?></code></td>
                <td><strong><?php echo escape_html($req['first_name'] . ' ' . $req['last_name']); ?></strong></td>
                <td><?php echo to_persian_num($req['mobile']); ?></td>
                <td><?php echo escape_html($req['test_title']); ?></td>
                <td><?php echo format_toman($req['amount']); ?></td>
                <td><?php echo format_jalali_date($req['requested_at']); ?></td>
                <td><?php echo format_request_status_badge($req['payment_status']); ?></td>
                <td>
                  <a href="/admin/request-detail.php?id=<?php echo $req['id']; ?>" class="btn btn-primary btn-sm">
                    بررسی و ویرایش
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <!-- Recent Test Results Table -->
  <div class="admin-card">
    <div class="card-header-flex">
      <h3 style="font-size: 1.15rem; margin-bottom: 0;">آخرین کارنامه‌های صادرشده</h3>
      <a href="/admin/results.php" class="btn btn-outline btn-sm">مشاهده تمام کارنامه‌ها</a>
    </div>

    <?php if (empty($recent_results)): ?>
      <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 0;">هنوز آزمونی انجام نشده است.</p>
    <?php else: ?>
      <div class="table-responsive">
        <table class="admin-table">
          <thead>
            <tr>
              <th>نام مراجع</th>
              <th>شماره تماس</th>
              <th>سن</th>
              <th>آزمون</th>
              <th>نمره کل</th>
              <th>طبقه‌بندی</th>
              <th>شدت</th>
              <th>تاریخ</th>
              <th>عملیات</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_results as $res): ?>
              <tr>
                <td><strong><?php echo escape_html($res['first_name'] . ' ' . $res['last_name']); ?></strong></td>
                <td><?php echo to_persian_num($res['mobile']); ?></td>
                <td><?php echo to_persian_num($res['age']); ?></td>
                <td><?php echo escape_html($res['test_title']); ?></td>
                <td style="font-weight: 700; color: var(--primary-teal);"><?php echo to_persian_num($res['total_score']); ?></td>
                <td><?php echo escape_html($res['overall_category']); ?></td>
                <td><?php echo format_severity_badge($res['overall_severity']); ?></td>
                <td><?php echo format_jalali_date($res['created_at']); ?></td>
                <td>
                  <div style="display: flex; gap: 6px;">
                    <a href="/admin/result-detail.php?id=<?php echo $res['id']; ?>" class="btn btn-outline btn-sm">
                      جزئیات و استناد
                    </a>
                    <?php if (!empty($res['request_id'])): ?>
                      <a href="/admin/request-detail.php?id=<?php echo $res['request_id']; ?>" class="btn btn-primary btn-sm">
                        تدوین تفسیر
                      </a>
                    <?php else: ?>
                      <a href="/admin/result-detail.php?id=<?php echo $res['id']; ?>&action=create_direct_interpretation" class="btn btn-luxury btn-sm">
                        تدوین تفسیر
                      </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>
