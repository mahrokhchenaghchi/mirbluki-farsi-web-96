<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * مدیریت کاربران و مراجعین (Users Directory)
 */

$admin_page_title = 'مدیریت کاربران و مراجعین';
$active_tab = 'users';

require_once __DIR__ . '/header.php';

$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';

$sql = "SELECT u.*, 
        (SELECT COUNT(*) FROM `test_results` r WHERE r.user_id = u.id) as tests_taken_count,
        (SELECT COUNT(*) FROM `interpretation_requests` req WHERE req.user_id = u.id) as interp_requests_count
        FROM `users` u 
        WHERE 1=1";

$types = '';
$params = array();

if (!empty($search)) {
    $sql .= " AND (u.mobile LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $like = '%' . $search . '%';
    $types .= 'sss';
    $params = array($like, $like, $like);
}

$sql .= " ORDER BY u.created_at DESC";
$users = db_fetch_all($sql, $types, $params);
?>

<div class="admin-card">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.25rem; margin-bottom: 4px;">فهرست کاربران و مراجعین</h3>
      <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 0;">مشاهده سوابق و تاریخچه ارزیابی‌های روان‌شناختی هر مراجع</p>
    </div>

    <!-- Search Form -->
    <form method="GET" action="/admin/users.php" style="display: flex; gap: 8px;">
      <input type="text" name="search" class="form-control" style="width: 240px; padding: 8px 12px;" placeholder="جستجوی نام یا همراه..." value="<?php echo escape_html($search); ?>">
      <button type="submit" class="btn btn-primary btn-sm">جستجو</button>
      <?php if (!empty($search)): ?>
        <a href="/admin/users.php" class="btn btn-outline btn-sm">پاکسازی</a>
      <?php endif; ?>
    </form>
  </div>

  <?php if (empty($users)): ?>
    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
      کاربری یافت نشد.
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>شناسه</th>
            <th>نام و نام خانوادگی</th>
            <th>شماره تلفن همراه</th>
            <th>جنسیت</th>
            <th>سن</th>
            <th>تعداد تست‌ها</th>
            <th>درخواست‌های تفسیر</th>
            <th>تاریخ عضویت</th>
            <th>عملیات مراجع</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $u): ?>
            <tr>
              <td><code>#<?php echo $u['id']; ?></code></td>
              <td><strong><?php echo escape_html($u['first_name'] . ' ' . $u['last_name']); ?></strong></td>
              <td><?php echo to_persian_num($u['mobile']); ?></td>
              <td><?php echo $u['gender'] === 'female' ? 'زن' : ($u['gender'] === 'male' ? 'مرد' : 'نامشخص'); ?></td>
              <td><?php echo to_persian_num($u['age']); ?> سال</td>
              <td>
                <a href="/admin/results.php?user_id=<?php echo $u['id']; ?>" class="custom-badge badge-primary" title="مشاهده کارنامه‌های آزمون">
                  📝 <?php echo to_persian_num($u['tests_taken_count']); ?> آزمون
                </a>
              </td>
              <td>
                <a href="/admin/requests.php?search=<?php echo urlencode($u['mobile']); ?>" class="custom-badge badge-secondary" title="مشاهده درخواست‌های تفسیر این مراجع">
                  💳 <?php echo to_persian_num($u['interp_requests_count']); ?> درخواست
                </a>
              </td>
              <td><?php echo format_jalali_date($u['created_at']); ?></td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="/admin/results.php?user_id=<?php echo $u['id']; ?>" class="btn btn-primary btn-sm" title="مشاهده تست‌های انجام‌شده و نتایج">
                    مشاهده تست‌ها و نتایج
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
