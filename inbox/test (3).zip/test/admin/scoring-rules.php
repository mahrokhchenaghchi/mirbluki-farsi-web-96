<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * مدیریت ابعاد، نقاط برش، قوانین نمره‌دهی و منابع علمی (Dimensions, Scoring Rules & Sources)
 */

$admin_page_title = 'ابعاد و نمره‌دهی آزمون';
$active_tab = 'tests';

require_once __DIR__ . '/header.php';

$test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : 0;
if ($test_id <= 0) {
    redirect('/admin/tests.php');
}

$test = engine_get_test($test_id);
if (!$test) {
    set_flash('danger', 'آزمون یافت نشد.');
    redirect('/admin/tests.php');
}

$admin_page_title = 'ابعاد و نمره‌دهی: ' . $test['title'];

// ۱. افزودن بعد جدید
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_dimension') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی.');
        redirect('/admin/scoring-rules.php?test_id=' . $test_id);
    }

    $dim_title = clean_input($_POST['title']);
    $dim_code = clean_input($_POST['code']);
    $dim_color = clean_input($_POST['color_hex']);
    $dim_min = floatval($_POST['min_score']);
    $dim_max = floatval($_POST['max_score']);
    $dim_desc = clean_input($_POST['description']);

    if (!empty($dim_title)) {
        db_insert('test_dimensions', array(
            'test_id' => $test_id,
            'code' => $dim_code ? $dim_code : 'dim_' . time(),
            'title' => $dim_title,
            'color_hex' => $dim_color ? $dim_color : '#3b82f6',
            'min_score' => $dim_min,
            'max_score' => $dim_max,
            'description' => $dim_desc
        ));
        set_flash('success', 'بعد روان‌شناختی افزوده شد.');
    }
    redirect('/admin/scoring-rules.php?test_id=' . $test_id);
}

// ۲. حذف بعد
if (isset($_GET['delete_dim'])) {
    $dim_id = intval($_GET['delete_dim']);
    db_query("DELETE FROM `test_dimensions` WHERE `id` = ? AND `test_id` = ?", 'ii', array($dim_id, $test_id));
    set_flash('info', 'بعد حذف شد.');
    redirect('/admin/scoring-rules.php?test_id=' . $test_id);
}

// ۳. افزودن قانون نمره‌دهی و نقطه برش (Cut-off Rule)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_rule') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی.');
        redirect('/admin/scoring-rules.php?test_id=' . $test_id);
    }

    $dim_id = !empty($_POST['dimension_id']) ? intval($_POST['dimension_id']) : null;
    $cat_name = clean_input($_POST['category_name']);
    $min_r = floatval($_POST['min_range']);
    $max_r = floatval($_POST['max_range']);
    $severity = clean_input($_POST['severity_level']);
    $short_interp = clean_input($_POST['short_interpretation']);

    if (!empty($cat_name)) {
        db_insert('test_scoring_rules', array(
            'test_id' => $test_id,
            'dimension_id' => $dim_id,
            'category_name' => $cat_name,
            'min_range' => $min_r,
            'max_range' => $max_r,
            'severity_level' => $severity,
            'short_interpretation' => $short_interp
        ));
        set_flash('success', 'قانون نمره‌دهی و نقطه برش افزوده شد.');
    }
    redirect('/admin/scoring-rules.php?test_id=' . $test_id);
}

// ۴. حذف قانون نمره‌دهی
if (isset($_GET['delete_rule'])) {
    $rule_id = intval($_GET['delete_rule']);
    db_query("DELETE FROM `test_scoring_rules` WHERE `id` = ? AND `test_id` = ?", 'ii', array($rule_id, $test_id));
    set_flash('info', 'قانون نمره‌دهی حذف شد.');
    redirect('/admin/scoring-rules.php?test_id=' . $test_id);
}

// ۵. افزودن منبع علمی
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_source') {
    if (!csrf_verify()) {
        set_flash('danger', 'خطای امنیتی.');
        redirect('/admin/scoring-rules.php?test_id=' . $test_id);
    }

    $citation = clean_input($_POST['citation_title']);
    $authors = clean_input($_POST['authors']);
    $year = clean_input($_POST['year']);
    $doi = clean_input($_POST['doi']);
    $url = clean_input($_POST['url']);

    if (!empty($citation)) {
        db_insert('test_sources', array(
            'test_id' => $test_id,
            'citation_title' => $citation,
            'authors' => $authors,
            'year' => $year,
            'doi' => $doi,
            'url' => $url
        ));
        set_flash('success', 'منبع علمی ثبت شد.');
    }
    redirect('/admin/scoring-rules.php?test_id=' . $test_id);
}

// ۶. حذف منبع
if (isset($_GET['delete_src'])) {
    $src_id = intval($_GET['delete_src']);
    db_query("DELETE FROM `test_sources` WHERE `id` = ? AND `test_id` = ?", 'ii', array($src_id, $test_id));
    set_flash('info', 'منبع حذف شد.');
    redirect('/admin/scoring-rules.php?test_id=' . $test_id);
}

$dimensions = db_fetch_all("SELECT * FROM `test_dimensions` WHERE `test_id` = ? ORDER BY `sort_order` ASC, `id` ASC", 'i', array($test_id));
$rules = db_fetch_all(
    "SELECT r.*, d.title as dim_title 
     FROM `test_scoring_rules` r 
     LEFT JOIN `test_dimensions` d ON r.dimension_id = d.id 
     WHERE r.test_id = ? 
     ORDER BY r.dimension_id ASC, r.min_range ASC",
    'i',
    array($test_id)
);
$sources = db_fetch_all("SELECT * FROM `test_sources` WHERE `test_id` = ? ORDER BY `id` ASC", 'i', array($test_id));
?>

<div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
  <a href="/admin/tests.php" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; color: #64748b; font-weight: 600;">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
    <span>بازگشت به آزمون‌ها</span>
  </a>
  <a href="/admin/questions.php?test_id=<?php echo $test_id; ?>" class="btn btn-outline btn-sm">
    مدیریت بانک سؤالات ↗
  </a>
</div>

<!-- 1. Dimensions Section -->
<div class="admin-card" style="margin-bottom: 30px;">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.2rem; margin-bottom: 4px;">۱. ابعاد و زیرمقیاس‌های آزمون (Dimensions)</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 0;">مؤلفه‌های مستقل مورد سنجش و رنگ اختصاصی در نمودارها</p>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 24px;">
    <div>
      <?php if (empty($dimensions)): ?>
        <p style="color: var(--text-muted); font-size: 0.9rem;">هنوز بعدی تعریف نشده است.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="admin-table">
            <thead>
              <tr>
                <th>کد</th>
                <th>عنوان بعد</th>
                <th>رنگ نمودار</th>
                <th>بازه نمره</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($dimensions as $d): ?>
                <tr>
                  <td><code><?php echo escape_html($d['code']); ?></code></td>
                  <td><strong><?php echo escape_html($d['title']); ?></strong></td>
                  <td>
                    <span style="display: inline-block; width: 18px; height: 18px; border-radius: 4px; background: <?php echo escape_html($d['color_hex']); ?>; vertical-align: middle; margin-left: 6px;"></span>
                    <small><?php echo escape_html($d['color_hex']); ?></small>
                  </td>
                  <td><?php echo to_persian_num($d['min_score']); ?> تا <?php echo to_persian_num($d['max_score']); ?></td>
                  <td>
                    <a href="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>&delete_dim=<?php echo $d['id']; ?>" class="btn-confirm-action" data-confirm="آیا از حذف این بعد اطمینان دارید؟" style="color: #ef4444; font-size: 0.85rem;">حذف</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <div style="background: #f8fafc; padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
      <h4 style="font-size: 1rem; margin-bottom: 14px;">+ افزودن بعد جدید</h4>
      <form method="POST" action="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_dimension">

        <div class="form-group">
          <label class="form-label" for="dim_title">عنوان فارسی بعد <span style="color: #dc2626;">*</span></label>
          <input type="text" id="dim_title" name="title" class="form-control" required placeholder="مثال: محرومیت هیجانی">
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
          <div class="form-group">
            <label class="form-label" for="dim_code">کد اختصاری</label>
            <input type="text" id="dim_code" name="code" class="form-control" dir="ltr" placeholder="ED">
          </div>
          <div class="form-group">
            <label class="form-label" for="dim_color">رنگ</label>
            <input type="color" id="dim_color" name="color_hex" class="form-control" value="#3b82f6" style="height: 44px; padding: 3px;">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="dim_desc">توضیح کوتاه بعد</label>
          <input type="text" id="dim_desc" name="description" class="form-control" placeholder="توضیح روان‌شناختی...">
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-sm">+ ثبت بعد</button>
      </form>
    </div>
  </div>
</div>

<!-- 2. Scoring Rules & Cut-offs Section -->
<div class="admin-card" style="margin-bottom: 30px;">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.2rem; margin-bottom: 4px;">۲. قوانین نمره‌دهی، نقاط برش و طبقه‌بندی (Scoring Rules & Cut-offs)</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 0;">تعیین بازه‌های نمرات، سطح شدت و متن تفسیر کوتاه اتوماتیک</p>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 24px;">
    <div>
      <?php if (empty($rules)): ?>
        <p style="color: var(--text-muted); font-size: 0.9rem;">هنوز قانون نمره‌دهی ثبت نشده است.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="admin-table">
            <thead>
              <tr>
                <th>مؤلفه مربوطه</th>
                <th>عنوان طبقه</th>
                <th>بازه نمره</th>
                <th>سطح شدت</th>
                <th>خلاصه تفسیر</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rules as $r): ?>
                <tr>
                  <td><?php echo escape_html($r['dim_title'] ? $r['dim_title'] : 'نمره کل آزمون'); ?></td>
                  <td><strong><?php echo escape_html($r['category_name']); ?></strong></td>
                  <td><?php echo to_persian_num($r['min_range']); ?> تا <?php echo to_persian_num($r['max_range']); ?></td>
                  <td><?php echo format_severity_badge($r['severity_level']); ?></td>
                  <td style="font-size: 0.82rem; max-width: 200px;"><?php echo escape_html(mb_substr($r['short_interpretation'], 0, 45, 'UTF-8')) . '...'; ?></td>
                  <td>
                    <a href="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>&delete_rule=<?php echo $r['id']; ?>" class="btn-confirm-action" data-confirm="حذف شود؟" style="color: #ef4444; font-size: 0.85rem;">حذف</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <div style="background: #f8fafc; padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
      <h4 style="font-size: 1rem; margin-bottom: 14px;">+ افزودن قانون نمره‌دهی</h4>
      <form method="POST" action="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_rule">

        <div class="form-group">
          <label class="form-label" for="rule_dim_id">انتساب به بعد یا کل آزمون</label>
          <select id="rule_dim_id" name="dimension_id" class="form-control">
            <option value="">(نمره کل آزمون)</option>
            <?php foreach ($dimensions as $dim): ?>
              <option value="<?php echo $dim['id']; ?>"><?php echo escape_html($dim['title']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="category_name">عنوان طبقه (Category) <span style="color: #dc2626;">*</span></label>
          <input type="text" id="category_name" name="category_name" class="form-control" required placeholder="مثال: شدت بالا / فعال">
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1.2fr; gap: 8px;">
          <div class="form-group">
            <label class="form-label" for="min_range">از نمره</label>
            <input type="number" step="0.1" id="min_range" name="min_range" class="form-control" required value="0">
          </div>
          <div class="form-group">
            <label class="form-label" for="max_range">تا نمره</label>
            <input type="number" step="0.1" id="max_range" name="max_range" class="form-control" required value="10">
          </div>
          <div class="form-group">
            <label class="form-label" for="severity_level">سطح شدت</label>
            <select id="severity_level" name="severity_level" class="form-control">
              <option value="normal">عادی</option>
              <option value="low">خفیف</option>
              <option value="moderate">متوسط</option>
              <option value="high">بالا</option>
              <option value="severe">بسیار شدید</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="short_interpretation">متن تفسیر کوتاه خودکار <span style="color: #dc2626;">*</span></label>
          <textarea id="short_interpretation" name="short_interpretation" class="form-control" rows="3" required placeholder="توضیح تحلیلی این بازه نمره..."></textarea>
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-sm">+ ثبت قانون نمره‌دهی</button>
      </form>
    </div>
  </div>
</div>

<!-- 3. Scientific Sources Section -->
<div class="admin-card">
  <div class="card-header-flex">
    <div>
      <h3 style="font-size: 1.2rem; margin-bottom: 4px;">۳. منابع و مستندات علمی آزمون (Scientific Sources)</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 0;">مقالات مرجع، پدیدآورندگان و شناسه‌های DOI جهت تضمین استنادپذیری</p>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 24px;">
    <div>
      <?php if (empty($sources)): ?>
        <p style="color: var(--text-muted); font-size: 0.9rem;">هنوز منبع علمی ثبت نشده است.</p>
      <?php else: ?>
        <ul style="list-style: none;">
          <?php foreach ($sources as $s): ?>
            <li style="padding: 12px; background: #f8fafc; border-radius: var(--radius-sm); margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong><?php echo escape_html($s['citation_title']); ?></strong>
                <div style="font-size: 0.82rem; color: #64748b; margin-top: 4px;">
                  <?php if (!empty($s['authors'])): ?>نویسندگان: <?php echo escape_html($s['authors']); ?> (<?php echo escape_html($s['year']); ?>)<?php endif; ?>
                  <?php if (!empty($s['doi'])): ?> | DOI: <?php echo escape_html($s['doi']); ?><?php endif; ?>
                </div>
              </div>
              <a href="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>&delete_src=<?php echo $s['id']; ?>" class="btn-confirm-action" data-confirm="حذف شود؟" style="color: #ef4444; font-size: 0.85rem;">حذف</a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    <div style="background: #f8fafc; padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
      <h4 style="font-size: 1rem; margin-bottom: 14px;">+ ثبت منبع جدید</h4>
      <form method="POST" action="/admin/scoring-rules.php?test_id=<?php echo $test_id; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_source">

        <div class="form-group">
          <label class="form-label" for="citation_title">عنوان مقاله یا کتاب <span style="color: #dc2626;">*</span></label>
          <input type="text" id="citation_title" name="citation_title" class="form-control" required placeholder="عنوان مرجع...">
        </div>

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 8px;">
          <div class="form-group">
            <label class="form-label" for="authors">نویسندگان</label>
            <input type="text" id="authors" name="authors" class="form-control" placeholder="Young et al.">
          </div>
          <div class="form-group">
            <label class="form-label" for="year">سال</label>
            <input type="text" id="year" name="year" class="form-control" placeholder="2003">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="doi">شناسه DOI یا URL</label>
          <input type="text" id="doi" name="doi" class="form-control" dir="ltr" placeholder="10.1016/...">
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-sm">+ ثبت منبع علمی</button>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
