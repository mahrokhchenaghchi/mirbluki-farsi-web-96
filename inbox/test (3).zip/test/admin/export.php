<?php
/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * خروجی اکسل و CSV نتایج آزمون‌ها (CSV Export Handler)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

require_admin_login();

$test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : 0;
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

$sql = "SELECT r.id, u.first_name, u.last_name, u.mobile, u.age, u.gender,
        t.title as test_title, r.test_version, r.total_score, r.overall_category, r.overall_severity,
        req.payment_status, fi.status as interp_status, r.created_at
        FROM `test_results` r 
        JOIN `users` u ON r.user_id = u.id 
        JOIN `tests` t ON r.test_id = t.id 
        LEFT JOIN `interpretation_requests` req ON r.id = req.result_id 
        LEFT JOIN `full_interpretations` fi ON r.id = fi.result_id 
        WHERE 1=1";

$types = '';
$params = array();

if ($test_id > 0) {
    $sql .= " AND r.test_id = ?";
    $types .= 'i';
    $params[] = $test_id;
}

if ($user_id > 0) {
    $sql .= " AND r.user_id = ?";
    $types .= 'i';
    $params[] = $user_id;
}

$sql .= " ORDER BY r.created_at DESC";
$results = db_fetch_all($sql, $types, $params);

$filename = 'mirbolouki_results_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

// چاپ UTF-8 BOM جهت نمایش صحیح فونت‌های فارسی در نرم‌افزار Excel
echo "\xEF\xBB\xBF";

$output = fopen('php://output', 'w');

// هدرهای ستون‌ها
fputcsv($output, array(
    'شناسه',
    'نام مراجع',
    'شماره تماس',
    'سن',
    'جنسیت',
    'عنوان آزمون',
    'نسخه ابزار',
    'نمره کل',
    'طبقه‌بندی کلی',
    'سطح شدت',
    'وضعیت پرداخت',
    'وضعیت انتشار تفسیر',
    'تاریخ و زمان ثبت'
));

foreach ($results as $r) {
    $gender_fa = $r['gender'] === 'female' ? 'زن' : ($r['gender'] === 'male' ? 'مرد' : 'نامشخص');
    fputcsv($output, array(
        $r['id'],
        $r['first_name'] . ' ' . $r['last_name'],
        $r['mobile'],
        $r['age'],
        $gender_fa,
        $r['test_title'],
        $r['test_version'],
        $r['total_score'],
        $r['overall_category'],
        $r['overall_severity'],
        $r['payment_status'] ? $r['payment_status'] : 'not_requested',
        $r['interp_status'] ? $r['interp_status'] : 'none',
        $r['created_at']
    ));
}

fclose($output);
exit;
