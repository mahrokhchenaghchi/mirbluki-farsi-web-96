<?php
/**
 * ابزار بازنشانی کلمه عبور مدیر سامانه Mirbolouki
 * این فایل کلمه عبور کاربر admin را به Admin@123456 تنظیم می‌کند.
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/db.php';

$new_password = 'Admin@123456';
$new_hash = password_hash($new_password, PASSWORD_BCRYPT, array('cost' => 12));

// بررسی وجود کاربر admin یا افزودن آن
$admin_exists = db_fetch_one("SELECT id FROM `admins` WHERE `username` = 'admin' LIMIT 1");

if ($admin_exists) {
    db_update('admins', array('password_hash' => $new_hash, 'is_active' => 1), 'username = ?', 's', array('admin'));
} else {
    db_insert('admins', array(
        'username' => 'admin',
        'password_hash' => $new_hash,
        'full_name' => 'مدیر سامانه میربلوکی',
        'email' => 'info@mirbolouki.com',
        'role' => 'superadmin',
        'is_active' => 1,
        'created_at' => date('Y-m-d H:i:s')
    ));
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>بازنشانی رمز عبور مدیریت | دکتر جواد میربلوکی</title>
  <style>
    body {
      background: #091424;
      font-family: system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      color: #1e293b;
    }
    .card {
      background: #ffffff;
      border-radius: 16px;
      padding: 36px 30px;
      max-width: 440px;
      width: 100%;
      text-align: center;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.4);
    }
    .success-icon {
      width: 56px;
      height: 56px;
      background: #dcfce7;
      color: #16a34a;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
      margin: 0 auto 16px;
    }
    .title {
      color: #0f172a;
      font-size: 1.3rem;
      font-weight: 800;
      margin: 0 0 10px;
    }
    .info-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 16px;
      margin: 20px 0;
      text-align: right;
      font-size: 0.95rem;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 8px 0;
      padding-bottom: 8px;
      border-bottom: 1px dashed #e2e8f0;
    }
    .info-row:last-child {
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
    }
    .val {
      font-family: monospace;
      font-weight: 700;
      color: #0f766e;
      background: #e6fffa;
      padding: 3px 8px;
      border-radius: 6px;
      direction: ltr;
    }
    .btn {
      display: block;
      width: 100%;
      box-sizing: border-box;
      padding: 12px 20px;
      background: #0f766e;
      color: #ffffff;
      text-decoration: none;
      border-radius: 10px;
      font-weight: 700;
      font-size: 0.95rem;
      transition: background 0.2s;
    }
    .btn:hover {
      background: #0d9488;
    }
    .hint {
      margin-top: 18px;
      font-size: 0.8rem;
      color: #64748b;
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="success-icon">✓</div>
    <h2 class="title">کلمه عبور مدیر با موفقیت فعال شد</h2>
    <p style="color: #64748b; font-size: 0.88rem; margin: 0;">اطلاعات ورود به پنل مدیریت با موفقیت بازنشانی شد:</p>

    <div class="info-box">
      <div class="info-row">
        <span>نام کاربری (Username):</span>
        <span class="val">admin</span>
      </div>
      <div class="info-row">
        <span>کلمه عبور (Password):</span>
        <span class="val">Admin@123456</span>
      </div>
    </div>

    <a href="/admin/login.php" class="btn">
      ورود به پنل مدیریت (Admin Panel) &larr;
    </a>

    <div class="hint">
      🔒 جهت امنیت، پس از ورود موفق به پنل مدیریت، می‌توانید این فایل (<code>reset_admin.php</code>) را از هاست حذف نمایید.
    </div>
  </div>
</body>
</html>
