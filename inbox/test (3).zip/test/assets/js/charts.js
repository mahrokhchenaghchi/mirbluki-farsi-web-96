/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * کتابخانه اختصاصی رسم نمودارهای روان‌سنجی (Pure Vanilla JS & HTML5 Canvas Chart Engine)
 * بدون نیاز به Chart.js یا هرگونه CDN یا پکیج خارجی - ۱۰۰٪ مستقل و سازگار با حالت آفلاین
 */

const MirboloukiCharts = (function() {
  'use strict';

  // تبدیل اعداد به ارقام فارسی
  function toFa(num) {
    const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(num).replace(/[0-9]/g, function(w) {
      return fa[+w];
    });
  }

  // تنظیم رزولوشن و وضوح رتینا (High DPI Screen scaling)
  function setupCanvas(canvas) {
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width || canvas.parentElement.clientWidth || 600;
    const height = rect.height || 360;

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    return { ctx: ctx, width: width, height: height };
  }

  /**
   * رسم نمودار میله‌ای افقی ابعاد (Horizontal Dimension Bar Chart)
   * شبیه به نمودارهای دقیق و پیشرفته اکسل و مقالات علمی روان‌سنجی
   */
  function renderDimensionBarChart(canvasId, dimensionsData) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !dimensionsData || dimensionsData.length === 0) return;

    const setup = setupCanvas(canvas);
    const ctx = setup.ctx;
    const width = setup.width;
    const height = setup.height;

    const padding = { top: 30, right: 180, bottom: 40, left: 50 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // پیدا کردن بیشترین مقدار نمره برای مقیاس‌بندی
    let maxVal = 0;
    dimensionsData.forEach(function(d) {
      const val = parseFloat(d.raw_score) || 0;
      if (val > maxVal) maxVal = val;
    });
    if (maxVal === 0) maxVal = 10;
    // گرد کردن به ضریب مناسب
    maxVal = Math.ceil(maxVal * 1.15);

    // خطوط شبکه عمودی (Grid Lines)
    const gridSteps = 5;
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#64748b';
    ctx.font = '12px Vazirmatn, Tahoma, sans-serif';
    ctx.textAlign = 'center';

    for (let i = 0; i <= gridSteps; i++) {
      const val = (maxVal / gridSteps) * i;
      const x = padding.left + (chartWidth / gridSteps) * i;

      // رسم خط عمودی
      ctx.beginPath();
      ctx.moveTo(x, padding.top);
      ctx.lineTo(x, height - padding.bottom);
      ctx.stroke();

      // چاپ برچسب عدد در پایین
      ctx.fillText(toFa(Math.round(val)), x, height - padding.bottom + 20);
    }

    // رسم میله‌های هر بعد
    const count = dimensionsData.length;
    const barHeight = Math.min(28, (chartHeight / count) * 0.65);
    const gap = chartHeight / count;

    dimensionsData.forEach(function(dim, index) {
      const y = padding.top + index * gap + (gap - barHeight) / 2;
      const score = parseFloat(dim.raw_score) || 0;
      const barW = (score / maxVal) * chartWidth;
      const barColor = dim.color_hex || '#0d9488';

      // ۱. برچسب عنوان بعد در سمت راست
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 13px Vazirmatn, Tahoma, sans-serif';
      ctx.textAlign = 'right';
      
      let title = dim.title || ('بعد ' + (index + 1));
      if (title.length > 22) {
        title = title.substring(0, 20) + '...';
      }
      ctx.fillText(title, width - 15, y + barHeight / 2 + 5);

      // ۲. پس‌زمینه خاکستری میله
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(padding.left, y, chartWidth, barHeight, 6) : ctx.rect(padding.left, y, chartWidth, barHeight);
      ctx.fill();

      // ۳. میله رنگی مقدار
      ctx.fillStyle = barColor;
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(padding.left, y, Math.max(barW, 6), barHeight, 6) : ctx.rect(padding.left, y, Math.max(barW, 6), barHeight);
      ctx.fill();

      // ۴. برچسب نمره در انتهای میله
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 12px Vazirmatn, Tahoma, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(toFa(score), padding.left + barW + 8, y + barHeight / 2 + 4);
    });
  }

  /**
   * رسم نمودار مدور / گیج پیشرفت نمره کل (Circular Gauge / Donut Chart)
   */
  function renderScoreGauge(canvasId, score, maxScore, label, color) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    const setup = setupCanvas(canvas);
    const ctx = setup.ctx;
    const width = setup.width;
    const height = setup.height;

    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(centerX, centerY) - 20;

    const scoreVal = parseFloat(score) || 0;
    const maxVal = parseFloat(maxScore) || (scoreVal * 1.5) || 100;
    const ratio = Math.min(Math.max(scoreVal / maxVal, 0), 1);

    // زاویه شروع و پایان (قوس ۲۴۰ درجه)
    const startAngle = 0.75 * Math.PI;
    const endAngle = 2.25 * Math.PI;
    const currentAngle = startAngle + (endAngle - startAngle) * ratio;

    // ۱. رسم مسیر پس‌زمینه
    ctx.lineWidth = 14;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, endAngle);
    ctx.stroke();

    // ۲. رسم مسیر رنگی امتیاز
    ctx.strokeStyle = color || '#0d9488';
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, currentAngle);
    ctx.stroke();

    // ۳. متن وسط
    ctx.textAlign = 'center';
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 28px Vazirmatn, Tahoma, sans-serif';
    ctx.fillText(toFa(scoreVal), centerX, centerY + 6);

    ctx.fillStyle = '#64748b';
    ctx.font = '500 12px Vazirmatn, Tahoma, sans-serif';
    ctx.fillText(label || 'نمره کل', centerX, centerY + 28);
  }

  return {
    renderDimensionBarChart: renderDimensionBarChart,
    renderScoreGauge: renderScoreGauge
  };
})();
