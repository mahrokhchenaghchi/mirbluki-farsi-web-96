/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * اسکریپت‌های پنل مدیریت (Admin Panel Interactivity)
 */

document.addEventListener('DOMContentLoaded', function() {
  // ۱. نوار ابزار ادیتور متنی تفسیر (Rich Text Toolbar)
  const formatButtons = document.querySelectorAll('.editor-btn');
  formatButtons.forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('data-target') || 'adminNotesTextarea';
      const textarea = document.getElementById(targetId);
      if (!textarea) return;

      const formatType = this.getAttribute('data-format');
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      const selected = text.substring(start, end);

      let replacement = '';
      switch (formatType) {
        case 'bold':
          replacement = '**' + (selected || 'متن برجسته') + '**';
          break;
        case 'italic':
          replacement = '*' + (selected || 'متن مورب') + '*';
          break;
        case 'h3':
          replacement = '\n### ' + (selected || 'عنوان بخش') + '\n';
          break;
        case 'list':
          replacement = '\n- ' + (selected || 'مورد اول') + '\n- مورد دوم';
          break;
        case 'quote':
          replacement = '\n> ' + (selected || 'نقل قول یا نکته مهم') + '\n';
          break;
      }

      textarea.value = text.substring(0, start) + replacement + text.substring(end);
      textarea.focus();
    });
  });

  // ۲. تایید عملیات‌های حساس (Confirm Prompts)
  const confirmActions = document.querySelectorAll('.btn-confirm-action');
  confirmActions.forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      const msg = this.getAttribute('data-confirm') || 'آیا از انجام این عملیات اطمینان دارید؟';
      if (!confirm(msg)) {
        e.preventDefault();
      }
    });
  });
});
