/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * جاوااسکریپت عمومی و تعاملی (Main UI Scripts)
 */

document.addEventListener('DOMContentLoaded', function() {
  // ۱. مدیریت منوی موبایل
  const menuToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', function() {
      if (navLinks.style.display === 'flex') {
        navLinks.style.display = 'none';
      } else {
        navLinks.style.display = 'flex';
        navLinks.style.flexDirection = 'column';
        navLinks.style.position = 'absolute';
        navLinks.style.top = '75px';
        navLinks.style.right = '0';
        navLinks.style.width = '100%';
        navLinks.style.background = '#ffffff';
        navLinks.style.padding = '20px';
        navLinks.style.boxShadow = '0 10px 25px rgba(0,0,0,0.1)';
      }
    });
  }

  // ۲. مدیریت بخش آکاردئون پرسش‌های متداول (FAQ Accordion)
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(function(item) {
    const questionBtn = item.querySelector('.faq-question');
    const answerDiv = item.querySelector('.faq-answer');
    if (questionBtn && answerDiv) {
      questionBtn.addEventListener('click', function() {
        const isActive = item.classList.contains('active');
        
        // بستن تمام موارد دیگر
        faqItems.forEach(function(other) {
          other.classList.remove('active');
          const otherAns = other.querySelector('.faq-answer');
          if (otherAns) otherAns.style.maxHeight = null;
        });

        if (!isActive) {
          item.classList.add('active');
          answerDiv.style.maxHeight = answerDiv.scrollHeight + 'px';
        }
      });
    }
  });

  // ۳. کپی کردن شماره کارت به حافظه (Copy to Clipboard)
  const copyCardBtns = document.querySelectorAll('.btn-copy-card');
  copyCardBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
      const cardNum = this.getAttribute('data-card') || '5859831854405833';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(cardNum).then(function() {
          btn.innerText = 'کپی شد ✓';
          setTimeout(function() {
            btn.innerText = 'کپی شماره کارت';
          }, 2500);
        });
      } else {
        // روش جایگزین
        const tempInput = document.createElement('input');
        tempInput.value = cardNum;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        btn.innerText = 'کپی شد ✓';
        setTimeout(function() {
          btn.innerText = 'کپی شماره کارت';
        }, 2500);
      }
    });
  });

  // ۴. بسته شدن خودکار هشدارهای موقت
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(function(alert) {
    setTimeout(function() {
      alert.style.transition = 'opacity 0.5s ease';
      alert.style.opacity = '0';
      setTimeout(function() {
        if (alert.parentNode) alert.parentNode.removeChild(alert);
      }, 500);
    }, 6000);
  });
});
