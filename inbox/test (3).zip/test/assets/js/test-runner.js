/**
 * سامانه جامع آزمون‌های روان‌شناختی Mirbolouki
 * موتور پیشرفته اجرای آزمون‌های بالینی و طولانی (Clinical Test Runner Engine)
 * - پیشروی خودکار هوشمند (Auto-advance)
 * - ذخیره‌سازی ابری و محلی (LocalStorage Draft Resilience)
 * - جعبه ابزار پرش سریع بین سوالات (Question Matrix Navigator)
 * - نوار پیشرفت بلادرنگ و میانبرهای کیبورد
 */

(function() {
  'use strict';

  document.addEventListener('DOMContentLoaded', function() {
    const testForm = document.getElementById('psychTestForm');
    if (!testForm) return;

    const questionCards = document.querySelectorAll('.question-card');
    const totalQuestions = questionCards.length;
    if (totalQuestions === 0) return;

    let currentStep = 0;
    const sessionTokenInput = testForm.querySelector('input[name="session_token"]');
    const sessionToken = sessionTokenInput ? sessionTokenInput.value : 'default_session';
    const storageKey = 'mb_draft_' + sessionToken;

    // عناصر رابط کاربری
    const progressBar = document.getElementById('progressBarFill');
    const currentQSpan = document.getElementById('currentQuestionNum');
    const totalQSpan = document.getElementById('totalQuestionsCount');
    const percentSpan = document.getElementById('progressPercent');

    const btnPrev = document.getElementById('btnPrevQuestion');
    const btnNext = document.getElementById('btnNextQuestion');
    const btnSubmit = document.getElementById('btnSubmitTest');
    const validationAlert = document.getElementById('validationAlert');
    const validationAlertText = document.getElementById('validationAlertText');
    const btnToggleMatrix = document.getElementById('btnToggleMatrix');
    const matrixContainer = document.getElementById('questionMatrixModal');
    const matrixGrid = document.getElementById('matrixGrid');
    const btnCloseMatrix = document.getElementById('btnCloseMatrix');

    // تنظیم ارقام کل سوالات
    if (totalQSpan) {
      totalQSpan.innerText = toPersianNumber(totalQuestions);
    }

    function toPersianNumber(num) {
      const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
      const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
      return String(num).replace(/[0-9]/g, function(w) {
        return fa[+w];
      });
    }

    // بازخوانی پیش‌نویس از LocalStorage در صورت رفرش یا قطع ارتباط
    function restoreDraft() {
      try {
        const saved = localStorage.getItem(storageKey);
        if (saved) {
          const answers = JSON.parse(saved);
          let lastAnsweredIdx = 0;
          
          questionCards.forEach(function(card, idx) {
            const qId = card.getAttribute('data-question-id');
            if (qId && answers[qId]) {
              const targetRadio = card.querySelector('input[type="radio"][value="' + answers[qId] + '"]');
              if (targetRadio) {
                targetRadio.checked = true;
                const parentLabel = targetRadio.closest('.option-item-label');
                if (parentLabel) parentLabel.classList.add('selected');
                lastAnsweredIdx = idx;
              }
            }
          });

          // رفتن به اولین سوال بی‌پاسخ
          let firstUnanswered = -1;
          for (let i = 0; i < totalQuestions; i++) {
            const checked = questionCards[i].querySelector('input[type="radio"]:checked');
            if (!checked) {
              firstUnanswered = i;
              break;
            }
          }

          if (firstUnanswered !== -1) {
            currentStep = firstUnanswered;
          } else if (lastAnsweredIdx < totalQuestions - 1) {
            currentStep = lastAnsweredIdx + 1;
          } else {
            currentStep = totalQuestions - 1;
          }
        }
      } catch (e) {
        console.warn('Draft restoration error:', e);
      }
    }

    // ذخیره وضعیت جاری در LocalStorage
    function saveDraft() {
      try {
        const draft = {};
        questionCards.forEach(function(card) {
          const qId = card.getAttribute('data-question-id');
          const checked = card.querySelector('input[type="radio"]:checked');
          if (qId && checked) {
            draft[qId] = checked.value;
          }
        });
        localStorage.setItem(storageKey, JSON.stringify(draft));
      } catch (e) {
        console.warn('Draft save error:', e);
      }
    }

    // ایجاد ماتریس پرش سریع سوالات
    function buildMatrix() {
      if (!matrixGrid) return;
      matrixGrid.innerHTML = '';

      for (let i = 0; i < totalQuestions; i++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'matrix-item-btn';
        btn.innerText = toPersianNumber(i + 1);
        btn.setAttribute('data-index', i);

        const isAnswered = questionCards[i].querySelector('input[type="radio"]:checked') !== null;
        if (isAnswered) btn.classList.add('answered');
        if (i === currentStep) btn.classList.add('current');

        btn.addEventListener('click', function() {
          const targetIdx = parseInt(this.getAttribute('data-index'), 10);
          currentStep = targetIdx;
          updateUI();
          if (matrixContainer) matrixContainer.classList.remove('open');
          window.scrollTo({ top: testForm.offsetTop - 30, behavior: 'smooth' });
        });

        matrixGrid.appendChild(btn);
      }
    }

    // بروزرسانی رابط کاربری
    function updateUI() {
      questionCards.forEach(function(card, index) {
        if (index === currentStep) {
          card.classList.add('active');
        } else {
          card.classList.remove('active');
        }
      });

      const answeredCount = countAnsweredQuestions();
      const progressPercent = Math.round((answeredCount / totalQuestions) * 100);

      if (progressBar) progressBar.style.width = progressPercent + '%';
      if (percentSpan) percentSpan.innerText = toPersianNumber(progressPercent) + '٪ (' + toPersianNumber(answeredCount) + ' از ' + toPersianNumber(totalQuestions) + ')';
      if (currentQSpan) currentQSpan.innerText = toPersianNumber(currentStep + 1);

      // دکمه قبلی
      if (btnPrev) {
        if (currentStep > 0) {
          btnPrev.classList.add('visible');
        } else {
          btnPrev.classList.remove('visible');
        }
      }

      // دکمه بعدی / ثبت نهایی
      if (currentStep === totalQuestions - 1) {
        if (btnNext) btnNext.style.display = 'none';
        if (btnSubmit) btnSubmit.style.display = 'inline-flex';
      } else {
        if (btnNext) btnNext.style.display = 'inline-flex';
        if (btnSubmit) btnSubmit.style.display = 'none';
      }

      hideValidationError();
      buildMatrix();
      saveDraft();
    }

    function countAnsweredQuestions() {
      let count = 0;
      questionCards.forEach(function(card) {
        if (card.querySelector('input[type="radio"]:checked')) count++;
      });
      return count;
    }

    function isCurrentQuestionAnswered() {
      const currentCard = questionCards[currentStep];
      if (!currentCard) return false;
      return currentCard.querySelector('input[type="radio"]:checked') !== null;
    }

    function showValidationError(message) {
      if (validationAlert) {
        if (validationAlertText) {
          validationAlertText.innerText = message || 'لطفاً یکی از گزینه‌ها را انتخاب کنید.';
        }
        validationAlert.classList.add('show');
        validationAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }

    function hideValidationError() {
      if (validationAlert) {
        validationAlert.classList.remove('show');
      }
    }

    // پیشروی خودکار با تاخیر لطیف (Auto-Advance UX)
    questionCards.forEach(function(card, cardIdx) {
      const radioInputs = card.querySelectorAll('input[type="radio"]');
      const labels = card.querySelectorAll('.option-item-label');

      radioInputs.forEach(function(radio) {
        radio.addEventListener('change', function() {
          labels.forEach(function(lbl) {
            lbl.classList.remove('selected');
          });
          if (this.checked) {
            const parentLabel = this.closest('.option-item-label');
            if (parentLabel) parentLabel.classList.add('selected');
            hideValidationError();
            saveDraft();

            // در صورتی که سوال جاری بود و آخرین سوال نیست، پیشروی روان
            if (cardIdx === currentStep && currentStep < totalQuestions - 1) {
              setTimeout(function() {
                if (currentStep < totalQuestions - 1) {
                  currentStep++;
                  updateUI();
                }
              }, 160);
            } else if (cardIdx === currentStep && currentStep === totalQuestions - 1) {
              updateUI();
            }
          }
        });
      });
    });

    // دکمه مرحله بعد
    if (btnNext) {
      btnNext.addEventListener('click', function(e) {
        e.preventDefault();
        if (!isCurrentQuestionAnswered()) {
          showValidationError('پاسخ به این سؤال الزامی است؛ لطفاً یکی از گزینه‌ها را انتخاب کنید.');
          return;
        }

        if (currentStep < totalQuestions - 1) {
          currentStep++;
          updateUI();
          window.scrollTo({ top: testForm.offsetTop - 30, behavior: 'smooth' });
        }
      });
    }

    // دکمه مرحله قبل
    if (btnPrev) {
      btnPrev.addEventListener('click', function(e) {
        e.preventDefault();
        if (currentStep > 0) {
          currentStep--;
          updateUI();
          window.scrollTo({ top: testForm.offsetTop - 30, behavior: 'smooth' });
        }
      });
    }

    // کنترل ماتریس سوالات
    if (btnToggleMatrix && matrixContainer) {
      btnToggleMatrix.addEventListener('click', function(e) {
        e.preventDefault();
        buildMatrix();
        matrixContainer.classList.toggle('open');
      });
    }

    if (btnCloseMatrix && matrixContainer) {
      btnCloseMatrix.addEventListener('click', function() {
        matrixContainer.classList.remove('open');
      });
    }

    // میانبرهای کیبورد (کلیدهای عددی و فلش‌ها)
    document.addEventListener('keydown', function(e) {
      if (matrixContainer && matrixContainer.classList.contains('open')) return;

      const currentCard = questionCards[currentStep];
      if (!currentCard) return;

      // کلیدهای عددی 1 تا 7
      if (e.key >= '1' && e.key <= '7') {
        const optionIdx = parseInt(e.key, 10) - 1;
        const radios = currentCard.querySelectorAll('input[type="radio"]');
        if (radios[optionIdx]) {
          radios[optionIdx].checked = true;
          radios[optionIdx].dispatchEvent(new Event('change'));
        }
      } else if (e.key === 'ArrowLeft') {
        // بعدی
        if (btnNext && btnNext.style.display !== 'none') btnNext.click();
      } else if (e.key === 'ArrowRight') {
        // قبلی
        if (btnPrev && btnPrev.classList.contains('visible')) btnPrev.click();
      }
    });

    // ارسال نهایی آزمون
    if (testForm) {
      testForm.addEventListener('submit', function(e) {
        e.preventDefault();

        if (!isCurrentQuestionAnswered()) {
          showValidationError('لطفاً به سؤال جاری پاسخ دهید.');
          return;
        }

        let firstUnansweredIndex = -1;
        for (let i = 0; i < totalQuestions; i++) {
          const checked = questionCards[i].querySelector('input[type="radio"]:checked');
          if (!checked) {
            firstUnansweredIndex = i;
            break;
          }
        }

        if (firstUnansweredIndex !== -1) {
          currentStep = firstUnansweredIndex;
          updateUI();
          showValidationError('سؤال شماره ' + toPersianNumber(firstUnansweredIndex + 1) + ' بدون پاسخ است. لطفاً آن را تکمیل فرمایید.');
          return;
        }

        if (btnSubmit) {
          btnSubmit.disabled = true;
          btnSubmit.innerText = 'در حال محاسبه نمرات و ثبت تشخیصی...';
        }

        const formData = new FormData(testForm);
        
        fetch('/ajax/submit-test.php', {
          method: 'POST',
          body: formData
        })
        .then(function(res) {
          return res.json();
        })
        .then(function(data) {
          if (data && data.success) {
            try {
              localStorage.removeItem(storageKey);
            } catch (e) {}
            window.location.href = data.redirect_url;
          } else {
            alert(data.message || 'خطا در ثبت اطلاعات. لطفاً مجدداً تلاش فرمایید.');
            if (btnSubmit) {
              btnSubmit.disabled = false;
              btnSubmit.innerText = 'تکمیل آزمون و دریافت نتیجه';
            }
          }
        })
        .catch(function(err) {
          console.error('Submission Error:', err);
          testForm.submit();
        });
      });
    }

    // بازیابی پیش‌نویس و بارگذاری اولیه
    restoreDraft();
    updateUI();
  });
})();
